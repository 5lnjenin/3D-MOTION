import Foundation

/// Runs on a worker task. File providers may download or coordinate a movie
/// while it is read; none of those waits may block the editor's main actor.
enum VideoImportFile {
    static func copy(_ source: URL, to destination: URL) throws {
        try Task.checkCancellation()
        guard source.isFileURL, destination.isFileURL else { throw CocoaError(.fileReadUnsupportedScheme) }
        var produced = false, finished = false
        defer { if produced && !finished { try? FileManager.default.removeItem(at: destination) } }
        #if canImport(Darwin)
        let access = source.startAccessingSecurityScopedResource()
        defer { if access { source.stopAccessingSecurityScopedResource() } }
        var coordinationError: NSError?
        var copyingError: Error?
        NSFileCoordinator().coordinate(readingItemAt: source, options: .withoutChanges, error: &coordinationError) { readable in
            do { try copyBytes(readable, to: destination); produced = true }
            catch { copyingError = error }
        }
        if let error = coordinationError { throw error }
        if let error = copyingError { throw error }
        #else
        try copyBytes(source, to: destination)
        produced = true
        #endif
        try Task.checkCancellation()
        finished = true
    }

    private static func copyBytes(_ source: URL, to destination: URL) throws {
        try Task.checkCancellation()
        let manager = FileManager.default
        let values = try source.resourceValues(forKeys: [.isDirectoryKey, .isRegularFileKey])
        guard values.isDirectory != true, values.isRegularFile != false else { throw CocoaError(.fileReadUnsupportedScheme) }
        try manager.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
        // Never delete or overwrite a pre-existing file on an unsuccessful import.
        guard !manager.fileExists(atPath: destination.path) else { throw CocoaError(.fileWriteFileExists) }
        let input = try FileHandle(forReadingFrom: source)
        defer { try? input.close() }
        guard manager.createFile(atPath: destination.path, contents: nil) else { throw CocoaError(.fileWriteUnknown) }
        var finished = false
        defer { if !finished { try? manager.removeItem(at: destination) } }
        let output = try FileHandle(forWritingTo: destination)
        defer { try? output.close() }
        while true {
            try Task.checkCancellation()
            // Bounded memory and cancellation between chunks, even for long 4K movies.
            guard let data = try input.read(upToCount: 1_048_576), !data.isEmpty else { break }
            try output.write(contentsOf: data)
        }
        try Task.checkCancellation()
        try output.synchronize()
        finished = true
    }
}
