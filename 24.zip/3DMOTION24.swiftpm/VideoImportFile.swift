import Foundation

/// Runs on a worker task. File providers may download or coordinate a movie
/// while it is read; none of those waits may block the editor's main actor.
enum VideoImportFile {
    final class Operation: @unchecked Sendable {
        private let lock = NSLock()
        private var cancelled = false
        #if canImport(Darwin)
        private var coordinator: NSFileCoordinator?
        #endif

        func cancel() {
            lock.lock(); cancelled = true
            #if canImport(Darwin)
            let pending = coordinator
            #endif
            lock.unlock()
            #if canImport(Darwin)
            pending?.cancel()
            #endif
        }
        func copy(_ source: URL, to destination: URL) throws {
            try VideoImportFile.copy(source, to: destination, operation: self)
        }
        fileprivate func checkCancellation() throws {
            lock.lock(); let stopped = cancelled; lock.unlock()
            // File-coordination callbacks need not carry the caller's Swift task.
            if stopped { throw CancellationError() }
            try Task.checkCancellation()
        }
        #if canImport(Darwin)
        fileprivate func install(_ next: NSFileCoordinator?) {
            lock.lock(); coordinator = next; let stopped = cancelled; lock.unlock()
            if stopped { next?.cancel() }
        }
        #endif
    }

    static func copy(_ source: URL, to destination: URL) throws {
        try Operation().copy(source, to: destination)
    }

    private static func copy(_ source: URL, to destination: URL, operation: Operation) throws {
        try operation.checkCancellation()
        guard source.isFileURL, destination.isFileURL else { throw CocoaError(.fileReadUnsupportedScheme) }
        var produced = false, finished = false
        defer { if produced && !finished { try? FileManager.default.removeItem(at: destination) } }
        #if canImport(Darwin)
        let access = source.startAccessingSecurityScopedResource()
        defer { if access { source.stopAccessingSecurityScopedResource() } }
        let home = URL(fileURLWithPath: NSHomeDirectory()).resolvingSymlinksInPath().standardizedFileURL.path
        let path = source.resolvingSymlinksInPath().standardizedFileURL.path
        if path.hasPrefix(home + "/") {
            // Already materialized files in our own sandbox have no external
            // presenter. Avoid waiting on the file-provider broker for them.
            try copyBytes(source, to: destination, operation: operation); produced = true
        } else {
            let coordinator = NSFileCoordinator(filePresenter: nil)
            operation.install(coordinator)
            defer { operation.install(nil) }
            var coordinationError: NSError?
            var copyingError: Error?
            coordinator.coordinate(readingItemAt: source, options: .withoutChanges, error: &coordinationError) { readable in
                do { try copyBytes(readable, to: destination, operation: operation); produced = true }
                catch { copyingError = error }
            }
            try operation.checkCancellation()
            if let error = coordinationError { throw error }
            if let error = copyingError { throw error }
        }
        #else
        try copyBytes(source, to: destination, operation: operation)
        produced = true
        #endif
        try operation.checkCancellation()
        finished = true
    }

    private static func copyBytes(_ source: URL, to destination: URL, operation: Operation) throws {
        try operation.checkCancellation()
        let manager = FileManager.default
        let values = try source.resourceValues(forKeys: [.isDirectoryKey, .isRegularFileKey])
        guard values.isDirectory != true, values.isRegularFile != false else { throw CocoaError(.fileReadUnsupportedScheme) }
        try manager.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
        // Never delete or overwrite a pre-existing file on an unsuccessful import.
        guard !manager.fileExists(atPath: destination.path) else { throw CocoaError(.fileWriteFileExists) }
        let input = try FileHandle(forReadingFrom: source)
        defer { try? input.close() }
        guard manager.createFile(atPath: destination.path, contents: nil) else { throw CocoaError(.fileWriteUnknown) }
        var finished = false
        defer { if !finished { try? manager.removeItem(at: destination) } }
        let output = try FileHandle(forWritingTo: destination)
        defer { try? output.close() }
        while true {
            try operation.checkCancellation()
            // Bounded memory and cancellation between chunks, even for long 4K movies.
            guard let data = try input.read(upToCount: 1_048_576), !data.isEmpty else { break }
            try output.write(contentsOf: data)
        }
        try operation.checkCancellation()
        try output.synchronize()
        finished = true
    }
}
