import Foundation
import SwiftUI
import UIKit
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

@MainActor
struct AnimationInspector: View {
    @EnvironmentObject var studio: StudioStore

    private var selectedKeyCount: Int {
        guard let name = studio.selectedNode?.name else { return 0 }
        return studio.keyframes.filter { $0.nodeName == name }.count
    }

    var body: some View {
        VStack(spacing: 12) {
            InspectorCard(title: "Manual Animation") {
                Toggle(
                    "Auto Keyframe",
                    isOn:
                        $studio.autoKeyframeEnabled
                )

                Text("اختَر أي قطعة: سيارة، دولاب، باب، كاميرا أو إضاءة. عدّل Position / Rotation / Scale، حرّك المؤشر الزمني، ثم اضغط Keyframe.")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Text(String(format: studio.appLanguage == .arabic ? "الوقت الحالي: %.2f ثانية" : "Current time: %.2f seconds", studio.currentTime))
                    .font(.caption.monospacedDigit())
            }

            InspectorCard(title: "Timeline") {
                HStack {
                    Text(studio.appLanguage == .arabic ? "المدة" : "Duration")
                    Text(studio.appLanguage == .arabic ? "تتبع أطول محتوى مضاف" : "Follows the longest content")
                        .font(.caption)
                    Spacer()
                    Text(String(format: "%.2fs", studio.duration))
                        .font(.caption.monospacedDigit())
                }

                Picker("FPS", selection: $studio.fps) {
                    ForEach([24.0, 30.0, 60.0, 90.0, 120.0, 144.0], id: \.self) { value in
                        Text("\(Int(value))").tag(value)
                    }
                }
                .pickerStyle(.segmented)

                Picker(studio.appLanguage == .arabic ? "انتقال النقطة" : "Interpolation", selection: $studio.keyframeInterpolation) {
                    Text("Linear").tag(StudioInterpolation.linear)
                    Text("Smooth").tag(StudioInterpolation.smooth)
                    Text("Ease In").tag(StudioInterpolation.easeIn)
                    Text("Ease Out").tag(StudioInterpolation.easeOut)
                    Text("Hold").tag(StudioInterpolation.hold)
                }
                .pickerStyle(.menu)
                .onChange(of: studio.keyframeInterpolation) { _, value in
                    if studio.selectedKeyframeID != nil { studio.setSelectedKeyframeInterpolation(value) }
                }

                HStack {
                    Text("Selected keyframes")
                    Spacer()
                    Text("\(selectedKeyCount)")
                        .font(.caption.monospacedDigit())
                }
            }

            InspectorCard(title: "Quick Motion") {
                LazyVGrid(
                    columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ],
                    spacing: 8
                ) {
                    ForEach(
                        MotionPreset.allCases,
                        id: \.self
                    ) { preset in
                        Button {
                            studio.applyMotionPreset(
                                preset
                            )
                        } label: {
                            Label(
                                preset.title,
                                systemImage:
                                    preset.icon
                            )
                            .font(.caption)
                        }
                        .buttonStyle(.bordered)
                    }
                }

                Button(role: .destructive) {
                    studio.stopQuickMotion()
                } label: {
                    Label(
                        "Stop Motion",
                        systemImage: "stop.fill"
                    )
                }
                .buttonStyle(.bordered)
            }

            InspectorCard(title: "How to animate parts") {
                Text("مثال: اختَر الدولاب من الشجرة → Rotation → ضع Keyframe عند 0s → انتقل إلى 2s → لف X عدة دورات → Keyframe. نفس المبدأ للسيارة والكاميرا وكل قطعة.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

@MainActor
struct AudioInspector: View {
    @EnvironmentObject var studio: StudioStore
    @State private var masterDraft: Double = 1

    var body: some View {
        VStack(spacing: 12) {
            InspectorCard(title: studio.appLanguage == .arabic ? "الصوت العام" : "Master audio") {
                Slider(value: $masterDraft, in: 0...1, onEditingChanged: { editing in
                    if !editing { studio.setMasterAudioVolume(masterDraft) }
                })
                Text(String(format: "%.0f%%", masterDraft * 100)).monospacedDigit()
            }
            if let id = studio.selectedAudioClipID, let clip = studio.audioClips.first(where: { $0.id == id }) {
                InspectorCard(title: clip.name) {
                    Text(String(format: studio.appLanguage == .arabic ? "البداية: %.2f ث · المدة: %.2f ث" : "Start: %.2f s · Duration: %.2f s", clip.startTime, clip.trimmedDuration))
                        .font(.caption).monospacedDigit()
                }
            }
            Text(studio.appLanguage == .arabic ? "حدد المقطع في التراك وافتح قائمة تحرير لقصه أو نسخه. انقر مرتين لتحريره، واسحبه لتغيير بدايته. الملفات الأصلية تظهر في ملفات الصوت ضمن لوحة المشهد." : "Select a timeline clip and open Edit to trim or copy it. Double-tap to edit; drag to move. Original files appear under Audio files in the scene panel.")
                .font(.caption).foregroundStyle(.secondary)
        }
        .onAppear { masterDraft = studio.masterAudioVolume }
        .onChange(of: studio.masterAudioVolume) { _, value in masterDraft = value }
    }
}

@MainActor
struct LightInspector: View {
    @EnvironmentObject var studio: StudioStore

    var body: some View {
        VStack(spacing: 12) {
            if let node = studio.selectedNode, let light = node.light {
                InspectorCard(title: "Light Type") {
                    Picker("Type", selection: lightTypeBinding(light)) {
                        Text("Point").tag(LightEditorType.omni)
                        Text("Spot").tag(LightEditorType.spot)
                        Text("Sun").tag(LightEditorType.directional)
                        Text("Ambient").tag(LightEditorType.ambient)
                    }
                    .pickerStyle(.segmented)

                    ColorPicker("Color", selection: lightColorBinding(light))
                }

                InspectorCard(title: "Power") {
                    lightSlider(
                        "Intensity",
                        value: Binding(
                            get: { Double(light.intensity) },
                            set: { light.intensity = CGFloat($0); studio.objectWillChange.send() }
                        ),
                        range: 0...5000
                    )

                    lightSlider(
                        "Temperature",
                        value: Binding(
                            get: { Double(light.temperature) },
                            set: { light.temperature = CGFloat($0); studio.objectWillChange.send() }
                        ),
                        range: 1000...12000
                    )

                    Toggle(
                        "Cast Shadows",
                        isOn: Binding(
                            get: { light.castsShadow },
                            set: { light.castsShadow = $0; studio.objectWillChange.send() }
                        )
                    )

                    if light.castsShadow {
                        lightSlider(
                            "Shadow Radius",
                            value: Binding(
                                get: { Double(light.shadowRadius) },
                                set: { light.shadowRadius = CGFloat($0); studio.objectWillChange.send() }
                            ),
                            range: 0...30
                        )
                    }
                }

                if light.type == .spot {
                    InspectorCard(title: "Spot Cone") {
                        lightSlider(
                            "Inner",
                            value: Binding(
                                get: { light.spotInnerAngle },
                                set: { light.spotInnerAngle = $0; studio.objectWillChange.send() }
                            ),
                            range: 0...90
                        )

                        lightSlider(
                            "Outer",
                            value: Binding(
                                get: { light.spotOuterAngle },
                                set: { light.spotOuterAngle = $0; studio.objectWillChange.send() }
                            ),
                            range: 1...120
                        )
                    }
                }

                if light.type == .omni || light.type == .spot {
                    InspectorCard(title: "Range") {
                        lightSlider(
                            "Start",
                            value: Binding(
                                get: { light.attenuationStartDistance },
                                set: { light.attenuationStartDistance = $0; studio.objectWillChange.send() }
                            ),
                            range: 0...50
                        )

                        lightSlider(
                            "End",
                            value: Binding(
                                get: { light.attenuationEndDistance },
                                set: { light.attenuationEndDistance = $0; studio.objectWillChange.send() }
                            ),
                            range: 1...200
                        )
                    }
                }

                InspectorCard(title: "Position / Animation") {
                    Text("حرّك الإضاءة من Transform على X/Y/Z، وغيّر Rotation لتوجيه Spot/Sun. تقدر تضيف Keyframes لموقع واتجاه الإضاءة.")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    HStack {
                        Button {
                            studio.aimSelectedLightAtWorkPoint()
                        } label: {
                            Label("Aim Center", systemImage: "scope")
                        }


                    }
                    .buttonStyle(.bordered)
                }
            } else {
                InspectorCard(title: "Lighting") {
                    Text("حدد Light من قائمة Lights، أو أضف Point / Spot / Sun / Ambient من زر إضافة.")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    HStack {
                    }
                    .buttonStyle(.bordered)
                }
            }
        }
    }

    private func lightTypeBinding(_ light: SCNLight) -> Binding<LightEditorType> {
        Binding(
            get: {
                switch light.type {
                case .spot: return .spot
                case .directional: return .directional
                case .ambient: return .ambient
                default: return .omni
                }
            },
            set: { type in
                switch type {
                case .omni: light.type = .omni
                case .spot: light.type = .spot
                case .directional: light.type = .directional
                case .ambient: light.type = .ambient
                }
                studio.objectWillChange.send()
            }
        )
    }

    private func lightColorBinding(_ light: SCNLight) -> Binding<Color> {
        Binding(
            get: {
                if let ui = light.color as? UIColor {
                    return Color(uiColor: ui)
                }
                return .white
            },
            set: {
                light.color = UIColor($0)
                studio.objectWillChange.send()
            }
        )
    }

    private func lightSlider(_ title: String, value: Binding<Double>, range: ClosedRange<Double>) -> some View {
        HStack {
            Text(title)
                .font(.caption)
                .frame(width: 72, alignment: .leading)
            Slider(value: value, in: range)
            Text(String(format: "%.0f", value.wrappedValue))
                .font(.caption2.monospacedDigit())
                .frame(width: 42)
        }
    }
}

@MainActor
struct FXInspector: View {
    @EnvironmentObject var studio: StudioStore

    var body: some View {
        VStack(spacing: 12) {
            InspectorCard(title: "Render Filter") {
                Picker(
                    "Preset",
                    selection:
                        $studio.renderFilterPreset
                ) {
                    ForEach(
                        RenderFilterPreset.allCases,
                        id: \.self
                    ) { preset in
                        Text(preset.title)
                            .tag(preset)
                    }
                }

                HStack {
                    Text(studio.appLanguage == .arabic ? "الشدة" : "Intensity")
                    Slider(
                        value:
                            $studio.renderFilterIntensity,
                        in: 0...1
                    )
                    Text(
                        String(
                            format: "%.2f",
                            studio.renderFilterIntensity
                        )
                    )
                    .font(
                        .caption.monospacedDigit()
                    )
                    .frame(width: 40)
                }

                Text(
                    "الفلاتر تطبق على الصورة والفيديو المصدّر."
                )
                .font(.caption2)
                .foregroundStyle(.secondary)
            }

            InspectorCard(title: studio.appLanguage == .arabic ? "الغلاف الجوي" : "Atmosphere") {
                HStack {
                    Toggle(studio.appLanguage == .arabic ? "ضباب" : "Fog", isOn: $studio.fogEnabled)
                        .onChange(of: studio.fogEnabled) { _, _ in studio.applySceneSettings() }
                    Spacer()

                }
                if studio.fogEnabled {
                    HStack {
                        Text(studio.appLanguage == .arabic ? "الكثافة" : "Density")
                        Slider(value: $studio.fogDensity, in: 0...1)
                            .onChange(of: studio.fogDensity) { _, _ in studio.applySceneSettings() }
                    }

                    ColorPicker("Fog Color", selection: $studio.fogColor)
                        .onChange(of: studio.fogColor) { _, _ in studio.applySceneSettings() }
                }
            }

            if let particle = studio.selectedNode?.particleSystems?.first {
                InspectorCard(title: "المؤثر / Effect") {
                    Button("مطر للأسفل / Reset as rain") { studio.resetSelectedRainDirection() }
                    Text("الكثافة × العمر يحددان عدد الجزيئات؛ قللهما لمعاينة أسرع.")
                        .font(.caption2).foregroundStyle(.secondary)
                    particleSlider(
                        "Birth",
                        value: Binding(
                            get: { particle.birthRate },
                            set: { particle.birthRate = $0; studio.objectWillChange.send() }
                        ),
                        range: 0...600
                    )

                    particleSlider(
                        "Life",
                        value: Binding(
                            get: { particle.particleLifeSpan },
                            set: { particle.particleLifeSpan = $0; studio.objectWillChange.send() }
                        ),
                        range: 0.1...6
                    )

                    particleSlider(
                        "Size",
                        value: Binding(
                            get: { particle.particleSize },
                            set: { particle.particleSize = $0; studio.objectWillChange.send() }
                        ),
                        range: 0.005...1.5
                    )

                    particleSlider(
                        "Velocity",
                        value: Binding(
                            get: { particle.particleVelocity },
                            set: { particle.particleVelocity = $0; studio.objectWillChange.send() }
                        ),
                        range: 0...20
                    )

                    particleSlider(
                        "Spread",
                        value: Binding(
                            get: { particle.spreadingAngle },
                            set: { particle.spreadingAngle = $0; studio.objectWillChange.send() }
                        ),
                        range: 0...180
                    )

                    ColorPicker(
                        "Particle Color",
                        selection: Binding(
                            get: { Color(uiColor: particle.particleColor) },
                            set: { particle.particleColor = UIColor($0); studio.objectWillChange.send() }
                        )
                    )
                }
            } else {
                InspectorCard(title: "Particles") {
                    Text("أضف Smoke / Sparks / Rain من زر إضافة، وبعدها حدد العنصر وعدّل خصائصه من هنا.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            InspectorCard(title: "Glow / Light Trails") {
                Text("لعمل إضاءة مثل الفيديو: أضف Neon Trail، عدّل مكانه وحجمه، ثم من Material ارفع Emission، ومن Camera ارفع Bloom. كل خطوة تحت تحكمك.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private func particleSlider(_ title: String, value: Binding<CGFloat>, range: ClosedRange<CGFloat>) -> some View {
        HStack {
            Text(title)
                .font(.caption)
                .frame(width: 62, alignment: .leading)
            Slider(value: value, in: range)
            Text(String(format: "%.2f", Double(value.wrappedValue)))
                .font(.caption2.monospacedDigit())
                .frame(width: 42)
        }
    }
}

@MainActor
struct CameraInspector: View {
    @EnvironmentObject var studio: StudioStore
    @State private var showAdvanced = false

    var body: some View {
        VStack(spacing: 10) {
            if studio.selectedNode?.camera == nil {
                InspectorCard(title: studio.tr("camera")) {
                    Text("حدد كاميرا من المشهد أو أضف كاميرا من زر إضافة. الكاميرا تتعامل معها كأي عنصر: حرّكها ودوّرها من الـ Gizmo.")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                }
            } else {
                InspectorCard(title: studio.selectedNode?.name ?? "Camera") {
                    cameraSlider("FOV", value: $studio.cameraFOV, range: 15...110)
                    LensSettingsCard()

                    Text("حرّك أو دوّر الكاميرا بالـ Gizmo مثل أي عنصر. غيّر الوقت واضغط Keyframe لصنع حركة كاميرا.")
                        .font(.caption2)
                        .foregroundStyle(.secondary)

                    Divider()
                    Text(studio.appLanguage == .arabic ? "حركات كاميرا جاهزة • 15 ثانية" : "Camera Presets • 15 seconds")
                        .font(.caption.bold())
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 105))], spacing: 7) {
                        ForEach(StudioStore.CameraMotionPreset.allCases) { preset in
                            Button(preset.title) { studio.applyCameraMotionPreset(preset, seconds: 15) }
                                .buttonStyle(.bordered)
                                .font(.caption2)
                        }
                    }
                }

                DisclosureGroup("إعدادات متقدمة / Advanced", isExpanded: $showAdvanced) {
                    VStack(spacing: 9) {
                        cameraSlider("Exposure", value: $studio.cameraExposure, range: -3...3)
                        Toggle("Depth of Field", isOn: $studio.cameraDOF)
                            .onChange(of: studio.cameraDOF) { _, _ in studio.applyCameraEngine() }
                        if studio.cameraDOF {
                            cameraSlider("Focus", value: $studio.cameraFocusDistance, range: 0.1...50)
                            cameraSlider("F-Stop", value: $studio.cameraFStop, range: 1.2...22)
                        }
                        Toggle("HDR", isOn: $studio.cameraHDR)
                            .onChange(of: studio.cameraHDR) { _, _ in studio.applyCameraEngine() }
                        cameraSlider("Bloom", value: $studio.cameraBloom, range: 0...4)
                        cameraSlider("Vignette", value: $studio.cameraVignette, range: 0...2)
                    }
                    .padding(.top, 8)
                }
                .padding(10)
                .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 10))
            }
        }
        .onAppear { studio.syncCameraControls() }
        .onChange(of: studio.selectedNode) { _, node in
            if node?.camera != nil { studio.syncCameraControls() }
        }
    }

    private func cameraSlider(_ title: String, value: Binding<Double>, range: ClosedRange<Double>) -> some View {
        HStack {
            Text(title)
                .font(.caption)
                .frame(width: 66, alignment: .leading)
            Slider(value: value, in: range)
                .onChange(of: value.wrappedValue) { _, _ in studio.applyCameraEngine() }
            Text(String(format: "%.1f", value.wrappedValue))
                .font(.caption2.monospacedDigit())
                .frame(width: 38)
        }
    }
}

struct SceneInspector: View {
    @EnvironmentObject var studio: StudioStore

    var body: some View {
        VStack(spacing: 12) {
            InspectorCard(title: "Environment") {
                Picker("Background", selection: Binding(
                    get: { studio.environmentPreset },
                    set: { studio.setEnvironmentPreset($0) }
                )) {
                    ForEach(SceneEnvironmentPreset.allCases, id: \.self) { preset in
                        Text(preset.title).tag(preset)
                    }
                }

                HStack {
                    Text(studio.appLanguage == .arabic ? "الشدة" : "Intensity")
                    Slider(
                        value: $studio.environmentIntensity,
                        in: 0...3
                    )
                    .onChange(of: studio.environmentIntensity) { _, _ in
                        studio.applySceneEnvironment()
                    }
                    Text(String(format: "%.2f", studio.environmentIntensity))
                        .font(.caption.monospacedDigit())
                        .frame(width: 40)
                }

                Text("للصورة المخصصة افتح زر Environment داخل مساحة العمل واختر Custom Image.")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }

            InspectorCard(title: "Scene") {
                Toggle("Grid", isOn: $studio.showGrid)
                    .onChange(of: studio.showGrid) { _, _ in studio.rebuildHelpers() }
                Toggle("Axes", isOn: $studio.showAxes)
                    .onChange(of: studio.showAxes) { _, _ in studio.rebuildHelpers() }

                if studio.showGrid {
                    HStack {
                        Text("Grid Cell")
                        Slider(value: $studio.gridSpacing, in: 0.05...10.0)
                            .onChange(of: studio.gridSpacing) { _, _ in studio.rebuildHelpers() }
                        Text(String(format: "%.2f", studio.gridSpacing))
                            .font(.caption.monospacedDigit())
                            .frame(width: 42)
                    }

                    HStack {
                        Text("Grid Count")
                        Slider(value: $studio.gridHalfCount, in: 2...100, step: 1)
                            .onChange(of: studio.gridHalfCount) { _, _ in studio.rebuildHelpers() }
                        Text("\(Int(studio.gridHalfCount))")
                            .font(.caption.monospacedDigit())
                            .frame(width: 36)
                    }
                }

                HStack {
                    Toggle("Fog", isOn: $studio.fogEnabled)
                        .onChange(of: studio.fogEnabled) { _, _ in studio.applySceneSettings() }
                    Spacer()
                    Button(studio.appLanguage == .arabic ? "إعادة تعيين" : "Reset") {
                        studio.resetFog()
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                }

                if studio.fogEnabled {
                    HStack {
                        Text(studio.appLanguage == .arabic ? "الكثافة" : "Density")
                        Slider(value: $studio.fogDensity, in: 0...1)
                            .onChange(of: studio.fogDensity) { _, _ in studio.applySceneSettings() }
                    }
                    ColorPicker("Fog Color", selection: $studio.fogColor)
                        .onChange(of: studio.fogColor) { _, _ in studio.applySceneSettings() }
                }

                HStack {
                    Text("Ambient")
                    Slider(value: $studio.ambientStrength, in: 0...1500)
                        .onChange(of: studio.ambientStrength) { _, _ in studio.applySceneSettings() }
                }
            }
        }
    }
}

// MARK: - Timeline

@MainActor
struct TimelinePanel: View {
    @EnvironmentObject var studio: StudioStore
    @State private var editingAudio: StudioAudioClip?

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Button {
                    studio.seek(to: 0)
                } label: {
                    Image(systemName: "backward.end.fill")
                }

                Button {
                    studio.togglePlayback()
                } label: {
                    Image(systemName: studio.isPlaying ? "pause.fill" : "play.fill")
                        .frame(width: 22)
                }

                Button {
                    studio.addKeyframe()
                } label: {
                    Image(systemName: "diamond.fill")
                }
                .disabled(studio.selectedNode == nil)
                .accessibilityLabel(studio.appLanguage == .arabic ? "إضافة نقطة حركة" : "Add keyframe")

                TimelineEditMenu(editAudio: { editingAudio = $0 })

                Text(String(format: "%.2fs", studio.currentTime))
                    .font(.system(.caption, design: .monospaced))
                    .frame(width: 62, alignment: .leading)

                Slider(value: Binding(
                    get: { studio.currentTime },
                    set: { studio.seek(to: $0) }
                ), in: 0...max(0.1, studio.duration))

                Text("\(Int(studio.fps)) FPS")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            .buttonStyle(.bordered)
            .padding(8)

            Divider()

            TimelineCanvas(editAudio: { editingAudio = $0 })
                .environmentObject(studio)
        }
        .sheet(item: $editingAudio) { clip in
            AudioClipEditorSheet(clip: clip).environmentObject(studio)
        }
        .background(Color(red: 0.12, green: 0.12, blue: 0.14))
        // Time is spatial, not linguistic: 0s is always on the left and time
        // always increases to the right, even while the rest of the UI is Arabic RTL.
        .environment(\.layoutDirection, .leftToRight)
    }
}

@MainActor
struct TimelineCanvas: View {
    @EnvironmentObject var studio: StudioStore
    let editAudio: (StudioAudioClip) -> Void
    @State private var pixelsPerSecond: CGFloat = 42
    @State private var extensionDragBase: Double? = nil
    @State private var trackNameDraft: String = ""
    @State private var keyDragBase: [UUID: Double] = [:]
    @State private var editingKeyframe: StudioKeyframe? = nil

    private var selectedNode: SCNNode? { studio.selectedAudioClipID == nil ? studio.selectedNode : nil }
    private var tracks: [String] {
        guard let node = selectedNode else { return [] }
        return studio.motionTrackIDs(for: node)
    }

    private var audioTrackIDs: [UUID] {
        var seen = Set<UUID>()
        return studio.audioClips.map(\.trackID).filter { seen.insert($0).inserted }
    }
    private var timelineHeight: CGFloat { max(96, CGFloat(58 + tracks.count * 37 + audioTrackIDs.count * 40)) }

    var body: some View {
        VStack(spacing: 0) {
            ScrollView([.horizontal, .vertical], showsIndicators: true) {
                let width = max(CGFloat(max(studio.duration, studio.currentTime)) * pixelsPerSecond + 42, 300)
                ZStack(alignment: .topLeading) {
                    Color(red: 0.10, green: 0.10, blue: 0.12).opacity(0.65)

                    Canvas { context, size in
                        let seconds = max(1, Int(ceil(studio.duration)))
                        let major = pixelsPerSecond < 22 ? 5 : (pixelsPerSecond < 38 ? 2 : 1)
                        for second in stride(from: 0, through: seconds, by: major) {
                            let x = CGFloat(second) * pixelsPerSecond
                            var path = Path()
                            path.move(to: CGPoint(x: x, y: 18))
                            path.addLine(to: CGPoint(x: x, y: size.height))
                            context.stroke(path, with: .color(.white.opacity(0.08)), lineWidth: 1)
                            context.draw(Text("\(second)s").font(.system(size: 9)).foregroundColor(.secondary),
                                         at: CGPoint(x: x + 11, y: 9))
                        }
                    }

                    if let node = selectedNode {
                        VStack(alignment: .leading, spacing: 3) {
                            Color.clear.frame(height: 24)
                            HStack(spacing: 6) {
                                Image(systemName: node.camera != nil ? "camera.fill" : "cube.fill")
                                Text(node.name ?? (node.camera != nil ? "Camera" : "Object"))
                                    .lineLimit(1)
                                Button {
                                    _ = studio.addMotionTrack(for: node)
                                } label: {
                                    Image(systemName: "plus.circle.fill")
                                }
                                .buttonStyle(.plain)
                            }
                            .font(.caption.weight(.semibold))
                            .padding(.horizontal, 8)
                            .frame(height: 28)

                            ForEach(Array(tracks.enumerated()), id: \.element) { index, trackID in
                                let active = studio.activeMotionTrackByNode[studio.animationIdentity(node)] == trackID
                                let selectedTrack = studio.selectedMotionTrackID == trackID
                                ZStack(alignment: .leading) {
                                    RoundedRectangle(cornerRadius: 6)
                                        .fill(selectedTrack ? Color.cyan.opacity(0.78) : (active ? Color.blue.opacity(0.72) : Color.blue.opacity(0.38)))
                                        .frame(width: width - 18, height: 32)

                                    Text(studio.motionTrackNames[trackID] ?? "Animation \(index + 1)")
                                        .font(.caption.weight(.semibold))
                                        .padding(.leading, 10)

                                    ForEach(studio.keyframes.filter { key in
                                        let sameNode = key.nodeID == studio.animationIdentity(node) || (key.nodeID == nil && key.nodeName == node.name)
                                        let sameTrack = key.trackID == trackID || (key.trackID == nil && tracks.count == 1)
                                        return sameNode && sameTrack
                                    }) { key in
                                        let selected = studio.selectedKeyframeID == key.id
                                        Button {
                                            studio.selectMotionTrack(trackID, for: node)
                                            studio.selectKeyframe(key)
                                        } label: {
                                            Image(systemName: "diamond.fill")
                                                .font(.system(size: selected ? 15 : 12))
                                                .foregroundStyle(selected ? .yellow : .white.opacity(0.8))
                                        }
                                        .buttonStyle(.plain)
                                        .highPriorityGesture(TapGesture(count: 2).onEnded {
                                            studio.selectMotionTrack(trackID, for: node)
                                            studio.selectKeyframe(key)
                                            editingKeyframe = key
                                        })
                                        .frame(width: 34, height: 34)
                                        .contentShape(Rectangle())
                                        .offset(x: CGFloat(key.time) * pixelsPerSecond - 17)
                                        .simultaneousGesture(
                                            DragGesture(minimumDistance: 3)
                                                .onChanged { value in
                                                    if keyDragBase[key.id] == nil { keyDragBase[key.id] = key.time }
                                                    studio.selectedKeyframeID = key.id
                                                    let base = keyDragBase[key.id] ?? key.time
                                                    studio.moveSelectedKeyframe(to: base + Double(value.translation.width / pixelsPerSecond))
                                                }
                                                .onEnded { _ in keyDragBase[key.id] = nil }
                                        )
                                    }
                                }
                                .frame(height: 34)
                                .contentShape(Rectangle())
                                .onTapGesture { value in
                                    studio.selectMotionTrack(trackID, for: node)
                                    trackNameDraft = studio.motionTrackNames[trackID] ?? "Animation \(index + 1)"
                                    studio.seek(to: Double(value.x / pixelsPerSecond))
                                }
                            }
                        }
                    }

                    VStack(spacing: 2) {
                        ForEach(audioTrackIDs, id: \.self) { id in
                            AudioTimelineRow(clips: studio.audioClips.filter { $0.trackID == id }, width: width,
                                             pixelsPerSecond: pixelsPerSecond, edit: editAudio)
                        }
                    }.offset(y: selectedNode == nil ? 26 : CGFloat(58 + tracks.count * 37))

                    let playX = min(max(0, CGFloat(studio.currentTime) * pixelsPerSecond), width - 2)
                    Rectangle().fill(Color.red)
                        .frame(width: 1.5, height: timelineHeight - 4)
                        .offset(x: playX, y: 2)
                        .allowsHitTesting(false)
                    Circle().fill(Color.red).frame(width: 10, height: 10)
                        .offset(x: playX - 4.5, y: 0)
                        .allowsHitTesting(false)

                    // An explicit extension is optional; automatic duration follows content.
                    VStack(spacing: 2) {
                        Image(systemName: "arrow.left.and.right.circle.fill")
                        Text("+").font(.caption.bold())
                    }
                    .foregroundStyle(.cyan)
                    .frame(width: 30, height: 48)
                    .offset(x: width - 34, y: 22)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                if extensionDragBase == nil { extensionDragBase = studio.duration }
                                let base = extensionDragBase ?? studio.duration
                                let extra = max(0, Double(value.translation.width / pixelsPerSecond))
                                studio.setProjectDuration(ceil((base + extra) * 10) / 10)
                            }
                            .onEnded { _ in extensionDragBase = nil }
                    )
                }
                .frame(width: width, height: timelineHeight)
            }

            if let node = selectedNode,
               let trackID = studio.selectedMotionTrackID,
               tracks.contains(trackID) {
                HStack(spacing: 8) {
                    Image(systemName: "rectangle.stack.fill")
                    TextField("Animation name", text: $trackNameDraft)
                        .textFieldStyle(.roundedBorder)
                        .onSubmit { studio.renameMotionTrack(trackID, to: trackNameDraft) }
                    Button {
                        studio.renameMotionTrack(trackID, to: trackNameDraft)
                    } label: { Image(systemName: "checkmark") }
                    .buttonStyle(.bordered)
                    Toggle(isOn: Binding(
                        get: { studio.isMotionTrackLooping(trackID) },
                        set: { studio.setMotionTrackLoop($0, trackID: trackID) }
                    )) {
                        Image(systemName: "repeat")
                    }
                    .toggleStyle(.button)
                    .buttonStyle(.bordered)
                    .tint(studio.isMotionTrackLooping(trackID) ? .cyan : nil)
                    .studioTooltip(studio.appLanguage == .arabic ? "تكرار الحركة Loop" : "Loop animation")
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
            }

            Divider()
            HStack(spacing: 10) {
                Image(systemName: "minus.magnifyingglass")
                Slider(value: Binding(
                    get: { Double(pixelsPerSecond) },
                    set: { pixelsPerSecond = CGFloat($0) }
                ), in: 12...120)
                Image(systemName: "plus.magnifyingglass")
                Text(String(format: "%.2fs", studio.duration))
                    .font(.caption.monospacedDigit())
                    .frame(minWidth: 42)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
        }
        .environment(\.layoutDirection, .leftToRight)
        .sheet(item: $editingKeyframe) { key in
            KeyframeEditorSheet(keyframe: key).environmentObject(studio)
        }
    }
}


@MainActor
struct KeyframeEditorSheet: View {
    @EnvironmentObject var studio: StudioStore
    @Environment(\.dismiss) private var dismiss
    let keyframe: StudioKeyframe
    @State private var time: Double
    @State private var px: Double; @State private var py: Double; @State private var pz: Double
    @State private var rx: Double; @State private var ry: Double; @State private var rz: Double
    @State private var sx: Double; @State private var sy: Double; @State private var sz: Double
    @State private var interpolation: StudioInterpolation

    init(keyframe: StudioKeyframe) {
        self.keyframe = keyframe; _time = State(initialValue: keyframe.time)
        _px=State(initialValue:Double(keyframe.position.x)); _py=State(initialValue:Double(keyframe.position.y)); _pz=State(initialValue:Double(keyframe.position.z))
        _rx = State(initialValue: Double(keyframe.euler.x) * 180.0 / Double.pi); _ry = State(initialValue: Double(keyframe.euler.y) * 180.0 / Double.pi); _rz = State(initialValue: Double(keyframe.euler.z) * 180.0 / Double.pi)
        _sx=State(initialValue:Double(keyframe.scale.x)); _sy=State(initialValue:Double(keyframe.scale.y)); _sz=State(initialValue:Double(keyframe.scale.z))
        _interpolation=State(initialValue:keyframe.interpolation)
    }
    var body: some View {
        NavigationStack { ScrollView { VStack(spacing:16) {
            GroupBox(studio.appLanguage == .arabic ? "توقيت الحركة / Trim" : "Movement Timing / Trim") { VStack(spacing:10) {
                HStack { Text(studio.appLanguage == .arabic ? "وقت النقطة" : "Keyframe time"); Spacer(); Text(String(format:"%.3fs",time)).monospacedDigit() }
                Slider(value:$time,in:0...max(0.1,studio.duration))
                HStack { Button(studio.appLanguage == .arabic ? "قص البداية للمؤشر" : "Trim start to playhead") { studio.trimSegmentStart(for:keyframe.id,to:studio.currentTime) }.buttonStyle(.bordered); Button(studio.appLanguage == .arabic ? "قص النهاية للمؤشر" : "Trim end to playhead") { time=studio.currentTime }.buttonStyle(.bordered) }
                Text(studio.appLanguage == .arabic ? "غيّر وقت النقطة لتقصير أو تمديد الحركة السابقة." : "Change the keyframe time to shorten or extend the preceding motion.").font(.caption).foregroundStyle(.secondary)
            }.padding(.top,6) }
            vectorEditor("Position",x:$px,y:$py,z:$pz,range:-50...50)
            vectorEditor("Rotation °",x:$rx,y:$ry,z:$rz,range:-1080...1080)
            vectorEditor("Scale",x:$sx,y:$sy,z:$sz,range:0.01...20)
            GroupBox(studio.appLanguage == .arabic ? "نعومة الحركة" : "Interpolation") { Picker("Interpolation",selection:$interpolation) { Text("Linear").tag(StudioInterpolation.linear); Text("Smooth").tag(StudioInterpolation.smooth); Text("Ease In").tag(StudioInterpolation.easeIn); Text("Ease Out").tag(StudioInterpolation.easeOut); Text("Hold").tag(StudioInterpolation.hold) }.pickerStyle(.segmented).padding(.top,6) }
        }.padding(18) } .navigationTitle(studio.appLanguage == .arabic ? "محرر Keyframe" : "Keyframe Editor")
        .toolbar { ToolbarItem(placement:.cancellationAction) { Button(studio.appLanguage == .arabic ? "إلغاء" : "Cancel") { dismiss() } }; ToolbarItem(placement:.confirmationAction) { Button(studio.appLanguage == .arabic ? "حفظ" : "Save") { studio.updateKeyframeFromEditor(id:keyframe.id,time:time,position:SCNVector3(Float(px),Float(py),Float(pz)),euler: SCNVector3(Float(rx * Double.pi / 180.0), Float(ry * Double.pi / 180.0), Float(rz * Double.pi / 180.0)),scale:SCNVector3(Float(sx),Float(sy),Float(sz)),interpolation:interpolation); dismiss() }.fontWeight(.semibold) } } }
        .frame(minWidth:620,minHeight:620)
    }
    @ViewBuilder private func vectorEditor(_ title:String,x:Binding<Double>,y:Binding<Double>,z:Binding<Double>,range:ClosedRange<Double>)->some View { GroupBox(title) { VStack(spacing:8) { axisRow("X",value:x,range:range); axisRow("Y",value:y,range:range); axisRow("Z",value:z,range:range) }.padding(.top,6) } }
    @ViewBuilder private func axisRow(_ name:String,value:Binding<Double>,range:ClosedRange<Double>)->some View { HStack { Text(name).font(.headline).frame(width:24); Slider(value:value,in:range); Text(String(format:"%.3f",value.wrappedValue)).font(.caption.monospacedDigit()).frame(width:76) } }
}

// MARK: - Add Sheet

@MainActor
struct ImportMonitorSheet: View {
    @EnvironmentObject var studio: StudioStore
    @Environment(\.dismiss) private var dismiss

    private var meshCount: Int {
        studio.importNodeItems.filter {
            $0.isMesh
        }.count
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack(spacing: 10) {
                    statCard(
                        value: "\(studio.importFileItems.count)",
                        label: "Files"
                    )

                    statCard(
                        value: "\(studio.importNodeItems.count)",
                        label: "Nodes"
                    )

                    statCard(
                        value: "\(meshCount)",
                        label: "Meshes"
                    )

                    statCard(
                        value: "\(studio.multiSelectedNodes.count)",
                        label: "Selected"
                    )
                }
                .padding(12)

                if studio.importIsRunning {
                    Button(studio.importCancellationRequested ? "جارٍ الإيقاف…" : "إيقاف الاستيراد / Stop import") {
                        studio.cancelImport()
                    }.disabled(studio.importCancellationRequested)
                    ProgressView()
                        .padding(.horizontal, 12)
                        .padding(.bottom, 8)
                }

                List {
                    Section("Files / الملفات") {
                        ForEach(
                            studio.importFileItems
                        ) { item in
                            HStack(spacing: 10) {
                                Image(
                                    systemName: fileIcon(
                                        item.fileType
                                    )
                                )
                                .foregroundStyle(
                                    statusColor(
                                        item.status
                                    )
                                )

                                VStack(
                                    alignment: .leading,
                                    spacing: 2
                                ) {
                                    Text(item.name)
                                        .font(.subheadline)
                                        .lineLimit(1)

                                    Text(ProductInterfaceText.message(item.detail, arabic: studio.appLanguage == .arabic))
                                        .font(.caption2)
                                        .foregroundStyle(.secondary)
                                        .lineLimit(2)
                                }

                                Spacer()

                                Text(item.status)
                                    .font(.caption2.bold())
                                    .foregroundStyle(
                                        statusColor(
                                            item.status
                                        )
                                    )
                            }
                        }
                    }

                    Section("Nodes / أجزاء المشروع") {
                        if studio.importNodeItems.isEmpty {
                            Text(
                                studio.importIsRunning
                                    ? "يتم قراءة الـNodes…"
                                    : "لا توجد Nodes قابلة للعرض"
                            )
                            .foregroundStyle(.secondary)
                        }

                        ForEach(
                            studio.importNodeItems
                        ) { item in
                            HStack(spacing: 8) {
                                Color.clear
                                    .frame(
                                        width: CGFloat(
                                            min(
                                                item.depth,
                                                7
                                            ) * 11
                                        )
                                    )

                                Image(
                                    systemName: item.isMesh
                                        ? "cube.fill"
                                        : "square.stack.3d.up"
                                )
                                .foregroundStyle(
                                    item.isMesh
                                        ? .orange
                                        : .secondary
                                )

                                VStack(
                                    alignment: .leading,
                                    spacing: 1
                                ) {
                                    Text(item.name)
                                        .font(.subheadline)
                                        .lineLimit(1)

                                    Text(item.sourceFile)
                                        .font(.caption2)
                                        .foregroundStyle(.secondary)
                                        .lineLimit(1)
                                }

                                Spacer()

                                if item.isMesh {
                                    Button {
                                        studio.toggleMultiSelection(
                                            item.node
                                        )
                                    } label: {
                                        Image(
                                            systemName:
                                                studio.isNodeMultiSelected(
                                                    item.node
                                                )
                                                ? "checkmark.circle.fill"
                                                : "circle"
                                        )
                                        .font(.title3)
                                    }
                                    .buttonStyle(.plain)
                                } else {
                                    Text("NODE")
                                        .font(
                                            .system(
                                                size: 8,
                                                weight: .bold
                                            )
                                        )
                                        .foregroundStyle(.secondary)
                                }
                            }
                            .contentShape(Rectangle())
                            .onTapGesture {
                                if item.isMesh {
                                    studio.toggleMultiSelection(
                                        item.node
                                    )
                                } else {
                                    studio.select(
                                        item.node
                                    )
                                }
                            }
                        }
                    }
                }
                .listStyle(.insetGrouped)
            }
            .navigationTitle("Import Monitor")
            .toolbar {
                ToolbarItemGroup(
                    placement: .topBarLeading
                ) {
                    Button("Clear") {
                        studio.clearMultiSelection()
                    }

                    Button("All Meshes") {
                        studio.selectAllImportedMeshes()
                    }
                    .disabled(meshCount == 0)
                }

                ToolbarItem(
                    placement: .topBarTrailing
                ) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }

    private func statCard(
        value: String,
        label: String
    ) -> some View {
        VStack(spacing: 2) {
            Text(value)
                .font(.title3.bold())
                .monospacedDigit()

            Text(label)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
        .background(
            Color.white.opacity(0.045),
            in: RoundedRectangle(
                cornerRadius: 10
            )
        )
    }

    private func fileIcon(
        _ type: String
    ) -> String {
        switch type.lowercased() {
        case "png",
             "jpg",
             "jpeg",
             "webp",
             "bmp",
             "tif",
             "tiff":
            return "photo"

        case "bin":
            return "shippingbox"

        default:
            return "cube.transparent"
        }
    }

    private func statusColor(
        _ status: String
    ) -> Color {
        switch status {
        case "Loaded":
            return .green

        case "Error":
            return .red

        case "Loading":
            return .orange

        case "Resource":
            return .blue

        default:
            return .secondary
        }
    }
}

