import Foundation

struct ImportedAnimationCurve:Codable,Sendable {
    enum Interpolation:String,Codable,Sendable {case linear="LINEAR",step="STEP",cubic="CUBICSPLINE"}
    var target:String
    var path:String
    var times:[Double]
    var values:[Double]
    var components:Int
    var interpolation:Interpolation
    func validate() throws {
        guard !times.isEmpty,times.count<=1_000_000,components>0,components<=64,
              ["translation","rotation","scale","weights"].contains(path),
              (path=="weights" || components==(path=="rotation" ? 4 : 3)),
              times.allSatisfy({$0.isFinite && $0>=0}),values.allSatisfy(\.isFinite),
              zip(times,times.dropFirst()).allSatisfy({$0<$1}),
              values.count==times.count*components*(interpolation == .cubic ? 3 : 1) else {throw MeshWorkshopError.invalid}
    }
    // Tangents are derivatives per second. Hermite evaluates the authored curve
    // at the actual project/export time; no conversion to linear keyframes.
    func sample(_ time:Double) -> [Double] {
        guard time.isFinite,!times.isEmpty else {return []}
        let multiplier=interpolation == .cubic ? 3 : 1
        func value(_ key:Int,_ part:Int=1) -> [Double] {
            let start=(key*multiplier+(multiplier==3 ? part : 0))*components
            guard start>=0,start+components<=values.count else {return []}
            return Array(values[start..<(start+components)])
        }
        var result:[Double]
        if time<=times[0] {result=value(0)}
        else if time>=times[times.count-1] {result=value(times.count-1)}
        else {
            var low=0,high=times.count-1
            while high-low>1 {let mid=(low+high)/2;if times[mid]<=time {low=mid}else{high=mid}}
            let dt=times[high]-times[low],t=(time-times[low])/dt,a=value(low),b=value(high)
            guard a.count==components,b.count==components else {return []}
            switch interpolation {
            case .step:result=a
            case .cubic:
                let outgoing=value(low,2),incoming=value(high,0),t2=t*t,t3=t2*t
                guard outgoing.count==components,incoming.count==components else {return []}
                let h00=2*t3-3*t2+1,h10=(t3-2*t2+t)*dt,h01 = -2*t3+3*t2,h11=(t3-t2)*dt
                result=(0..<components).map {i in
                    let position=h00*a[i]+h01*b[i]
                    let tangent=h10*outgoing[i]+h11*incoming[i]
                    return position+tangent
                }
            case .linear:
                if path=="rotation" {
                    let qa=Self.normalized(a),qb=Self.normalized(b)
                    var dot=zip(qa,qb).reduce(0) {$0+$1.0*$1.1},end=qb
                    if dot<0 {end=qb.map {-$0};dot = -dot}
                    dot=min(1,max(-1,dot))
                    if dot>0.9995 {result=zip(qa,end).map {$0+($1-$0)*t}}
                    else {let theta=acos(dot),s=sin(theta);result=zip(qa,end).map {$0*sin((1-t)*theta)/s+$1*sin(t*theta)/s}}
                } else {result=zip(a,b).map {$0+($1-$0)*t}}
            }
        }
        return path=="rotation" ? Self.normalized(result) : result
    }
    static func normalized(_ q:[Double]) -> [Double] {
        guard q.count==4 else {return [0,0,0,1]}
        let n=sqrt(q.reduce(0) {$0+$1*$1});return n>1e-12 ? q.map {$0/n} : [0,0,0,1]
    }
}

struct ImportedAnimationClip:Codable,Sendable {
    var name:String
    var channels:[ImportedAnimationCurve]
    var duration:Double {channels.compactMap {$0.times.last}.max() ?? 0}
}
struct ImportedRestPose:Codable,Sendable {
    var target:String
    var translation:[Double]
    var rotation:[Double]
    var scale:[Double]
    var weights:[Double]
}
struct ImportedAnimationLibrary:Codable,Sendable {
    var clips:[ImportedAnimationClip]
    var rest:[ImportedRestPose]
    var selected:Int?=0
    var start:Double=0
    var speed:Double=1
    var loops:Bool=true
    var pausedAt:Double?
    func validate() throws {
        guard clips.count<=256,rest.count<=20_000,selected==nil || clips.indices.contains(selected!),
              start.isFinite,start>=0,speed.isFinite,speed>=0.01,speed<=16,pausedAt==nil || (pausedAt!.isFinite && pausedAt!>=0),
              Set(rest.map(\.target)).count==rest.count else {throw MeshWorkshopError.invalid}
        var scalarCount=0
        let ids=Set(rest.map(\.target))
        for pose in rest {
            guard pose.translation.count==3,pose.rotation.count==4,pose.scale.count==3,pose.weights.count<=64,
                  (pose.translation+pose.rotation+pose.scale+pose.weights).allSatisfy(\.isFinite) else {throw MeshWorkshopError.invalid}
        }
        for clip in clips {
            guard clip.channels.count<=20_000 else {throw MeshWorkshopError.limit}
            var used=Set<String>()
            for channel in clip.channels {
                try channel.validate();scalarCount += channel.values.count
                guard scalarCount<=4_000_000,ids.contains(channel.target),used.insert(channel.target+"/"+channel.path).inserted else {throw MeshWorkshopError.invalid}
            }
        }
    }
    var timelineEnd:Double {guard let selected,clips.indices.contains(selected) else {return 0};return start+clips[selected].duration/speed}
    func clipTime(_ projectTime:Double) -> Double? {
        guard let selected,clips.indices.contains(selected),projectTime>=start else {return nil}
        let end=clips[selected].duration,time=max(0,(pausedAt ?? projectTime)-start)*speed
        if loops,end>0 {return time.truncatingRemainder(dividingBy:end)}
        return min(time,end)
    }
}
