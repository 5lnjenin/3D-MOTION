import Foundation

enum MaterialMapRole: String, Codable, CaseIterable, Identifiable, Sendable {
    case baseColor, normal, roughness, metalness, ambientOcclusion, emission, opacity, displacement, specular, orm, metallicRoughness, ignore
    var id: String { rawValue }
    var channels: [String] {
        switch self {
        case .baseColor: return ["diffuse"]
        case .normal: return ["normal"]
        case .roughness: return ["roughness"]
        case .metalness: return ["metalness"]
        case .ambientOcclusion: return ["ambientOcclusion"]
        case .emission: return ["emission"]
        case .opacity: return ["transparent"]
        case .displacement: return ["displacement"]
        case .specular: return ["specular"]
        case .orm: return ["ambientOcclusion", "roughness", "metalness"]
        case .metallicRoughness: return ["roughness", "metalness"]
        case .ignore: return []
        }
    }
    func title(_ ar: Bool) -> String {
        switch self {
        case .baseColor: return ar ? "اللون الأساسي" : "Base color"
        case .normal: return ar ? "الخريطة العمودية" : "Normal"
        case .roughness: return ar ? "الخشونة" : "Roughness"
        case .metalness: return ar ? "المعدنية" : "Metalness"
        case .ambientOcclusion: return ar ? "الظلال المحيطية" : "Ambient occlusion"
        case .emission: return ar ? "الإضاءة الذاتية" : "Emission"
        case .opacity: return ar ? "الشفافية" : "Opacity"
        case .displacement: return ar ? "الإزاحة" : "Displacement"
        case .specular: return ar ? "الانعكاس اللامع" : "Specular"
        case .orm: return "ORM • AO/Roughness/Metalness"
        case .metallicRoughness: return "Roughness/Metalness • G/B"
        case .ignore: return ar ? "تجاهل هذه الصورة" : "Ignore this image"
        }
    }
}

enum MaterialImportFailure: LocalizedError {
    case invalid(String), tooLarge, noMaterials, damaged
    var errorDescription: String? {
        switch self {
        case .invalid(let detail): return "تعذر استيراد الخامة / Material import failed: " + detail
        case .tooLarge: return "الحزمة أو خرائطها كبيرة؛ اختر خامات أقل أو دقة أقل / Choose fewer materials or a lower texture resolution"
        case .noMaterials: return "لم يُعثر على خامات مدعومة؛ اختر صور الخامة أو حزمة ZIP أو ملف GLB / No supported materials were found"
        case .damaged: return "بيانات الخامة المحفوظة تالفة / Saved material integrity check failed"
        }
    }
}

struct MaterialSourceCredit: Codable, Equatable, Sendable {
    var label: String
    var modelURL: String? = nil
    var author: String? = nil
    var authorURL: String? = nil
    var license: String? = nil
    var licenseURL: String? = nil
}

struct MaterialMapInput: Identifiable, Sendable {
    var id: UUID = UUID()
    var url: URL
    var role: MaterialMapRole
    var flipGreen: Bool = false
    var invert: Bool = false
}

struct MaterialImportCandidate: Identifiable, Sendable {
    enum Kind: Sendable { case images, gltf(Int) }
    var id: UUID = UUID()
    var name: String
    var file: URL
    var kind: Kind
    var maps: [MaterialMapInput] = []
    var selected = true
}

enum MaterialImportNames {
    static func classify(_ url: URL) -> (name: String, role: MaterialMapRole, flipGreen: Bool, invert: Bool) {
        let original = url.deletingPathExtension().lastPathComponent
        let spaced = original.replacingOccurrences(of: "([a-z])([A-Z])", with: "$1_$2", options: .regularExpression)
        let aliases: [(String, MaterialMapRole)] = [
            ("occlusionroughnessmetallic", .orm), ("occlusion_roughness_metallic", .orm),
            ("metallicroughness", .metallicRoughness), ("metallic_roughness", .metallicRoughness),
            ("ambientocclusion", .ambientOcclusion), ("ambient_occlusion", .ambientOcclusion),
            ("normal_opengl", .normal), ("normal_directx", .normal), ("normal_gl", .normal), ("normal_dx", .normal),
            ("normalgl", .normal), ("normaldx", .normal),
            ("base_color", .baseColor), ("basecolor", .baseColor), ("base_colour", .baseColor),
            ("albedo", .baseColor), ("diffuse", .baseColor), ("color", .baseColor), ("colour", .baseColor),
            ("roughness", .roughness), ("rough", .roughness), ("glossiness", .roughness), ("gloss", .roughness),
            ("metalness", .metalness), ("metallic", .metalness), ("metal", .metalness),
            ("normal", .normal), ("nrm", .normal), ("occlusion", .ambientOcclusion), ("ao", .ambientOcclusion),
            ("emissive", .emission), ("emission", .emission), ("opacity", .opacity), ("alpha", .opacity),
            ("displacement", .displacement), ("height", .displacement), ("specular", .specular), ("orm", .orm)
        ]
        for (alias, role) in aliases {
            let pattern = "(?i)(?:^|[_\\- .])" + alias + "(?=$|[_\\- .])"
            guard let range = spaced.range(of: pattern, options: .regularExpression) else { continue }
            var name = spaced.replacingCharacters(in: range, with: "_")
            name = name.replacingOccurrences(of: "(?i)(?:^|[_\\- .])(?:[1248]k|\\d+x\\d+|srgb|linear)(?=$|[_\\- .])", with: "_", options: .regularExpression)
            name = name.trimmingCharacters(in: CharacterSet(charactersIn: "_- ."))
            if name.isEmpty { name = url.deletingLastPathComponent().lastPathComponent }
            return (name, role, alias.contains("dx") || alias.contains("directx"), alias.hasPrefix("gloss"))
        }
        return (original, .baseColor, false, false)
    }

    static func validate(_ maps: [MaterialMapInput]) throws {
        var channels = Set<String>()
        for map in maps {
            for channel in map.role.channels {
                guard channels.insert(channel).inserted else {
                    throw MaterialImportFailure.invalid("خريطتان للقناة نفسها؛ غيّر تعيين الصورة أو تجاهل إحداهما / Two maps target the same channel")
                }
            }
        }
        guard !channels.isEmpty else { throw MaterialImportFailure.noMaterials }
    }
}
