import Foundation
import SwiftUI
import UIKit
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

@MainActor
extension StudioStore {
// MARK: - Camera Focus Tools

    func enableDepthOfFieldOnSelectedCamera(_ enabled: Bool) {
        guard let camera = selectedNode?.camera else { toast = "حدد كاميرا أولًا"; return }
        camera.wantsDepthOfField = enabled
        objectWillChange.send()
        toast = enabled ? "Depth of Field ON" : "Depth of Field OFF"
    }

    func focusSelectedCameraOnWorkPoint() {
        guard let node = selectedNode, let camera = node.camera else {
            toast = "حدد كاميرا أولًا"
            return
        }
        let p = node.presentation.worldPosition
        let dx = p.x - workPoint.x, dy = p.y - workPoint.y, dz = p.z - workPoint.z
        camera.focusDistance = max(0.01, Double(sqrt(dx * dx + dy * dy + dz * dz)))
        camera.wantsDepthOfField = true
        objectWillChange.send()
        toast = "Focus → Work Point"
    }

    // MARK: - Camera Engine

    var activeCameraNode: SCNNode? {
        if let selectedNode, selectedNode.camera != nil { return selectedNode }
        if let pov = scnView?.pointOfView, pov.camera != nil { return pov }
        return camerasRoot.childNodes.first(where: { $0.camera != nil })
    }

    func useSelectedCamera() {
        guard let selectedNode, selectedNode.camera != nil else {
            toast = tr("select_camera_first")
            return
        }
        if scnView?.pointOfView !== selectedNode {
            cameraBeforePreview = scnView?.pointOfView
        }
        selectedNode.camera?.categoryBitMask = Int.max ^ editorOnlyCategoryBit
        scnView?.pointOfView = selectedNode
        isUsingSelectedCamera = true
        syncCameraControls()
        toast = "Camera View · \(selectedNode.name ?? "Camera")"
    }

    func exitSelectedCameraView() {
        if let previous = cameraBeforePreview, previous.camera != nil {
            scnView?.pointOfView = previous
        } else if let editorViewportCamera, editorViewportCamera.camera != nil {
            scnView?.pointOfView = editorViewportCamera
        } else if let editor = camerasRoot.childNode(withName: "Camera 1", recursively: false), editor.camera != nil {
            scnView?.pointOfView = editor
        }
        cameraBeforePreview = nil
        isUsingSelectedCamera = false
        toast = "Editor View"
    }

    func toggleSelectedCameraView() {
        if isUsingSelectedCamera { exitSelectedCameraView() } else { useSelectedCamera() }
    }

    func syncCameraControls() {
        guard let c = activeCameraNode?.camera else { return }
        cameraFOV = Double(c.fieldOfView)
        cameraExposure = Double(c.exposureOffset)
        cameraBloom = Double(c.bloomIntensity)
        cameraBloomThreshold = Double(c.bloomThreshold)
        cameraBloomRadius = Double(c.bloomBlurRadius)
        cameraDOF = c.wantsDepthOfField
        cameraFocusDistance = Double(c.focusDistance)
        cameraFStop = Double(c.fStop)
        cameraVignette = Double(c.vignettingIntensity)
        cameraChromatic = Double(c.colorFringeIntensity)
        cameraHDR = c.wantsHDR
    }

    func applyCameraEngine() {
        guard let c = activeCameraNode?.camera else { return }

        pushUndoSnapshotThrottled(
            label: "Camera Edit",
            key: "camera-edit"
        )
        c.fieldOfView = CGFloat(cameraFOV)
        c.exposureOffset = CGFloat(cameraExposure)
        c.wantsHDR = cameraHDR
        c.bloomIntensity = CGFloat(cameraBloom)
        c.bloomThreshold = CGFloat(cameraBloomThreshold)
        c.bloomBlurRadius = CGFloat(cameraBloomRadius)
        c.wantsDepthOfField = cameraDOF
        c.focusDistance = CGFloat(cameraFocusDistance)
        c.fStop = CGFloat(cameraFStop)
        c.vignettingIntensity = CGFloat(cameraVignette)
        c.vignettingPower = 1.5
        c.colorFringeIntensity = CGFloat(cameraChromatic)
        c.colorFringeStrength = CGFloat(cameraChromatic * 10)
        objectWillChange.send()
    }

    func cameraPreset(_ preset: CameraPreset) {
        guard let camera = activeCameraNode else { return }
        let target = selectedNode?.camera == nil ? selectedNode?.presentation.worldPosition : SCNVector3(0, 0.8, 0)
        let t = target ?? SCNVector3(0, 0.8, 0)

        switch preset {
        case .perspective:
            camera.position = SCNVector3(t.x + 5.5, t.y + 3.2, t.z + 7.5)
        case .front:
            camera.position = SCNVector3(t.x, t.y + 1.0, t.z + 8)
        case .side:
            camera.position = SCNVector3(t.x + 8, t.y + 1.0, t.z)
        case .top:
            camera.position = SCNVector3(t.x, t.y + 10, t.z + 0.01)
        case .cinematic:
            camera.position = SCNVector3(t.x + 4.4, t.y + 1.25, t.z + 6.4)
            cameraFOV = 42
            cameraBloom = max(cameraBloom, 0.45)
            cameraVignette = max(cameraVignette, 0.25)
            applyCameraEngine()
        }

        camera.studioLook(at: t)
        scnView?.pointOfView = camera
        toast = "Camera: \(preset.title)"
    }

    func focusCameraOnSelection() {
        frameSelected()
    }

    // MARK: - FX / Design Engine

    func addParticle(_ kind: ParticleKind) {
        pushUndoSnapshot("Add Effect")
        let node = SCNNode()
        node.name = nextName(kind.title)

        let p = SCNParticleSystem()
        p.loops = true
        p.isLightingEnabled = false
        p.isLocal = false
        p.isAffectedByGravity = false

        // Keep weather emitters broad and flat. A spherical rain emitter wastes
        // particles under/behind the scene and can make the effect appear to travel
        // in the wrong direction.
        if kind == .rain {
            p.emitterShape = SCNBox(
                width: 12,
                height: 0.04,
                length: 12,
                chamferRadius: 0
            )
            p.birthLocation = .volume
            p.birthDirection = .constant
            p.emittingDirection = SCNVector3(0, -1, 0)
        } else {
            p.emitterShape = SCNSphere(radius: 0.7)
        }

        switch kind {
        case .smoke:
            p.birthRate = 55
            p.particleLifeSpan = 3.8
            p.particleLifeSpanVariation = 1.4
            p.particleSize = 0.34
            p.particleSizeVariation = 0.18
            p.particleVelocity = 0.55
            p.particleVelocityVariation = 0.28
            p.spreadingAngle = 28
            p.acceleration = SCNVector3(0, 0.18, 0)
            p.particleColor = UIColor(white: 0.62, alpha: 0.20)
            p.blendMode = .alpha

        case .sparks:
            p.birthRate = 80
            p.particleLifeSpan = 1.2
            p.particleLifeSpanVariation = 0.45
            p.particleSize = 0.035
            p.particleVelocity = 3.2
            p.particleVelocityVariation = 1.2
            p.spreadingAngle = 55
            p.acceleration = SCNVector3(0, -3.8, 0)
            p.particleColor = .systemOrange
            p.blendMode = .additive

        case .rain:
            // Downward-only rain. The previous default SceneKit emission vector
            // points toward +Z, so gravity alone could make the rain look reversed.
            // A lower birth rate plus a shorter life also keeps the editor responsive.
            p.birthRate = 180
            p.particleLifeSpan = 0.8
            p.particleLifeSpanVariation = 0.05
            p.particleSize = 0.014
            p.particleVelocity = 11.5
            p.particleVelocityVariation = 0.8
            p.spreadingAngle = 2
            p.birthDirection = .constant
            p.emittingDirection = SCNVector3(0, -1, 0)
            p.acceleration = SCNVector3(0, -9.8, 0)
            p.particleColor = UIColor(white: 0.78, alpha: 0.50)
            p.blendMode = .alpha
            node.position = SCNVector3(workPoint.x, workPoint.y + 8, workPoint.z)
        }

        node.addParticleSystem(p)
        contentRoot.addChildNode(node)
        select(node)
        toast = "تمت إضافة \(kind.title)"
    }

    func resetSelectedRainDirection() {
        guard let node = selectedNode, let particle = node.particleSystems?.first else { return }
        pushUndoSnapshot("Reset rain direction")
        node.simdWorldOrientation = simd_quatf(angle: 0, axis: SIMD3<Float>(0,1,0))
        particle.birthDirection = .constant
        particle.emittingDirection = SCNVector3(0,-1,0)
        particle.acceleration = SCNVector3(0,-9.8,0)
        particle.isLocal = false
        particle.isAffectedByGravity = false
        particle.particleVelocity = 11.5
        particle.particleVelocityVariation = 0.8
        particle.spreadingAngle = 2
        particle.birthRate = min(particle.birthRate, 260)
        particle.particleLifeSpan = 0.8
        particle.reset()
        refreshSelectionGizmo()
        toast = "المطر باتجاه الأسفل / Rain falls downward"
    }

    func addNeonTrail() {
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.systemRed
        material.emission.contents = UIColor.systemRed
        material.emission.intensity = 4
        material.lightingModel = .constant

        let tube = SCNTube(innerRadius: 0.025, outerRadius: 0.055, height: 5.0)
        tube.materials = [material]

        let node = SCNNode(geometry: tube)
        node.name = nextName("Neon Trail")
        node.eulerAngles.z = .pi / 2
        node.position = SCNVector3(0, 0.8, -2)
        contentRoot.addChildNode(node)
        select(node)
        toast = "تمت إضافة Neon Trail"
    }
}
