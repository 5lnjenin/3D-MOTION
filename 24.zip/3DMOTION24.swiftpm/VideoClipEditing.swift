import Foundation
import AVFoundation
import SceneKit
import SwiftUI

final class StudioMoviePlayer: AVPlayer {
    var clipID = UUID().uuidString
    var clipTiming = VideoClipTiming()
}

extension AVPlayer {
    var authoredMovieTiming: VideoClipTiming {
        var value = (self as? StudioMoviePlayer)?.clipTiming ?? VideoClipTiming(volume: Double(volume))
        value.muted = isMuted
        return value
    }
}

@MainActor
extension StudioStore {
    var selectedMoviePlayer: StudioMoviePlayer? {
        guard let node = selectedNode else { return nil }
        for child in ProjectSceneCodec.nodes(in: node) {
            for material in child.geometry?.materials ?? [] {
                for (_, property) in ProjectSceneCodec.properties(material) {
                    if let player = property.contents as? StudioMoviePlayer { return player }
                }
            }
        }
        return nil
    }

    func updateMovieClip(_ player: StudioMoviePlayer, _ change: (inout VideoClipTiming) -> Void) {
        var value = player.authoredMovieTiming
        change(&value)
        do { try value.validate() } catch { reportProjectError(error); return }
        let length = CMTimeGetSeconds(player.currentItem?.duration ?? .invalid)
        guard length.isFinite, value.sourceIn < length, value.sourceOut.map({ $0 <= length + 0.000001 }) != false else {
            reportProjectError(StudioVideoFailure.problem("القص خارج مدة الفيديو / Trim exceeds movie duration")); return
        }
        guard value != player.authoredMovieTiming else { return }
        pushUndoSnapshotThrottled(label: "Edit Video Clip", key: "video-" + player.clipID)
        player.clipTiming = value; player.volume = Float(value.volume * masterAudioVolume); player.isMuted = value.muted
        reconcileTimelineDuration(); synchronizeVideoTimeline(); objectWillChange.send()
    }
}

@MainActor
struct VideoClipInspector: View {
    @EnvironmentObject var studio: StudioStore
    let player: StudioMoviePlayer
    private var length: Double {
        let value = CMTimeGetSeconds(player.currentItem?.duration ?? .zero)
        return value.isFinite && value > 0 ? value : 1
    }
    private func binding(_ key: WritableKeyPath<VideoClipTiming, Double>) -> Binding<Double> {
        Binding(get: { player.authoredMovieTiming[keyPath: key] }, set: { value in studio.updateMovieClip(player) { $0[keyPath: key] = value } })
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(studio.appLanguage == .arabic ? "مقطع الفيديو" : "Video clip").font(.headline)
            HStack {
                Text(studio.appLanguage == .arabic ? "البداية" : "Start")
                TextField("0", value: binding(\.start), format: .number).keyboardType(.decimalPad).textFieldStyle(.roundedBorder)
            }
            HStack {
                Text(studio.appLanguage == .arabic ? "القص من" : "Trim in")
                TextField("0", value: binding(\.sourceIn), format: .number).keyboardType(.decimalPad).textFieldStyle(.roundedBorder)
            }
            HStack {
                Text(studio.appLanguage == .arabic ? "القص إلى" : "Trim out")
                TextField("", value: Binding(get: { player.clipTiming.sourceOut ?? length }, set: { value in studio.updateMovieClip(player) { $0.sourceOut = value } }), format: .number)
                    .keyboardType(.decimalPad).textFieldStyle(.roundedBorder)
            }
            Text(studio.appLanguage == .arabic ? "السرعة" : "Speed")
            Slider(value: binding(\.speed), in: 0.1...4)
            Text(studio.appLanguage == .arabic ? "مستوى الصوت" : "Volume")
            Slider(value: binding(\.volume), in: 0...1)
            Toggle(studio.appLanguage == .arabic ? "تكرار" : "Loop", isOn: Binding(get: { player.clipTiming.loops }, set: { value in studio.updateMovieClip(player) { $0.loops = value } }))
            Toggle(studio.appLanguage == .arabic ? "كتم" : "Mute", isOn: Binding(get: { player.isMuted }, set: { value in studio.updateMovieClip(player) { $0.muted = value } }))
        }.padding(.vertical, 12)
    }
}
