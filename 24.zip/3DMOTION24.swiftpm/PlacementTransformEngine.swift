import Foundation
import SwiftUI
import UIKit
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

@MainActor
extension StudioStore {
// MARK: - Imported asset placement
    // Imported files may use huge/small authoring units or a pivot far away
    // from their visible geometry. Recenter the top-level imported container
    // without destroying the internal hierarchy/transforms.
    func prepareImportedAssetForWorkspace(_ root: SCNNode) {
        let bounds = root.boundingBox
        let minV = bounds.min
        let maxV = bounds.max
        guard minV.x.isFinite, minV.y.isFinite, minV.z.isFinite,
              maxV.x.isFinite, maxV.y.isFinite, maxV.z.isFinite else { return }

        let center = SCNVector3(
            (minV.x + maxV.x) * 0.5,
            (minV.y + maxV.y) * 0.5,
            (minV.z + maxV.z) * 0.5
        )
        let size = SCNVector3(
            maxV.x - minV.x,
            maxV.y - minV.y,
            maxV.z - minV.z
        )
        let longest = max(size.x, max(size.y, size.z))
        guard longest.isFinite, longest > 0.000_001 else { return }

        // Put the visible center on the workspace origin. Keep hierarchy intact.
        root.pivot = SCNMatrix4MakeTranslation(center.x, center.y, center.z)

        // Only repair obviously incompatible authoring scales. Normal-sized
        // assets keep their authored scale.
        let targetLongest: Float = 6.0
        if longest > 100.0 || longest < 0.02 {
            let factor = targetLongest / longest
            root.scale = SCNVector3(
                root.scale.x * factor,
                root.scale.y * factor,
                root.scale.z * factor
            )
        }

        // Top-level translation from DCC/export files is not useful for a newly
        // imported standalone asset. Internal child transforms are preserved.
        let placedHeight = abs(size.y * root.scale.y)
        root.position = SCNVector3(0, max(0, placedHeight * 0.5), 0)
    }

    func frameSelected() {
        guard let selectedNode else { return }
        frameNode(selectedNode)
    }

    func viewportPivot() -> SCNVector3 {
        if let selectedNode {
            if let bounds = worldBounds(of: selectedNode) {
                return SCNVector3(
                    (bounds.min.x + bounds.max.x) * 0.5,
                    (bounds.min.y + bounds.max.y) * 0.5,
                    (bounds.min.z + bounds.max.z) * 0.5
                )
            }
            return selectedNode.presentation.worldPosition
        }
        return workPoint
    }

    func frameNode(_ node: SCNNode) {
        guard let view = scnView,
              let pov = view.pointOfView,
              let bounds = worldBounds(of: node) else {
            toast = "تعذر حساب حدود العنصر. جرّب تحديد Mesh من القائمة."
            return
        }

        let center = SCNVector3(
            (bounds.min.x + bounds.max.x) * 0.5,
            (bounds.min.y + bounds.max.y) * 0.5,
            (bounds.min.z + bounds.max.z) * 0.5
        )

        let sx = max(0.05, bounds.max.x - bounds.min.x)
        let sy = max(0.05, bounds.max.y - bounds.min.y)
        let sz = max(0.05, bounds.max.z - bounds.min.z)
        let radius = max(0.05, 0.5 * sqrtf(sx * sx + sy * sy + sz * sz))

        // Fit by the actual camera FOV with generous editor padding. The old
        // maxSide * 1.2 formula put a 1-unit cube almost against the lens.
        let fovDegrees = Float(pov.camera?.fieldOfView ?? 50)
        let halfFov = max(0.12, fovDegrees * .pi / 360)
        let fittedDistance = radius / tanf(halfFov) * 1.75
        let distance = max(4.8, fittedDistance)

        // Preserve the user's current viewing direction while moving to a safe
        // framing distance. If the direction is degenerate, use a pleasant 3/4 view.
        let current = pov.presentation.worldPosition
        var dx = current.x - center.x
        var dy = current.y - center.y
        var dz = current.z - center.z
        var length = sqrtf(dx * dx + dy * dy + dz * dz)
        if !length.isFinite || length < 0.001 {
            dx = 0.55; dy = 0.32; dz = 1.0
            length = sqrtf(dx * dx + dy * dy + dz * dz)
        }
        dx /= length; dy /= length; dz /= length

        SCNTransaction.begin()
        SCNTransaction.animationDuration = 0.18
        pov.camera?.usesOrthographicProjection = false
        pov.camera?.fieldOfView = 50
        pov.camera?.zNear = Double(max(0.001, distance / 10_000))
        pov.camera?.zFar = Double(max(1000, distance * 1000))
        pov.position = SCNVector3(
            center.x + dx * distance,
            center.y + dy * distance,
            center.z + dz * distance
        )
        pov.studioLook(at: center)
        view.pointOfView = pov
        SCNTransaction.commit()

        statusText = "مركز على \(node.name ?? "Object")"
    }

    // MARK: Transform Editing
    func recordDirectTransformEdit(
        _ node: SCNNode,
        label: String,
        change: () -> Void
    ) {
        let before = TransformHistoryState(
            node: node,
            position: node.position,
            orientation: node.simdOrientation,
            scale: node.scale
        )
        change()
        let after = TransformHistoryState(
            node: node,
            position: node.position,
            orientation: node.simdOrientation,
            scale: node.scale
        )
        transformUndoStack.append(
            TransformHistoryCommand(label: label, before: [before], after: [after])
        )
        if transformUndoStack.count > 80 {
            transformUndoStack.removeFirst(transformUndoStack.count - 80)
        }
        transformRedoStack.removeAll()
        materialRedoStack.removeAll()
        undoCount = transformUndoStack.count + materialUndoStack.count
        redoCount = 0
    }


    func updatePosition(axis: Axis3D, value: Float) {
        guard value.isFinite, let n = selectedNode, !isNodeLocked(n) else { return }
        recordDirectTransformEdit(n, label: "Position") {
            var p = n.position
            switch axis {
            case .x: p.x = value
            case .y: p.y = value
            case .z: p.z = value
            }
            n.position = p
        }
        refreshSelectionGizmo()
        objectWillChange.send()
    }

    func updateRotation(axis: Axis3D, degrees: Float) {
        guard degrees.isFinite, let n = selectedNode, !isNodeLocked(n) else { return }
        recordDirectTransformEdit(n, label: "Rotation") {
            var r = n.eulerAngles
            let rad = degrees * .pi / 180
            switch axis {
            case .x: r.x = rad
            case .y: r.y = rad
            case .z: r.z = rad
            }
            n.eulerAngles = r
        }
        refreshSelectionGizmo()
        objectWillChange.send()
    }

    func updateScale(axis: Axis3D, value: Float) {
        guard value.isFinite, let n = selectedNode, !isNodeLocked(n) else { return }
        let safeValue: Float = (value < 0 ? -1 : 1) * min(10000, max(0.001, abs(value)))
        recordDirectTransformEdit(n, label: "Scale") {
            var scale = n.scale
            switch axis {
            case .x: scale.x = safeValue
            case .y: scale.y = safeValue
            case .z: scale.z = safeValue
            }
            n.scale = scale
        }
        refreshSelectionGizmo()
        objectWillChange.send()
    }

    /// Quick scale control used by the + / - buttons that appear when Scale is active.
    /// ALL scales uniformly; X/Y/Z only affect the currently selected axis.
    func nudgeSelectedScale(_ direction: Int) {
        guard direction != 0, let n = selectedNode, !isNodeLocked(n) else { return }

        let step: Float = fineMode ? 1.025 : 1.10
        let factor: Float = direction > 0 ? step : (1.0 / step)

        func scaled(_ value: Float) -> Float {
            let sign: Float = value < 0 ? -1 : 1
            let magnitude = min(10000, max(0.001, abs(value) * factor))
            return sign * magnitude
        }

        recordDirectTransformEdit(n, label: direction > 0 ? "Scale +" : "Scale -") {
            var value = n.scale
            switch transformAxis {
            case .free:
                value.x = scaled(value.x)
                value.y = scaled(value.y)
                value.z = scaled(value.z)
            case .x:
                value.x = scaled(value.x)
            case .y:
                value.y = scaled(value.y)
            case .z:
                value.z = scaled(value.z)
            }
            n.scale = value
        }

        refreshSelectionGizmo()
        statusText = direction > 0
            ? (appLanguage == .arabic ? "تكبير العنصر" : "Scale up")
            : (appLanguage == .arabic ? "تصغير العنصر" : "Scale down")
        objectWillChange.send()
    }

    func resetSelectedPositionOnly() {
        guard let n = selectedNode, !isNodeLocked(n) else { return }
        recordDirectTransformEdit(n, label: "Reset Position") {
            n.position = SCNVector3Zero
        }
        refreshSelectionGizmo()
        statusText = appLanguage == .arabic ? "تمت إعادة الموقع" : "Position reset"
        objectWillChange.send()
    }

    func resetSelectedRotationOnly() {
        guard let n = selectedNode, !isNodeLocked(n) else { return }
        recordDirectTransformEdit(n, label: "Reset Rotation") {
            n.eulerAngles = SCNVector3Zero
        }
        refreshSelectionGizmo()
        statusText = appLanguage == .arabic ? "تمت إعادة الدوران" : "Rotation reset"
        objectWillChange.send()
    }

    func resetSelectedScaleOnly() {
        guard let n = selectedNode, !isNodeLocked(n) else { return }
        recordDirectTransformEdit(n, label: "Reset Scale") {
            n.scale = SCNVector3(1, 1, 1)
        }
        refreshSelectionGizmo()
        statusText = appLanguage == .arabic ? "تمت إعادة الحجم" : "Scale reset"
        objectWillChange.send()
    }

    func resetTransform() {
        guard let n = selectedNode, !isNodeLocked(n) else { return }
        recordDirectTransformEdit(n, label: "Reset Transform") {
            n.position = SCNVector3Zero
            n.eulerAngles = SCNVector3Zero
            n.scale = SCNVector3(1, 1, 1)
        }
        refreshSelectionGizmo()
        objectWillChange.send()
    }
}
