import SwiftUI
import SceneKit
import UIKit

enum WorkshopSection: String, CaseIterable, Identifiable {
    case modeling, materials, text, looks, arrange, animation
    var id: String { rawValue }
    func title(_ ar: Bool) -> String {
        switch self {
        case .modeling: return ar ? "النمذجة وUV" : "Modeling & UV"
        case .materials: return ar ? "مكتبة الخامات" : "Material library"
        case .text: return ar ? "النصوص والخطوط" : "Text & fonts"
        case .looks: return ar ? "أنماط وإضاءة" : "Looks & lighting"
        case .arrange: return ar ? "ترتيب وتكرار العناصر" : "Arrange & repeat objects"
        case .animation: return ar ? "الحركة والعظام" : "Animation & rigs"
        }
    }
    var symbol: String {
        switch self {
        case .modeling: return "cube.transparent"
        case .materials: return "paintpalette"
        case .text: return "textformat"
        case .looks: return "lightbulb.2"
        case .arrange: return "square.stack.3d.up"
        case .animation: return "figure.walk"
        }
    }
    var searchTerms: String {
        let keywords: String
        switch self {
        case .modeling: keywords = "mesh geometry extrude boolean UV sculpt mirror نمذجة بثق نحت أسطح"
        case .materials: keywords = "materials textures surface خامات نسيج"
        case .text: keywords = "text fonts typography نصوص خطوط"
        case .looks: keywords = "look styles lighting أنماط إضاءة"
        case .arrange: keywords = "transform arrange array mirror repeat تنظيم ترتيب تكرار"
        case .animation: keywords = "clips animation rig bones حركة عظام"
        }
        return title(true) + " " + title(false) + " " + keywords
    }
}

@MainActor
struct WorkshopLibraryView: View {
    @EnvironmentObject var studio: StudioStore
    @Environment(\.dismiss) private var dismiss
    var initialSection: WorkshopSection? = nil
    @State private var search = ""
    private var ar: Bool { studio.appLanguage == .arabic }
    var body: some View {
        NavigationStack {
            Group {
                if let initialSection {
                    destination(initialSection).navigationTitle(initialSection.title(ar))
                } else {
                    List {
                        category(ar ? "بناء وتنظيم" : "Build & organize", sections: [.modeling, .arrange])
                        category(ar ? "المظهر والتصميم" : "Surface & design", sections: [.materials, .text, .looks])
                        category(ar ? "التحريك" : "Animate", sections: [.animation])
                        Section(ar ? "المشروع الحالي" : "Current project") {
                            Text(studio.selectedNode?.name ?? (ar ? "لم يُحدد عنصر" : "No object selected"))
                            Button(ar ? "تراجع" : "Undo") { studio.undoLast() }.disabled(studio.undoCount == 0)
                            Text(ar ? "اختر عنصرًا ثم افتح القسم المناسب. النمذجة والخامات والتصميم متاحة أيضًا في الشريط العلوي." : "Select an object, then open a category. Modeling, materials and design are also available in the top bar.")
                                .font(.callout).foregroundStyle(.secondary)
                        }
                    }
                    .searchable(text: $search, prompt: ar ? "ابحث عن قسم" : "Find a category")
                    .navigationTitle(ar ? "ورشة الأدوات" : "Tool workshop")
                }
            }
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button(ar ? "إغلاق" : "Close") { dismiss() } } }
            .disabled(studio.workshopIsRunning)
            .overlay { if studio.workshopIsRunning { ProgressView(ar ? "تجهيز الهندسة…" : "Processing mesh…").padding(24).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16)) } }
        }
        .environment(\.layoutDirection, studio.appLanguage.direction)
        .presentationDetents([.large])
        .interactiveDismissDisabled(studio.workshopIsRunning)
        .alert(ar ? "تعذر إكمال الأداة" : "Tool failed", isPresented: Binding(get: { !studio.projectErrorDetails.isEmpty }, set: { if !$0 { studio.projectErrorDetails = "" } })) {
            Button(ar ? "نسخ التفاصيل" : "Copy details") { UIPasteboard.general.string = studio.projectErrorDetails }
            Button(ar ? "إغلاق" : "Close", role: .cancel) { studio.projectErrorDetails = "" }
        } message: { Text(studio.projectErrorDetails) }
    }
    @ViewBuilder private func category(_ title: String, sections: [WorkshopSection]) -> some View {
        let visible = sections.filter { search.isEmpty || $0.searchTerms.localizedCaseInsensitiveContains(search) }
        if !visible.isEmpty {
            Section(title) {
                ForEach(visible) { section in
                    NavigationLink { destination(section).navigationTitle(section.title(ar)) }
                    label: { Label(section.title(ar), systemImage: section.symbol).padding(.vertical, 4) }
                }
            }
        }
    }
    @ViewBuilder private func destination(_ section: WorkshopSection) -> some View {
        switch section {
        case .modeling: ScrollView { WorkshopModelingPanel().padding() }
        case .materials: WorkshopMaterialLibrary()
        case .text: TextStudioSheet(editingSelected: studio.selectedNode?.geometry is SCNText)
        case .looks: WorkshopLooksView()
        case .arrange: ScrollView { WorkshopArrangePanel().padding() }
        case .animation: ScrollView { ImportedAnimationInspector().padding(); AdvancedToolsInspector().padding() }
        }
    }
}

@MainActor
struct WorkshopModelingPanel:View {
    @EnvironmentObject var studio:StudioStore
    @State private var tool:WorkshopTool = .subdivide
    @State private var axis=1
    @State private var amount=0.2
    @State private var faceScope=1
    @State private var faceIndex=0
    @State private var radius=1.0
    @State private var centerX=0.0
    @State private var centerY=0.0
    @State private var centerZ=0.0
    @State private var cutterKey=""
    private var ar:Bool {studio.appLanguage == .arabic}
    var body:some View {
        VStack(alignment:.leading,spacing:16) {
            InspectorCard(title:ar ? "العنصر" : "Object") {
                Text(studio.selectedNode?.name ?? "—").font(.headline)
                Menu(ar ? "اختيار مجسم من المشروع" : "Choose a project mesh") {
                    ForEach(Array(ProjectSceneCodec.nodes(in:studio.contentRoot).filter {$0.geometry != nil}.prefix(200)),id:\.self) {node in
                        Button(node.name ?? "Mesh") {studio.select(node)}
                    }
                }.frame(minHeight:44)
                if studio.selectedNode?.geometry==nil,let root=studio.selectedNode {
                    let meshes=ProjectSceneCodec.nodes(in:root).filter {$0.geometry != nil}
                    ForEach(Array(meshes.prefix(40).enumerated()),id:\.offset) {_,node in
                        Button(node.name ?? "Mesh") {studio.select(node)}.frame(minHeight:44)
                    }
                }
                Text(ar ? "اختر جزءًا هندسيًا من المشهد. البثق والإطار يعملان على مثلثات محددة، ويمكنك تحديد جهة السطح أو رقم المثلث." : "Select a mesh part. Extrude and inset use a surface side or an individual triangle index.")
                    .font(.callout).foregroundStyle(.secondary)
            }
            InspectorCard(title:ar ? "أداة الهندسة" : "Mesh tool") {
                Picker(ar ? "الأداة" : "Tool",selection:$tool) {ForEach(WorkshopTool.allCases) {t in Text(t.title(ar)).tag(t)}}
                    .pickerStyle(.menu)
                Picker(ar ? "المحور" : "Axis",selection:$axis) {Text("X").tag(0);Text("Y").tag(1);Text("Z").tag(2)}.pickerStyle(.segmented)
                if ![WorkshopTool.subdivide,.flat,.mirror].contains(tool) {
                    HStack {Text(parameterTitle);TextField(parameterTitle,value:$amount,format:.number).textFieldStyle(.roundedBorder).keyboardType(.numbersAndPunctuation)}
                }
                if tool == .extrude || tool == .inset {
                    Picker(ar ? "الأسطح" : "Faces",selection:$faceScope) {
                        Text(ar ? "الجهة الموجبة" : "Positive side").tag(1)
                        Text(ar ? "الجهة السالبة" : "Negative side").tag(2)
                        Text(ar ? "مثلث واحد" : "One triangle").tag(3)
                        Text(ar ? "جميع الأسطح" : "All faces").tag(0)
                    }.pickerStyle(.menu)
                    if faceScope==3 {HStack {Text(ar ? "رقم المثلث (من 0)" : "Triangle index (from 0)");TextField("Index",value:$faceIndex,format:.number).textFieldStyle(.roundedBorder)}}
                }
                if tool == .sculpt {
                    HStack {Text(ar ? "نصف قطر الفرشاة" : "Brush radius");TextField("Radius",value:$radius,format:.number).textFieldStyle(.roundedBorder)}
                    Text(ar ? "مركز الفرشاة داخل المجسم" : "Brush center in object coordinates").font(.callout)
                    HStack {TextField("X",value:$centerX,format:.number);TextField("Y",value:$centerY,format:.number);TextField("Z",value:$centerZ,format:.number)}.textFieldStyle(.roundedBorder)
                }
                Button {apply()} label: {Label(tool.title(ar),systemImage:"checkmark.circle")}.buttonStyle(.borderedProminent).frame(minHeight:44)
                    .disabled(studio.selectedNode?.geometry==nil || studio.workshopIsRunning)
                Button(ar ? "قلب اتجاه الأسطح" : "Flip normals") {studio.flipSelectedNormals()}.frame(minHeight:44)
                Button(ar ? "شطف حواف الصندوق" : "Bevel box edges") {studio.bevelSelectedBox(amount)}.frame(minHeight:44)
            }
            InspectorCard(title:"Boolean") {
                Text(ar ? "حدد جسمين مغلقين بالتحديد المتعدد، واجعل الهدف هو العنصر النشط. يحتفظ التطبيق بالجسم الثاني مخفيًا بعد نجاح العملية." : "Select two closed solids; make the target active. The second object is kept hidden after success.").font(.callout)
                Picker(ar ? "الجسم الثاني" : "Second mesh",selection:$cutterKey) {
                    Text(ar ? "استخدم التحديد المتعدد" : "Use multiple selection").tag("")
                    ForEach(Array(ProjectSceneCodec.nodes(in:studio.contentRoot).filter {$0.geometry != nil && $0 !== studio.selectedNode}.prefix(200)),id:\.self) {node in
                        Text(node.name ?? "Mesh").tag(String(ObjectIdentifier(node).hashValue))
                    }
                }.pickerStyle(.menu)
                ForEach(WorkshopMesh.BooleanOperation.allCases,id:\.self) {op in
                    Button(booleanTitle(op)) {
                        if !cutterKey.isEmpty,let target=studio.selectedNode,let cutter=ProjectSceneCodec.nodes(in:studio.contentRoot).first(where:{String(ObjectIdentifier($0).hashValue)==cutterKey}) {studio.multiSelectedNodes=[target,cutter]}
                        studio.workshopBoolean(op)
                    }.frame(minHeight:44)
                }
            }
            Text(ar ? "تحتاج هذه الأدوات هندسة مثلثة ثابتة. حرّر الشخصيات من قسم العظام؛ الأداة ترفض التعديل الذي يفقد عظامًا أو مورفًا أو قنوات UV إضافية." : "These tools require static triangle geometry. Use the rig section for characters; edits that would lose skin, morphs or extra UV channels are rejected.")
                .font(.callout).foregroundStyle(.secondary)
        }
        .buttonStyle(.bordered)
        .onChange(of:tool) {_,value in
            amount=[.uvBox,.uvPlanar,.uvCylinder,.uvSphere].contains(value) ? 1 : (value == .weld ? 0.001 : 0.2)
        }
    }
    private var parameterTitle:String {
        if [.uvBox,.uvPlanar,.uvCylinder,.uvSphere].contains(tool) {return ar ? "تكرار الخريطة" : "UV scale"}
        if [.twist,.bend].contains(tool) {return ar ? "الزاوية بالراديان" : "Angle in radians"}
        if tool == .inset {return ar ? "النسبة (0–1)" : "Fraction (0–1)"}
        return ar ? "المقدار" : "Amount"
    }
    private func booleanTitle(_ op:WorkshopMesh.BooleanOperation) -> String {
        switch op {case .union:return ar ? "اتحاد" : "Union";case .subtract:return ar ? "طرح الجسم الثاني" : "Subtract second mesh";case .intersect:return ar ? "تقاطع" : "Intersection"}
    }
    private func apply() {
        var faces:Set<Int>?
        if tool == .extrude || tool == .inset {
            guard let node=studio.selectedNode,let mesh=try? WorkshopGeometry.mesh(node) else {return}
            if faceScope==3 {faces=[faceIndex]}
            else if faceScope != 0 {faces=Set(mesh.faces.indices.filter {mesh.faceNormal(mesh.faces[$0])[axis]*(faceScope==1 ? 1 : -1)>0.5})}
        }
        studio.runWorkshop(tool,axis:axis,amount:amount,faces:faces,brushCenter:.init(centerX,centerY,centerZ),radius:radius)
    }
}

@MainActor
struct WorkshopMaterialLibrary:View {
    @EnvironmentObject var studio:StudioStore
    @State private var search=""
    @State private var tiling=1.0
    private var ar:Bool {studio.appLanguage == .arabic}
    var body:some View {
        ScrollView {
            VStack(alignment:.leading,spacing:16) {
                Text(ar ? "خامات محلية • تُحفظ خرائطها داخل المشروع" : "Offline materials • maps travel with your project").font(.callout)
                HStack {Text(ar ? "التكرار" : "Tiling");Slider(value:$tiling,in:0.5...8,step:0.5);Text(tiling,format:.number).monospacedDigit()}
                UserMaterialLibraryPanel(search: search, tiling: tiling)
                Text(ar ? "الخامات الجاهزة" : "Built-in materials").font(.title2.bold())
                LazyVGrid(columns:[GridItem(.adaptive(minimum:130))],spacing:12) {
                    ForEach(WorkshopMaterial.allCases.filter {search.isEmpty || $0.title(ar).localizedCaseInsensitiveContains(search) || $0.rawValue.localizedCaseInsensitiveContains(search)}) {preset in
                        Button {studio.applyWorkshopMaterial(preset,tiling:tiling)} label: {
                            VStack {Image(uiImage:WorkshopTextures.thumbnail(preset)).resizable().scaledToFit().clipShape(RoundedRectangle(cornerRadius:12));Text(preset.title(ar)).font(.body).lineLimit(2)}
                        }.buttonStyle(.plain).accessibilityLabel(preset.title(ar)).disabled(studio.selectedNode==nil)
                    }
                }
            }.padding()
        }.searchable(text:$search,prompt:ar ? "بحث عن خامة" : "Search materials")
    }
}

@MainActor
struct WorkshopLooksView:View {
    @EnvironmentObject var studio:StudioStore
    var body:some View {
        List {
            Text(studio.appLanguage == .arabic ? "يضيف النمط مجموعة إضاءة قابلة للتحرير. الأضواء الموجودة تبقى؛ حدّدها وأخفها إذا رغبت بنمط منفرد." : "Each look adds an editable light rig. Existing lights remain; select and hide them for an isolated look.").font(.callout)
            ForEach(StudioStore.WorkshopLook.allCases) {look in Button(look.title(studio.appLanguage == .arabic)) {studio.applyWorkshopLook(look)}.frame(minHeight:44)}
        }
    }
}

@MainActor
struct WorkshopArrangePanel:View {
    @EnvironmentObject var studio:StudioStore
    @State private var count=4
    @State private var axis=0
    @State private var spacing=1.5
    @State private var radius=2.0
    private var ar:Bool {studio.appLanguage == .arabic}
    var body:some View {
        VStack(spacing:16) {
            InspectorCard(title:ar ? "التكرار" : "Arrays") {
                Stepper("\(ar ? "عدد النسخ" : "Copies"): \(count)",value:$count,in:2...64)
                Picker(ar ? "المحور" : "Axis",selection:$axis) {Text("X").tag(0);Text("Y").tag(1);Text("Z").tag(2)}.pickerStyle(.segmented)
                TextField(ar ? "المسافة" : "Spacing",value:$spacing,format:.number).textFieldStyle(.roundedBorder)
                Button(ar ? "تكرار خطي" : "Linear array") {studio.createLinearArray(count:count,spacing:Float(spacing),axis:selectedAxis)}.frame(minHeight:44)
                TextField(ar ? "نصف القطر" : "Radius",value:$radius,format:.number).textFieldStyle(.roundedBorder)
                Button(ar ? "تكرار دائري" : "Radial array") {studio.createRadialArray(count:count,radius:Float(radius),axis:selectedAxis)}.frame(minHeight:44)
            }
            InspectorCard(title:ar ? "التنظيم" : "Organize") {
                Button(ar ? "تجميع" : "Group") {studio.groupSelectedNodes()}
                Button(ar ? "فك التجميع" : "Ungroup") {studio.ungroupSelectedNode()}
                Button(ar ? "محاذاة مع العنصر النشط" : "Align to active") {studio.alignSelectionToActive(axis:selectedAxis)}
                Button(ar ? "توزيع" : "Distribute") {studio.distributeSelection(axis:selectedAxis)}
                Button(ar ? "مركز المحور" : "Center pivot") {studio.centerPivotOnSelection()}
                Button(ar ? "هندسة مستقلة" : "Make geometry unique") {studio.makeSelectedGeometryUnique()}
            }
        }.buttonStyle(.bordered)
    }
    private var selectedAxis:Axis3D {axis==0 ? .x : (axis==1 ? .y : .z)}
}


extension InspectorSection {
    func localizedTitle(_ language: StudioLanguage) -> String {
        guard language == .arabic else { return title }
        switch self {
        case .transform: return "تحويل"
        case .material: return "خامات"
        case .object: return "عنصر"
        case .modeling: return "نمذجة"
        case .animation: return "حركة"
        case .advanced: return "متقدم"
        case .audio: return "صوت"
        case .light: return "إضاءة"
        case .camera: return "كاميرا"
        case .fx: return "مؤثرات"
        case .scene: return "مشهد"
        }
    }
}
