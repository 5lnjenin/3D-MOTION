import Foundation
import SwiftUI
import UIKit
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

@MainActor
extension StudioStore {
// MARK: - Render Filter Engine

    func applyRenderFilter(
        to image: UIImage
    ) -> UIImage {
        guard renderFilterPreset != .none,
              let cgImage = image.cgImage else {
            return image
        }

        var output =
            CIImage(cgImage: cgImage)

        let intensity = max(
            0,
            min(
                1,
                renderFilterIntensity
            )
        )

        func apply(
            _ name: String,
            values: [String: Any]
        ) {
            guard let filter =
                    CIFilter(name: name) else {
                return
            }

            filter.setValue(
                output,
                forKey: kCIInputImageKey
            )

            for (key, value) in values {
                filter.setValue(
                    value,
                    forKey: key
                )
            }

            if let filtered =
                    filter.outputImage {
                output = filtered
            }
        }

        switch renderFilterPreset {
        case .none:
            break

        case .cinematic:
            apply(
                "CIColorControls",
                values: [
                    kCIInputContrastKey:
                        1.0 + 0.28 * intensity,
                    kCIInputSaturationKey:
                        1.0 - 0.18 * intensity,
                    kCIInputBrightnessKey:
                        -0.03 * intensity
                ]
            )

            apply(
                "CIVignette",
                values: [
                    kCIInputIntensityKey:
                        1.2 * intensity,
                    kCIInputRadiusKey: 1.8
                ]
            )

        case .vivid:
            apply(
                "CIVibrance",
                values: [
                    "inputAmount":
                        0.8 * intensity
                ]
            )

            apply(
                "CIColorControls",
                values: [
                    kCIInputSaturationKey:
                        1.0 + 0.45 * intensity
                ]
            )

        case .warm:
            apply(
                "CITemperatureAndTint",
                values: [
                    "inputNeutral":
                        CIVector(
                            x: 6500,
                            y: 0
                        ),
                    "inputTargetNeutral":
                        CIVector(
                            x:
                                6500 +
                                1800 * intensity,
                            y: 0
                        )
                ]
            )

        case .cool:
            apply(
                "CITemperatureAndTint",
                values: [
                    "inputNeutral":
                        CIVector(
                            x: 6500,
                            y: 0
                        ),
                    "inputTargetNeutral":
                        CIVector(
                            x:
                                6500 -
                                1800 * intensity,
                            y: 0
                        )
                ]
            )

        case .mono:
            apply(
                "CIPhotoEffectMono",
                values: [:]
            )

        case .noir:
            apply(
                "CIPhotoEffectNoir",
                values: [:]
            )
        }

        guard let rendered =
                ciContext.createCGImage(
                    output,
                    from: output.extent
                ) else {
            return image
        }

        return UIImage(
            cgImage: rendered,
            scale: image.scale,
            orientation:
                image.imageOrientation
        )
    }

    // MARK: Snapshot

    func saveSnapshotToPhotos() {
        guard let view = scnView, !importIsRunning else { return }
        let outlineHidden = selectionOutline?.isHidden ?? true
        let editorHidden = editorRoot.isHidden
        let helpersHidden = helpersRoot.isHidden
        selectionOutline?.isHidden = true
        editorRoot.isHidden = true
        helpersRoot.isHidden = true
        let image = applyRenderFilter(to: view.snapshot())
        selectionOutline?.isHidden = outlineHidden
        editorRoot.isHidden = editorHidden
        helpersRoot.isHidden = helpersHidden
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
            guard status == .authorized || status == .limited else {
                Task { @MainActor in self.toast = "اسمح بحفظ الصور من الإعدادات / Allow Photos access" }
                return
            }
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAsset(from: image)
            }) { success, error in
                Task { @MainActor in
                    self.toast = success ? "تم حفظ الصورة / Image saved" :
                        "تعذر الحفظ / Save failed: \(error?.localizedDescription ?? "")"
                }
            }
        }
    }
}
