import Foundation
import SwiftUI
import UIKit
import SceneKit

// MARK: - Built-in Ready Model Library
// Procedural assets keep the app package small and make every part editable.
// Grass/reeds are animated with lightweight SceneKit actions and need no downloads.

enum ReadyModelKind: String, CaseIterable, Identifiable {
    case grassSoft, grassTall, grassMeadow, grassWild, grassDense
    case reeds, bush, flowerPatch
    case rockCluster, pineTree, palmTree, broadleafTree, cactus, fern, deadTree
    case boulder, treeStump, terrainHill, dirtPatch
    case roadStraight, roadCorner, roadCross
    case concreteWall, woodenFence, warehouse, smallHouse, archway, stairs
    case crateStack, barrelStack, bench, streetLamp, signPost

    var id: String { rawValue }

    static var vegetation: [ReadyModelKind] {
        [.grassSoft, .grassTall, .grassMeadow, .grassWild, .grassDense, .reeds, .bush, .flowerPatch]
    }

    static var nature: [ReadyModelKind] {
        [.pineTree, .palmTree, .broadleafTree, .cactus, .fern, .deadTree,
         .rockCluster, .boulder, .treeStump, .terrainHill, .dirtPatch]
    }

    static var roads: [ReadyModelKind] {
        [.roadStraight, .roadCorner, .roadCross]
    }

    static var structures: [ReadyModelKind] {
        [.concreteWall, .woodenFence, .warehouse, .smallHouse, .archway, .stairs]
    }

    static var props: [ReadyModelKind] {
        [.crateStack, .barrelStack, .bench, .streetLamp, .signPost]
    }

    var icon: String {
        switch self {
        case .grassSoft, .grassTall, .grassMeadow, .grassWild, .grassDense, .reeds, .bush, .flowerPatch, .fern:
            return "leaf.fill"
        case .pineTree, .palmTree, .broadleafTree, .deadTree, .treeStump:
            return "tree.fill"
        case .cactus:
            return "camera.macro"
        case .rockCluster, .boulder, .terrainHill:
            return "mountain.2.fill"
        case .dirtPatch:
            return "circle.grid.cross.fill"
        case .roadStraight, .roadCorner, .roadCross:
            return "road.lanes"
        case .concreteWall, .woodenFence, .archway, .stairs:
            return "square.3.layers.3d"
        case .warehouse, .smallHouse:
            return "building.2.fill"
        case .crateStack:
            return "shippingbox.fill"
        case .barrelStack:
            return "cylinder.fill"
        case .bench:
            return "rectangle.3.group.fill"
        case .streetLamp:
            return "lightbulb.fill"
        case .signPost:
            return "signpost.right.fill"
        }
    }

    func title(for language: StudioLanguage) -> String {
        if language == .arabic {
            switch self {
            case .grassSoft: return "عشب ناعم 01"
            case .grassTall: return "عشب طويل 02"
            case .grassMeadow: return "عشب مرج 03"
            case .grassWild: return "عشب بري 04"
            case .grassDense: return "عشب كثيف 05"
            case .reeds: return "قصب متحرك"
            case .bush: return "شجيرة متحركة"
            case .flowerPatch: return "رقعة زهور"
            case .rockCluster: return "مجموعة صخور"
            case .pineTree: return "شجرة صنوبر"
            case .palmTree: return "نخلة متحركة"
            case .broadleafTree: return "شجرة عريضة متحركة"
            case .cactus: return "صبار"
            case .fern: return "سرخس متحرك"
            case .deadTree: return "شجرة يابسة"
            case .boulder: return "صخرة كبيرة"
            case .treeStump: return "جذع شجرة"
            case .terrainHill: return "تل أرضي"
            case .dirtPatch: return "رقعة تراب"
            case .roadStraight: return "طريق مستقيم"
            case .roadCorner: return "منعطف طريق"
            case .roadCross: return "تقاطع طريق"
            case .concreteWall: return "جدار إسمنتي"
            case .woodenFence: return "سياج خشبي"
            case .warehouse: return "مستودع"
            case .smallHouse: return "بيت صغير"
            case .archway: return "بوابة قوس"
            case .stairs: return "درج"
            case .crateStack: return "صناديق"
            case .barrelStack: return "براميل"
            case .bench: return "مقعد"
            case .streetLamp: return "عمود إنارة"
            case .signPost: return "لوحة طريق"
            }
        }

        switch self {
        case .grassSoft: return "Soft Grass 01"
        case .grassTall: return "Tall Grass 02"
        case .grassMeadow: return "Meadow Grass 03"
        case .grassWild: return "Wild Grass 04"
        case .grassDense: return "Dense Grass 05"
        case .reeds: return "Animated Reeds"
        case .bush: return "Animated Bush"
        case .flowerPatch: return "Flower Patch"
        case .rockCluster: return "Rock Cluster"
        case .pineTree: return "Pine Tree"
        case .palmTree: return "Animated Palm"
        case .broadleafTree: return "Animated Broadleaf Tree"
        case .cactus: return "Cactus"
        case .fern: return "Animated Fern"
        case .deadTree: return "Dead Tree"
        case .boulder: return "Boulder"
        case .treeStump: return "Tree Stump"
        case .terrainHill: return "Terrain Hill"
        case .dirtPatch: return "Dirt Patch"
        case .roadStraight: return "Straight Road"
        case .roadCorner: return "Road Corner"
        case .roadCross: return "Road Cross"
        case .concreteWall: return "Concrete Wall"
        case .woodenFence: return "Wood Fence"
        case .warehouse: return "Warehouse"
        case .smallHouse: return "Small House"
        case .archway: return "Archway"
        case .stairs: return "Stairs"
        case .crateStack: return "Crate Stack"
        case .barrelStack: return "Barrel Stack"
        case .bench: return "Bench"
        case .streetLamp: return "Street Lamp"
        case .signPost: return "Sign Post"
        }
    }

    var baseName: String {
        switch self {
        case .grassSoft: return "Grass Soft"
        case .grassTall: return "Grass Tall"
        case .grassMeadow: return "Grass Meadow"
        case .grassWild: return "Grass Wild"
        case .grassDense: return "Grass Dense"
        case .reeds: return "Reeds"
        case .bush: return "Bush"
        case .flowerPatch: return "Flower Patch"
        case .rockCluster: return "Rock Cluster"
        case .pineTree: return "Pine Tree"
        case .palmTree: return "Palm Tree"
        case .broadleafTree: return "Broadleaf Tree"
        case .cactus: return "Cactus"
        case .fern: return "Fern"
        case .deadTree: return "Dead Tree"
        case .boulder: return "Boulder"
        case .treeStump: return "Tree Stump"
        case .terrainHill: return "Terrain Hill"
        case .dirtPatch: return "Dirt Patch"
        case .roadStraight: return "Road Straight"
        case .roadCorner: return "Road Corner"
        case .roadCross: return "Road Cross"
        case .concreteWall: return "Concrete Wall"
        case .woodenFence: return "Wood Fence"
        case .warehouse: return "Warehouse"
        case .smallHouse: return "Small House"
        case .archway: return "Archway"
        case .stairs: return "Stairs"
        case .crateStack: return "Crate Stack"
        case .barrelStack: return "Barrel Stack"
        case .bench: return "Bench"
        case .streetLamp: return "Street Lamp"
        case .signPost: return "Sign Post"
        }
    }
}


@MainActor
extension StudioStore {
    func addReadyModel(_ kind: ReadyModelKind) {
        pushUndoSnapshot("Add Ready Model")

        let root: SCNNode
        switch kind {
        case .grassSoft:
            root = makeGrassPatch(
                name: kind.baseName,
                tuftCount: 18,
                radius: 1.25,
                minHeight: 0.42,
                maxHeight: 0.72,
                width: 0.16,
                palette: [
                    UIColor(red: 0.16, green: 0.50, blue: 0.15, alpha: 1),
                    UIColor(red: 0.24, green: 0.62, blue: 0.19, alpha: 1),
                    UIColor(red: 0.34, green: 0.70, blue: 0.22, alpha: 1)
                ],
                sway: 0.09,
                speed: 2.4,
                planesPerTuft: 2
            )

        case .grassTall:
            root = makeGrassPatch(
                name: kind.baseName,
                tuftCount: 15,
                radius: 1.35,
                minHeight: 0.85,
                maxHeight: 1.45,
                width: 0.19,
                palette: [
                    UIColor(red: 0.12, green: 0.38, blue: 0.10, alpha: 1),
                    UIColor(red: 0.18, green: 0.52, blue: 0.13, alpha: 1),
                    UIColor(red: 0.29, green: 0.61, blue: 0.16, alpha: 1)
                ],
                sway: 0.16,
                speed: 2.9,
                planesPerTuft: 3
            )

        case .grassMeadow:
            root = makeGrassPatch(
                name: kind.baseName,
                tuftCount: 28,
                radius: 1.7,
                minHeight: 0.35,
                maxHeight: 0.95,
                width: 0.14,
                palette: [
                    UIColor(red: 0.18, green: 0.46, blue: 0.12, alpha: 1),
                    UIColor(red: 0.31, green: 0.63, blue: 0.18, alpha: 1),
                    UIColor(red: 0.42, green: 0.71, blue: 0.20, alpha: 1)
                ],
                sway: 0.11,
                speed: 2.1,
                planesPerTuft: 2
            )

        case .grassWild:
            root = makeGrassPatch(
                name: kind.baseName,
                tuftCount: 22,
                radius: 1.55,
                minHeight: 0.50,
                maxHeight: 1.25,
                width: 0.13,
                palette: [
                    UIColor(red: 0.21, green: 0.37, blue: 0.08, alpha: 1),
                    UIColor(red: 0.34, green: 0.52, blue: 0.10, alpha: 1),
                    UIColor(red: 0.48, green: 0.61, blue: 0.16, alpha: 1)
                ],
                sway: 0.18,
                speed: 3.3,
                planesPerTuft: 3
            )

        case .grassDense:
            root = makeGrassPatch(
                name: kind.baseName,
                tuftCount: 38,
                radius: 1.85,
                minHeight: 0.30,
                maxHeight: 0.74,
                width: 0.12,
                palette: [
                    UIColor(red: 0.10, green: 0.34, blue: 0.08, alpha: 1),
                    UIColor(red: 0.16, green: 0.48, blue: 0.10, alpha: 1),
                    UIColor(red: 0.25, green: 0.57, blue: 0.12, alpha: 1)
                ],
                sway: 0.075,
                speed: 1.9,
                planesPerTuft: 2
            )

        case .reeds:
            root = makeReeds()

        case .bush:
            root = makeBush()

        case .flowerPatch:
            root = makeFlowerPatch()

        case .rockCluster:
            root = makeRockCluster()

        case .pineTree:
            root = makePineTree()
        case .palmTree:
            root = makePalmTree()
        case .broadleafTree:
            root = makeBroadleafTree()
        case .cactus:
            root = makeCactus()
        case .fern:
            root = makeFern()
        case .deadTree:
            root = makeDeadTree()
        case .boulder:
            root = makeBoulder()
        case .treeStump:
            root = makeTreeStump()
        case .terrainHill:
            root = makeTerrainHill()
        case .dirtPatch:
            root = makeDirtPatch()
        case .roadStraight:
            root = makeRoadStraight()
        case .roadCorner:
            root = makeRoadCorner()
        case .roadCross:
            root = makeRoadCross()
        case .concreteWall:
            root = makeConcreteWall()
        case .woodenFence:
            root = makeWoodenFence()
        case .warehouse:
            root = makeWarehouse()
        case .smallHouse:
            root = makeSmallHouse()
        case .archway:
            root = makeArchway()
        case .stairs:
            root = makeStairs()
        case .crateStack:
            root = makeCrateStack()
        case .barrelStack:
            root = makeBarrelStack()
        case .bench:
            root = makeBench()
        case .streetLamp:
            root = makeStreetLamp()
        case .signPost:
            root = makeSignPost()
        }

        root.name = nextName(kind.baseName)
        contentRoot.addChildNode(root)
        placeNewNode(root)
        statusText = appLanguage == .arabic
            ? "تمت إضافة \(kind.title(for: .arabic)) عند نقطة العمل"
            : "Added \(kind.title(for: .english)) at the work point"
        toast = statusText
    }

    private func makeGrassPatch(
        name: String,
        tuftCount: Int,
        radius: CGFloat,
        minHeight: CGFloat,
        maxHeight: CGFloat,
        width: CGFloat,
        palette: [UIColor],
        sway: CGFloat,
        speed: Double,
        planesPerTuft: Int
    ) -> SCNNode {
        let root = SCNNode()
        root.name = name

        for index in 0..<tuftCount {
            let u = readyNoise(index, salt: 11)
            let v = readyNoise(index, salt: 29)
            let angle = readyNoise(index, salt: 47) * CGFloat.pi * 2
            let distance = sqrt(u) * radius
            let x = cos(angle) * distance
            let z = sin(angle) * distance
            let height = minHeight + (maxHeight - minHeight) * v

            let tuft = SCNNode()
            tuft.name = "Grass Tuft \(index + 1)"
            tuft.position = SCNVector3(Float(x), 0, Float(z))
            tuft.eulerAngles.y = Float(readyNoise(index, salt: 61) * CGFloat.pi)

            for planeIndex in 0..<max(1, planesPerTuft) {
                let plane = SCNPlane(
                    width: width * (0.78 + readyNoise(index + planeIndex, salt: 83) * 0.45),
                    height: height
                )
                plane.widthSegmentCount = 1
                plane.heightSegmentCount = 1

                let material = SCNMaterial()
                material.lightingModel = .physicallyBased
                material.diffuse.contents = palette[(index + planeIndex) % palette.count]
                material.roughness.contents = 0.88
                material.metalness.contents = 0.0
                material.isDoubleSided = true
                material.transparency = 0.98
                plane.materials = [material]

                let blade = SCNNode(geometry: plane)
                blade.name = "Blade \(planeIndex + 1)"
                blade.position.y = Float(height * 0.5)
                blade.eulerAngles.y = Float(CGFloat(planeIndex) * (.pi / CGFloat(max(1, planesPerTuft))))
                tuft.addChildNode(blade)
            }

            addWindAction(
                to: tuft,
                amplitude: sway * (0.70 + readyNoise(index, salt: 101) * 0.55),
                duration: speed * Double(0.78 + readyNoise(index, salt: 131) * 0.50),
                phaseDelay: Double(readyNoise(index, salt: 149)) * 0.7
            )
            root.addChildNode(tuft)
        }

        return root
    }

    private func makeReeds() -> SCNNode {
        let root = SCNNode()
        root.name = "Reeds"

        for index in 0..<16 {
            let stemRoot = SCNNode()
            stemRoot.name = "Reed \(index + 1)"
            let angle = readyNoise(index, salt: 13) * CGFloat.pi * 2
            let radius = sqrt(readyNoise(index, salt: 17)) * 1.25
            stemRoot.position = SCNVector3(
                Float(cos(angle) * radius),
                0,
                Float(sin(angle) * radius)
            )

            let height = 1.2 + readyNoise(index, salt: 23) * 1.0
            let stem = SCNCylinder(radius: 0.018, height: height)
            let stemMaterial = SCNMaterial()
            stemMaterial.lightingModel = .physicallyBased
            stemMaterial.diffuse.contents = UIColor(red: 0.34, green: 0.48, blue: 0.12, alpha: 1)
            stemMaterial.roughness.contents = 0.92
            stem.materials = [stemMaterial]

            let stemNode = SCNNode(geometry: stem)
            stemNode.name = "Stem"
            stemNode.position.y = Float(height * 0.5)
            stemRoot.addChildNode(stemNode)

            let head = SCNCapsule(capRadius: 0.055, height: 0.28)
            let headMaterial = SCNMaterial()
            headMaterial.lightingModel = .physicallyBased
            headMaterial.diffuse.contents = UIColor(red: 0.34, green: 0.24, blue: 0.10, alpha: 1)
            headMaterial.roughness.contents = 1.0
            head.materials = [headMaterial]

            let headNode = SCNNode(geometry: head)
            headNode.name = "Seed Head"
            headNode.position.y = Float(height + 0.10)
            stemRoot.addChildNode(headNode)

            addWindAction(
                to: stemRoot,
                amplitude: 0.12 + readyNoise(index, salt: 37) * 0.08,
                duration: 2.6 + Double(readyNoise(index, salt: 41)) * 1.8,
                phaseDelay: Double(readyNoise(index, salt: 43)) * 0.8
            )
            root.addChildNode(stemRoot)
        }
        return root
    }

    private func makeBush() -> SCNNode {
        let root = SCNNode()
        root.name = "Bush"

        let trunkMaterial = SCNMaterial()
        trunkMaterial.lightingModel = .physicallyBased
        trunkMaterial.diffuse.contents = UIColor(red: 0.22, green: 0.13, blue: 0.06, alpha: 1)
        trunkMaterial.roughness.contents = 0.95

        for branchIndex in 0..<7 {
            let branchRoot = SCNNode()
            branchRoot.name = "Branch \(branchIndex + 1)"
            branchRoot.eulerAngles.y = Float(CGFloat(branchIndex) / 7.0 * .pi * 2)

            let branch = SCNCylinder(radius: 0.025, height: 0.78 + readyNoise(branchIndex, salt: 7) * 0.45)
            branch.materials = [trunkMaterial]
            let branchNode = SCNNode(geometry: branch)
            branchNode.position = SCNVector3(0.14, 0.40, 0)
            branchNode.eulerAngles.z = -0.26
            branchRoot.addChildNode(branchNode)

            for leafIndex in 0..<4 {
                let leaf = SCNSphere(radius: 0.20 + readyNoise(branchIndex + leafIndex, salt: 19) * 0.09)
                leaf.segmentCount = 8
                let leafMaterial = SCNMaterial()
                leafMaterial.lightingModel = .physicallyBased
                leafMaterial.diffuse.contents = [
                    UIColor(red: 0.08, green: 0.34, blue: 0.08, alpha: 1),
                    UIColor(red: 0.12, green: 0.46, blue: 0.10, alpha: 1),
                    UIColor(red: 0.20, green: 0.55, blue: 0.12, alpha: 1)
                ][(branchIndex + leafIndex) % 3]
                leafMaterial.roughness.contents = 0.86
                leaf.materials = [leafMaterial]

                let leafNode = SCNNode(geometry: leaf)
                leafNode.name = "Leaves \(leafIndex + 1)"
                leafNode.scale = SCNVector3(1.15, 0.72, 0.90)
                leafNode.position = SCNVector3(
                    Float(0.18 + CGFloat(leafIndex) * 0.10),
                    Float(0.42 + CGFloat(leafIndex) * 0.12),
                    Float((readyNoise(branchIndex + leafIndex, salt: 31) - 0.5) * 0.22)
                )
                branchRoot.addChildNode(leafNode)
            }

            addWindAction(
                to: branchRoot,
                amplitude: 0.055 + readyNoise(branchIndex, salt: 59) * 0.04,
                duration: 2.5 + Double(readyNoise(branchIndex, salt: 71)) * 1.6,
                phaseDelay: Double(readyNoise(branchIndex, salt: 73)) * 0.6
            )
            root.addChildNode(branchRoot)
        }

        return root
    }

    private func makeFlowerPatch() -> SCNNode {
        let root = makeGrassPatch(
            name: "Flower Patch",
            tuftCount: 16,
            radius: 1.15,
            minHeight: 0.22,
            maxHeight: 0.52,
            width: 0.11,
            palette: [
                UIColor(red: 0.18, green: 0.46, blue: 0.10, alpha: 1),
                UIColor(red: 0.29, green: 0.59, blue: 0.15, alpha: 1)
            ],
            sway: 0.07,
            speed: 2.0,
            planesPerTuft: 2
        )

        let flowerColors: [UIColor] = [.systemPink, .systemYellow, .systemPurple, .white, .systemOrange]
        for index in 0..<12 {
            let flowerRoot = SCNNode()
            flowerRoot.name = "Flower \(index + 1)"
            let angle = readyNoise(index, salt: 173) * CGFloat.pi * 2
            let radius = sqrt(readyNoise(index, salt: 179)) * 1.05
            flowerRoot.position = SCNVector3(Float(cos(angle) * radius), 0, Float(sin(angle) * radius))

            let stemHeight = 0.28 + readyNoise(index, salt: 181) * 0.26
            let stem = SCNCylinder(radius: 0.012, height: stemHeight)
            let stemMaterial = SCNMaterial()
            stemMaterial.diffuse.contents = UIColor(red: 0.15, green: 0.42, blue: 0.10, alpha: 1)
            stemMaterial.roughness.contents = 0.95
            stem.materials = [stemMaterial]
            let stemNode = SCNNode(geometry: stem)
            stemNode.position.y = Float(stemHeight * 0.5)
            flowerRoot.addChildNode(stemNode)

            let blossom = SCNSphere(radius: 0.055)
            blossom.segmentCount = 10
            let flowerMaterial = SCNMaterial()
            flowerMaterial.diffuse.contents = flowerColors[index % flowerColors.count]
            flowerMaterial.roughness.contents = 0.75
            blossom.materials = [flowerMaterial]
            let blossomNode = SCNNode(geometry: blossom)
            blossomNode.name = "Blossom"
            blossomNode.scale = SCNVector3(1.25, 0.45, 1.25)
            blossomNode.position.y = Float(stemHeight + 0.02)
            flowerRoot.addChildNode(blossomNode)

            addWindAction(
                to: flowerRoot,
                amplitude: 0.07,
                duration: 2.0 + Double(readyNoise(index, salt: 191)),
                phaseDelay: Double(readyNoise(index, salt: 193)) * 0.6
            )
            root.addChildNode(flowerRoot)
        }
        return root
    }

    private func makeRockCluster() -> SCNNode {
        let root = SCNNode()
        root.name = "Rock Cluster"
        let colors = [
            UIColor(white: 0.23, alpha: 1),
            UIColor(white: 0.31, alpha: 1),
            UIColor(red: 0.28, green: 0.25, blue: 0.21, alpha: 1)
        ]

        for index in 0..<7 {
            let sphere = SCNSphere(radius: 0.34 + readyNoise(index, salt: 211) * 0.34)
            sphere.segmentCount = 12
            let material = SCNMaterial()
            material.lightingModel = .physicallyBased
            material.diffuse.contents = colors[index % colors.count]
            material.roughness.contents = 0.94
            material.metalness.contents = 0.02
            sphere.materials = [material]

            let node = SCNNode(geometry: sphere)
            node.name = "Rock \(index + 1)"
            let angle = readyNoise(index, salt: 223) * CGFloat.pi * 2
            let radius = readyNoise(index, salt: 227) * 0.95
            node.position = SCNVector3(
                Float(cos(angle) * radius),
                Float(0.16 + readyNoise(index, salt: 229) * 0.18),
                Float(sin(angle) * radius)
            )
            node.scale = SCNVector3(
                Float(0.82 + readyNoise(index, salt: 233) * 0.65),
                Float(0.45 + readyNoise(index, salt: 239) * 0.48),
                Float(0.75 + readyNoise(index, salt: 241) * 0.70)
            )
            node.eulerAngles = SCNVector3(
                Float((readyNoise(index, salt: 251) - 0.5) * 0.34),
                Float(readyNoise(index, salt: 257) * CGFloat.pi),
                Float((readyNoise(index, salt: 263) - 0.5) * 0.28)
            )
            root.addChildNode(node)
        }
        return root
    }

    private func makePineTree() -> SCNNode {
        let root = SCNNode()
        root.name = "Pine Tree"

        let trunk = SCNCylinder(radius: 0.16, height: 2.2)
        let trunkMaterial = SCNMaterial()
        trunkMaterial.lightingModel = .physicallyBased
        trunkMaterial.diffuse.contents = UIColor(red: 0.25, green: 0.13, blue: 0.055, alpha: 1)
        trunkMaterial.roughness.contents = 0.96
        trunk.materials = [trunkMaterial]
        let trunkNode = SCNNode(geometry: trunk)
        trunkNode.name = "Trunk"
        trunkNode.position.y = 1.1
        root.addChildNode(trunkNode)

        let leafColors = [
            UIColor(red: 0.06, green: 0.25, blue: 0.08, alpha: 1),
            UIColor(red: 0.08, green: 0.32, blue: 0.10, alpha: 1),
            UIColor(red: 0.10, green: 0.38, blue: 0.12, alpha: 1)
        ]

        for level in 0..<4 {
            let crownRoot = SCNNode()
            crownRoot.name = "Crown \(level + 1)"
            let cone = SCNCone(
                topRadius: 0.03,
                bottomRadius: 1.0 - CGFloat(level) * 0.14,
                height: 1.05
            )
            let material = SCNMaterial()
            material.lightingModel = .physicallyBased
            material.diffuse.contents = leafColors[level % leafColors.count]
            material.roughness.contents = 0.90
            cone.materials = [material]
            let coneNode = SCNNode(geometry: cone)
            coneNode.name = "Needles"
            coneNode.position.y = Float(1.15 + CGFloat(level) * 0.48)
            crownRoot.addChildNode(coneNode)
            addWindAction(
                to: crownRoot,
                amplitude: 0.018 + CGFloat(level) * 0.006,
                duration: 3.1 + Double(level) * 0.35,
                phaseDelay: Double(level) * 0.12
            )
            root.addChildNode(crownRoot)
        }

        return root
    }

    private func readyMaterial(
        _ color: UIColor,
        roughness: CGFloat = 0.85,
        metalness: CGFloat = 0.0,
        emission: UIColor? = nil,
        emissionIntensity: CGFloat = 1.0
    ) -> SCNMaterial {
        let material = SCNMaterial()
        material.lightingModel = .physicallyBased
        material.diffuse.contents = color
        material.roughness.contents = roughness
        material.metalness.contents = metalness
        if let emission {
            material.emission.contents = emission
            material.emission.intensity = emissionIntensity
        }
        return material
    }

    private func makePalmTree() -> SCNNode {
        let root = SCNNode()
        root.name = "Palm Tree"

        let trunk = SCNCylinder(radius: 0.18, height: 2.9)
        trunk.radialSegmentCount = 10
        trunk.materials = [readyMaterial(UIColor(red: 0.38, green: 0.23, blue: 0.10, alpha: 1), roughness: 0.95)]
        let trunkNode = SCNNode(geometry: trunk)
        trunkNode.name = "Trunk"
        trunkNode.position.y = 1.45
        root.addChildNode(trunkNode)

        let crown = SCNNode()
        crown.name = "Palm Crown"
        crown.position.y = 2.9
        let leafMaterial = readyMaterial(UIColor(red: 0.08, green: 0.42, blue: 0.12, alpha: 1), roughness: 0.86)
        leafMaterial.isDoubleSided = true
        for i in 0..<10 {
            let leaf = SCNBox(width: 0.20, height: 0.035, length: 1.55, chamferRadius: 0.05)
            leaf.materials = [leafMaterial]
            let leafNode = SCNNode(geometry: leaf)
            leafNode.name = "Palm Leaf \(i + 1)"
            leafNode.position.z = -0.67
            leafNode.eulerAngles.x = -0.22
            leafNode.eulerAngles.y = Float(i) / 10.0 * Float.pi * 2
            let arm = SCNNode()
            arm.eulerAngles.y = Float(i) / 10.0 * Float.pi * 2
            arm.addChildNode(leafNode)
            crown.addChildNode(arm)
        }
        addWindAction(to: crown, amplitude: 0.035, duration: 3.2, phaseDelay: 0.1)
        root.addChildNode(crown)
        return root
    }

    private func makeBroadleafTree() -> SCNNode {
        let root = SCNNode()
        root.name = "Broadleaf Tree"
        let trunkMaterial = readyMaterial(UIColor(red: 0.28, green: 0.16, blue: 0.07, alpha: 1), roughness: 0.96)
        let leafColors = [
            UIColor(red: 0.07, green: 0.34, blue: 0.08, alpha: 1),
            UIColor(red: 0.10, green: 0.42, blue: 0.10, alpha: 1),
            UIColor(red: 0.16, green: 0.50, blue: 0.12, alpha: 1)
        ]

        let trunk = SCNCylinder(radius: 0.22, height: 2.4)
        trunk.materials = [trunkMaterial]
        let trunkNode = SCNNode(geometry: trunk)
        trunkNode.name = "Trunk"
        trunkNode.position.y = 1.2
        root.addChildNode(trunkNode)

        let crown = SCNNode()
        crown.name = "Crown"
        for i in 0..<8 {
            let sphere = SCNSphere(radius: 0.63 + readyNoise(i, salt: 307) * 0.22)
            sphere.segmentCount = 10
            sphere.materials = [readyMaterial(leafColors[i % leafColors.count], roughness: 0.88)]
            let node = SCNNode(geometry: sphere)
            node.name = "Leaf Cluster \(i + 1)"
            let a = CGFloat(i) / 8 * .pi * 2
            node.position = SCNVector3(Float(cos(a) * 0.72), Float(2.25 + readyNoise(i, salt: 313) * 0.75), Float(sin(a) * 0.72))
            node.scale = SCNVector3(1.0, 0.78, 1.0)
            crown.addChildNode(node)
        }
        addWindAction(to: crown, amplitude: 0.025, duration: 3.6, phaseDelay: 0.15)
        root.addChildNode(crown)
        return root
    }

    private func makeCactus() -> SCNNode {
        let root = SCNNode()
        root.name = "Cactus"
        let green = readyMaterial(UIColor(red: 0.10, green: 0.43, blue: 0.22, alpha: 1), roughness: 0.78)

        let body = SCNCapsule(capRadius: 0.22, height: 2.1)
        body.materials = [green]
        let bodyNode = SCNNode(geometry: body)
        bodyNode.name = "Main Stem"
        bodyNode.position.y = 1.05
        root.addChildNode(bodyNode)

        for (index, side) in [-1.0, 1.0].enumerated() {
            let armRoot = SCNNode()
            armRoot.name = "Arm \(index + 1)"
            armRoot.position = SCNVector3(Float(side * 0.24), 1.05 + Float(index) * 0.30, 0)

            let arm = SCNCapsule(capRadius: 0.12, height: 0.75)
            arm.materials = [green]
            let armNode = SCNNode(geometry: arm)
            armNode.eulerAngles.z = Float(side * Double.pi / 2)
            armNode.position.x = Float(side * 0.30)
            armRoot.addChildNode(armNode)

            let tip = SCNCapsule(capRadius: 0.12, height: 0.65)
            tip.materials = [green]
            let tipNode = SCNNode(geometry: tip)
            tipNode.position = SCNVector3(Float(side * 0.60), 0.27, 0)
            armRoot.addChildNode(tipNode)
            root.addChildNode(armRoot)
        }
        return root
    }

    private func makeFern() -> SCNNode {
        let root = SCNNode()
        root.name = "Fern"
        let material = readyMaterial(UIColor(red: 0.08, green: 0.45, blue: 0.13, alpha: 1), roughness: 0.90)
        material.isDoubleSided = true
        for i in 0..<12 {
            let branch = SCNNode()
            branch.name = "Fern Frond \(i + 1)"
            branch.eulerAngles.y = Float(i) / 12 * Float.pi * 2
            let leaf = SCNBox(width: 0.13, height: 0.025, length: 1.15, chamferRadius: 0.035)
            leaf.materials = [material]
            let leafNode = SCNNode(geometry: leaf)
            leafNode.position = SCNVector3(0, 0.32, -0.48)
            leafNode.eulerAngles.x = -0.45
            branch.addChildNode(leafNode)
            addWindAction(to: branch, amplitude: 0.04, duration: 2.7 + Double(i % 3) * 0.25, phaseDelay: Double(i) * 0.03)
            root.addChildNode(branch)
        }
        return root
    }

    private func makeDeadTree() -> SCNNode {
        let root = SCNNode()
        root.name = "Dead Tree"
        let wood = readyMaterial(UIColor(red: 0.29, green: 0.20, blue: 0.12, alpha: 1), roughness: 1)
        let trunk = SCNCylinder(radius: 0.20, height: 2.8)
        trunk.materials = [wood]
        let trunkNode = SCNNode(geometry: trunk)
        trunkNode.name = "Dry Trunk"
        trunkNode.position.y = 1.4
        root.addChildNode(trunkNode)

        for i in 0..<6 {
            let branch = SCNCylinder(radius: 0.055, height: 1.15)
            branch.materials = [wood]
            let node = SCNNode(geometry: branch)
            node.name = "Dry Branch \(i + 1)"
            node.position = SCNVector3(0, 1.75 + Float(i % 3) * 0.30, 0)
            node.eulerAngles = SCNVector3(0, Float(i) / 6 * Float.pi * 2, Float(i % 2 == 0 ? -0.78 : 0.78))
            root.addChildNode(node)
        }
        return root
    }

    private func makeBoulder() -> SCNNode {
        let root = SCNNode()
        root.name = "Boulder"
        let rock = SCNSphere(radius: 0.95)
        rock.segmentCount = 12
        rock.materials = [readyMaterial(UIColor(red: 0.27, green: 0.25, blue: 0.22, alpha: 1), roughness: 0.97)]
        let node = SCNNode(geometry: rock)
        node.name = "Boulder Mesh"
        node.scale = SCNVector3(1.25, 0.70, 1.0)
        node.position.y = 0.58
        node.eulerAngles = SCNVector3(0.10, 0.35, -0.08)
        root.addChildNode(node)
        return root
    }

    private func makeTreeStump() -> SCNNode {
        let root = SCNNode()
        root.name = "Tree Stump"
        let bark = readyMaterial(UIColor(red: 0.28, green: 0.16, blue: 0.07, alpha: 1), roughness: 0.98)
        let cut = readyMaterial(UIColor(red: 0.55, green: 0.38, blue: 0.19, alpha: 1), roughness: 0.92)
        let body = SCNCylinder(radius: 0.48, height: 0.75)
        body.radialSegmentCount = 10
        body.materials = [bark]
        let bodyNode = SCNNode(geometry: body)
        bodyNode.name = "Stump Body"
        bodyNode.position.y = 0.375
        root.addChildNode(bodyNode)
        let top = SCNCylinder(radius: 0.43, height: 0.025)
        top.materials = [cut]
        let topNode = SCNNode(geometry: top)
        topNode.name = "Cut Surface"
        topNode.position.y = 0.76
        root.addChildNode(topNode)
        return root
    }

    private func makeTerrainHill() -> SCNNode {
        let root = SCNNode()
        root.name = "Terrain Hill"
        let hill = SCNSphere(radius: 2.2)
        hill.segmentCount = 20
        hill.materials = [readyMaterial(UIColor(red: 0.20, green: 0.37, blue: 0.12, alpha: 1), roughness: 1)]
        let node = SCNNode(geometry: hill)
        node.name = "Hill"
        node.scale = SCNVector3(1.5, 0.34, 1.15)
        node.position.y = -0.05
        root.addChildNode(node)
        return root
    }

    private func makeDirtPatch() -> SCNNode {
        let root = SCNNode()
        root.name = "Dirt Patch"
        let dirt = SCNCylinder(radius: 1.9, height: 0.06)
        dirt.radialSegmentCount = 24
        dirt.materials = [readyMaterial(UIColor(red: 0.35, green: 0.22, blue: 0.11, alpha: 1), roughness: 1)]
        let node = SCNNode(geometry: dirt)
        node.name = "Dirt"
        node.position.y = 0.03
        root.addChildNode(node)
        return root
    }

    private func roadBase(length: CGFloat, width: CGFloat = 3.2) -> SCNNode {
        let root = SCNNode()
        let road = SCNBox(width: width, height: 0.08, length: length, chamferRadius: 0.03)
        road.materials = [readyMaterial(UIColor(white: 0.12, alpha: 1), roughness: 0.96)]
        let roadNode = SCNNode(geometry: road)
        roadNode.name = "Asphalt"
        roadNode.position.y = 0.04
        root.addChildNode(roadNode)

        let lineMaterial = readyMaterial(UIColor(red: 0.95, green: 0.78, blue: 0.12, alpha: 1), roughness: 0.75)
        let segmentCount = max(1, Int(length / 1.0))
        for i in 0..<segmentCount {
            if i % 2 == 0 {
                let line = SCNBox(width: 0.08, height: 0.015, length: 0.55, chamferRadius: 0.01)
                line.materials = [lineMaterial]
                let lineNode = SCNNode(geometry: line)
                lineNode.name = "Center Mark \(i + 1)"
                lineNode.position = SCNVector3(0, 0.09, Float(-length / 2 + 0.5 + CGFloat(i)))
                root.addChildNode(lineNode)
            }
        }
        return root
    }

    private func makeRoadStraight() -> SCNNode {
        let root = roadBase(length: 6.0)
        root.name = "Road Straight"
        return root
    }

    private func makeRoadCorner() -> SCNNode {
        let root = SCNNode()
        root.name = "Road Corner"
        let a = roadBase(length: 4.0)
        a.name = "Road Leg A"
        a.position.z = -1.8
        root.addChildNode(a)
        let b = roadBase(length: 4.0)
        b.name = "Road Leg B"
        b.eulerAngles.y = .pi / 2
        b.position.x = 1.8
        root.addChildNode(b)
        return root
    }

    private func makeRoadCross() -> SCNNode {
        let root = SCNNode()
        root.name = "Road Cross"
        let vertical = roadBase(length: 7.0)
        vertical.name = "North South"
        root.addChildNode(vertical)
        let horizontal = roadBase(length: 7.0)
        horizontal.name = "East West"
        horizontal.eulerAngles.y = .pi / 2
        root.addChildNode(horizontal)
        return root
    }

    private func makeConcreteWall() -> SCNNode {
        let root = SCNNode()
        root.name = "Concrete Wall"
        let mat = readyMaterial(UIColor(white: 0.46, alpha: 1), roughness: 0.94)
        let wall = SCNBox(width: 4.0, height: 2.2, length: 0.24, chamferRadius: 0.04)
        wall.materials = [mat]
        let node = SCNNode(geometry: wall)
        node.name = "Wall"
        node.position.y = 1.1
        root.addChildNode(node)
        return root
    }

    private func makeWoodenFence() -> SCNNode {
        let root = SCNNode()
        root.name = "Wood Fence"
        let wood = readyMaterial(UIColor(red: 0.42, green: 0.24, blue: 0.10, alpha: 1), roughness: 0.95)
        for i in 0..<7 {
            let post = SCNBox(width: 0.16, height: 1.45, length: 0.16, chamferRadius: 0.025)
            post.materials = [wood]
            let n = SCNNode(geometry: post)
            n.name = "Fence Post \(i + 1)"
            n.position = SCNVector3(Float(-2.1 + CGFloat(i) * 0.7), 0.725, 0)
            root.addChildNode(n)
        }
        for i in 0..<2 {
            let rail = SCNBox(width: 4.4, height: 0.14, length: 0.12, chamferRadius: 0.02)
            rail.materials = [wood]
            let n = SCNNode(geometry: rail)
            n.name = "Fence Rail \(i + 1)"
            n.position = SCNVector3(0, Float(0.48 + CGFloat(i) * 0.62), 0)
            root.addChildNode(n)
        }
        return root
    }

    private func makeWarehouse() -> SCNNode {
        let root = SCNNode()
        root.name = "Warehouse"
        let wallMat = readyMaterial(UIColor(red: 0.35, green: 0.38, blue: 0.40, alpha: 1), roughness: 0.86, metalness: 0.18)
        let dark = readyMaterial(UIColor(white: 0.08, alpha: 1), roughness: 0.78, metalness: 0.25)
        let body = SCNBox(width: 5.2, height: 2.7, length: 4.2, chamferRadius: 0.05)
        body.materials = [wallMat]
        let bodyNode = SCNNode(geometry: body)
        bodyNode.name = "Warehouse Body"
        bodyNode.position.y = 1.35
        root.addChildNode(bodyNode)

        let door = SCNBox(width: 2.2, height: 2.15, length: 0.08, chamferRadius: 0.02)
        door.materials = [dark]
        let doorNode = SCNNode(geometry: door)
        doorNode.name = "Large Door"
        doorNode.position = SCNVector3(0, 1.075, 2.14)
        root.addChildNode(doorNode)

        let roof = SCNBox(width: 5.45, height: 0.16, length: 4.45, chamferRadius: 0.04)
        roof.materials = [dark]
        let roofNode = SCNNode(geometry: roof)
        roofNode.name = "Roof"
        roofNode.position.y = 2.78
        root.addChildNode(roofNode)
        return root
    }

    private func makeSmallHouse() -> SCNNode {
        let root = SCNNode()
        root.name = "Small House"
        let wall = readyMaterial(UIColor(red: 0.72, green: 0.65, blue: 0.52, alpha: 1), roughness: 0.92)
        let roofMat = readyMaterial(UIColor(red: 0.32, green: 0.10, blue: 0.07, alpha: 1), roughness: 0.90)
        let body = SCNBox(width: 3.2, height: 2.2, length: 2.8, chamferRadius: 0.04)
        body.materials = [wall]
        let bodyNode = SCNNode(geometry: body)
        bodyNode.name = "House Body"
        bodyNode.position.y = 1.1
        root.addChildNode(bodyNode)
        let roof = SCNPyramid(width: 3.7, height: 1.1, length: 3.3)
        roof.materials = [roofMat]
        let roofNode = SCNNode(geometry: roof)
        roofNode.name = "Roof"
        roofNode.position.y = 2.72
        root.addChildNode(roofNode)
        let door = SCNBox(width: 0.72, height: 1.55, length: 0.06, chamferRadius: 0.02)
        door.materials = [readyMaterial(UIColor(red: 0.22, green: 0.12, blue: 0.05, alpha: 1), roughness: 0.95)]
        let doorNode = SCNNode(geometry: door)
        doorNode.name = "Door"
        doorNode.position = SCNVector3(0, 0.775, 1.43)
        root.addChildNode(doorNode)
        return root
    }

    private func makeArchway() -> SCNNode {
        let root = SCNNode()
        root.name = "Archway"
        let stone = readyMaterial(UIColor(white: 0.48, alpha: 1), roughness: 0.96)
        for side in [-1.0, 1.0] {
            let pillar = SCNBox(width: 0.55, height: 2.7, length: 0.75, chamferRadius: 0.05)
            pillar.materials = [stone]
            let node = SCNNode(geometry: pillar)
            node.name = side < 0 ? "Left Pillar" : "Right Pillar"
            node.position = SCNVector3(Float(side * 1.15), 1.35, 0)
            root.addChildNode(node)
        }
        let top = SCNBox(width: 2.85, height: 0.62, length: 0.78, chamferRadius: 0.08)
        top.materials = [stone]
        let topNode = SCNNode(geometry: top)
        topNode.name = "Arch Top"
        topNode.position.y = 2.65
        root.addChildNode(topNode)
        return root
    }

    private func makeStairs() -> SCNNode {
        let root = SCNNode()
        root.name = "Stairs"
        let concrete = readyMaterial(UIColor(white: 0.44, alpha: 1), roughness: 0.96)
        for i in 0..<8 {
            let width: CGFloat = 2.4
            let height = CGFloat(i + 1) * 0.22
            let step = SCNBox(width: width, height: height, length: 0.42, chamferRadius: 0.015)
            step.materials = [concrete]
            let node = SCNNode(geometry: step)
            node.name = "Step \(i + 1)"
            node.position = SCNVector3(0, Float(height / 2), Float(CGFloat(i) * -0.40))
            root.addChildNode(node)
        }
        return root
    }

    private func makeCrateStack() -> SCNNode {
        let root = SCNNode()
        root.name = "Crate Stack"
        let wood = readyMaterial(UIColor(red: 0.48, green: 0.29, blue: 0.12, alpha: 1), roughness: 0.90)
        let positions: [SCNVector3] = [
            SCNVector3(-0.55, 0.45, 0), SCNVector3(0.55, 0.45, 0), SCNVector3(0, 1.30, 0.08)
        ]
        for (i, pos) in positions.enumerated() {
            let crate = SCNBox(width: 0.95, height: 0.85, length: 0.95, chamferRadius: 0.035)
            crate.materials = [wood]
            let node = SCNNode(geometry: crate)
            node.name = "Crate \(i + 1)"
            node.position = pos
            node.eulerAngles.y = Float(i) * 0.12
            root.addChildNode(node)
        }
        return root
    }

    private func makeBarrelStack() -> SCNNode {
        let root = SCNNode()
        root.name = "Barrel Stack"
        let metal = readyMaterial(UIColor(red: 0.13, green: 0.24, blue: 0.31, alpha: 1), roughness: 0.55, metalness: 0.65)
        let positions: [SCNVector3] = [
            SCNVector3(-0.48, 0.55, 0), SCNVector3(0.48, 0.55, 0), SCNVector3(0, 1.60, 0)
        ]
        for (i, pos) in positions.enumerated() {
            let barrel = SCNCylinder(radius: 0.42, height: 1.05)
            barrel.radialSegmentCount = 16
            barrel.materials = [metal]
            let node = SCNNode(geometry: barrel)
            node.name = "Barrel \(i + 1)"
            node.position = pos
            root.addChildNode(node)
        }
        return root
    }

    private func makeBench() -> SCNNode {
        let root = SCNNode()
        root.name = "Bench"
        let wood = readyMaterial(UIColor(red: 0.44, green: 0.25, blue: 0.10, alpha: 1), roughness: 0.88)
        let metal = readyMaterial(UIColor(white: 0.15, alpha: 1), roughness: 0.45, metalness: 0.8)
        for y in [0.62, 0.96] as [Float] {
            let slat = SCNBox(width: 2.6, height: 0.16, length: 0.42, chamferRadius: 0.03)
            slat.materials = [wood]
            let node = SCNNode(geometry: slat)
            node.name = y < 0.8 ? "Seat" : "Back"
            node.position = SCNVector3(0, y, y < 0.8 ? 0 : -0.30)
            if y > 0.8 { node.eulerAngles.x = -0.10 }
            root.addChildNode(node)
        }
        for x in [-0.9, 0.9] as [Float] {
            let leg = SCNBox(width: 0.12, height: 0.65, length: 0.12, chamferRadius: 0.02)
            leg.materials = [metal]
            let node = SCNNode(geometry: leg)
            node.name = x < 0 ? "Left Leg" : "Right Leg"
            node.position = SCNVector3(x, 0.325, 0)
            root.addChildNode(node)
        }
        return root
    }

    private func makeStreetLamp() -> SCNNode {
        let root = SCNNode()
        root.name = "Street Lamp"
        let metal = readyMaterial(UIColor(white: 0.12, alpha: 1), roughness: 0.42, metalness: 0.85)
        let pole = SCNCylinder(radius: 0.075, height: 3.4)
        pole.materials = [metal]
        let poleNode = SCNNode(geometry: pole)
        poleNode.name = "Lamp Pole"
        poleNode.position.y = 1.7
        root.addChildNode(poleNode)
        let arm = SCNBox(width: 0.8, height: 0.08, length: 0.08, chamferRadius: 0.03)
        arm.materials = [metal]
        let armNode = SCNNode(geometry: arm)
        armNode.name = "Lamp Arm"
        armNode.position = SCNVector3(0.34, 3.35, 0)
        root.addChildNode(armNode)
        let bulbColor = UIColor(red: 1.0, green: 0.82, blue: 0.42, alpha: 1)
        let bulb = SCNSphere(radius: 0.15)
        bulb.materials = [readyMaterial(UIColor(white: 0.90, alpha: 1), roughness: 0.25, emission: bulbColor, emissionIntensity: 2.5)]
        let bulbNode = SCNNode(geometry: bulb)
        bulbNode.name = "Lamp Bulb"
        bulbNode.position = SCNVector3(0.68, 3.27, 0)
        let light = SCNLight()
        light.type = .omni
        light.color = bulbColor
        light.intensity = 500
        light.attenuationEndDistance = 9
        bulbNode.light = light
        root.addChildNode(bulbNode)
        return root
    }

    private func makeSignPost() -> SCNNode {
        let root = SCNNode()
        root.name = "Sign Post"
        let metal = readyMaterial(UIColor(white: 0.20, alpha: 1), roughness: 0.55, metalness: 0.68)
        let post = SCNCylinder(radius: 0.07, height: 2.35)
        post.materials = [metal]
        let postNode = SCNNode(geometry: post)
        postNode.name = "Post"
        postNode.position.y = 1.175
        root.addChildNode(postNode)
        let board = SCNBox(width: 1.65, height: 0.75, length: 0.08, chamferRadius: 0.07)
        board.materials = [readyMaterial(UIColor(red: 0.10, green: 0.34, blue: 0.68, alpha: 1), roughness: 0.68, metalness: 0.10)]
        let boardNode = SCNNode(geometry: board)
        boardNode.name = "Sign Board"
        boardNode.position.y = 2.15
        root.addChildNode(boardNode)
        return root
    }

    private func addWindAction(
        to node: SCNNode,
        amplitude: CGFloat,
        duration: Double,
        phaseDelay: Double
    ) {
        let left = SCNAction.rotateBy(x: 0, y: 0, z: amplitude, duration: duration * 0.5)
        left.timingMode = .easeInEaseOut
        let right = SCNAction.rotateBy(x: 0, y: 0, z: -amplitude * 2, duration: duration)
        right.timingMode = .easeInEaseOut
        let center = SCNAction.rotateBy(x: 0, y: 0, z: amplitude, duration: duration * 0.5)
        center.timingMode = .easeInEaseOut
        let loop = SCNAction.repeatForever(.sequence([left, right, center]))

        if phaseDelay > 0.001 {
            node.runAction(.sequence([.wait(duration: phaseDelay), loop]), forKey: "5LnReadyWind")
        } else {
            node.runAction(loop, forKey: "5LnReadyWind")
        }
    }

    private func readyNoise(_ index: Int, salt: Int) -> CGFloat {
        let x = sin(Double(index * 127 + salt * 311) * 12.9898) * 43758.5453
        return CGFloat(x - floor(x))
    }
}
