import Foundation

enum VideoImportStage: String, Codable {
    case copying, inspecting, decoding, preparing, adding, starting
    func label(arabic: Bool) -> String {
        switch self {
        case .copying: return arabic ? "نسخ ملف الفيديو" : "Copying the video file"
        case .inspecting: return arabic ? "قراءة بيانات الفيديو" : "Reading video information"
        case .decoding: return arabic ? "قراءة أول صورة من الفيديو" : "Decoding the first movie image"
        case .preparing: return arabic ? "تجهيز تشغيل الفيديو" : "Preparing video playback"
        case .adding: return arabic ? "إضافة الفيديو إلى المشهد" : "Adding the video to the scene"
        case .starting: return arabic ? "بدء تشغيل الفيديو" : "Starting video playback"
        }
    }
}

struct VideoImportJournal {
    enum State: String, Codable { case active, completed, failed, cancelled, interrupted }
    struct Record: Codable {
        let attempt: UUID
        let filename: String
        var stage: VideoImportStage
        var state: State
        var updated: Date
        var error: String?
    }
    let folder: URL
    var url: URL { folder.appendingPathComponent("VideoImport.last.json") }

    func read() -> Record? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(Record.self, from: data)
    }
    @discardableResult
    func begin(filename: String) -> UUID {
        let attempt = UUID()
        write(Record(attempt: attempt, filename: filename, stage: .copying, state: .active, updated: Date()))
        return attempt
    }
    func advance(_ attempt: UUID, to stage: VideoImportStage) {
        guard var record = read(), record.attempt == attempt, record.state == .active else { return }
        record.stage = stage; record.updated = Date(); write(record)
    }
    func finish(_ attempt: UUID, state: State, error: Error? = nil) {
        guard state != .active, var record = read(), record.attempt == attempt, record.state == .active else { return }
        record.state = state; record.updated = Date()
        if let error {
            let failure = error as NSError
            record.error = "\(failure.domain) (\(failure.code)): \(failure.localizedDescription)"
        }
        write(record)
    }
    /// This is an interrupted operation, not a claim about the OS termination reason.
    func consumeInterrupted() -> Record? {
        guard let record = read(), record.state == .active else { return nil }
        finish(record.attempt, state: .interrupted)
        return record
    }
    func report() -> String? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        return String(data: data, encoding: .utf8)
    }
    private func write(_ record: Record) {
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            try encoder.encode(record).write(to: url, options: .atomic)
        } catch {
            // A diagnostic failure must not destroy a working scene or prevent importing.
            fputs("3DMOTION VIDEO_IMPORT diagnostic write failed: \(error.localizedDescription)\n", stderr)
        }
        fputs("3DMOTION VIDEO_IMPORT \(record.stage.rawValue) \(record.state.rawValue)\n", stderr)
    }
}
