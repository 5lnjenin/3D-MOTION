import Foundation
import SceneKit
import UIKit

/// Wavefront image paths belong to the MTL that declares them. SceneKit's OBJ
/// loader can instead leave them relative to the OBJ, including broken strings.
enum OBJMaterialResources {
    struct Texture {
        var command: String
        var path: String
        var scale: [Float]?
        var offset: [Float]?
        var clamp: Bool?
        var bumpMultiplier: Float?
    }

    static func words(_ line: String) -> [String] {
        var result: [String] = [], current = ""
        var quote: Character?
        for character in line {
            if let active = quote {
                if character == active { quote = nil } else { current.append(character) }
            } else if character == "\"" || character == "'" {
                quote = character
            } else if character == "#" {
                break
            } else if character.isWhitespace {
                if !current.isEmpty { result.append(current); current = "" }
            } else {
                current.append(character)
            }
        }
        if !current.isEmpty { result.append(current) }
        return result
    }

    static func lines(_ url: URL) -> [[String]] {
        guard let data = try? Data(contentsOf: url), data.count <= 8 * 1024 * 1024,
              let text = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1) else { return [] }
        return text.split(whereSeparator: \.isNewline).map { words(String($0)) }.filter { !$0.isEmpty }
    }

    static func materialLibraries(_ obj: URL) -> [String] {
        lines(obj).filter { $0[0].lowercased() == "mtllib" }.flatMap { tokens -> [String] in
            let names = Array(tokens.dropFirst())
            // Some exporters use an unquoted single filename containing spaces.
            let whole = names.joined(separator: " ")
            if FileManager.default.fileExists(atPath: obj.deletingLastPathComponent().appendingPathComponent(whole).path) { return [whole] }
            return names
        }
    }

    static func texture(_ tokens: [String]) -> Texture? {
        guard let command = tokens.first?.lowercased(),
              ["map_kd", "map_ka", "map_ks", "map_ke", "map_d", "map_pr", "map_pm", "map_ao", "bump", "map_bump", "disp", "decal", "norm", "refl"].contains(command) else { return nil }
        var result = Texture(command: command, path: "")
        var index = 1
        while index < tokens.count, tokens[index].hasPrefix("-") {
            let option = tokens[index].lowercased(); index += 1
            if ["-s", "-o", "-t"].contains(option) {
                var values: [Float] = []
                while index < tokens.count, values.count < 3, let value = Float(tokens[index]), value.isFinite {
                    values.append(value); index += 1
                }
                if option == "-s" { result.scale = values }
                if option == "-o" { result.offset = values }
            } else if option == "-halo" {
                continue
            } else {
                let count = option == "-mm" ? 2 : 1
                guard index + count <= tokens.count else { return nil }
                if option == "-clamp" { result.clamp = tokens[index].lowercased() == "on" }
                if option == "-bm" { result.bumpMultiplier = Float(tokens[index]) }
                index += count
            }
        }
        guard index < tokens.count else { return nil }
        result.path = tokens[index...].joined(separator: " ").replacingOccurrences(of: "\\", with: "/")
        return result
    }

    static func texturePaths(_ mtl: URL) -> [String] { lines(mtl).compactMap { texture($0)?.path } }

    static func property(_ command: String, material: SCNMaterial) -> SCNMaterialProperty? {
        switch command {
        case "map_kd": return material.diffuse
        case "map_ka": return material.ambient
        case "map_ks": return material.specular
        case "map_ke": return material.emission
        case "map_d": return material.transparent
        case "map_pr": return material.roughness
        case "map_pm": return material.metalness
        case "map_ao": return material.ambientOcclusion
        case "bump", "map_bump", "norm": return material.normal
        case "disp": return material.displacement
        case "refl": return material.reflective
        default: return nil
        }
    }

    static func bindImages(in root: SCNNode, obj: URL) throws {
        var definitions: [String: [(Texture, URL)]] = [:]
        let objFolder = obj.deletingLastPathComponent()
        for name in materialLibraries(obj) {
            let mtl = objFolder.appendingPathComponent(name).standardizedFileURL
            guard FileManager.default.isReadableFile(atPath: mtl.path) else {
                throw StudioImportError.cannotStage(obj.lastPathComponent, "Missing material library: \(name)")
            }
            var current: String?
            for tokens in lines(mtl) {
                if tokens[0].lowercased() == "newmtl" {
                    current = tokens.dropFirst().joined(separator: " ")
                    if let current { definitions[current] = [] }
                } else if let current, let image = texture(tokens) {
                    definitions[current, default: []].append((image, mtl.deletingLastPathComponent()))
                }
            }
        }
        var seen = Set<ObjectIdentifier>()
        for node in ProjectSceneCodec.nodes(in: root) {
            for material in node.geometry?.materials ?? [] where seen.insert(ObjectIdentifier(material)).inserted {
                guard let name = material.name, let textures = definitions[name] else { continue }
                for (texture, folder) in textures {
                    guard let property = property(texture.command, material: material) else { continue }
                    let declared = folder.appendingPathComponent(texture.path).standardizedFileURL
                    let objRelative = objFolder.appendingPathComponent(texture.path).standardizedFileURL
                    let url = FileManager.default.fileExists(atPath: declared.path) ? declared : objRelative
                    guard let image = UIImage(contentsOfFile: url.path) else {
                        throw StudioImportError.cannotStage(obj.lastPathComponent, "Missing texture for material \(name): \(texture.path)")
                    }
                    // Retain the geometry's material order, colors, mapping channel,
                    // filtering and other imported properties; replace only the map.
                    property.contents = image
                    if let clamp = texture.clamp { property.wrapS = clamp ? .clamp : .repeat; property.wrapT = clamp ? .clamp : .repeat }
                    if texture.scale != nil || texture.offset != nil {
                        let scale = texture.scale ?? [], offset = texture.offset ?? []
                        var transform = SCNMatrix4Identity
                        transform.m11 = scale.first ?? 1; transform.m22 = scale.count > 1 ? scale[1] : 1
                        transform.m41 = offset.first ?? 0; transform.m42 = offset.count > 1 ? offset[1] : 0
                        property.contentsTransform = transform
                    }
                    if let multiplier = texture.bumpMultiplier, multiplier.isFinite { property.intensity = CGFloat(multiplier) }
                }
            }
        }
    }
}
