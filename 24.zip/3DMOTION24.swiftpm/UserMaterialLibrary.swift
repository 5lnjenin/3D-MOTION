import Foundation
import UIKit
import SceneKit

struct UserMaterialPayload: Codable {
    var version = 1
    var material: ProjectMaterialRecord
    var resources: [String: ProjectResource]
    var checksum: String

    private struct Content: Codable {
        var version: Int
        var material: ProjectMaterialRecord
        var resources: [String: ProjectResource]
    }
    private func digest() throws -> String {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
        return ProjectIntegrity.hash(try encoder.encode(Content(version: version, material: material, resources: resources)))
    }
    mutating func seal() throws { checksum = try digest() }
    func validate() throws {
        try material.validateShaderFactors()
        guard version == 1, checksum == (try digest()), !material.archive.isEmpty,
              resources.count <= 32,
              resources.values.reduce(0, { $0 + $1.data.count }) <= 128 * 1024 * 1024 else { throw MaterialImportFailure.damaged }
        for (id, resource) in resources {
            guard id == ProjectIntegrity.hash(resource.data), resource.kind == "image", !resource.data.isEmpty else { throw MaterialImportFailure.damaged }
        }
        for property in material.properties.values { try property.value.validate(resources: resources) }
    }
}

struct UserMaterialCard: Codable, Identifiable {
    var id: String
    var batchID: String
    var name: String
    var created: Date
    var source: MaterialSourceCredit
}

@MainActor
final class UserMaterialLibrary: ObservableObject {
    static let shared = UserMaterialLibrary()
    @Published private(set) var cards: [UserMaterialCard] = []
    @Published var errorText = ""
    let directory: URL
    private var thumbnails: [String: UIImage] = [:]

    init(directory: URL? = nil) {
        self.directory = directory ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("5LnPersonalMaterials", isDirectory: true)
        do { try reload() } catch { errorText = error.localizedDescription }
    }

    private func folder(_ card: UserMaterialCard) throws -> URL {
        guard UUID(uuidString: card.id) != nil, UUID(uuidString: card.batchID) != nil else { throw MaterialImportFailure.damaged }
        return directory.appendingPathComponent(card.batchID, isDirectory: true).appendingPathComponent(card.id, isDirectory: true)
    }
    func reload() throws {
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        var result: [UserMaterialCard] = []
        for batch in try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)
            where UUID(uuidString: batch.lastPathComponent) != nil {
            for item in try FileManager.default.contentsOfDirectory(at: batch, includingPropertiesForKeys: nil)
                where UUID(uuidString: item.lastPathComponent) != nil {
                let metadata = item.appendingPathComponent("Card.json")
                guard let bytes = try? Data(contentsOf: metadata), bytes.count < 64 * 1024,
                      let card = try? JSONDecoder().decode(UserMaterialCard.self, from: bytes),
                      card.id == item.lastPathComponent, card.batchID == batch.lastPathComponent,
                      FileManager.default.fileExists(atPath: item.appendingPathComponent("Material.json").path) else { continue }
                result.append(card)
            }
        }
        cards = result.sorted { $0.created == $1.created ? $0.name.localizedStandardCompare($1.name) == .orderedAscending : $0.created > $1.created }
    }

    func thumbnail(_ card: UserMaterialCard) -> UIImage? {
        guard let path = try? folder(card).appendingPathComponent("Thumbnail.png") else { return nil }
        if let cached = thumbnails[card.id] { return cached }
        guard let image = UIImage(contentsOfFile: path.path) else { return nil }
        if thumbnails.count >= 64 { thumbnails.removeAll() }
        thumbnails[card.id] = image
        return image
    }
    func material(_ card: UserMaterialCard) throws -> SCNMaterial {
        let path = try folder(card).appendingPathComponent("Material.json")
        let size = try path.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
        guard size > 0, size <= 192 * 1024 * 1024 else { throw MaterialImportFailure.damaged }
        let payload = try JSONDecoder().decode(UserMaterialPayload.self, from: Data(contentsOf: path))
        try payload.validate()
        let decoder = ProjectSceneCodec.Decoder(resources: payload.resources, folder: try folder(card))
        let material = try decoder.material(payload.material); material.name = card.name
        return material
    }

    // The entire batch becomes visible through one directory rename. Errors,
    // cancellation and partial encodes never replace an existing library item.
    @discardableResult
    func add(_ materials: [(String, SCNMaterial)], source: MaterialSourceCredit) async throws -> [UserMaterialCard] {
        guard !materials.isEmpty, materials.count <= 64 else { throw MaterialImportFailure.noMaterials }
        let batchID = UUID().uuidString
        let staging = directory.appendingPathComponent("." + batchID + ".staging", isDirectory: true)
        let destination = directory.appendingPathComponent(batchID, isDirectory: true)
        try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: staging) }
        var added: [UserMaterialCard] = [], resourceBytes = 0
        for (name, material) in materials {
            try Task.checkCancellation()
            let clean = name.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty, clean.utf8.count <= 512 else { throw MaterialImportFailure.invalid("اسم الخامة غير صالح / Invalid material name") }
            var resources: [String: ProjectResource] = [:]
            let record = try ProjectSceneCodec.captureMaterial(material, resources: &resources)
            resourceBytes += resources.values.reduce(0) { $0 + $1.data.count }
            guard resourceBytes <= 128 * 1024 * 1024 else { throw MaterialImportFailure.tooLarge }
            var payload = UserMaterialPayload(material: record, resources: resources, checksum: "")
            try payload.seal(); try payload.validate()
            let card = UserMaterialCard(id: UUID().uuidString, batchID: batchID, name: clean, created: Date(), source: source)
            let item = staging.appendingPathComponent(card.id, isDirectory: true)
            try FileManager.default.createDirectory(at: item, withIntermediateDirectories: true)
            try JSONEncoder().encode(payload).write(to: item.appendingPathComponent("Material.json"), options: .atomic)
            try JSONEncoder().encode(card).write(to: item.appendingPathComponent("Card.json"), options: .atomic)
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 96, height: 96))
            let image = renderer.image { context in
                if let texture = material.diffuse.contents as? UIImage {
                    texture.draw(in: CGRect(x: 0, y: 0, width: 96, height: 96))
                } else {
                    ((material.diffuse.contents as? UIColor) ?? .gray).setFill()
                    context.fill(CGRect(x: 0, y: 0, width: 96, height: 96))
                }
            }
            guard let png = image.pngData() else { throw MaterialImportFailure.damaged }
            try png.write(to: item.appendingPathComponent("Thumbnail.png"), options: .atomic)
            added.append(card)
            await Task.yield()
        }
        try Task.checkCancellation()
        try FileManager.default.moveItem(at: staging, to: destination)
        cards = (added + cards).sorted { $0.created > $1.created }
        return added
    }

    func rename(_ card: UserMaterialCard, to name: String) throws {
        let clean = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty, clean.utf8.count <= 512 else { throw MaterialImportFailure.invalid("اسم الخامة غير صالح / Invalid material name") }
        var renamed = card; renamed.name = clean
        try JSONEncoder().encode(renamed).write(to: try folder(card).appendingPathComponent("Card.json"), options: .atomic)
        if let index = cards.firstIndex(where: { $0.id == card.id }) { cards[index] = renamed }
    }
    func delete(_ card: UserMaterialCard) throws {
        try FileManager.default.removeItem(at: folder(card))
        cards.removeAll { $0.id == card.id }
        thumbnails.removeValue(forKey: card.id)
    }
}

@MainActor
extension StudioStore {
    func applyUserMaterial(_ material: SCNMaterial, tiling: Double = 1) throws {
        guard !workshopIsRunning, !isExporting, !importIsRunning, !audioImportRunning,
              tiling.isFinite, (0.5...8).contains(tiling), let selectedNode, !isNodeLocked(selectedNode) else { throw ProjectFailure.busy }
        let nodes = editableDescendants(of: selectedNode).filter { $0.geometry != nil }
        guard !nodes.isEmpty else { throw MaterialImportFailure.invalid("حدد مجسمًا / Select a mesh") }
        for node in nodes {
            let uvCount = node.geometry?.sources(for: .texcoord).count ?? 0
            for (_, property) in ProjectSceneCodec.properties(material) where property.contents is UIImage {
                guard property.mappingChannel >= 0, property.mappingChannel < uvCount else {
                    throw MaterialImportFailure.invalid("المجسم لا يحتوي قناة UV المطلوبة للخامة / Mesh lacks the material's UV channel")
                }
            }
        }
        let beforeMaterials = captureMaterialHistory(nodes.flatMap { $0.geometry?.materials ?? [] })
        pushUndoSnapshot("Apply imported material")
        for node in nodes {
            guard let geometry = node.geometry, let copy = geometry.copy() as? SCNGeometry else { continue }
            copy.materials = (0..<max(1, geometry.materials.count)).map { _ in
                let authored = ProjectSceneCodec.copyMaterialPreservingProperties(material)
                for (_, property) in ProjectSceneCodec.properties(authored) {
                    // Scale the UV basis while retaining authored translation,
                    // rotation, texture channel masks and sampler parameters.
                    var transform = property.contentsTransform
                    let repeatScale = Float(tiling)
                    transform.m11 *= repeatScale; transform.m12 *= repeatScale
                    transform.m21 *= repeatScale; transform.m22 *= repeatScale
                    property.contentsTransform = transform
                }
                return authored
            }
            node.geometry = copy
            if let skinner = node.skinner { skinner.baseGeometry = copy }
        }
        reconcileStaticMaterialKeys(beforeMaterials, requireMultipleFrames: false)
        applyViewportSettings(updateMaterials: true, updateProjectLights: false)
        objectWillChange.send()
        toast = appLanguage == .arabic ? "تم تطبيق الخامة" : "Material applied"
    }
}
