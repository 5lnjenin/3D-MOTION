import SwiftUI
import UIKit

@MainActor
struct LaunchSplashView: View {
    @Binding var isPresented: Bool
    @State private var showGrid = false
    @State private var logoScale: CGFloat = 0.72
    @State private var logoRotation: Double = -18
    @State private var logoTilt: Double = -24
    @State private var logoOpacity: Double = 0
    @State private var titleOpacity: Double = 0
    @State private var titleOffset: CGFloat = 24
    @State private var fadeOut = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.05, green: 0.06, blue: 0.08),
                    Color(red: 0.09, green: 0.10, blue: 0.13),
                    Color.black
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            PerspectiveGridBackground(showGrid: showGrid)
                .ignoresSafeArea()

            VStack(spacing: 14) {
                Spacer(minLength: 0)

                logoView
                    .scaleEffect(logoScale)
                    .rotationEffect(.degrees(logoTilt * 0.12))
                    .rotation3DEffect(.degrees(logoRotation), axis: (x: 0, y: 1, z: 0), perspective: 0.72)
                    .opacity(logoOpacity)
                    .shadow(color: .cyan.opacity(0.28), radius: 30, x: 0, y: 14)

                Text("3D MOTION")
                    .font(.system(size: 33, weight: .heavy, design: .rounded))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.white, Color.cyan.opacity(0.92), Color.purple.opacity(0.95)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .tracking(0.8)
                    .opacity(titleOpacity)
                    .offset(y: titleOffset)
                    .shadow(color: .blue.opacity(0.22), radius: 16, x: 0, y: 8)

                Spacer(minLength: 0)
            }
            .padding(.vertical, 54)
        }
        .opacity(fadeOut ? 0 : 1)
        .onAppear(perform: startAnimation)
    }

    @ViewBuilder
    private var logoView: some View {
        if let image = launchLogoImage() {
            Image(uiImage: image)
                .resizable()
                .interpolation(.high)
                .scaledToFit()
                .frame(width: 250, height: 250)
        } else {
            ZStack {
                RoundedRectangle(cornerRadius: 32, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [Color(red: 0.14, green: 0.18, blue: 0.34), Color(red: 0.07, green: 0.08, blue: 0.16)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 32, style: .continuous)
                            .stroke(
                                LinearGradient(colors: [.cyan, .purple, .pink], startPoint: .topLeading, endPoint: .bottomTrailing),
                                lineWidth: 4
                            )
                    )
                    .frame(width: 178, height: 178)

                Image(systemName: "cube.transparent")
                    .font(.system(size: 76, weight: .bold))
                    .foregroundStyle(.white)
            }
            .frame(width: 250, height: 250)
        }
    }

    private func startAnimation() {
        showGrid = false
        logoScale = 0.72
        logoRotation = -22
        logoOpacity = 0
        logoTilt = -12
        titleOpacity = 0
        titleOffset = 24
        fadeOut = false

        withAnimation(.easeOut(duration: 0.35)) {
            showGrid = true
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) {
            withAnimation(.spring(response: 0.64, dampingFraction: 0.82)) {
                logoOpacity = 1
                logoScale = 1
            }
            withAnimation(.easeInOut(duration: 1.55)) {
                logoRotation = 720
                logoTilt = 0
            }
        }

        // The app name appears only after the logo has completed its spin.
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.82) {
            withAnimation(.easeOut(duration: 0.42)) {
                titleOpacity = 1
                titleOffset = 0
            }
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 3.15) {
            withAnimation(.easeInOut(duration: 0.35)) {
                fadeOut = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.36) {
                isPresented = false
            }
        }
    }

    private func launchLogoImage() -> UIImage? {
        if let named = UIImage(named: "app_logo") { return named }

        let candidates: [URL?] = [
            Bundle.main.resourceURL?.appendingPathComponent("app_logo.png"),
            Bundle.main.resourceURL?.appendingPathComponent("Resources/app_logo.png"),
            Bundle.main.bundleURL.appendingPathComponent("app_logo.png"),
            Bundle.main.bundleURL.appendingPathComponent("Resources/app_logo.png")
        ]

        for candidate in candidates {
            if let path = candidate?.path, let image = UIImage(contentsOfFile: path) {
                return image
            }
        }
        return nil
    }
}

struct PerspectiveGridBackground: View {
    let showGrid: Bool

    var body: some View {
        GeometryReader { proxy in
            let size = proxy.size
            let horizon = size.height * 0.38
            let vanishingX = size.width * 0.5
            let nearY = size.height * 0.94
            let columnCount = 17
            let rowCount = 13

            ZStack {
                Path { path in
                    path.move(to: CGPoint(x: 0, y: horizon))
                    path.addLine(to: CGPoint(x: size.width, y: horizon))
                }
                .stroke(Color.white.opacity(0.16), lineWidth: 1)

                ForEach(0...columnCount, id: \.self) { index in
                    let t = CGFloat(index) / CGFloat(columnCount)
                    let x = size.width * t
                    Path { path in
                        path.move(to: CGPoint(x: x, y: nearY))
                        path.addLine(to: CGPoint(x: vanishingX + (x - vanishingX) * 0.05, y: horizon))
                    }
                    .stroke(Color.white.opacity(showGrid ? 0.16 : 0.0), lineWidth: 1)
                }

                ForEach(0...rowCount, id: \.self) { index in
                    let t = CGFloat(index) / CGFloat(rowCount)
                    let eased = t * t
                    let y = horizon + (nearY - horizon) * eased
                    let inset = (size.width * 0.5 - 18) * (1 - eased)
                    Path { path in
                        path.move(to: CGPoint(x: inset, y: y))
                        path.addLine(to: CGPoint(x: size.width - inset, y: y))
                    }
                    .stroke(Color.white.opacity(showGrid ? Double(0.05 + 0.16 * t) : 0.0), lineWidth: 1)
                }

                LinearGradient(
                    colors: [
                        Color.clear,
                        Color.white.opacity(0.02),
                        Color.blue.opacity(0.04),
                        Color.black.opacity(0.30)
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .frame(width: size.width, height: size.height - horizon)
                .position(x: size.width / 2, y: horizon + (size.height - horizon) / 2)
            }
            .opacity(showGrid ? 1 : 0)
            .animation(.easeOut(duration: 0.35), value: showGrid)
        }
    }
}
