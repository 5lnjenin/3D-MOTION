import Foundation
import SwiftUI
import UIKit
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

@MainActor
struct TransformInspector: View {
    @EnvironmentObject var studio: StudioStore

    var body: some View {
        guard let n = studio.selectedNode else { return AnyView(EmptyView()) }

        return AnyView(
            VStack(spacing: 12) {
                InspectorCard(title: "Position") {
                    VectorEditor(
                        x: bindingPosition(.x, node: n),
                        y: bindingPosition(.y, node: n),
                        z: bindingPosition(.z, node: n)
                    )
                    Button(studio.appLanguage == .arabic ? "إعادة الموقع" : "Reset Position") {
                        studio.resetSelectedPositionOnly()
                    }
                    .buttonStyle(.bordered)
                }

                InspectorCard(title: "Rotation") {
                    VectorEditor(
                        x: bindingRotation(.x, node: n),
                        y: bindingRotation(.y, node: n),
                        z: bindingRotation(.z, node: n),
                        suffix: "°"
                    )
                    Button(studio.appLanguage == .arabic ? "إعادة الدوران" : "Reset Rotation") {
                        studio.resetSelectedRotationOnly()
                    }
                    .buttonStyle(.bordered)
                }

                InspectorCard(title: "Scale") {
                    VectorEditor(
                        x: bindingScale(.x, node: n),
                        y: bindingScale(.y, node: n),
                        z: bindingScale(.z, node: n)
                    )

                    HStack(spacing: 8) {



                    }
                    .buttonStyle(.bordered)
                }

                InspectorCard(title: "Direct Edit") {
                    Picker(
                        "Space",
                        selection:
                            $studio.transformSpace
                    ) {
                        ForEach(
                            TransformSpace.allCases,
                            id: \.self
                        ) { space in
                            Text(space.title)
                                .tag(space)
                        }
                    }
                    .pickerStyle(.segmented)
                    .onChange(
                        of: studio.transformSpace
                    ) { _, _ in
                        studio.rebuildTransformGizmo()
                    }

                    AxisSelector()
                        .environmentObject(studio)

                    Toggle(
                        "Fine / تحكم دقيق",
                        isOn: $studio.fineMode
                    )

                    Toggle(
                        "Snapping",
                        isOn: $studio.snapEnabled
                    )

                    if studio.snapEnabled {
                        Picker(
                            "Snap Target",
                            selection: $studio.snapTarget
                        ) {
                            ForEach(
                                SnapTarget.allCases,
                                id: \.self
                            ) { target in
                                Text(target.title)
                                    .tag(target)
                            }
                        }
                    }

                    HStack {
                        Text(studio.appLanguage == .arabic ? "السرعة" : "Speed")
                            .font(.caption)
                        Slider(value: $studio.manipulationSpeed, in: 0.15...1.25)
                        Text(String(format: "%.2f", studio.manipulationSpeed))
                            .font(.caption2.monospacedDigit())
                            .frame(width: 38)
                    }

                    if studio.snapEnabled,
                       studio.snapTarget == .increment {
                        VStack(spacing: 7) {
                            HStack {
                                Text("Move")
                                    .font(.caption)
                                Slider(
                                    value: $studio.snapStep,
                                    in: 0.05...2.0,
                                    step: 0.05
                                )
                                Text(
                                    String(
                                        format: "%.2f",
                                        studio.snapStep
                                    )
                                )
                                .font(.caption2.monospacedDigit())
                                .frame(width: 38)
                            }

                            HStack {
                                Text("Rotate")
                                    .font(.caption)
                                Slider(
                                    value: $studio.rotationSnapDegrees,
                                    in: 1...45,
                                    step: 1
                                )
                                Text("\(Int(studio.rotationSnapDegrees))°")
                                    .font(.caption2.monospacedDigit())
                                    .frame(width: 38)
                            }

                            HStack {
                                Text(studio.appLanguage == .arabic ? "الحجم" : "Scale")
                                    .font(.caption)
                                Slider(
                                    value: $studio.scaleSnapStep,
                                    in: 0.01...0.5,
                                    step: 0.01
                                )
                                Text(
                                    String(
                                        format: "%.2f",
                                        studio.scaleSnapStep
                                    )
                                )
                                .font(.caption2.monospacedDigit())
                                .frame(width: 38)
                            }
                        }
                    }

                    HStack {


                    }
                    .buttonStyle(.bordered)
                }

                HStack {
                    Button("Reset") { studio.resetTransform() }
                    Spacer()

                }
                .buttonStyle(.bordered)
            }
        )
    }

    private func bindingPosition(_ axis: Axis3D, node: SCNNode) -> Binding<Float> {
        Binding(
            get: {
                switch axis { case .x: node.position.x; case .y: node.position.y; case .z: node.position.z }
            },
            set: { studio.updatePosition(axis: axis, value: $0) }
        )
    }

    private func bindingRotation(_ axis: Axis3D, node: SCNNode) -> Binding<Float> {
        Binding(
            get: {
                let rad: Float
                switch axis { case .x: rad = node.eulerAngles.x; case .y: rad = node.eulerAngles.y; case .z: rad = node.eulerAngles.z }
                return rad * 180 / .pi
            },
            set: { studio.updateRotation(axis: axis, degrees: $0) }
        )
    }

    private func bindingScale(_ axis: Axis3D, node: SCNNode) -> Binding<Float> {
        Binding(
            get: {
                switch axis { case .x: node.scale.x; case .y: node.scale.y; case .z: node.scale.z }
            },
            set: { studio.updateScale(axis: axis, value: max(0.001, $0)) }
        )
    }
}

@MainActor
struct MaterialInspector: View {
    @EnvironmentObject var studio: StudioStore

    @State private var baseColor = Color.gray
    @State private var metalness = 0.2
    @State private var roughness = 0.35
    @State private var emissionColor = Color.white
    @State private var emissionStrength = 0.0
    @State private var opacity = 1.0
    @State private var isLoadingMaterial = false

    var body: some View {
        VStack(spacing: 12) {
            InspectorCard(title: "Ready Materials / خامات جاهزة") {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                    presetButton("Matte", .matte)
                    presetButton("Plastic", .plastic)
                    presetButton("Metal", .metal)
                    presetButton("Chrome", .chrome)
                    presetButton("Gold", .gold)
                    presetButton("Glass", .glass)
                    presetButton("Neon Blue", .neonBlue)
                    presetButton("Neon Pink", .neonPink)
                    presetButton("Neon Green", .neonGreen)
                }
            }

            InspectorCard(title: "Base Color / اللون الأساسي") {
                ColorPicker(
                    "Color / اللون",
                    selection: $baseColor,
                    supportsOpacity: true
                )
                .onChange(of: baseColor) { _, newValue in
                    guard !isLoadingMaterial else { return }
                    studio.setMaterialColor(newValue)
                }

                propertyResetButton {
                    baseColor = Color.gray
                }
            }

            InspectorCard(title: "Metalness / المعدنية") {
                rangedSliderRow(
                    studio.appLanguage == .arabic ? "القيمة" : "Value",
                    value: $metalness,
                    range: 0...1
                )
                .onChange(of: metalness) { _, value in
                    guard !isLoadingMaterial else { return }
                    studio.setMetalness(value)
                }

                propertyResetButton {
                    metalness = 0.2
                }
            }

            InspectorCard(title: "Roughness / الخشونة") {
                rangedSliderRow(
                    studio.appLanguage == .arabic ? "القيمة" : "Value",
                    value: $roughness,
                    range: 0...1
                )
                .onChange(of: roughness) { _, value in
                    guard !isLoadingMaterial else { return }
                    studio.setRoughness(value)
                }

                propertyResetButton {
                    roughness = 0.35
                }
            }

            InspectorCard(title: "Neon / Emission • النيون والإضاءة") {
                ColorPicker(
                    studio.appLanguage == .arabic ? "لون النيون" : "Neon Color",
                    selection: $emissionColor,
                    supportsOpacity: false
                )
                .onChange(of: emissionColor) { _, newValue in
                    guard !isLoadingMaterial else { return }
                    studio.setEmissionColor(newValue)
                }

                rangedSliderRow(
                    studio.appLanguage == .arabic ? "قوة اللون" : "Glow Strength",
                    value: $emissionStrength,
                    range: 0...12,
                    step: 0.1
                )
                .onChange(of: emissionStrength) { _, value in
                    guard !isLoadingMaterial else { return }
                    studio.setEmissionStrength(value)
                }

                Text(
                    studio.appLanguage == .arabic
                        ? "اختَر أي لون للنيون، ثم ارفع قوة اللون حسب النتيجة المطلوبة."
                        : "Choose any neon color, then adjust its glow strength."
                )
                .font(.caption2)
                .foregroundStyle(.secondary)

                HStack(spacing: 8) {
                    Button {
                        emissionColor = .white
                    } label: {
                        Label(
                            studio.appLanguage == .arabic ? "إعادة لون" : "Reset Color",
                            systemImage: "arrow.counterclockwise"
                        )
                    }

                    Button {
                        emissionStrength = 0
                    } label: {
                        Label(
                            studio.appLanguage == .arabic ? "إعادة القوة" : "Reset Strength",
                            systemImage: "arrow.counterclockwise"
                        )
                    }
                }
                .buttonStyle(.bordered)
            }

            InspectorCard(title: "Opacity / الشفافية") {
                rangedSliderRow(
                    studio.appLanguage == .arabic ? "القيمة" : "Value",
                    value: $opacity,
                    range: 0...1
                )
                .onChange(of: opacity) { _, value in
                    guard !isLoadingMaterial else { return }
                    studio.setMaterialOpacity(value)
                }

                propertyResetButton {
                    opacity = 1.0
                }
            }

            InspectorCard(title: "Material Reset / إعادة الخامة") {
                Button {
                    studio.resetSelectedMaterialToOriginal()
                    loadSelectedMaterial()
                } label: {
                    Label(
                        studio.appLanguage == .arabic ? "إعادة تعيين كل خصائص الخامة" : "Reset All Material Properties",
                        systemImage: "arrow.counterclockwise.circle"
                    )
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
            }

            UniformMaterialCard()

            Text(
                studio.appLanguage == .arabic
                    ? "كل خاصية مقسمة بقسم مستقل، وكل تعديل يطبق على القطعة المحددة فقط. للزجاج خفّض الشفافية، وللنيون اختَر اللون وارفع قوة اللون."
                    : "Each property has its own section and applies only to the selected part. Lower opacity for glass; choose a color and increase glow strength for neon."
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .onAppear { loadSelectedMaterial() }
        .onChange(of: studio.selectedName) { _, _ in
            loadSelectedMaterial()
        }
    }

    private func presetButton(
        _ title: String,
        _ preset: StudioStore.ReadyMaterialPreset
    ) -> some View {
        Button(title) {
            studio.applyReadyMaterial(preset)
            loadSelectedMaterial()
        }
        .buttonStyle(.bordered)
        .frame(maxWidth: .infinity)
    }

    @ViewBuilder
    private func propertyResetButton(_ action: @escaping () -> Void) -> some View {
        HStack {
            Spacer()
            Button(action: action) {
                Label(
                    studio.appLanguage == .arabic ? "إعادة تعيين" : "Reset",
                    systemImage: "arrow.counterclockwise"
                )
            }
            .buttonStyle(.bordered)
        }
    }

    private func rangedSliderRow(
        _ title: String,
        value: Binding<Double>,
        range: ClosedRange<Double>,
        step: Double? = nil
    ) -> some View {
        HStack(spacing: 8) {
            Text(title)
                .font(.caption)
                .frame(minWidth: 70, alignment: .leading)

            if let step {
                Slider(value: value, in: range, step: step)
            } else {
                Slider(value: value, in: range)
            }

            Text(String(format: range.upperBound > 1 ? "%.1f" : "%.2f", value.wrappedValue))
                .font(.caption2.monospacedDigit())
                .frame(width: 42)
        }
    }

    private func resetAllMaterialControls() {
        studio.resetSelectedMaterialToOriginal()
        loadSelectedMaterial()
    }

    private func loadSelectedMaterial() {
        guard let material = studio.selectedNode?.geometry?.firstMaterial else { return }

        isLoadingMaterial = true

        if let color = material.diffuse.contents as? UIColor {
            baseColor = Color(uiColor: color)
        }

        if let value = material.metalness.contents as? NSNumber {
            metalness = max(0, min(1, value.doubleValue))
        }

        if let value = material.roughness.contents as? NSNumber {
            roughness = max(0, min(1, value.doubleValue))
        }

        if let color = material.emission.contents as? UIColor {
            emissionColor = Color(uiColor: color)
        } else if let color = material.diffuse.contents as? UIColor {
            emissionColor = Color(uiColor: color)
        } else {
            emissionColor = .white
        }

        emissionStrength = max(0, min(12, Double(material.emission.intensity)))
        opacity = max(0, min(1, Double(material.transparency)))

        DispatchQueue.main.async {
            isLoadingMaterial = false
        }
    }
}

@MainActor
private struct UniformMaterialCard: View {
    @EnvironmentObject var studio: StudioStore
    @State private var metalness: Double = 0.1
    @State private var roughness: Double = 0.4

    var body: some View {
        DisclosureGroup(studio.appLanguage == .arabic ? "خامة موحدة لجميع أجزاء العنصر" : "Uniform material for all object parts") {
            Slider(value: $metalness, in: 0...1) { Text(studio.appLanguage == .arabic ? "المعدنية" : "Metalness") }
            Slider(value: $roughness, in: 0...1) { Text(studio.appLanguage == .arabic ? "الخشونة" : "Roughness") }
            Button(studio.appLanguage == .arabic ? "تطبيق الخامة الرمادية" : "Apply uniform gray material") {
                studio.applyPBRToSelected(color: .gray, metalness: CGFloat(metalness), roughness: CGFloat(roughness), opacity: 1)
            }.buttonStyle(.bordered)
        }
    }
}

@MainActor
struct ObjectInspector: View {
    @EnvironmentObject var studio: StudioStore

    var body: some View {
        VStack(spacing: 12) {
            if studio.selectedNode?.geometry is SCNText {
                TextObjectInspector()
            }
            InspectorCard(title: "Selected Part") {
                if let node = studio.selectedNode {
                    infoRow("Name", node.name ?? "Object")
                    infoRow("Type", node.geometry != nil ? "Mesh / Part" : "Group")
                    infoRow("Parent", node.parent?.name ?? "Scene")
                    infoRow("Children", "\(node.childNodes.filter { $0.name != "_SelectionOutline" }.count)")
                    infoRow("Meshes", "\(studio.partCount(in: node))")

                    if let geometry = node.geometry {
                        infoRow("Materials", "\(geometry.materials.count)")
                        infoRow("Geometry Sources", "\(geometry.sources.count)")
                    }

                    Toggle("Visible", isOn: Binding(
                        get: { !node.isHidden },
                        set: { node.isHidden = !$0; studio.objectWillChange.send() }
                    ))
                }
            }

            InspectorCard(title: "Part Tools") {
                HStack {
                    Button("Focus") { studio.frameSelected() }
                    Button("Work Point") { studio.centerSelectedOnWorkPoint() }
                }.buttonStyle(.bordered)
                HStack {


                    Button {
                        studio.selectParent()
                    } label: {
                        Label("Parent", systemImage: "arrow.up.to.line")
                    }
                }
                .buttonStyle(.bordered)

                HStack {
                    Button {
                        studio.toggleIsolation()
                    } label: {
                        Label(studio.isolateSelection ? "Show All" : "Isolate", systemImage: "eye")
                    }


                }
                .buttonStyle(.bordered)

                Button {
                    studio.extractDeepPartsFromSelection()
                } label: {
                    Label("استخراج القطع / Deep Parts", systemImage: "square.stack.3d.down.right")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)

                Text("الاستيراد يفصل القطع والخامات تلقائيًا بشكل آمن. استخدم Deep Parts فقط عندما تحتاج تفكيك الأجزاء المتصلة بنفس الخامة أيضًا.")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }

            InspectorCard(title: "Constraints / Display") {
                HStack {
                    Button("Look At Active") { studio.addLookAtConstraintToActive() }
                    Button("Billboard Y") { studio.addBillboardConstraintToSelection() }
                }
                .buttonStyle(.bordered)

                Button("Clear Constraints • Keep Transform") {
                    studio.clearSelectedConstraintsKeepTransform()
                }
                .buttonStyle(.bordered)

                HStack {
                    Button("Wire") { studio.setSelectedWireframe(true) }
                    Button("Solid") { studio.setSelectedWireframe(false) }
                    Button("X-Ray") { studio.setSelectedDepthRead(false) }
                    Button("Depth") { studio.setSelectedDepthRead(true) }
                }
                .buttonStyle(.bordered)
            }

            InspectorCard(title: "Array / Instance") {
                Text("Linked arrays reuse geometry; Make Unique creates independent geometry.")
                    .font(.caption2)
                    .foregroundStyle(.secondary)

                HStack {
                    Button("Array X ×4") { studio.createLinearArray(count: 4, spacing: 1.5, axis: .x) }
                    Button("Array Y ×4") { studio.createLinearArray(count: 4, spacing: 1.5, axis: .y) }
                    Button("Array Z ×4") { studio.createLinearArray(count: 4, spacing: 1.5, axis: .z) }
                }
                .buttonStyle(.bordered)

                HStack {
                    Button("Radial ×8") { studio.createRadialArray(count: 8, radius: 2, axis: .y) }
                    Button("Make Unique") { studio.makeSelectedGeometryUnique() }
                    Button("Isolate") { studio.isolateSelectedObjects() }
                }
                .buttonStyle(.bordered)
            }

            InspectorCard(title: "Object Workflow") {
                HStack {
                    Button {
                        studio.duplicateSelectedObjects()
                    } label: {
                        Label(
                            "Duplicate",
                            systemImage: "plus.square.on.square"
                        )
                    }

                    Button {
                        studio.duplicateSelectedObjects(
                            linkedGeometry: true
                        )
                    } label: {
                        Label(
                            "Linked",
                            systemImage: "link"
                        )
                    }
                }
                .buttonStyle(.bordered)

                HStack {
                    Button("Parent") {
                        studio.parentSelectionToActive()
                    }

                    Button("Clear Parent") {
                        studio.clearParentKeepTransform()
                    }
                }
                .buttonStyle(.bordered)

                Text("Reset Transform")
                    .font(.caption.bold())

                HStack {
                    Button("Rotation") {
                        studio.resetSelectedRotation()
                    }

                    Button("Scale") {
                        studio.resetSelectedScale()
                    }
                }
                .buttonStyle(.bordered)

                HStack {
                    Button {
                        studio.showAllObjects()
                    } label: {
                        Label("Show All", systemImage: "eye")
                    }

                    Button {
                        studio.unlockAllObjects()
                    } label: {
                        Label("Unlock All", systemImage: "lock.open")
                    }
                }
                .buttonStyle(.bordered)
            }

            InspectorCard(title: "Snap / Align") {
                HStack {
                    Button("→ Grid") {
                        studio.snapSelectionToGridPrecise()
                    }
                    Button("→ Work Point") {
                        studio.snapSelectionToWorkPoint()
                    }
                    Button("→ Origin") {
                        studio.snapSelectionToWorldOrigin()
                    }
                }
                .buttonStyle(.bordered)

                HStack {
                    Button("Work ← Selection") {
                        studio.workPointToSelection()
                    }
                    Button("Work ← Origin") {
                        studio.workPointToWorldOrigin()
                    }
                }
                .buttonStyle(.bordered)

                Text("Align to active")
                    .font(.caption.bold())

                HStack {
                    Button("X") {
                        studio.alignSelectionToActive(axis: .x)
                    }
                    Button("Y") {
                        studio.alignSelectionToActive(axis: .y)
                    }
                    Button("Z") {
                        studio.alignSelectionToActive(axis: .z)
                    }
                }
                .buttonStyle(.bordered)

                Text("Distribute evenly")
                    .font(.caption.bold())

                HStack {
                    Button("X") {
                        studio.distributeSelection(axis: .x)
                    }
                    Button("Y") {
                        studio.distributeSelection(axis: .y)
                    }
                    Button("Z") {
                        studio.distributeSelection(axis: .z)
                    }
                }
                .buttonStyle(.bordered)
            }

            InspectorCard(title: "Organization") {
                HStack {



                }
                .buttonStyle(.bordered)

                HStack {
                    Button {
                        studio.toggleLockSelected()
                    } label: {
                        Label(
                            studio.selectedNode.map(
                                studio.isNodeLocked
                            ) == true
                                ? "Unlock"
                                : "Lock",
                            systemImage: "lock"
                        )
                    }

                    Button {
                        studio.toggleHideSelected()
                    } label: {
                        Label(
                            "Hide",
                            systemImage: "eye.slash"
                        )
                    }
                }
                .buttonStyle(.bordered)

                HStack {
                    Button {
                        studio.centerPivotOnSelection()
                    } label: {
                        Text("Center Pivot")
                    }

                    Button {
                        studio.resetPivotOnSelection()
                    } label: {
                        Text("Reset Pivot")
                    }
                }
                .buttonStyle(.bordered)

                HStack {
                    Button("Mirror X") {
                        studio.mirrorSelected(
                            axis: .x
                        )
                    }

                    Button("Mirror Y") {
                        studio.mirrorSelected(
                            axis: .y
                        )
                    }

                    Button("Mirror Z") {
                        studio.mirrorSelected(
                            axis: .z
                        )
                    }
                }
                .buttonStyle(.bordered)
            }



            HStack {


                Spacer()


            }
            .buttonStyle(.bordered)
        }
    }

    private func infoRow(_ key: String, _ value: String) -> some View {
        HStack {
            Text(key)
                .foregroundStyle(.secondary)
            Spacer()
            Text(value)
                .lineLimit(1)
                .font(.caption.monospaced())
        }
    }
}



@MainActor
struct ModelingInspector: View {
    @EnvironmentObject var studio: StudioStore
    @State private var subdivision: Double = 0
    @State private var roughness: Double = 0.4
    @State private var metalness: Double = 0.1

    var body: some View {
        VStack(spacing: 10) {


            InspectorCard(title: "Subdivision") {
                Slider(value: $subdivision, in: 0...5, step: 1)
                Button("Apply \(Int(subdivision))") {
                    studio.setSelectedSubdivision(Int(subdivision))
                }
            }


        }
        .buttonStyle(.bordered)
    }
}

@MainActor
struct AdvancedToolsInspector: View {
    @EnvironmentObject var studio: StudioStore

    var body: some View {
        VStack(spacing: 10) {
            PhysicsEngineCard()
            RigEngineCard()
            MorphEngineCard()
        }
    }
}

@MainActor
private struct PhysicsEngineCard: View {
    @EnvironmentObject var studio: StudioStore

    var body: some View {
        InspectorCard(title: "Physics") {
            HStack {
                Button("Static") { apply(.static) }
                Button("Dynamic") { apply(.dynamic) }
                Button("Kinematic") { apply(.kinematic) }
            }
            Button("Remove Physics") {
                guard let node = studio.selectedNode else { return }
                studio.setPhysicsMode(nil, on: node)
            }
            if let body = studio.selectedNode?.physicsBody {
                HStack {
                    Text(studio.appLanguage == .arabic ? "الكتلة" : "Mass")
                    Slider(value: Binding(get: { Double(body.mass) }, set: { value in
                        studio.pushUndoSnapshotThrottled(label: "Physics Mass", key: "physics-mass")
                        body.mass = CGFloat(value); studio.objectWillChange.send()
                    }), in: 0.05...100)
                    Text(String(format: "%.1f", Double(body.mass))).monospacedDigit()
                }
            }
        }
        .buttonStyle(.bordered)
    }

    private func apply(_ type: SCNPhysicsBodyType) {
        guard let node = studio.selectedNode else { return }
        studio.setPhysicsMode(type, on: node)
    }
}

@MainActor
private struct RigEngineCard: View {
    @EnvironmentObject var studio: StudioStore

    var body: some View {
        InspectorCard(title: "Rig / IK / Ragdoll") {
            let count = studio.selectedNode.map { studio.bones(in: $0).count } ?? 0
            Text("Bones: \(count)")
                .font(.caption)
                .foregroundStyle(.secondary)

            Button("Build Ragdoll") {
                guard let node = studio.selectedNode else { return }
                studio.makeRagdoll(root: node)
            }

            Button("Remove IK") {
                guard let node = studio.selectedNode else { return }
                studio.removeIK(from: node)
            }
        }
        .buttonStyle(.bordered)
    }
}

@MainActor
private struct MorphEngineCard: View {
    @EnvironmentObject var studio: StudioStore
    @State private var weight: Double = 0

    var body: some View {
        InspectorCard(title: "Morph") {
            Slider(value: $weight, in: 0...1)
            Button("Apply First Morph") {
                guard let node = studio.selectedNode else { return }
                studio.setMorphWeight(CGFloat(weight), targetIndex: 0, on: node)
            }
        }
        .buttonStyle(.bordered)
    }
}

@MainActor
struct LensSettingsCard: View {
    @EnvironmentObject var studio: StudioStore
    @State private var focalLength: Double = 50

    var body: some View {
        InspectorCard(title: studio.appLanguage == .arabic ? "العدسة" : "Lens") {
            Slider(value: $focalLength, in: 18...135)
            Button("Apply Lens") {
                guard let node = studio.selectedNode, node.camera != nil else { return }
                studio.configureCinematicCamera(
                    node,
                    focalLength: CGFloat(focalLength),
                    aperture: 5.6,
                    focusDistance: 5
                )
                studio.syncCameraControls()
            }
        }
        .buttonStyle(.bordered)
    }
}



@MainActor
private struct TextObjectInspector: View {
    @EnvironmentObject var studio: StudioStore
    @State private var value = ""
    @State private var fontName = "HelveticaNeue-Bold"
    @State private var fontSize = 1.0
    @State private var extrusion = 0.08
    @State private var bevel = 0.02
    @State private var flatness = 0.12
    @State private var alignment = "center"
    @State private var style: StudioStore.TextMaterialStyle = .plain

    private var textGeometry: SCNText? { studio.selectedNode?.geometry as? SCNText }

    var body: some View {
        InspectorCard(title: studio.appLanguage == .arabic ? "تحرير النص" : "Text Editor") {
            TextField(studio.appLanguage == .arabic ? "اكتب النص" : "Text", text: $value, axis: .vertical)
                .textFieldStyle(.roundedBorder)
                .onChange(of: value) { _, newValue in
                    textGeometry?.string = newValue
                    studio.objectWillChange.send()
                }

            Picker(studio.appLanguage == .arabic ? "الخط" : "Font", selection: $fontName) {
                ForEach(studio.availableTextFonts(), id: \.self) { Text($0).tag($0) }
            }
            .onChange(of: fontName) { _, name in
                guard let text = textGeometry, let font = UIFont(name: name, size: CGFloat(fontSize)) else { return }
                text.font = font
                studio.selectedNode?.setValue(name, forKey: "studioTextFont")
                studio.objectWillChange.send()
            }

            Picker(studio.appLanguage == .arabic ? "النمط" : "Style", selection: $style) {
                ForEach(StudioStore.TextMaterialStyle.allCases) { Text($0.rawValue.capitalized).tag($0) }
            }
            .onChange(of: style) { _, newStyle in
                guard let text = textGeometry else { return }
                if text.materials.isEmpty { text.materials = [SCNMaterial()] }
                let material = text.materials[0]
                let color = (material.diffuse.contents as? UIColor) ?? .white
                studio.applyTextMaterialStyle(newStyle, to: material, color: color)
                studio.selectedNode?.setValue(newStyle.rawValue, forKey: "studioTextStyle")
                studio.objectWillChange.send()
            }

            HStack {
                Text(studio.appLanguage == .arabic ? "الحجم" : "Size")
                Slider(value: $fontSize, in: 0.2...8, step: 0.05)
                Text(String(format: "%.1f", fontSize)).font(.caption.monospacedDigit())
            }
            .onChange(of: fontSize) { _, v in
                guard let text = textGeometry else { return }
                text.font = UIFont(name: fontName, size: CGFloat(v)) ?? UIFont.systemFont(ofSize: CGFloat(v), weight: .bold)
                studio.objectWillChange.send()
            }

            HStack {
                Text(studio.appLanguage == .arabic ? "العمق" : "Depth")
                Slider(value: $extrusion, in: 0...1, step: 0.01)
                Text(String(format: "%.2f", extrusion)).font(.caption.monospacedDigit())
            }
            .onChange(of: extrusion) { _, v in textGeometry?.extrusionDepth = CGFloat(v); studio.objectWillChange.send() }

            HStack {
                Text("Bevel")
                Slider(value: $bevel, in: 0...0.3, step: 0.005)
                Text(String(format: "%.2f", bevel)).font(.caption.monospacedDigit())
            }
            .onChange(of: bevel) { _, v in textGeometry?.chamferRadius = CGFloat(v); studio.objectWillChange.send() }

            HStack {
                Text(studio.appLanguage == .arabic ? "نعومة" : "Quality")
                Slider(value: $flatness, in: 0.01...0.5, step: 0.01)
            }
            .onChange(of: flatness) { _, v in textGeometry?.flatness = CGFloat(v); studio.objectWillChange.send() }

            Picker(studio.appLanguage == .arabic ? "المحاذاة" : "Alignment", selection: $alignment) {
                Text(studio.appLanguage == .arabic ? "يسار" : "Left").tag("left")
                Text(studio.appLanguage == .arabic ? "وسط" : "Center").tag("center")
                Text(studio.appLanguage == .arabic ? "يمين" : "Right").tag("right")
            }
            .pickerStyle(.segmented)
            .onChange(of: alignment) { _, v in textGeometry?.alignmentMode = v; studio.objectWillChange.send() }

            Text(studio.appLanguage == .arabic ? "اللون والنيون والمعدنية والخشونة والشفافية موجودة في تبويب الخامة." : "Color, neon, metalness, roughness and opacity are available in Material.")
                .font(.caption2).foregroundStyle(.secondary)
        }
        .onAppear(perform: load)
        .onChange(of: studio.selectedNode) { _, _ in load() }
    }

    private func load() {
        guard let node = studio.selectedNode, let text = node.geometry as? SCNText else { return }
        value = text.string as? String ?? ""
        fontName = (node.value(forKey: "studioTextFont") as? String).flatMap { $0.isEmpty ? nil : $0 } ?? text.font?.fontName ?? studio.availableTextFonts().first ?? "HelveticaNeue-Bold"
        fontSize = Double(text.font?.pointSize ?? 1)
        extrusion = Double(text.extrusionDepth)
        bevel = Double(text.chamferRadius)
        flatness = Double(text.flatness)
        alignment = text.alignmentMode
        if let raw = node.value(forKey: "studioTextStyle") as? String, let parsed = StudioStore.TextMaterialStyle(rawValue: raw) { style = parsed }
    }
}
