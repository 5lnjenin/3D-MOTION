import Foundation
import UIKit
import SceneKit
import AVFoundation

enum MaterialEditingSafety {
    static func isMap(_ value: Any?) -> Bool {
        guard let value else { return false }
        if value is UIColor || value is NSNumber { return false }
        if CFGetTypeID(value as CFTypeRef) == CGColor.typeID { return false }
        return true
    }
    static func colorValue(_ value: Any?) -> UIColor? {
        if let color = value as? UIColor { return color }
        if let value, CFGetTypeID(value as CFTypeRef) == CGColor.typeID { return UIColor(cgColor: value as! CGColor) }
        return nil
    }
    static func same(_ a: Any?, _ b: Any?) -> Bool {
        if a == nil && b == nil { return true }
        guard let a, let b else { return false }
        if let a = a as? NSObject, let b = b as? NSObject { return a.isEqual(b) }
        return CFEqual(a as CFTypeRef, b as CFTypeRef)
    }
    static func assign(_ value: Any?, to property: SCNMaterialProperty) {
        guard !same(property.contents, value) else { return }
        // SceneKit can keep a previous texture source behind an updated solid
        // value until transaction synchronization. Reset that source atomically
        // before writing an explicitly authored color or scalar.
        if colorValue(value) != nil || value is NSNumber {
            SCNTransaction.begin(); SCNTransaction.disableActions = true
            property.contents = nil; property.contents = value
            SCNTransaction.commit()
        } else { property.contents = value }
    }
    static func factor(_ property: SCNMaterialProperty) -> Double {
        if isMap(property.contents) { return Double(property.intensity) }
        return (property.contents as? NSNumber)?.doubleValue ?? 0
    }
    static func setFactor(_ value: Double, property: SCNMaterialProperty) {
        if isMap(property.contents) { property.intensity = CGFloat(value) }
        else { assign(NSNumber(value: value), to: property) }
    }
    static let tintMarker = "// 5Ln authored material tint"
    static let tintKey = "studioAuthoredTint"
    static func color(_ material: SCNMaterial) -> UIColor {
        if let value = colorValue(material.diffuse.contents) { return value }
        if material.shaderModifiers?[.surface]?.contains(tintMarker + " " + tintKey) == true,
           let value = material.value(forKey: tintKey) as? NSValue {
            let v = value.scnVector3Value; return UIColor(red: CGFloat(v.x), green: CGFloat(v.y), blue: CGFloat(v.z), alpha: 1)
        }
        return colorValue(material.multiply.contents) ?? .white
    }
    static func setColor(_ color: UIColor, material: SCNMaterial) {
        let opaque = color.withAlphaComponent(1)
        if !isMap(material.diffuse.contents) { resetShaderFactor(tintKey, material: material); assign(opaque, to: material.diffuse) }
        else if !isMap(material.multiply.contents) { resetShaderFactor(tintKey, material: material); assign(opaque, to: material.multiply) }
        else {
            // A material can already use both color-map channels. A shader
            // factor keeps both providers, their UVs and their animation alive.
            setShaderColor(opaque, material: material, key: tintKey, field: "diffuse")
        }
    }
    static func setShaderColor(_ color: UIColor, material: SCNMaterial, key: String, field: String) {
        var modifiers = material.shaderModifiers ?? [:]
        let original = modifiers[.surface] ?? ""
        let marker = tintMarker + " " + key
        if !original.contains(marker) {
            var source = original
            let declaration = "float3 \(key);\n"
            if let range = source.range(of: "#pragma arguments") {
                source.insert(contentsOf: "\n" + declaration, at: range.upperBound)
            } else { source = "#pragma arguments\n" + declaration + (source.contains("#pragma body") ? "" : "#pragma body\n") + source }
            if !source.contains("#pragma body") { source += "\n#pragma body\n" }
            source += "\n\(marker)\n_surface.\(field).rgb *= \(key);\n"
            modifiers[.surface] = source; material.shaderModifiers = modifiers
        }
        var r: CGFloat=0,g: CGFloat=0,b: CGFloat=0,a: CGFloat=0
        color.getRed(&r, green: &g, blue: &b, alpha: &a)
        material.setValue(NSValue(scnVector3: SCNVector3(Float(max(0,min(1,r))), Float(max(0,min(1,g))), Float(max(0,min(1,b))))), forKey: key)
    }
    static func resetShaderFactor(_ key: String, material: SCNMaterial) {
        if material.shaderModifiers?[.surface]?.contains(tintMarker + " " + key) == true {
            material.setValue(NSValue(scnVector3: SCNVector3(1,1,1)), forKey: key)
        }
    }
    static let varyingBegin = "// 5Ln overflow UV begin"
    static let varyingEnd = "// 5Ln overflow UV end"
    static func withoutPreviewVaryings(_ input: String) -> String {
        var source = input
        while let begin = source.range(of: varyingBegin), let end = source.range(of: varyingEnd), begin.lowerBound < end.upperBound { source.removeSubrange(begin.lowerBound..<end.upperBound) }
        return source.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    static func removePreviewVaryings(_ material: SCNMaterial) {
        var modifiers = material.shaderModifiers ?? [:], changed = false
        for entry in [SCNShaderModifierEntryPoint.geometry, .surface] {
            if let source = modifiers[entry], source.contains(varyingBegin) {
                let original = withoutPreviewVaryings(source)
                modifiers[entry] = original.isEmpty ? nil : original; changed = true
            }
        }
        if changed { material.shaderModifiers = modifiers.isEmpty ? nil : modifiers }
    }
    // SceneKit generates vertex outputs above index seven, but its Metal IO
    // omits their declarations. Its classic profile also aliases self-illumination
    // to emission when many maps are present. Supply a separate authored UV for
    // that field; native PBR outputs retain their original calculations.
    static func preparePreviewVaryings(_ material: SCNMaterial) {
        let order = [material.ambient, material.diffuse, material.specular, material.emission,
                     material.transparent, material.reflective, material.multiply, material.normal,
                     material.selfIllumination] + (material.lightingModel == .physicallyBased ? [material.metalness, material.roughness] : [])
        let maps = order.filter { isMap($0.contents) }
        var modifiers = material.shaderModifiers ?? [:]
        let originalGeometry = withoutPreviewVaryings(modifiers[.geometry] ?? "")
        let originalSurface = withoutPreviewVaryings(modifiers[.surface] ?? "")
        modifiers[.geometry] = originalGeometry.isEmpty ? nil : originalGeometry
        modifiers[.surface] = originalSurface.isEmpty ? nil : originalSurface
        guard maps.count > 8 else {
            let cleaned = modifiers.isEmpty ? nil : modifiers
            if material.shaderModifiers != cleaned { material.shaderModifiers = cleaned }
            return
        }
        var declarations = "#pragma varyings\n", body = ""
        for i in 8..<maps.count { declarations += "float2 texcoord\(i);\n" }
        if material.lightingModel != .physicallyBased {
            let p = material.selfIllumination, m = p.contentsTransform
            let channel = "min(\(max(0,p.mappingChannel)), kSCNTexcoordCount - 1)"
            declarations += "float2 studioClassicSelfUV;\n"
            body = "out.studioClassicSelfUV = float2(\(m.m11) * _geometry.texcoords[\(channel)].x + \(m.m21) * _geometry.texcoords[\(channel)].y + \(m.m41), \(m.m12) * _geometry.texcoords[\(channel)].x + \(m.m22) * _geometry.texcoords[\(channel)].y + \(m.m42));\n"
            let override = varyingBegin + "\n_surface.selfIlluminationTexcoord = in.studioClassicSelfUV;\n" + varyingEnd
            if let range = originalSurface.range(of: "#pragma body") {
                var surface = originalSurface
                surface.insert(contentsOf:"\n" + override + "\n",at:range.upperBound)
                modifiers[.surface] = surface
            } else if originalSurface.isEmpty {
                modifiers[.surface] = varyingBegin + "\n#pragma body\n_surface.selfIlluminationTexcoord = in.studioClassicSelfUV;\n" + varyingEnd
            } else { modifiers[.surface] = override + "\n" + originalSurface }
        }
        // Separate marked declarations/body allow exact recovery of the author's
        // existing shader, without archiving extra uniforms or copying textures.
        let declarationBlock = varyingBegin + "\n" + declarations + varyingEnd
        let bodyBlock = varyingBegin + "\n" + body + varyingEnd
        if let range = originalGeometry.range(of: "#pragma body") {
            var geometry = originalGeometry
            geometry.insert(contentsOf:declarationBlock + "\n",at:range.lowerBound)
            modifiers[.geometry] = geometry + "\n" + bodyBlock
        } else if originalGeometry.isEmpty {
            modifiers[.geometry] = varyingBegin + "\n" + declarations + "#pragma body\n" + body + varyingEnd
        } else {
            modifiers[.geometry] = declarationBlock + "\n" + originalGeometry + "\n" + bodyBlock
        }
        if material.shaderModifiers != modifiers { material.shaderModifiers = modifiers }
    }
    static func copyTint(from source: SCNMaterial, to destination: SCNMaterial) {
        for key in [tintKey, "studioEmissionTint"] where source.shaderModifiers?[.surface]?.contains(tintMarker + " " + key) == true {
            destination.setValue(source.value(forKey: key), forKey: key)
        }
    }
    static func shaderFactors(_ material: SCNMaterial) -> [String: [Float]] {
        var values: [String: [Float]] = [:]
        for key in [tintKey, "studioEmissionTint"] where material.shaderModifiers?[.surface]?.contains(tintMarker + " " + key) == true {
            if let value = material.value(forKey: key) as? NSValue { let v = value.scnVector3Value; values[key] = [v.x,v.y,v.z] }
        }
        return values
    }
    static func restore(_ material: SCNMaterial, from snapshot: SCNMaterial) {
        for ((_, source), (_, target)) in zip(ProjectSceneCodec.properties(snapshot), ProjectSceneCodec.properties(material)) {
            assign(source.contents, to: target)
            target.intensity = source.intensity; target.contentsTransform = source.contentsTransform
            target.mappingChannel = source.mappingChannel; target.wrapS = source.wrapS; target.wrapT = source.wrapT
            target.minificationFilter = source.minificationFilter; target.magnificationFilter = source.magnificationFilter
            target.mipFilter = source.mipFilter; target.textureComponents = source.textureComponents; target.maxAnisotropy = source.maxAnisotropy
        }
        material.name = snapshot.name; material.lightingModel = snapshot.lightingModel; material.fillMode = snapshot.fillMode
        material.shininess = snapshot.shininess; material.fresnelExponent = snapshot.fresnelExponent
        material.locksAmbientWithDiffuse = snapshot.locksAmbientWithDiffuse; material.isLitPerPixel = snapshot.isLitPerPixel
        material.transparency = snapshot.transparency; material.blendMode = snapshot.blendMode; material.transparencyMode = snapshot.transparencyMode
        material.writesToDepthBuffer = snapshot.writesToDepthBuffer; material.readsFromDepthBuffer = snapshot.readsFromDepthBuffer
        material.isDoubleSided = snapshot.isDoubleSided; material.cullMode = snapshot.cullMode
        material.colorBufferWriteMask = snapshot.colorBufferWriteMask; material.shaderModifiers = snapshot.shaderModifiers
        copyTint(from: snapshot, to: material)
    }
}

@MainActor
extension StudioStore {
    func authoredMaterialCopy(_ material: SCNMaterial) -> SCNMaterial {
        let copy = ProjectSceneCodec.copyMaterialPreservingProperties(material)
        MaterialEditingSafety.removePreviewVaryings(copy)
        if previousViewportShadingMode != .rendered, let model = materialLighting.object(forKey: material) {
            copy.lightingModel = SCNMaterial.LightingModel(rawValue: model as String)
            copy.fillMode = SCNFillMode(rawValue: materialFillMode.object(forKey: material)?.uintValue ?? 0) ?? .fill
        }
        if previousViewportShadingMode == .lit {
            if let value = materialSpecular.object(forKey: material) { copy.specular.intensity = CGFloat(value.doubleValue) }
            if let value = materialShininess.object(forKey: material) { copy.shininess = CGFloat(value.doubleValue) }
        }
        if !previousBackfaceCullingEnabled, let sided = materialDoubleSided.object(forKey: material) { copy.isDoubleSided = sided.boolValue }
        return copy
    }
    func resetMaterialDisplayCaches() {
        materialFillMode.removeAllObjects()
        materialLighting.removeAllObjects(); materialDoubleSided.removeAllObjects()
        materialSpecular.removeAllObjects(); materialShininess.removeAllObjects()
        previousViewportShadingMode = .rendered; previousBackfaceCullingEnabled = true
    }
    // Material changes affect only channels that were constant across a track.
    // Genuine color/roughness animation keeps its different authored key values.
    func reconcileStaticMaterialKeys(_ states: [MaterialHistoryState], requireMultipleFrames: Bool = true) {
        for state in states {
            for owner in state.owners {
                let indices = keyframes.indices.filter { keyframes[$0].nodeID == owner.nodeID }
                let tracks = Dictionary(grouping: indices) { keyframes[$0].trackID ?? "default" }
                for group in tracks.values {
                    let values = group.compactMap { keyframes[$0].materialStates }.filter { $0.indices.contains(owner.slot) }.map { $0[owner.slot] }
                    guard (!requireMultipleFrames || group.count >= 2), values.count == group.count, let first = values.first else { continue }
                    let live = ProjectSceneCodec.nodes(in: contentRoot).first { $0.studioAnimationID == owner.nodeID }?.geometry?.materials
                    guard let live, live.indices.contains(owner.slot) else { continue }
                    let replacement = MaterialKeyframeState(live[owner.slot])
                    for i in group {
                        guard var frames = keyframes[i].materialStates, frames.indices.contains(owner.slot) else { continue }
                        if values.allSatisfy({ MaterialEditingSafety.same($0.diffuse, first.diffuse) }) { frames[owner.slot].diffuse = replacement.diffuse }
                        if values.allSatisfy({ MaterialEditingSafety.same($0.metalness, first.metalness) }) { frames[owner.slot].metalness = replacement.metalness }
                        if values.allSatisfy({ MaterialEditingSafety.same($0.roughness, first.roughness) }) { frames[owner.slot].roughness = replacement.roughness }
                        if values.allSatisfy({ MaterialEditingSafety.same($0.emission, first.emission) }) { frames[owner.slot].emission = replacement.emission }
                        if values.allSatisfy({ $0.emissionIntensity == first.emissionIntensity }) { frames[owner.slot].emissionIntensity = replacement.emissionIntensity }
                        if values.allSatisfy({ $0.transparency == first.transparency }) { frames[owner.slot].transparency = replacement.transparency }
                        if values.allSatisfy({ $0.multiplyCaptured && MaterialEditingSafety.same($0.multiply, first.multiply) }) { frames[owner.slot].multiply = replacement.multiply; frames[owner.slot].multiplyCaptured = true }
                        for key in replacement.propertyFactors?.keys ?? Dictionary<String, Double>().keys {
                            if values.allSatisfy({ $0.propertyFactors?[key] == first.propertyFactors?[key] }) {
                                if frames[owner.slot].propertyFactors == nil { frames[owner.slot].propertyFactors = [:] }
                                frames[owner.slot].propertyFactors?[key] = replacement.propertyFactors?[key]
                            }
                        }
                        for (key, value) in replacement.shaderFactors ?? [:] {
                            if values.allSatisfy({ $0.shaderFactors?[key] == first.shaderFactors?[key] }) {
                                if frames[owner.slot].shaderFactors == nil { frames[owner.slot].shaderFactors = [:] }
                                frames[owner.slot].shaderFactors?[key] = value
                            }
                        }
                        keyframes[i].materialStates = frames
                    }
                }
            }
        }
        timelineChannels = nil
    }
}

