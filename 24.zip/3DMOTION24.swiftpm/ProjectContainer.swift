import Foundation
#if canImport(CryptoKit)
import CryptoKit
#else
import Crypto
#endif
#if canImport(Darwin)
import Darwin
#else
import Glibc
#endif

// A versioned document, not a renamed .scn. Every dependency belongs to this
// single transaction. Version 1 is read-only compatibility with build 23.
struct StudioPortablePackage: Codable {
    var version: Int
    var name: String
    var scene: Data
    var metadata: Data
    var environment: Data?
    var audio: [String: Data]
    var textures: Data?
    var format: String? = nil
    var sceneEncoding: String? = nil
    var resources: [String: ProjectResource]? = nil
    var materials: [String: ProjectMaterialRecord]? = nil
    var bindings: [ProjectGeometryBinding]? = nil
    var particles: [ProjectParticleBinding]? = nil
    var animations: [ProjectAnimationBinding]? = nil
    var hierarchy: [ProjectNodeRecord]? = nil
    var checksums: [String: String]? = nil

    mutating func seal() {
        format = "3D-MOTION"
        checksums = payloads.mapValues(ProjectIntegrity.hash)
    }

    private var payloads: [String: Data] {
        var result = ["scene": scene, "metadata": metadata]
        if let environment { result["environment"] = environment }
        if let textures { result["legacyTextures"] = textures }
        for (key, value) in audio { result["audio/" + key] = value }
        for (key, value) in resources ?? [:] {
            result["resource/" + key] = value.data
            result["descriptor/" + key] = Data((value.kind + "\0" + value.fileExtension).utf8)
        }
        // The material bindings and sampling properties are part of integrity
        // checking too; sorting makes the JSON independent of dictionary order.
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        if let materials, let data = try? encoder.encode(materials) { result["materials"] = data }
        if let bindings, let data = try? encoder.encode(bindings) { result["bindings"] = data }
        if let particles, let data = try? encoder.encode(particles) { result["particles"] = data }
        if let animations, let data = try? encoder.encode(animations) { result["animations"] = data }
        if let hierarchy, let data = try? encoder.encode(hierarchy) { result["hierarchy"] = data }
        result["name"] = Data(name.utf8)
        if let sceneEncoding { result["sceneEncoding"] = Data(sceneEncoding.utf8) }
        return result
    }

    func validate() throws {
        guard (version == 1 || version == 2), !scene.isEmpty, !metadata.isEmpty,
              !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw ProjectFailure.invalid("document header")
        }
        guard audio.keys.allSatisfy(ProjectFileStore.safeComponent) else {
            throw ProjectFailure.invalid("audio filename")
        }
        if version == 1 { return }
        guard format == "3D-MOTION", sceneEncoding == "scenekit-keyed-archive", let resources, let materials, let bindings,
              let checksums, checksums == payloads.mapValues(ProjectIntegrity.hash) else {
            throw ProjectFailure.invalid("document integrity")
        }
        for (id, resource) in resources {
            guard id == ProjectIntegrity.hash(resource.data), !resource.data.isEmpty,
                  ProjectFileStore.safeComponent(resource.fileExtension),
                  ["image", "video", "archive"].contains(resource.kind) else {
                throw ProjectFailure.invalid("resource " + id)
            }
        }
        var nodes = Set<String>()
        for binding in bindings {
            guard nodes.insert(binding.nodeID).inserted,
                  binding.materialIDs.allSatisfy({ materials[$0] != nil }) else {
                throw ProjectFailure.invalid("material binding")
            }
        }
        for material in materials.values {
            guard !material.archive.isEmpty else { throw ProjectFailure.invalid("material archive") }
            for property in material.properties.values {
                try property.value.validate(resources: resources)
                guard property.transform.count == 16, property.transform.allSatisfy(\.isFinite),
                      property.intensity.isFinite, property.mappingChannel >= 0,
                      property.maxAnisotropy.isFinite else {
                    throw ProjectFailure.invalid("texture sampling")
                }
            }
        }
        for particle in particles ?? [] {
            guard particle.index >= 0 else { throw ProjectFailure.invalid("particle slot") }
            try particle.value.validate(resources: resources)
        }
        var animatedSlots = Set<String>()
        for animation in animations ?? [] {
            guard !animation.archive.isEmpty, !animation.key.isEmpty,
                  animatedSlots.insert(animation.nodeID + ":" + animation.key).inserted else {
                throw ProjectFailure.invalid("animation binding")
            }
            guard animation.encoding == nil || ["scn-animation", "ca-animation"].contains(animation.encoding!),
                  animation.speed?.isFinite != false, animation.blendFactor?.isFinite != false,
                  animation.blendFactor.map({ (0...1).contains($0) }) != false else {
                throw ProjectFailure.invalid("animation player settings")
            }
            if let settings = animation.settings {
                guard [settings.blendInDuration, settings.blendOutDuration, settings.startDelay, settings.timeOffset].allSatisfy(\.isFinite),
                      settings.blendInDuration >= 0, settings.blendOutDuration >= 0 else {
                    throw ProjectFailure.invalid("animation timing")
                }
            }
        }
        var hierarchyIDs = Set<String>()
        for node in hierarchy ?? [] {
            guard hierarchyIDs.insert(node.id).inserted, node.transform.count == 16, node.pivot.count == 16,
                  node.transform.allSatisfy(\.isFinite), node.pivot.allSatisfy(\.isFinite), node.opacity.isFinite else {
                throw ProjectFailure.invalid("hierarchy record")
            }
        }
    }
}

struct ProjectResource: Codable {
    var kind: String
    var fileExtension: String
    var data: Data
}

struct ProjectValue: Codable {
    var kind: String
    var rgba: [Double]? = nil
    var number: Double? = nil
    var resourceID: String? = nil
    var faces: [ProjectValue]? = nil

    func validate(resources: [String: ProjectResource]) throws {
        switch kind {
        case "empty": break
        case "color":
            guard let rgba, rgba.count == 4, rgba.allSatisfy(\.isFinite) else {
                throw ProjectFailure.invalid("color")
            }
        case "number":
            guard let number, number.isFinite else { throw ProjectFailure.invalid("number") }
        case "image", "video", "archive":
            guard let resourceID, resources[resourceID]?.kind == kind else {
                throw ProjectFailure.invalid("missing " + kind + " resource")
            }
        case "cube":
            guard let faces, faces.count == 6, faces.allSatisfy({ $0.kind == "image" }) else {
                throw ProjectFailure.invalid("cube texture")
            }
            for face in faces { try face.validate(resources: resources) }
        default: throw ProjectFailure.invalid("unsupported material value")
        }
    }
}

struct ProjectPropertyRecord: Codable {
    var value: ProjectValue
    var intensity: Double
    var transform: [Float]
    var mappingChannel: Int
    var wrapS: Int
    var wrapT: Int
    var minification: Int
    var magnification: Int
    var mip: Int
    var components: Int
    var maxAnisotropy: Double
}

struct ProjectMaterialRecord: Codable {
    var archive: Data
    var properties: [String: ProjectPropertyRecord]
}

struct ProjectGeometryBinding: Codable {
    var nodeID: String
    var materialIDs: [String]
    var elementSignatures: [String]
    var texcoordSignatures: [String]
}

struct ProjectParticleBinding: Codable {
    var nodeID: String
    var index: Int
    var value: ProjectValue
}

struct ProjectAnimationBinding: Codable {
    var nodeID: String
    var key: String
    var archive: Data
    var encoding: String? = nil
    var speed: Double? = nil
    var blendFactor: Double? = nil
    var paused: Bool? = nil
    var settings: ProjectAnimationSettings? = nil
}

struct ProjectAnimationSettings: Codable {
    var blendInDuration: Double
    var blendOutDuration: Double
    var startDelay: Double
    var timeOffset: Double
    var removedOnCompletion: Bool
    var appliedOnCompletion: Bool
    var fillsForward: Bool
    var fillsBackward: Bool
    var usesSceneTimeBase: Bool
    var additive: Bool
    var cumulative: Bool
}

struct ProjectNodeRecord: Codable {
    var id: String
    var parentID: String?
    var name: String?
    var transform: [Float]
    var pivot: [Float]
    var opacity: Double
    var isHidden: Bool
}

enum ProjectIntegrity {
    static func hash(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }
}

enum ProjectFailure: LocalizedError {
    case invalid(String), missing(String), unsupported(String), busy, write
    var errorDescription: String? {
        switch self {
        case .invalid(let item): return "بيانات مشروع غير صالحة / Invalid project: \(item)"
        case .missing(let item): return "مورد مطلوب مفقود / Missing resource: \(item)"
        case .unsupported(let item): return "تعذر حفظ مورد بهذه الصيغة / Cannot persist resource: \(item)"
        case .busy: return "انتظر انتهاء الاستيراد أو التحويل ثم احفظ / Save when editing is idle"
        case .write: return "تعذر حفظ المشهد / Scene serialization failed"
        }
    }
}

enum ProjectFileStore {
    static func safeComponent(_ name: String) -> Bool {
        !name.isEmpty && name != "." && name != ".." &&
        !name.contains("/") && !name.contains("\\") && !name.contains("\0")
    }

    static func encode(_ package: StudioPortablePackage) throws -> Data {
        try package.validate()
        return try JSONEncoder().encode(package)
    }

    static func decode(_ data: Data) throws -> StudioPortablePackage {
        let package = try JSONDecoder().decode(StudioPortablePackage.self, from: data)
        try package.validate()
        return package
    }

    static func previous(_ url: URL) -> URL { url.appendingPathExtension("previous") }

    // Called only after the detached SceneKit decoder has validated this candidate.
    // Data.atomic uses a sibling temporary file and an atomic rename, so readers
    // can only observe a complete previous or complete new document.
    static func commit(_ data: Data, to url: URL) throws {
        _ = try decode(data)
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        let staging = url.deletingLastPathComponent().appendingPathComponent("." + UUID().uuidString + ".pending")
        defer { try? FileManager.default.removeItem(at: staging) }
        try data.write(to: staging, options: .atomic)
        guard try Data(contentsOf: staging) == data else { throw ProjectFailure.write }
        if let existing = try? Data(contentsOf: url), (try? decode(existing)) != nil {
            try existing.write(to: previous(url), options: .atomic)
        }
        let result = staging.path.withCString { source in
            url.path.withCString { destination in rename(source, destination) }
        }
        guard result == 0 else { throw POSIXError(POSIXErrorCode(rawValue: errno) ?? .EIO) }
    }
}
