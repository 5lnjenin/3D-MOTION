import Foundation
import SceneKit

enum GeometryNormals {
    static func reversed(_ original: SCNGeometry) throws -> SCNGeometry {
        let sources = try original.sources.map { source -> SCNGeometrySource in
            guard source.semantic == .normal || source.semantic == .tangent else { return source }
            guard source.usesFloatComponents, [4, 8].contains(source.bytesPerComponent),
                  source.componentsPerVector >= 3 else { throw ProjectFailure.unsupported("normal component format") }
            var bytes = source.data
            let stride = source.dataStride > 0 ? source.dataStride : source.componentsPerVector * source.bytesPerComponent
            let components = source.semantic == .normal ? Array(0..<3) : (source.componentsPerVector >= 4 ? [3] : [])
            for vertex in 0..<source.vectorCount {
                for component in components {
                    let offset = source.dataOffset + vertex * stride + component * source.bytesPerComponent
                    guard offset >= 0, offset + source.bytesPerComponent <= bytes.count else { throw ProjectFailure.invalid("normal buffer") }
                    // IEEE float sign bit, without alignment-dependent loads.
                    bytes[offset + source.bytesPerComponent - 1] ^= 0x80
                }
            }
            return SCNGeometrySource(data: bytes, semantic: source.semantic, vectorCount: source.vectorCount,
                usesFloatComponents: true, componentsPerVector: source.componentsPerVector,
                bytesPerComponent: source.bytesPerComponent, dataOffset: source.dataOffset, dataStride: source.dataStride)
        }
        let elements = try original.elements.map { element -> SCNGeometryElement in
            guard element.primitiveType == .triangles || element.primitiveType == .triangleStrip else {
                if element.primitiveType == .polygon { throw ProjectFailure.unsupported("polygon normals; triangulate first") }
                return element
            }
            let width = element.bytesPerIndex
            guard [1, 2, 4, 8].contains(width) else { throw ProjectFailure.invalid("index width") }
            func index(_ position: Int) throws -> Data {
                let start = position * width
                guard start >= 0, start + width <= element.data.count else { throw ProjectFailure.invalid("index buffer") }
                return element.data.subdata(in: start..<start + width)
            }
            var bytes = Data()
            for triangle in 0..<element.primitiveCount {
                let base = element.primitiveType == .triangles ? triangle * 3 : triangle
                let order = element.primitiveType == .triangleStrip && triangle % 2 == 1 ? [base, base + 1, base + 2] : [base + 1, base, base + 2]
                for position in order { bytes.append(try index(position)) }
            }
            let result = SCNGeometryElement(data: bytes, primitiveType: .triangles, primitiveCount: element.primitiveCount, bytesPerIndex: width)
            result.primitiveRange = element.primitiveRange
            return result
        }
        let result = SCNGeometry(sources: sources, elements: elements)
        result.name = original.name; result.materials = original.materials
        result.subdivisionLevel = original.subdivisionLevel
        return result
    }
}
