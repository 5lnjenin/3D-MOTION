import Foundation

private final class AssetDownloadProgress: NSObject, URLSessionDownloadDelegate, @unchecked Sendable {
    let changed: @Sendable (Int64, Int64) -> Void
    init(changed: @escaping @Sendable (Int64, Int64) -> Void) { self.changed = changed }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        changed(totalBytesWritten, totalBytesExpectedToWrite)
    }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {}
}

@MainActor
final class AssetDownloadManager: NSObject, ObservableObject {
    static let shared = AssetDownloadManager()

    @Published private(set) var progress: [String: Double] = [:]
    @Published private(set) var downloading: Set<String> = []
    @Published private(set) var revision: Int = 0
    @Published private(set) var downloadedBytes: [String: Int64] = [:]
    private var tasks: [String: Task<Void, Error>] = [:]
    private var generations: [String: UUID] = [:]

    private let baseURL = "https://github.com/5lnjenin/-5Ln-Assets/releases/download/assets-v1/"

    private override init() {
        super.init()
        try? FileManager.default.createDirectory(at: assetsDirectory, withIntermediateDirectories: true)
    }

    private var assetsDirectory: URL {
        let root = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return root.appendingPathComponent("5LnDownloadedAssets", isDirectory: true)
    }

    func installedURL(for asset: BundledAssetKind) -> URL? {
        let url = assetsDirectory.appendingPathComponent(asset.fileName)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    func isInstalled(_ asset: BundledAssetKind) -> Bool { installedURL(for: asset) != nil }
    func isDownloading(_ asset: BundledAssetKind) -> Bool { downloading.contains(asset.id) }
    func downloadProgress(_ asset: BundledAssetKind) -> Double { progress[asset.id] ?? 0 }

    func download(_ asset: BundledAssetKind) async throws {
        guard !isInstalled(asset), !isDownloading(asset) else { return }
        guard let remote = URL(string: baseURL + asset.remoteFileName.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed)!) else {
            throw URLError(.badURL)
        }

        let generation = UUID(), id = asset.id
        generations[id] = generation; downloading.insert(id); progress[id] = nil; downloadedBytes[id] = 0
        defer { tasks[id] = nil; generations[id] = nil; downloading.remove(id) }
        let delegate = AssetDownloadProgress { [weak self] bytes, expected in
            Task { @MainActor [weak self] in
                guard let self, generations[id] == generation else { return }
                downloadedBytes[id] = bytes
                progress[id] = expected > 0 ? min(0.99, Double(bytes) / Double(expected)) : nil
            }
        }
        let task = Task { @MainActor in
            let (temp, response) = try await URLSession.shared.download(from: remote, delegate: delegate)
            defer { try? FileManager.default.removeItem(at: temp) }
            try Task.checkCancellation()
            guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else { throw URLError(.badServerResponse) }
            try DownloadedAssetValidation.validate(temp, expectedBytes: http.expectedContentLength)
            try Task.checkCancellation()
            let destination = assetsDirectory.appendingPathComponent(asset.fileName)
            try FileManager.default.createDirectory(at: assetsDirectory, withIntermediateDirectories: true)
            // Validation and a complete download precede installation. Never
            // remove a working installed file to make room for a failed one.
            guard !FileManager.default.fileExists(atPath: destination.path) else { return }
            try FileManager.default.moveItem(at: temp, to: destination)
            progress[id] = 1; revision &+= 1
        }
        tasks[id] = task
        do { try await withTaskCancellationHandler(operation: { try await task.value }, onCancel: { task.cancel() }) }
        catch { progress[id] = nil; downloadedBytes[id] = nil; throw error }
    }

    func cancel(_ asset: BundledAssetKind) { tasks[asset.id]?.cancel() }

    func delete(_ asset: BundledAssetKind) throws {
        guard let url = installedURL(for: asset) else { return }
        try FileManager.default.removeItem(at: url)
        progress[asset.id] = nil
        revision &+= 1
    }

    func deleteAll() {
        for task in tasks.values { task.cancel() }
        do {
            if FileManager.default.fileExists(atPath: assetsDirectory.path) { try FileManager.default.removeItem(at: assetsDirectory) }
            try FileManager.default.createDirectory(at: assetsDirectory, withIntermediateDirectories: true)
        } catch { return }
        progress.removeAll()
        revision &+= 1
    }

    func installedBytes() -> Int64 {
        guard let files = try? FileManager.default.contentsOfDirectory(at: assetsDirectory, includingPropertiesForKeys: [.fileSizeKey]) else { return 0 }
        return files.reduce(0) { partial, url in
            partial + Int64((try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
        }
    }
}

