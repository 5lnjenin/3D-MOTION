import Foundation

@MainActor
final class AssetDownloadManager: NSObject, ObservableObject {
    static let shared = AssetDownloadManager()

    @Published private(set) var progress: [String: Double] = [:]
    @Published private(set) var downloading: Set<String> = []
    @Published private(set) var revision: Int = 0

    private let baseURL = "https://github.com/5lnjenin/-5Ln-Assets/releases/download/assets-v1/"

    private override init() {
        super.init()
        try? FileManager.default.createDirectory(at: assetsDirectory, withIntermediateDirectories: true)
    }

    private var assetsDirectory: URL {
        let root = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return root.appendingPathComponent("5LnDownloadedAssets", isDirectory: true)
    }

    func installedURL(for asset: BundledAssetKind) -> URL? {
        let url = assetsDirectory.appendingPathComponent(asset.fileName)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    func isInstalled(_ asset: BundledAssetKind) -> Bool { installedURL(for: asset) != nil }
    func isDownloading(_ asset: BundledAssetKind) -> Bool { downloading.contains(asset.id) }
    func downloadProgress(_ asset: BundledAssetKind) -> Double { progress[asset.id] ?? 0 }

    func download(_ asset: BundledAssetKind) async throws {
        guard !isInstalled(asset), !isDownloading(asset) else { return }
        guard let remote = URL(string: baseURL + asset.remoteFileName.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed)!) else {
            throw URLError(.badURL)
        }

        downloading.insert(asset.id)
        progress[asset.id] = 0.02
        defer { downloading.remove(asset.id) }

        progress[asset.id] = 0.12
        let (temp, response) = try await URLSession.shared.download(from: remote)
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            progress[asset.id] = nil
            throw URLError(.badServerResponse)
        }

        let destination = assetsDirectory.appendingPathComponent(asset.fileName)
        try? FileManager.default.removeItem(at: destination)
        try FileManager.default.moveItem(at: temp, to: destination)
        progress[asset.id] = 1
        revision &+= 1
    }

    func delete(_ asset: BundledAssetKind) throws {
        guard let url = installedURL(for: asset) else { return }
        try FileManager.default.removeItem(at: url)
        progress[asset.id] = nil
        revision &+= 1
    }

    func deleteAll() {
        try? FileManager.default.removeItem(at: assetsDirectory)
        try? FileManager.default.createDirectory(at: assetsDirectory, withIntermediateDirectories: true)
        progress.removeAll()
        revision &+= 1
    }

    func installedBytes() -> Int64 {
        guard let files = try? FileManager.default.contentsOfDirectory(at: assetsDirectory, includingPropertiesForKeys: [.fileSizeKey]) else { return 0 }
        return files.reduce(0) { partial, url in
            partial + Int64((try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
        }
    }
}

