import Compression
import Foundation
import SwiftUI
import UIKit
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

// MARK: - Settings

@MainActor
struct StudioSettingsSheet: View {
    @EnvironmentObject var studio: StudioStore
    @Environment(\.dismiss) private var dismiss
    @State private var showControlLayoutEditor = false

    var body: some View {
        NavigationStack {
            Form {
                CollapsibleSettingsSection(title: studio.appLanguage == .arabic ? "المعاينة" : "Preview") {
                    Toggle("معاينة خفيفة / Efficient preview", isOn: $studio.performanceMode)
                    Text("30 إطارًا للمعاينة الخفيفة، أو حتى 60 للسلاسة. هذا الخيار لا يغير بيانات المشروع.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                CollapsibleSettingsSection(title: studio.appLanguage == .arabic ? "الحفظ والأمان" : "Safety / Save") {
                    HStack {
                        Label(
                            "Autosave",
                            systemImage: "checkmark.circle.fill"
                        )

                        Spacer()

                        Text(ProductInterfaceText.message(studio.lastAutosaveText, arabic: studio.appLanguage == .arabic))
                            .foregroundStyle(.secondary)
                    }

                    Text(
                        "يحاول الحفظ كل 60 ثانية وعند الخروج. يتأجل أثناء التشغيل والاستيراد والسحب وللمشاهد الثقيلة؛ استخدم زر حفظ المشروع في الشريط العلوي."
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)

                }

                CollapsibleSettingsSection(title: studio.tr("language")) {
                    Picker(studio.tr("language"), selection: $studio.appLanguage) {
                        Text("العربية").tag(StudioLanguage.arabic)
                        Text("English").tag(StudioLanguage.english)
                    }
                    .pickerStyle(.segmented)
                }

                CollapsibleSettingsSection(title: studio.tr("playback")) {
                    HStack {
                        Text("FPS")
                        Spacer()
                        Picker("", selection: $studio.fps) {
                            Text("24").tag(24.0)
                            Text("30").tag(30.0)
                            Text("60").tag(60.0)
                        }
                        .pickerStyle(.segmented)
                        .frame(width: 180)
                    }

                    HStack {
                        Text(studio.appLanguage == .arabic ? "المدة" : "Duration")
                        Slider(value: Binding(get: { studio.duration }, set: { studio.setProjectDuration($0) }),
                               in: 1...max(60, studio.duration), step: 1)
                        Text(String(format: "%.2fs", studio.duration))
                            .monospacedDigit()
                    }
                    if studio.timelineMinimumDuration > 0 {
                        Button(studio.appLanguage == .arabic ? "مطابقة المدة مع المحتوى" : "Match content duration") { studio.useAutomaticProjectDuration() }
                    }
                    Text(studio.appLanguage == .arabic ? "المدة تلقائية حسب أطول محتوى. تغييرها يدويًا يحدد حدًا أدنى فقط." : "Duration follows the longest content. A manual duration sets only a minimum.")
                        .font(.caption).foregroundStyle(.secondary)
                }

                CollapsibleSettingsSection(title: studio.appLanguage == .arabic ? "بيئة المشهد" : "Scene Environment") {
                    Picker(studio.appLanguage == .arabic ? "الخلفية" : "Background", selection: Binding(
                        get: { studio.environmentPreset },
                        set: { studio.setEnvironmentPreset($0) }
                    )) {
                        ForEach(SceneEnvironmentPreset.allCases, id: \.self) { preset in
                            Text(preset.title).tag(preset)
                        }
                    }

                    HStack {
                        Text(studio.appLanguage == .arabic ? "الشدة" : "Intensity")
                        Slider(
                            value: $studio.environmentIntensity,
                            in: 0...3
                        )
                        .onChange(of: studio.environmentIntensity) { _, _ in
                            studio.applySceneEnvironment()
                        }
                        Text(String(format: "%.2f", studio.environmentIntensity))
                            .font(.caption.monospacedDigit())
                    }
                }

                CollapsibleSettingsSection(title: studio.appLanguage == .arabic ? "عرض مساحة العمل" : "Viewport Display") {
                    Toggle(studio.appLanguage == .arabic ? "إظهار الإحصائيات" : "Show Statistics", isOn: $studio.showViewportStatistics)

                    Toggle(studio.appLanguage == .arabic ? "إخفاء الأوجه الخلفية" : "Backface Culling", isOn: $studio.backfaceCullingEnabled)
                        .onChange(of: studio.backfaceCullingEnabled) { _, _ in
                            studio.applyViewportSettings()
                        }

                    Picker(studio.appLanguage == .arabic ? "نمط العرض" : "Shading", selection: $studio.viewportShadingMode) {
                        ForEach(ViewportShadingMode.allCases, id: \.self) { mode in
                            Text(mode.title).tag(mode)
                        }
                    }
                    .onChange(of: studio.viewportShadingMode) { _, _ in
                        studio.applyViewportSettings()
                    }
                }

                CollapsibleSettingsSection(title: studio.appLanguage == .arabic ? "مفاتيح التحكم" : "Controls") {
                    Button { showControlLayoutEditor = true } label: {
                        Label("تخصيص مفاتيح التحكم", systemImage: "rectangle.and.hand.point.up.left")
                    }
                    Text("يفتح شاشة المشروع نفسها. اسحب Joystick وأزرار الصعود/النزول وشريط Zoom لأي مكان، وحدد كل أداة لتغيير حجمها وشفافيتها مثل محرر تحكم الألعاب.")
                        .font(.caption2).foregroundStyle(.secondary)
                    HStack { Text("سرعة الحركة"); Slider(value: $studio.controlMoveSpeed, in: 0.35...3.0); Text(String(format: "%.1fx", studio.controlMoveSpeed)) }
                    Toggle("Pinch Zoom بالإصبعين", isOn: $studio.pinchZoomEnabled)

                }

                CollapsibleSettingsSection(title: studio.appLanguage == .arabic ? "التنقل في مساحة العمل" : "Viewport Navigation") {
                    Picker(studio.appLanguage == .arabic ? "وضع التحكم الافتراضي" : "Default interaction", selection: $studio.viewportInteractionMode) {
                        Text("VIEW").tag(ViewportInteractionMode.view)
                        Text("OBJECT").tag(ViewportInteractionMode.object)
                    }
                    .pickerStyle(.segmented)

                    Text("VIEW حر بالكامل: لف الكاميرا بمكانها، تحرك بأي اتجاه، وقرّب/بعّد بدون ارتباط بالمشروع. نقل المشروع لا يغيّر الكاميرا أو الزوم. OBJECT فقط لتعديل العنصر.")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    Text("Zoom ممتد: يمكنك الاقتراب إلى تفاصيل صغيرة جدًا أو الابتعاد لمسافات ضخمة باستخدام Pinch متكرر.")
                        .font(.caption2)
                        .foregroundStyle(.secondary)

                    Text("اختيار أي Node من القائمة لا يغيّر الكاميرا أو الزوم أو زاوية النظر. استخدم Focus / Frame فقط عندما تريد الانتقال للعنصر.")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }

                CollapsibleSettingsSection(title: studio.appLanguage == .arabic ? "مساحة العمل" : "Viewport / Workspace") {
                    Toggle(studio.appLanguage == .arabic ? "إظهار الشبكة" : "Show Grid", isOn: $studio.showGrid)
                        .onChange(of: studio.showGrid) { _, _ in studio.rebuildHelpers() }
                    Toggle(studio.appLanguage == .arabic ? "إظهار المحاور" : "Show Axes", isOn: $studio.showAxes)
                        .onChange(of: studio.showAxes) { _, _ in studio.rebuildHelpers() }
                    Toggle(studio.appLanguage == .arabic ? "إظهار نقطة العمل" : "Show Work Point", isOn: $studio.showWorkPoint)
                        .onChange(of: studio.showWorkPoint) { _, _ in studio.rebuildHelpers() }

                    HStack {
                        Text(studio.appLanguage == .arabic ? "حجم خلية الشبكة" : "Grid Cell Size")
                        Slider(value: $studio.gridSpacing, in: 0.05...10.0)
                            .onChange(of: studio.gridSpacing) { _, _ in studio.rebuildHelpers() }
                        Text(String(format: "%.2f", studio.gridSpacing))
                            .font(.caption.monospacedDigit())
                    }

                    HStack {
                        Text(studio.appLanguage == .arabic ? "حجم الشبكة" : "Grid Size")
                        Slider(value: $studio.gridHalfCount, in: 2...100, step: 1)
                            .onChange(of: studio.gridHalfCount) { _, _ in studio.rebuildHelpers() }
                        Text("\(Int(studio.gridHalfCount))")
                            .font(.caption.monospacedDigit())
                    }
                    Toggle(studio.appLanguage == .arabic ? "تركيز تلقائي على العناصر الجديدة" : "Auto Focus New Objects", isOn: $studio.autoFocusNewObjects)
                    Toggle(studio.appLanguage == .arabic ? "تركيز تلقائي على القطعة المحددة" : "Auto Focus Selected Part", isOn: $studio.autoFocusPartSelection)
                    Toggle(studio.appLanguage == .arabic ? "ضبط حجم الموديلات المستوردة تلقائيًا" : "Auto Fit Imported Models", isOn: $studio.autoFitImports)

                    Text(studio.appLanguage == .arabic ? "عند تفعيل ضبط الحجم، يتم توحيد وحدات الموديلات المستوردة تلقائيًا ثم وضعها في مركز المشروع بحجم مريح للتحرير." : "When Auto Fit is enabled, imported model units are normalized automatically and the model is placed at the project center at a comfortable editing size.")
                        .font(.caption2)
                        .foregroundStyle(.secondary)

                    Text(studio.appLanguage == .arabic ? "مساحة العمل تبدأ أكبر، والخط الزمني مخفي افتراضيًا. افتحه عند الحاجة للتحريك." : "The workspace starts larger and the timeline is hidden by default. Open it when animation editing is needed.")
                        .font(.caption2)
                        .foregroundStyle(.secondary)

                    HStack {
                        Text(studio.appLanguage == .arabic ? "سرعة التحرير" : "Edit Speed")
                        Slider(value: $studio.manipulationSpeed, in: 0.15...1.25)
                        Text(String(format: "%.2f", studio.manipulationSpeed))
                            .font(.caption.monospacedDigit())
                    }
                }

            }
            .navigationTitle(studio.appLanguage == .arabic ? "الإعدادات" : "Settings")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(studio.appLanguage == .arabic ? "تم" : "Done") { dismiss() }
                }
            }
        }
        .fullScreenCover(isPresented: $showControlLayoutEditor) {
            ControlLayoutEditor()
                .environmentObject(studio)
        }
    }
}



@MainActor
private struct CollapsibleSettingsSection<Content: View>: View {
    let title: String
    let content: Content
    @State private var expanded = false

    init(title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }

    var body: some View {
        DisclosureGroup(isExpanded: $expanded) {
            VStack(alignment: .leading, spacing: 12) {
                content
            }
            .padding(.top, 8)
        } label: {
            HStack {
                Text(title).font(.headline)
                Spacer()
            }
            .contentShape(Rectangle())
        }
        .padding(.vertical, 2)
    }
}

// MARK: - Game-style HUD layout editor

@MainActor
private struct ControlLayoutEditor: View {
    @EnvironmentObject var studio: StudioStore
    @Environment(\.dismiss) private var dismiss
    @State private var selected: HUDControl = .joystick
    // Exactly one HUD control owns the finger until that gesture ends.
    // This prevents another overlapping control from stealing selection mid-drag.
    @State private var activeDrag: HUDControl? = nil
    @State private var dragStartOffset: CGPoint = .zero

    enum HUDControl: String, CaseIterable {
        case joystick = "Joystick"
        case up = "↑"
        case down = "↓"
        case zoom = "Zoom"
    }

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                SceneKitViewport(registerAsPrimary: false).environmentObject(studio).allowsHitTesting(false)
                Color.black.opacity(0.05).ignoresSafeArea()

                hud(proxy: proxy)

                VStack(spacing: 0) {
                    HStack(spacing: 10) {
                        Button("إلغاء") { studio.controlEditLayout = false; dismiss() }
                        Spacer()
                        Text("تخصيص مفاتيح التحكم").font(.subheadline.bold())
                        Spacer()
                        Button("حفظ") { studio.controlEditLayout = false; dismiss() }.fontWeight(.bold)
                    }
                    .padding(.horizontal, 14)
                    .frame(height: 42)
                    .background(.ultraThinMaterial)

                    editorBar
                    Spacer()
                }
            }
        }
        .preferredColorScheme(.dark)
        .onAppear { studio.controlEditLayout = true }
        .onDisappear { studio.controlEditLayout = false }
    }

    @ViewBuilder private func hud(proxy: GeometryProxy) -> some View {
        let topSafe: CGFloat = 104
        let bottomSafe: CGFloat = 20

        // IMPORTANT: the controls themselves never receive gestures in edit mode.
        // One canvas gesture performs explicit hit-testing, then locks that finger
        // to exactly one control until the finger is lifted. This avoids SwiftUI's
        // overlapping-view gesture arbitration (the old Zoom-selection bug).
        ZStack {
            hudControl(.joystick,
                       baseX: 24 + CGFloat(studio.controlJoystickSize)/2,
                       baseY: proxy.size.height - bottomSafe - CGFloat(studio.controlJoystickSize)/2,
                       x: studio.joystickOffsetX, y: studio.joystickOffsetY) {
                let size = CGFloat(studio.controlJoystickSize)
                ZStack {
                    Circle().fill(.black.opacity(0.45))
                    Circle().stroke(.white.opacity(0.65), lineWidth: 2)
                    Circle().fill(.white.opacity(0.30)).frame(width:size*0.40,height:size*0.40)
                }.frame(width:size,height:size)
            }

            hudControl(.up,
                       baseX: proxy.size.width - 58,
                       baseY: proxy.size.height - 126,
                       x: studio.verticalOffsetX + studio.upOffsetX,
                       y: studio.verticalOffsetY + studio.upOffsetY) {
                hudCircle("chevron.up")
            }

            hudControl(.down,
                       baseX: proxy.size.width - 58,
                       baseY: proxy.size.height - 68,
                       x: studio.verticalOffsetX + studio.downOffsetX,
                       y: studio.verticalOffsetY + studio.downOffsetY) {
                hudCircle("chevron.down")
            }

            hudControl(.zoom,
                       baseX: proxy.size.width - 126,
                       baseY: proxy.size.height - 110,
                       x: studio.zoomOffsetX, y: studio.zoomOffsetY) {
                VStack(spacing:5) {
                    Image(systemName:"plus.magnifyingglass")
                    Capsule().fill(.white.opacity(0.58)).frame(width:8,height:96)
                    Image(systemName:"minus.magnifyingglass")
                }
                .padding(9).background(.black.opacity(0.38),in:Capsule())
                .scaleEffect(studio.zoomControlScale)
            }
        }
        .allowsHitTesting(false)
        .overlay {
            Color.clear
                .contentShape(Rectangle())
                .gesture(canvasDragGesture(proxy: proxy, topSafe: topSafe))
        }
    }

    private func hudCircle(_ icon:String)->some View {
        Image(systemName:icon).font(.system(size:17,weight:.bold))
            .frame(width:studio.controlButtonSize,height:studio.controlButtonSize)
            .background(.black.opacity(0.48),in:Circle())
    }

    private func hudControl<Content: View>(_ control: HUDControl,
                                           baseX: CGFloat, baseY: CGFloat,
                                           x: Double, y: Double,
                                           @ViewBuilder content: () -> Content) -> some View {
        content()
            .opacity(studio.controlOpacity)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(selected == control ? Color.yellow : Color.clear, lineWidth: 3)
                    .padding(-6)
            )
            .position(x: baseX + CGFloat(x), y: baseY + CGFloat(y))
    }

    private func canvasDragGesture(proxy: GeometryProxy, topSafe: CGFloat) -> some Gesture {
        DragGesture(minimumDistance: 0, coordinateSpace: .local)
            .onChanged { value in
                if activeDrag == nil {
                    guard let hit = hitControl(at: value.startLocation, in: proxy.size) else { return }
                    activeDrag = hit
                    selected = hit
                    dragStartOffset = currentOffset(for: hit)
                }
                guard let control = activeDrag else { return }

                let proposed = CGPoint(
                    x: dragStartOffset.x + value.translation.width,
                    y: dragStartOffset.y + value.translation.height
                )
                setOffset(proposed, for: control, bounds: proxy.size, topSafe: topSafe)
            }
            .onEnded { _ in
                // Release ownership after EVERY finger-up. The next touch performs
                // a fresh hit-test, so selection can never remain trapped on Zoom.
                activeDrag = nil
            }
    }

    private func hitControl(at point: CGPoint, in size: CGSize) -> HUDControl? {
        // Small expansion makes each button easy to pick without allowing Zoom to
        // steal touches from the up/down buttons. If areas overlap, choose nearest.
        let candidates: [(HUDControl, CGPoint, CGSize)] = [
            (.joystick, controlCenter(.joystick, in: size), CGSize(width: studio.controlJoystickSize + 20, height: studio.controlJoystickSize + 20)),
            (.up, controlCenter(.up, in: size), CGSize(width: studio.controlButtonSize + 18, height: studio.controlButtonSize + 18)),
            (.down, controlCenter(.down, in: size), CGSize(width: studio.controlButtonSize + 18, height: studio.controlButtonSize + 18)),
            (.zoom, controlCenter(.zoom, in: size), CGSize(width: 54 * studio.zoomControlScale + 12, height: 154 * studio.zoomControlScale + 12))
        ]

        let hits = candidates.filter { item in
            let c = item.1, s = item.2
            return abs(point.x - c.x) <= s.width/2 && abs(point.y - c.y) <= s.height/2
        }
        return hits.min { a, b in
            hypot(point.x-a.1.x, point.y-a.1.y) < hypot(point.x-b.1.x, point.y-b.1.y)
        }?.0
    }

    private func controlCenter(_ control: HUDControl, in size: CGSize) -> CGPoint {
        switch control {
        case .joystick:
            return CGPoint(x: 24 + CGFloat(studio.controlJoystickSize)/2 + studio.joystickOffsetX,
                           y: size.height - 20 - CGFloat(studio.controlJoystickSize)/2 + studio.joystickOffsetY)
        case .up:
            return CGPoint(x: size.width - 58 + studio.verticalOffsetX + studio.upOffsetX,
                           y: size.height - 126 + studio.verticalOffsetY + studio.upOffsetY)
        case .down:
            return CGPoint(x: size.width - 58 + studio.verticalOffsetX + studio.downOffsetX,
                           y: size.height - 68 + studio.verticalOffsetY + studio.downOffsetY)
        case .zoom:
            return CGPoint(x: size.width - 126 + studio.zoomOffsetX,
                           y: size.height - 110 + studio.zoomOffsetY)
        }
    }

    private func currentOffset(for control: HUDControl) -> CGPoint {
        switch control {
        case .joystick: return CGPoint(x: studio.joystickOffsetX, y: studio.joystickOffsetY)
        case .up: return CGPoint(x: studio.verticalOffsetX + studio.upOffsetX, y: studio.verticalOffsetY + studio.upOffsetY)
        case .down: return CGPoint(x: studio.verticalOffsetX + studio.downOffsetX, y: studio.verticalOffsetY + studio.downOffsetY)
        case .zoom: return CGPoint(x: studio.zoomOffsetX, y: studio.zoomOffsetY)
        }
    }

    private func setOffset(_ offset: CGPoint, for control: HUDControl, bounds: CGSize, topSafe: CGFloat) {
        let base: CGPoint
        switch control {
        case .joystick:
            base = CGPoint(x: 24 + CGFloat(studio.controlJoystickSize)/2,
                           y: bounds.height - 20 - CGFloat(studio.controlJoystickSize)/2)
        case .up: base = CGPoint(x: bounds.width - 58, y: bounds.height - 126)
        case .down: base = CGPoint(x: bounds.width - 58, y: bounds.height - 68)
        case .zoom: base = CGPoint(x: bounds.width - 126, y: bounds.height - 110)
        }

        let absoluteX = base.x + offset.x
        let absoluteY = base.y + offset.y
        let clampedX = min(max(28, absoluteX), max(28, bounds.width - 28))
        let clampedY = min(max(topSafe, absoluteY), max(topSafe, bounds.height - 28))
        let final = CGPoint(x: clampedX - base.x, y: clampedY - base.y)

        switch control {
        case .joystick:
            studio.joystickOffsetX = final.x; studio.joystickOffsetY = final.y
        case .up:
            studio.upOffsetX = final.x - studio.verticalOffsetX
            studio.upOffsetY = final.y - studio.verticalOffsetY
        case .down:
            studio.downOffsetX = final.x - studio.verticalOffsetX
            studio.downOffsetY = final.y - studio.verticalOffsetY
        case .zoom:
            studio.zoomOffsetX = final.x; studio.zoomOffsetY = final.y
        }
    }

    private var editorBar:some View {
        VStack(spacing:6) {
            HStack(spacing:8) {
                HStack(spacing: 6) {
                    Image(systemName: "hand.point.up.left.fill")
                    Text("المحدد: \(selected.rawValue)").font(.caption.bold())
                }
                .padding(.horizontal, 10).frame(height: 28)
                .background(.thinMaterial, in: Capsule())
                Spacer()
                Button("إعادة ضبط") { studio.resetControlLayout() }.buttonStyle(.bordered).controlSize(.small)
            }
            HStack(spacing:8) {
                Text("الحجم").font(.caption)
                Slider(value:sizeBinding,in:sizeRange)
                Text(sizeText).font(.caption.monospacedDigit()).frame(width:44)
                Divider().frame(height:20)
                Text("الشفافية").font(.caption)
                Slider(value:$studio.controlOpacity,in:0.20...1.0)
                Text("\(Int(studio.controlOpacity*100))%").font(.caption.monospacedDigit()).frame(width:42)
            }
        }
        .padding(.horizontal,12).padding(.vertical,7)
        .background(.ultraThinMaterial)
    }

    private var sizeBinding:Binding<Double> {
        switch selected {
        case .joystick: return $studio.controlJoystickSize
        case .up,.down: return $studio.controlButtonSize
        case .zoom: return $studio.zoomControlScale
        }
    }
    private var sizeRange:ClosedRange<Double> { selected == .joystick ? 70...170 : ((selected == .up || selected == .down) ? 34...90 : 0.65...1.6) }
    private var sizeText:String { selected == .zoom ? String(format:"%.1fx",studio.zoomControlScale) : "\(Int(sizeBinding.wrappedValue))" }
}

// MARK: - Edge Controls / Direct Manipulation

enum PanelEdge {
    case left, right
}

@MainActor
struct EdgeCollapseButton: View {
    @EnvironmentObject var studio: StudioStore
    let side: PanelEdge
    let isPanelVisible: Bool
    let action: () -> Void

    private var icon: String {
        switch (side, isPanelVisible) {
        case (.left, true): "chevron.left"
        case (.left, false): "chevron.right"
        case (.right, true): "chevron.right"
        case (.right, false): "chevron.left"
        }
    }

    var body: some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 11, weight: .bold))
                .frame(width: 18, height: 58)
                .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 7))
                .overlay(
                    RoundedRectangle(cornerRadius: 7)
                        .stroke(Color.white.opacity(0.09), lineWidth: 0.5)
                )
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 3)
        .studioTooltip(
            studio.appLanguage == .arabic
                ? (isPanelVisible ? "إخفاء اللوحة" : "إظهار اللوحة")
                : (isPanelVisible ? "Hide panel" : "Show panel")
        )
        .environment(\.layoutDirection, .leftToRight)
    }
}

@MainActor
struct DirectManipulationHint: View {
    @EnvironmentObject var studio: StudioStore
    let onEditText: () -> Void

    var body: some View {
        HStack(spacing: 8) {
            modeButton(.view, title: "VIEW", subtitle: studio.appLanguage == .arabic ? "المنظور" : "View", icon: "camera.viewfinder")
            modeButton(.object, title: "OBJECT", subtitle: studio.appLanguage == .arabic ? "العنصر" : "Object", icon: "move.3d")

            Divider().frame(height: 22)

            if studio.viewportInteractionMode == .object {
                AxisSelector().environmentObject(studio)
                    .frame(maxWidth: 300)
                Button { studio.fineMode.toggle() } label: {
                    Text(studio.fineMode ? "FINE ✓" : "FINE")
                        .font(.system(size: 9, weight: .bold))
                }
                .buttonStyle(.bordered).controlSize(.mini)
                .studioTooltip(studio.appLanguage == .arabic ? "وضع التحكم الدقيق" : "Fine control mode")

                if studio.selectedNode?.geometry is SCNText {
                    Button(action: onEditText) {
                        Label(studio.tr("editText"), systemImage: "pencil")
                            .font(.system(size: 9, weight: .bold))
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.mini)
                    .tint(.purple.opacity(0.85))
                    .studioTooltip(studio.appLanguage == .arabic ? "تعديل النص المحدد" : "Edit selected text")
                }
            } else {
                Label(studio.appLanguage == .arabic ? "تحريك المنظور" : "Move View", systemImage: "camera.viewfinder")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(.secondary)
                Spacer(minLength: 0)
            }
        }
        .frame(height: 34)
        .padding(.horizontal, 4)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 10))
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(studio.viewportInteractionMode == .view ? Color.cyan.opacity(0.25) : Color.orange.opacity(0.25), lineWidth: 0.8))
    }

    private func modeButton(_ mode: ViewportInteractionMode, title: String, subtitle: String, icon: String) -> some View {
        Button {
            studio.viewportInteractionMode = mode
            studio.statusText = mode == .view ? (studio.appLanguage == .arabic ? "الكاميرا فقط" : "Camera only") : (studio.appLanguage == .arabic ? "تعديل العنصر" : "Object edit")
        } label: {
            HStack(spacing: 5) {
                Image(systemName: icon)
                VStack(alignment: .leading, spacing: 0) {
                    Text(title).font(.system(size: 9.5, weight: .black, design: .rounded))
                    Text(subtitle).font(.system(size: 7.5, weight: .semibold))
                }
            }
            .frame(width: 76, height: 27)
            .background(studio.viewportInteractionMode == mode ? (mode == .view ? Color.cyan.opacity(0.25) : Color.orange.opacity(0.25)) : Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 8))
        }
        .buttonStyle(.plain)
        .studioTooltip(studio.appLanguage == .arabic ? subtitle : title)
    }
}

@MainActor
struct AxisSelector: View {
    @EnvironmentObject var studio: StudioStore

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 5) {
                axisButton(.free, title: "ALL", subtitle: "حر", tint: .orange)
                axisButton(.x, title: "X", subtitle: axisSubtitle(.x), tint: .red)
                axisButton(.y, title: "Y", subtitle: axisSubtitle(.y), tint: .green)
                axisButton(.z, title: "Z", subtitle: axisSubtitle(.z), tint: .blue)
            }

        }
    }

    private var selectedAxisDescription: String {
        switch studio.transformMode {
        case .move:
            switch studio.transformAxis {
            case .free: return "تحريك حر / Free Move"
            case .x: return "X — يمين / يسار"
            case .y: return "Y — فوق / تحت"
            case .z: return "Z — أمام / خلف"
            }
        case .rotate:
            switch studio.transformAxis {
            case .free: return "دوران حر / Free Rotate"
            case .x: return "X — دوران حول المحور X"
            case .y: return "Y — دوران حول المحور Y"
            case .z: return "Z — دوران حول المحور Z"
            }
        case .scale:
            switch studio.transformAxis {
            case .free: return "تكبير وتصغير كامل"
            case .x: return "X — حجم على X"
            case .y: return "Y — حجم على Y"
            case .z: return "Z — حجم على Z"
            }
        }
    }

    private func axisSubtitle(_ axis: TransformAxis) -> String {
        switch studio.transformMode {
        case .move:
            switch axis {
            case .x: return "يمين"
            case .y: return "فوق"
            case .z: return "عمق"
            case .free: return "حر"
            }
        case .rotate:
            return "لف"
        case .scale:
            return "حجم"
        }
    }

    private func axisButton(_ axis: TransformAxis, title: String, subtitle: String, tint: Color) -> some View {
        Button {
            studio.setTransformAxis(axis)
        } label: {
            VStack(spacing: 1) {
                Text(title)
                    .font(.system(size: 10, weight: .black, design: .rounded))
                Text(subtitle)
                    .font(.system(size: 7.5, weight: .semibold))
            }
            .frame(width: 43, height: 27)
            .contentShape(Rectangle())
            .background(
                studio.transformAxis == axis ? tint.opacity(0.32) : Color.white.opacity(0.05),
                in: RoundedRectangle(cornerRadius: 7)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 7)
                    .stroke(studio.transformAxis == axis ? tint.opacity(0.85) : Color.white.opacity(0.08), lineWidth: 0.7)
            )
        }
        .buttonStyle(.plain)
        .studioTooltip(studio.appLanguage == .arabic ? selectedAxisDescription : "Transform axis \(title)")
    }
}

// MARK: - Reusable UI

struct VectorEditor: View {
    @Binding var x: Float
    @Binding var y: Float
    @Binding var z: Float
    var suffix: String = ""

    var body: some View {
        VStack(spacing: 7) {
            axisRow("X", value: $x)
            axisRow("Y", value: $y)
            axisRow("Z", value: $z)
        }
    }

    private func axisRow(_ label: String, value: Binding<Float>) -> some View {
        HStack {
            Text(label)
                .font(.caption.bold())
                .frame(width: 18)
            TextField("0", value: value, format: .number.precision(.fractionLength(0...3)))
                .textFieldStyle(.roundedBorder)
                .keyboardType(.numbersAndPunctuation)
            if !suffix.isEmpty {
                Text(suffix)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

struct InspectorCard<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(.secondary)
            content
        }
        .padding(12)
        .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 12))
    }
}

@MainActor
struct ToolModeButton: View {
    @EnvironmentObject var studio: StudioStore
    let icon: String
    let title: String
    let mode: TransformMode

    var body: some View {
        Button {
            studio.transformMode = mode
            studio.viewportInteractionMode = .object
            studio.rebuildTransformGizmo()
            studio.statusText = "OBJECT • \(title)"
        } label: {
            Image(systemName: icon)
                .font(.system(size: 18, weight: .semibold))
                .frame(width: 44, height: 44)
                .background(studio.transformMode == mode ? Color.accentColor.opacity(0.3) : Color.black.opacity(0.25), in: Circle())
        }
        .buttonStyle(.plain)
        .studioTooltip(title)
    }
}

struct ViewportRoundButton: View {
    let icon: String
    let title: String
    var active: Bool = false
    var destructive: Bool = false
    let action: () -> Void


    var body: some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 17, weight: .bold))
                .foregroundStyle(destructive ? Color.red : Color.primary)
                .frame(width: 40, height: 40)
                .background(
                    active ? Color.accentColor.opacity(0.34) : Color(red: 0.12, green: 0.16, blue: 0.21).opacity(0.94),
                    in: Circle()
                )
                .overlay(
                    Circle().stroke(Color.white.opacity(active ? 0.20 : 0.08), lineWidth: 1)
                )
        }
        .buttonStyle(.plain)
        .contentShape(Circle())
        .studioTooltip(title)
        .accessibilityLabel(title)
    }
}

struct StudioToolbarButtonStyle: ButtonStyle {
    var active = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 11, weight: .semibold))
            .padding(.horizontal, 7)
            .frame(height: 30)
            .background(
                active ? Color.accentColor.opacity(0.3) :
                    (configuration.isPressed ? Color.white.opacity(0.11) : Color.white.opacity(0.055)),
                in: RoundedRectangle(cornerRadius: 9)
            )
            .contentShape(RoundedRectangle(cornerRadius: 9))
    }
}

func panelHeader(_ title: String, icon: String) -> some View {
    HStack {
        Label(title, systemImage: icon)
            .font(.system(size: 12, weight: .bold))
        Spacer()
    }
    .padding(.horizontal, 10)
    .frame(height: 38)
    .background(Color(red: 0.17, green: 0.17, blue: 0.19).opacity(0.96))
}

func sliderRow(_ title: String, value: Binding<Double>) -> some View {
    HStack {
        Text(title)
        Slider(value: value, in: 0...1)
        Text(String(format: "%.2f", value.wrappedValue))
            .font(.caption.monospacedDigit())
            .frame(width: 38)
    }
}

// MARK: - Models

enum SceneEnvironmentPreset: String, CaseIterable, Sendable {
    case none
    case day
    case sunset
    case overcast
    case night
    case custom

    var title: String {
        switch self {
        case .none: return "None"
        case .day: return "Day"
        case .sunset: return "Sunset"
        case .overcast: return "Overcast"
        case .night: return "Night"
        case .custom: return "Custom"
        }
    }
}

enum ViewportShadingMode: String, CaseIterable, Sendable {
    case wireframe
    case solid
    case lit
    case rendered

    var title: String {
        switch self {
        case .wireframe: return "Wire"
        case .solid: return "Solid"
        case .lit: return "Lit"
        case .rendered: return "Rendered"
        }
    }

    var icon: String {
        switch self {
        case .wireframe: return "globe"
        case .solid: return "circle.fill"
        case .lit: return "circle.lefthalf.filled"
        case .rendered: return "camera.aperture"
        }
    }
}

enum ViewportInteractionMode: String, CaseIterable, Sendable {
    case view
    case object
}

enum TransformMode: String, CaseIterable, Sendable {
    case move, rotate, scale
}

enum InspectorSection: String, CaseIterable, Sendable {
    case transform, material, object, modeling, animation, advanced, audio, light, camera, fx, scene

    var icon: String {
        switch self {
        case .transform: return "move.3d"
        case .material: return "paintpalette"
        case .object: return "cube"
        case .modeling: return "square.3.layers.3d.down.right"
        case .animation: return "timeline.selection"
        case .advanced: return "gearshape.2.fill"
        case .audio: return "waveform"
        case .light: return "lightbulb"
        case .camera: return "camera.aperture"
        case .fx: return "sparkles"
        case .scene: return "globe"
        }
    }

    var title: String {
        switch self {
        case .transform: return "Transform"
        case .material: return "Material"
        case .object: return "Object"
        case .modeling: return "Model"
        case .animation: return "Animate"
        case .advanced: return "Advanced"
        case .audio: return "Audio"
        case .light: return "Light"
        case .camera: return "Camera"
        case .fx: return "FX"
        case .scene: return "Scene"
        }
    }
}

enum PrimitiveKind: CaseIterable {
    case cube, sphere, cylinder, plane, torus, capsule, cone, pyramid, tube

    var title: String {
        switch self {
        case .cube: "Cube"
        case .sphere: "Sphere"
        case .cylinder: "Cylinder"
        case .plane: "Plane"
        case .torus: "Torus"
        case .capsule: "Capsule"
        case .cone: "Cone"
        case .pyramid: "Pyramid"
        case .tube: "Tube"
        }
    }

    var icon: String {
        switch self {
        case .cube: "cube.fill"
        case .sphere: "circle.inset.filled"
        case .cylinder: "cylinder.fill"
        case .plane: "rectangle.fill"
        case .torus: "circle.dashed"
        case .capsule: "capsule.fill"
        case .cone: "triangle.fill"
        case .pyramid: "triangle"
        case .tube: "circle.circle"
        }
    }
}

enum CameraPreset: CaseIterable {
    case perspective, front, side, top, cinematic

    var title: String {
        switch self {
        case .perspective: "Perspective"
        case .front: "Front"
        case .side: "Side"
        case .top: "Top"
        case .cinematic: "Cinematic"
        }
    }
}

enum ParticleKind: CaseIterable {
    case smoke, sparks, rain

    var title: String {
        switch self {
        case .smoke: "Smoke"
        case .sparks: "Sparks"
        case .rain: "Rain"
        }
    }

    var icon: String {
        switch self {
        case .smoke: "cloud.fog.fill"
        case .sparks: "sparkles"
        case .rain: "cloud.rain.fill"
        }
    }
}

enum LightEditorType: String, CaseIterable, Sendable {
    case omni, spot, directional, ambient
}

enum LightKind: CaseIterable {
    case omni, spot, directional, ambient

    var title: String {
        switch self {
        case .omni: "Point Light"
        case .spot: "Spot Light"
        case .directional: "Sun Light"
        case .ambient: "Ambient"
        }
    }
}

enum TransformAxis: String, CaseIterable, Sendable {
    case free, x, y, z
}

enum Axis3D {
    case x, y, z
}

struct MaterialKeyframeState {
    var preservesMissingContents = false
    var diffuse: Any?
    var metalness: Any?
    var roughness: Any?
    var emission: Any?
    var emissionIntensity: CGFloat
    var transparency: CGFloat

    init(_ material: SCNMaterial) {
        diffuse = material.diffuse.contents
        metalness = material.metalness.contents
        roughness = material.roughness.contents
        emission = material.emission.contents
        emissionIntensity = material.emission.intensity
        transparency = material.transparency
    }

    func apply(to material: SCNMaterial) {
        if !preservesMissingContents || diffuse != nil { material.diffuse.contents = diffuse }
        if !preservesMissingContents || metalness != nil { material.metalness.contents = metalness }
        if !preservesMissingContents || roughness != nil { material.roughness.contents = roughness }
        if !preservesMissingContents || emission != nil { material.emission.contents = emission }
        material.emission.intensity = emissionIntensity
        material.transparency = transparency
    }
}

enum StudioInterpolation: String, CaseIterable, Identifiable, Codable {
    case linear, smooth, easeIn, easeOut, hold
    var id: String { rawValue }
}

struct StudioKeyframe: Identifiable {
    let id = UUID()
    var nodeID: String? = nil
    var nodeName: String
    var time: Double
    var position: SCNVector3
    var euler: SCNVector3
    var scale: SCNVector3
    var cameraFOV: Double? = nil
    var cameraExposure: Double? = nil
    var cameraBloom: Double? = nil
    var lightIntensity: Double? = nil
    var lightColor: UIColor? = nil
    var trackID: String? = nil
    var interpolation: StudioInterpolation = .smooth
    var materialStates: [MaterialKeyframeState]? = nil

    func apply(to node: SCNNode) {
        node.position = position
        node.eulerAngles = euler
        node.scale = scale
        if let camera = node.camera {
            if let cameraFOV { camera.fieldOfView = CGFloat(cameraFOV) }
            if let cameraExposure { camera.exposureOffset = CGFloat(cameraExposure) }
            if let cameraBloom { camera.bloomIntensity = CGFloat(cameraBloom) }
        }
        if let light = node.light {
            if let lightIntensity { light.intensity = CGFloat(lightIntensity) }
            if let lightColor { light.color = lightColor }
        }
        if let materialStates = materialStates, let geometry = node.geometry {
            for (material, state) in zip(geometry.materials, materialStates) { state.apply(to: material) }
        }
    }
}

final class ImportedNodeBox: @unchecked Sendable {
    let node: SCNNode
    let warnings: [String]

    init(_ node: SCNNode, warnings: [String] = []) {
        self.node = node
        self.warnings = warnings
    }
}


enum SafeZIPExtractor {
    enum ZIPError: LocalizedError {
        case invalid, unsupported(String), tooLarge
        var errorDescription: String? {
            switch self {
            case .invalid: return "ملف ZIP غير صالح / Invalid ZIP archive"
            case .unsupported(let name): return "طريقة ضغط غير مدعومة داخل ZIP: \(name) / Unsupported ZIP compression"
            case .tooLarge: return "محتوى ZIP أكبر من حد الاستيراد الآمن / ZIP contents exceed import limit"
            }
        }
    }

    static func extract(_ archiveURL: URL, to destination: URL, maximumBytes: Int64) throws -> [URL] {
        let data = try Data(contentsOf: archiveURL, options: [.mappedIfSafe])
        guard data.count >= 22 else { throw ZIPError.invalid }
        func u16(_ o: Int) -> Int { Int(data[o]) | (Int(data[o+1]) << 8) }
        func u32(_ o: Int) -> Int { u16(o) | (u16(o+2) << 16) }

        let searchStart = max(0, data.count - 65_557)
        var eocd: Int? = nil
        if data.count >= 4 {
            for i in stride(from: data.count - 4, through: searchStart, by: -1) {
                if u32(i) == 0x06054b50 { eocd = i; break }
            }
        }
        guard let eocd else { throw ZIPError.invalid }
        let count = u16(eocd + 10)
        var cursor = u32(eocd + 16)
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
        let root = destination.standardizedFileURL
        var files: [URL] = []
        var expanded: Int64 = 0

        for _ in 0..<count {
            try Task.checkCancellation()
            guard cursor + 46 <= data.count, u32(cursor) == 0x02014b50 else { throw ZIPError.invalid }
            let method = u16(cursor + 10)
            let compressedSize = u32(cursor + 20)
            let uncompressedSize = u32(cursor + 24)
            let nameLength = u16(cursor + 28)
            let extraLength = u16(cursor + 30)
            let commentLength = u16(cursor + 32)
            let localOffset = u32(cursor + 42)
            guard cursor + 46 + nameLength <= data.count else { throw ZIPError.invalid }
            let nameData = data.subdata(in: (cursor + 46)..<(cursor + 46 + nameLength))
            guard let rawName = String(data: nameData, encoding: .utf8) ?? String(data: nameData, encoding: .isoLatin1) else { throw ZIPError.invalid }
            cursor += 46 + nameLength + extraLength + commentLength

            let cleaned = rawName.replacingOccurrences(of: "\\", with: "/")
            let parts = cleaned.split(separator: "/", omittingEmptySubsequences: true)
            guard !cleaned.hasPrefix("/"), !parts.contains(where: { $0 == ".." || $0 == "." }) else { continue }
            let target = parts.reduce(root) { $0.appendingPathComponent(String($1)) }.standardizedFileURL
            guard target.path == root.path || target.path.hasPrefix(root.path + "/") else { continue }
            if cleaned.hasSuffix("/") {
                try FileManager.default.createDirectory(at: target, withIntermediateDirectories: true)
                continue
            }
            expanded += Int64(uncompressedSize)
            guard expanded <= maximumBytes else { throw ZIPError.tooLarge }
            guard localOffset + 30 <= data.count, u32(localOffset) == 0x04034b50 else { throw ZIPError.invalid }
            let localNameLength = u16(localOffset + 26)
            let localExtraLength = u16(localOffset + 28)
            let payloadStart = localOffset + 30 + localNameLength + localExtraLength
            guard payloadStart + compressedSize <= data.count else { throw ZIPError.invalid }
            let payload = data.subdata(in: payloadStart..<(payloadStart + compressedSize))
            let decoded: Data
            switch method {
            case 0:
                decoded = payload
            case 8:
                var output = Data(count: uncompressedSize)
                let written = output.withUnsafeMutableBytes { dst in
                    payload.withUnsafeBytes { src in
                        compression_decode_buffer(
                            dst.bindMemory(to: UInt8.self).baseAddress!, uncompressedSize,
                            src.bindMemory(to: UInt8.self).baseAddress!, compressedSize,
                            nil, COMPRESSION_ZLIB
                        )
                    }
                }
                guard written == uncompressedSize else { throw ZIPError.unsupported(rawName) }
                output.count = written
                decoded = output
            default:
                throw ZIPError.unsupported(rawName)
            }
            try FileManager.default.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
            try decoded.write(to: target, options: .atomic)
            files.append(target)
        }
        return files
    }
}

enum ImportFileStager {
    static let maximumPrimaryFileBytes: Int64 = 1_000_000_000
    static let maximumHelperFileBytes: Int64 = 512_000_000
    static let maximumBatchBytes: Int64 = 1_000_000_000

    private static let helperExtensions: Set<String> = [
        "bin", "mtl", "png", "jpg", "jpeg", "webp", "bmp", "tga", "gif",
        "tif", "tiff", "hdr", "exr", "ktx", "ktx2"
    ]

    static func stage(_ urls: [URL]) throws -> [URL] {
        let root = FileManager.default.temporaryDirectory
            .appendingPathComponent("FiveLnImportSession-\(UUID().uuidString)", isDirectory: true)

        try FileManager.default.createDirectory(
            at: root,
            withIntermediateDirectories: true
        )

        var finished = false
        defer { if !finished { try? FileManager.default.removeItem(at: root) } }

        var common = urls.first?.deletingLastPathComponent().standardizedFileURL.pathComponents ?? []
        for url in urls.dropFirst() {
            let components = url.deletingLastPathComponent().standardizedFileURL.pathComponents
            while !components.starts(with: common) && !common.isEmpty { common.removeLast() }
        }

        var output: [URL] = []
        output.reserveCapacity(urls.count + 12)
        var totalBytes: Int64 = 0
        var stagedPaths = Set<String>()
        var selectedPairs: [(source: URL, staged: URL)] = []

        for originalURL in urls {
            try Task.checkCancellation()
            let access = originalURL.startAccessingSecurityScopedResource()
            defer {
                if access { originalURL.stopAccessingSecurityScopedResource() }
            }

            let values = try originalURL.resourceValues(
                forKeys: [.isDirectoryKey, .isRegularFileKey, .fileSizeKey]
            )

            guard values.isDirectory != true else {
                throw StudioImportError.cannotStage(
                    originalURL.lastPathComponent,
                    "المجلدات لا تُستورد مباشرة. اختر ملف الموديل نفسه."
                )
            }

            let ext = originalURL.pathExtension.lowercased()
            let limit = helperExtensions.contains(ext)
                ? maximumHelperFileBytes
                : maximumPrimaryFileBytes

            if let fileSize = values.fileSize,
               Int64(fileSize) > limit {
                throw StudioImportError.cannotStage(
                    originalURL.lastPathComponent,
                    "حجم الملف كبير جدًا للاستيراد الآمن على الجهاز."
                )
            }

            let fileBytes = Int64(values.fileSize ?? 0)
            totalBytes += fileBytes
            guard totalBytes <= maximumBatchBytes else {
                throw StudioImportError.cannotStage(
                    originalURL.lastPathComponent,
                    "حد الاستيراد للدفعة 1 GB؛ استورد على دفعات."
                )
            }

            let relative = originalURL.standardizedFileURL.pathComponents
                .dropFirst(common.count)
                .joined(separator: "/")
            let destination = root.appendingPathComponent(relative).standardizedFileURL

            guard destination.path.hasPrefix(root.path + "/") else {
                throw StudioImportError.cannotStage(originalURL.lastPathComponent, "مسار ملف غير صالح")
            }

            if stagedPaths.insert(destination.path).inserted {
                try FileManager.default.createDirectory(
                    at: destination.deletingLastPathComponent(),
                    withIntermediateDirectories: true
                )
                do {
                    try FileManager.default.copyItem(at: originalURL, to: destination)
                    output.append(destination)
                } catch {
                    throw StudioImportError.cannotStage(
                        originalURL.lastPathComponent,
                        error.localizedDescription
                    )
                }
            }
            selectedPairs.append((originalURL, destination))
        }

        // ZIP packages are expanded automatically inside the isolated import session.
        // This keeps OBJ/MTL/textures and glTF/BIN/images together with their relative paths.
        let zipFiles = output.filter { $0.pathExtension.lowercased() == "zip" }
        for zipURL in zipFiles {
            try Task.checkCancellation()
            let folder = zipURL.deletingPathExtension().appendingPathExtension("unzipped")
            let extracted = try SafeZIPExtractor.extract(zipURL, to: folder, maximumBytes: maximumBatchBytes - totalBytes)
            output.removeAll { $0 == zipURL }
            for file in extracted where stagedPaths.insert(file.path).inserted {
                output.append(file)
                let bytes = (try? file.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(Int64.init) ?? 0
                totalBytes += bytes
            }
        }

        // A common reason an OBJ/DAE/glTF arrives black is that the model file was
        // copied to the sandbox but its MTL/BIN/texture sidecars were left behind.
        // Pull only resources explicitly referenced by the selected model. This keeps
        // the import lightweight and preserves authored colors/textures whenever the
        // Files provider grants access to those sibling files.
        for pair in selectedPairs {
            try Task.checkCancellation()
            stageReferencedResources(
                sourceURL: pair.source,
                stagedURL: pair.staged,
                root: root,
                stagedPaths: &stagedPaths,
                output: &output,
                totalBytes: &totalBytes
            )
        }

        finished = true
        return output
    }

    private static func stageReferencedResources(
        sourceURL: URL,
        stagedURL: URL,
        root: URL,
        stagedPaths: inout Set<String>,
        output: inout [URL],
        totalBytes: inout Int64
    ) {
        let sourceBase = sourceURL.deletingLastPathComponent().standardizedFileURL

        var queue = referencedRelativePaths(in: sourceURL).map { ($0, sourceURL.deletingLastPathComponent(), stagedURL.deletingLastPathComponent()) }
        var visited = Set<String>()
        var processed = 0
        let resourceLimit = 256

        while !queue.isEmpty, processed < resourceLimit {
            if Task.isCancelled { return }
            processed += 1

            let (raw, referenceSourceBase, referenceStagedBase) = queue.removeFirst()
            guard let relative = normalizedRelativeResourcePath(raw) else { continue }
            let source = referenceSourceBase.appendingPathComponent(relative).standardizedFileURL
            guard visited.insert(source.path).inserted else { continue }
            guard source.path.hasPrefix(sourceBase.path + "/"),
                  FileManager.default.fileExists(atPath: source.path) else { continue }

            let destination = referenceStagedBase.appendingPathComponent(relative).standardizedFileURL
            guard destination.path.hasPrefix(root.path + "/") else { continue }

            if stagedPaths.contains(destination.path) {
                // A manually-selected MTL can still reference additional textures.
                if source.pathExtension.lowercased() == "mtl" {
                    queue.append(contentsOf: referencedRelativePaths(in: source).map { ($0, source.deletingLastPathComponent(), destination.deletingLastPathComponent()) })
                }
                continue
            }

            let access = source.startAccessingSecurityScopedResource()
            defer { if access { source.stopAccessingSecurityScopedResource() } }

            guard let values = try? source.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey]),
                  values.isRegularFile != false else { continue }

            let bytes = Int64(values.fileSize ?? 0)
            guard bytes >= 0,
                  bytes <= maximumHelperFileBytes,
                  totalBytes + bytes <= maximumBatchBytes else { continue }

            do {
                try FileManager.default.createDirectory(
                    at: destination.deletingLastPathComponent(),
                    withIntermediateDirectories: true
                )
                try FileManager.default.copyItem(at: source, to: destination)
                stagedPaths.insert(destination.path)
                output.append(destination)
                totalBytes += bytes

                if source.pathExtension.lowercased() == "mtl" {
                    queue.append(contentsOf: referencedRelativePaths(in: source).map { ($0, source.deletingLastPathComponent(), destination.deletingLastPathComponent()) })
                }
            } catch {
                // Companion resources are best-effort. The primary model should still
                // import and report missing textures rather than failing completely.
                continue
            }
        }
    }

    private static func normalizedRelativeResourcePath(_ raw: String) -> String? {
        var value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return nil }

        if value.hasPrefix("data:") || value.contains("://") { return nil }
        value = value.removingPercentEncoding ?? value
        value = value.trimmingCharacters(in: CharacterSet(charactersIn: "\\\"'"))
        value = value.replacingOccurrences(of: "\\", with: "/")

        while value.hasPrefix("./") { value.removeFirst(2) }
        guard !value.hasPrefix("/"), !value.isEmpty else { return nil }

        let components = value.split(separator: "/", omittingEmptySubsequences: true)
        // Parent segments are resolved against the referencing MTL, then bounded
        // by sourceBase and the isolated staging root in the caller.
        guard !components.isEmpty else { return nil }

        return components.joined(separator: "/")
    }

    private static func referencedRelativePaths(in url: URL) -> [String] {
        switch url.pathExtension.lowercased() {
        case "gltf":
            guard let data = try? Data(contentsOf: url, options: [.mappedIfSafe]),
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return [] }

            var refs: [String] = []
            if let buffers = json["buffers"] as? [[String: Any]] {
                refs.append(contentsOf: buffers.compactMap { $0["uri"] as? String })
            }
            if let images = json["images"] as? [[String: Any]] {
                refs.append(contentsOf: images.compactMap { $0["uri"] as? String })
            }
            return refs

        case "obj":
            return OBJMaterialResources.materialLibraries(url)

        case "mtl":
            return OBJMaterialResources.texturePaths(url)

        case "dae":
            guard let text = textPrefix(of: url, maximumBytes: 8 * 1024 * 1024),
                  let regex = try? NSRegularExpression(
                    pattern: #"<init_from>\s*([^<]+?)\s*</init_from>"#,
                    options: [.caseInsensitive]
                  ) else { return [] }
            let ns = text as NSString
            let range = NSRange(location: 0, length: ns.length)
            return regex.matches(in: text, options: [], range: range).compactMap { match in
                guard match.numberOfRanges > 1 else { return nil }
                return ns.substring(with: match.range(at: 1))
            }

        default:
            return []
        }
    }

    private static func textPrefix(of url: URL, maximumBytes: Int) -> String? {
        guard let handle = try? FileHandle(forReadingFrom: url) else { return nil }
        defer { try? handle.close() }
        let data = try? handle.read(upToCount: maximumBytes)
        guard let data, !data.isEmpty else { return nil }
        return String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1)
    }
}

enum AssetNodeLoader {
    private static let directSceneExtensions: Set<String> = [
        "scn", "dae", "obj", "usdz", "usd", "usda", "usdc", "abc"
    ]

    private static let modelIOFallbackExtensions: Set<String> = [
        "ply", "stl", "3ds", "md3", "off"
    ]

    static func load(url: URL) throws -> ImportedNodeBox {
        let values = try url.resourceValues(
            forKeys: [.isDirectoryKey, .isRegularFileKey, .fileSizeKey]
        )

        guard values.isDirectory != true,
              values.isRegularFile != false else {
            throw StudioImportError.unsupported("folder")
        }

        guard let fileSize = values.fileSize,
              fileSize > 0 else {
            throw StudioImportError.cannotStage(
                url.lastPathComponent,
                "الملف فارغ أو غير قابل للقراءة."
            )
        }

        let ext = url.pathExtension.lowercased()

        var warnings: [String] = []
        let resolvedOBJ = ext == "obj" ? try OBJMaterialResources.normalizedSource(url) : (url: url, temporaryFolder: nil)
        defer { if let folder = resolvedOBJ.temporaryFolder { try? FileManager.default.removeItem(at: folder) } }

        // Give the autorelease pool an explicit throwing/non-optional result type.
        // Swift Playgrounds can otherwise infer SCNNode? for this mixed loader
        // closure and then fail at the closing brace with:
        // “Cannot convert value of type 'SCNNode?' to specified type 'SCNNode'”.
        let node: SCNNode = try autoreleasepool { () throws -> SCNNode in
            if ext == "glb" || ext == "gltf" {
                let importer = GLTFImporter()
                let loadedNode = try importer.load(url: url)
                warnings = importer.warnings
                return loadedNode
            }

            if directSceneExtensions.contains(ext) {
                let options: [SCNSceneSource.LoadingOption: Any] = [
                    .checkConsistency: true,
                    .convertUnitsToMeters: true,
                    .createNormalsIfAbsent: true,
                    .flattenScene: false
                ]

                guard let source = SCNSceneSource(url: resolvedOBJ.url, options: options) else {
                    throw StudioImportError.unsupported(ext)
                }

                let importedScene = try source.scene(options: options)
                return wrappedRoot(
                    from: importedScene,
                    name: url.deletingPathExtension().lastPathComponent
                )
            }

            if modelIOFallbackExtensions.contains(ext) {
                let asset = MDLAsset(url: url)
                guard asset.count > 0 else {
                    throw StudioImportError.unsupported(ext)
                }
                let imported = SCNScene(mdlAsset: asset)
                return wrappedRoot(
                    from: imported,
                    name: url.deletingPathExtension().lastPathComponent
                )
            }

            // Last-chance system loaders: this lets future/system-supported model
            // formats work without hard-coding one extension at a time.
            let sceneOptions: [SCNSceneSource.LoadingOption: Any] = [
                .checkConsistency: true,
                .convertUnitsToMeters: true,
                .createNormalsIfAbsent: true,
                .flattenScene: false
            ]

            if let source = SCNSceneSource(url: url, options: sceneOptions) {
                do {
                    let scene = try source.scene(options: sceneOptions)
                    return wrappedRoot(
                        from: scene,
                        name: url.deletingPathExtension().lastPathComponent
                    )
                } catch {
                    // Fall through to Model I/O below; some files are accepted
                    // there even when SceneKit's direct scene loader rejects them.
                }
            }

            let fallbackAsset = MDLAsset(url: url)
            if fallbackAsset.count > 0 {
                let imported = SCNScene(mdlAsset: fallbackAsset)
                return wrappedRoot(
                    from: imported,
                    name: url.deletingPathExtension().lastPathComponent
                )
            }

            throw StudioImportError.unsupported(ext.isEmpty ? "unknown" : ext)
        }

        // Bound recursion before calling SceneKit's recursive editor operations.
        var stack: [(SCNNode, Int)] = [(node,0)]
        var count = 0
        while let (item,depth) = stack.popLast() {
            count += 1
            guard count <= 20_000, depth <= 256 else { throw GLTFImportError.resourceLimit }
            for child in item.childNodes { stack.append((child,depth+1)) }
        }
        if ext == "obj" { try OBJMaterialResources.bindImages(in: node, obj: url) }
        warnings.append(contentsOf: ProjectSceneCodec.embedImportedResources(node, baseURL: url.deletingLastPathComponent()))
        return ImportedNodeBox(node, warnings: warnings)
    }

    private static func wrappedRoot(from scene: SCNScene, name: String) -> SCNNode {
        let wrapper = SCNNode()
        wrapper.name = name

        // childNodes returns a snapshot array, so detaching while iterating it is safe.
        let children = scene.rootNode.childNodes
        for child in children {
            child.removeFromParentNode()
            wrapper.addChildNode(child)
        }

        return wrapper
    }
}

enum StudioImportError: LocalizedError {
    case unsupported(String)
    case cannotStage(String, String)

    var errorDescription: String? {
        switch self {
        case .unsupported(let ext):
            "صيغة \(ext.uppercased()) غير مدعومة مباشرة على هذا الجهاز حاليًا. جرّب USDZ/OBJ/GLB/glTF أو حوّل الملف لصيغة مدعومة."

        case .cannotStage(let fileName, let detail):
            "تعذر تجهيز الملف \(fileName) للاستيراد. \(detail)"
        }
    }
}


// MARK: - Small SceneKit Helpers

extension SCNNode {
    // SceneKit has no userData property. An invisible, geometry-free child stores
    // the persistent identity through native clone/archive without custom decoding.
    var isStudioMetadata: Bool { ["_5LnIdentity:", "_5LnGLTFTarget:", "_5LnGLTFState:", "_5LnIK:"].contains { name?.hasPrefix($0) == true } }
    var studioAnimationID: String? {
        get {
            guard let marker = childNodes.first(where: { $0.name?.hasPrefix("_5LnIdentity:") == true }), let name = marker.name else { return nil }
            return String(name.dropFirst("_5LnIdentity:".count))
        }
        set {
            childNodes.filter { $0.name?.hasPrefix("_5LnIdentity:") == true }.forEach { $0.removeFromParentNode() }
            if let newValue {
                let marker = SCNNode()
                marker.name = "_5LnIdentity:" + newValue
                marker.isHidden = true
                addChildNode(marker)
            }
        }
    }

    func studioLook(at target: SCNVector3) {
        // Callers place a newly created/moved camera before aiming it. Its
        // presentation pose still belongs to the previous render (or origin).
        // Aim from the current model pose so initial views never point skyward.
        let p = worldPosition
        let dx = target.x - p.x
        let dy = target.y - p.y
        let dz = target.z - p.z

        let horizontal = max(0.000001, sqrtf(dx * dx + dz * dz))
        let yaw = atan2f(-dx, -dz)
        let pitch = atan2f(dy, horizontal)

        eulerAngles = SCNVector3(pitch, yaw, 0)
    }
}

// Unattached import graph processing; all live scene edits stay on MainActor.
enum ImportedHierarchyProcessor {
    static func prepareImportedHierarchy(_ root: SCNNode, assetName: String) {
        if root.name == nil || root.name?.isEmpty == true || root.name == "glTF" {
            root.name = assetName
        }

        // Prisma/Meld-style editable import:
        // Keep the original object hierarchy, but expose material/geometry sections
        // as real child nodes whenever SceneKit imported them as one combined mesh.
        // This is what makes glass, lamps, trim, wheels, body panels, etc. selectable
        // independently when the source file actually contains separate material slots.
        separateImportedMaterialParts(in: root)

        var genericCounter = 1
        var meshCounter = 1

        root.enumerateChildNodes { node, _ in
            if node.name == "_SelectionOutline" { return }

            let oldName = node.name?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            let lower = oldName.lowercased()
            let isGeneric = oldName.isEmpty ||
                            lower.hasPrefix("node ") ||
                            lower.hasPrefix("primitive ") ||
                            lower.hasPrefix("material part ")

            if isGeneric {
                if let geometry = node.geometry {
                    let materialName = geometry.firstMaterial?.name?
                        .trimmingCharacters(in: .whitespacesAndNewlines)

                    if let materialName, !materialName.isEmpty {
                        node.name = materialName
                    } else {
                        node.name = inferredPartName(
                            material: geometry.firstMaterial,
                            fallback: "Mesh \(meshCounter)"
                        )
                        meshCounter += 1
                    }
                } else if let light = node.light {
                    let lightName = light.name?
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                    node.name = (lightName?.isEmpty == false)
                        ? lightName
                        : "Light \(genericCounter)"
                    genericCounter += 1
                } else if let camera = node.camera {
                    let cameraName = camera.name?
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                    node.name = (cameraName?.isEmpty == false)
                        ? cameraName
                        : "Camera \(genericCounter)"
                    genericCounter += 1
                } else {
                    node.name = "Part \(genericCounter)"
                    genericCounter += 1
                }
            }
        }
    }

    /// SceneKit/ModelIO frequently import an OBJ/USD/DAE object as one SCNNode
    /// with several geometry elements. Each element can point at a different
    /// material, which means a car's glass/lamp/body may exist in the file but
    /// still appear as one unselectable object in the editor. Convert those
    /// elements into child nodes while preserving the parent's transform.
    ///
    /// Animated/skinned geometry is intentionally left intact because splitting
    /// it would detach the skin/morph bindings. glTF static primitives are already
    /// emitted as independent nodes by our GLTF importer.
    static func separateImportedMaterialParts(in root: SCNNode, deep: Bool = false) {
        var candidates: [SCNNode] = []

        if root.geometry != nil {
            candidates.append(root)
        }

        root.enumerateChildNodes { node, _ in
            if node.geometry != nil &&
               node.name != "_SelectionOutline" &&
               node.name != "_SelectionOutline" && node.name != "_TransformGizmo" && !node.isStudioMetadata {
                candidates.append(node)
            }
        }

        var serial = 1
        var generatedPartCount = 0
        let generatedPartLimit = deep ? 5_000 : 1_200

        for node in candidates {
            guard let geometry = node.geometry,
                  node.skinner == nil,
                  node.morpher == nil else {
                continue
            }

            let elements = geometry.elements
            guard !elements.isEmpty,
                  generatedPartCount + elements.count <= generatedPartLimit else { continue }
            if !deep && elements.count == 1 { continue }

            let materials = geometry.materials
            var children: [SCNNode] = []
            var usedNames = Set(node.childNodes.compactMap { $0.name })

            let baseName = node.name?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let cleanBase = (baseName?.isEmpty == false ? baseName! : "Object")

            for (elementIndex, element) in elements.enumerated() {
                let material: SCNMaterial?
                if !materials.isEmpty {
                    material = materials[elementIndex % materials.count]
                } else {
                    material = nil
                }

                // First split by source geometry element/material slot, then split
                // disconnected triangle islands inside that element. This exposes
                // pieces that are separate in topology even when the source used
                // one object and one material for several disconnected parts.
                var componentElements = geometryElementsForEditableParts(from: element, deep: deep)

                // Never drop geometry. If automatic/deep decomposition would exceed
                // the scene-node budget, keep this source element as one editable part.
                if generatedPartCount + componentElements.count + (elements.count - elementIndex - 1) > generatedPartLimit {
                    componentElements = [cloneGeometryElement(element)]
                }

                for (componentIndex, componentElement) in componentElements.enumerated() {
                    let partGeometry = SCNGeometry(
                        sources: geometry.sources,
                        elements: [componentElement]
                    )
                    partGeometry.name = geometry.name
                    partGeometry.subdivisionLevel = geometry.subdivisionLevel
                    if let bounds = boundsForElement(componentElement, geometry: geometry) {
                        partGeometry.boundingBox = bounds
                    }

                    if let material {
                        partGeometry.materials = [material]
                    }

                    let partNode = SCNNode(geometry: partGeometry)
                    let materialName = material?.name?
                        .trimmingCharacters(in: .whitespacesAndNewlines)

                    let requestedName: String
                    if let materialName, !materialName.isEmpty {
                        requestedName = componentElements.count > 1
                            ? "\(materialName) • \(componentIndex + 1)"
                            : materialName
                    } else {
                        let inferred = inferredPartName(
                            material: material,
                            fallback: "\(cleanBase) • Part \(serial)"
                        )
                        requestedName = componentElements.count > 1
                            ? "\(inferred) • \(componentIndex + 1)"
                            : inferred
                    }

                    partNode.name = uniqueImportedPartName(
                        requestedName,
                        usedNames: &usedNames,
                        suffix: serial
                    )

                    partNode.categoryBitMask = node.categoryBitMask
                    partNode.castsShadow = node.castsShadow
                    partNode.renderingOrder = node.renderingOrder
                    partNode.movabilityHint = node.movabilityHint
                    children.append(partNode)
                    generatedPartCount += 1
                    serial += 1
                }
            }

            // Do not rewrite a simple one-element/one-island mesh. It is already
            // a perfect editable part and preserving it avoids needless node growth.
            guard children.count > 1 || elements.count > 1 else { continue }

            node.geometry = nil
            for child in children {
                node.addChildNode(child)
            }
        }
    }

    static func geometryElementsForEditableParts(
        from element: SCNGeometryElement,
        deep: Bool
    ) -> [SCNGeometryElement] {
        // Fast import follows the object/material boundaries already authored in
        // the file. Computing disconnected triangle islands for every mesh during
        // import caused the large post-import slowdown in complex cars/scenes.
        // Deep Parts performs that expensive topology pass only when requested.
        guard deep else {
            return [cloneGeometryElement(element)]
        }

        let triangleLimit = 350_000
        let componentLimit = 2_000

        guard element.primitiveType == .triangles,
              element.primitiveCount > 1,
              element.primitiveCount <= triangleLimit,
              let indices = triangleIndices(from: element),
              indices.count == element.primitiveCount * 3 else {
            return [cloneGeometryElement(element)]
        }

        let triangleCount = element.primitiveCount
        var parent = Array(0..<triangleCount)
        var rank = Array(repeating: UInt8(0), count: triangleCount)
        var firstTriangleForVertex: [UInt32: Int] = [:]
        firstTriangleForVertex.reserveCapacity(min(indices.count, 500_000))

        func find(_ value: Int) -> Int {
            var x = value
            while parent[x] != x {
                x = parent[x]
            }
            var y = value
            while parent[y] != y {
                let next = parent[y]
                parent[y] = x
                y = next
            }
            return x
        }

        func unite(_ a: Int, _ b: Int) {
            var ra = find(a)
            var rb = find(b)
            guard ra != rb else { return }

            if rank[ra] < rank[rb] {
                swap(&ra, &rb)
            }
            parent[rb] = ra
            if rank[ra] == rank[rb] {
                rank[ra] &+= 1
            }
        }

        for triangle in 0..<triangleCount {
            let base = triangle * 3
            for vertex in indices[base..<(base + 3)] {
                if let previous = firstTriangleForVertex[vertex] {
                    unite(triangle, previous)
                } else {
                    firstTriangleForVertex[vertex] = triangle
                }
            }
        }

        var grouped: [Int: [UInt32]] = [:]
        grouped.reserveCapacity(min(triangleCount, 256))

        for triangle in 0..<triangleCount {
            let root = find(triangle)
            let base = triangle * 3
            grouped[root, default: []].append(indices[base])
            grouped[root, default: []].append(indices[base + 1])
            grouped[root, default: []].append(indices[base + 2])
        }

        // One connected island means the original geometry element is already
        // the smallest meaningful editable piece. Also avoid pathological assets
        // that would create tens of thousands of SceneKit nodes.
        guard grouped.count > 1, grouped.count <= componentLimit else {
            return [cloneGeometryElement(element)]
        }

        return grouped.values
            .sorted { $0.count > $1.count }
            .map { componentIndices in
                SCNGeometryElement(
                    data: uint32Data(componentIndices),
                    primitiveType: .triangles,
                    primitiveCount: componentIndices.count / 3,
                    bytesPerIndex: MemoryLayout<UInt32>.size
                )
            }
    }

    // Shared vertex buffers can contain the whole car. Bound a part using its own
    // referenced vertices so the gizmo and Frame action center on that part.
    static func boundsForElement(_ element: SCNGeometryElement, geometry: SCNGeometry)
        -> (min: SCNVector3, max: SCNVector3)? {
        guard let source = geometry.sources(for: .vertex).first,
              source.usesFloatComponents, source.bytesPerComponent == 4,
              source.componentsPerVector >= 3,
              [1,2,4].contains(element.bytesPerIndex),
              source.dataStride >= 12, source.dataOffset >= 0,
              source.dataOffset <= source.data.count else { return nil }
        let bytes = element.bytesPerIndex
        let count = element.data.count / bytes
        guard count > 0, count <= 12_000_000 else { return nil }
        var minimum = SCNVector3(Float.greatestFiniteMagnitude,Float.greatestFiniteMagnitude,Float.greatestFiniteMagnitude)
        var maximum = SCNVector3(-Float.greatestFiniteMagnitude,-Float.greatestFiniteMagnitude,-Float.greatestFiniteMagnitude)
        var valid = true
        element.data.withUnsafeBytes { (indices: UnsafeRawBufferPointer) in
            source.data.withUnsafeBytes { (vertices: UnsafeRawBufferPointer) in
                func word(_ data: UnsafeRawBufferPointer, _ offset: Int, _ length: Int) -> UInt32 {
                    var result: UInt32 = 0
                    for byte in 0..<length { result |= UInt32(data[offset+byte]) << (byte*8) }
                    return result
                }
                for index in 0..<count {
                    let vertex = Int(word(indices,index*bytes,bytes))
                    guard vertex < source.vectorCount,
                          vertices.count-source.dataOffset >= 12,
                          vertex <= (vertices.count-source.dataOffset-12)/source.dataStride else { valid = false; break }
                    let offset = source.dataOffset+vertex*source.dataStride
                    let x = Float(bitPattern: word(vertices,offset,4))
                    let y = Float(bitPattern: word(vertices,offset+4,4))
                    let z = Float(bitPattern: word(vertices,offset+8,4))
                    guard x.isFinite, y.isFinite, z.isFinite else { valid = false; break }
                    minimum.x = min(minimum.x,x); minimum.y = min(minimum.y,y); minimum.z = min(minimum.z,z)
                    maximum.x = max(maximum.x,x); maximum.y = max(maximum.y,y); maximum.z = max(maximum.z,z)
                }
            }
        }
        return valid ? (minimum,maximum) : nil
    }

    static func cloneGeometryElement(_ element: SCNGeometryElement) -> SCNGeometryElement {
        let copy = SCNGeometryElement(
            data: element.data,
            primitiveType: element.primitiveType,
            primitiveCount: element.primitiveCount,
            bytesPerIndex: element.bytesPerIndex
        )
        copy.primitiveRange = element.primitiveRange
        return copy
    }

    static func triangleIndices(from element: SCNGeometryElement) -> [UInt32]? {
        let bytes = element.bytesPerIndex
        guard bytes == 1 || bytes == 2 || bytes == 4 else { return nil }

        guard element.primitiveCount >= 0, element.primitiveCount <= 4_000_000 else { return nil }
        let indexCount = element.primitiveCount * 3

        let data = element.data
        guard data.count >= indexCount * bytes else { return nil }

        var result: [UInt32] = []
        result.reserveCapacity(indexCount)

        data.withUnsafeBytes { raw in
            guard let baseAddress = raw.baseAddress else { return }
            let base = baseAddress.assumingMemoryBound(to: UInt8.self)

            for index in 0..<indexCount {
                let offset = index * bytes
                switch bytes {
                case 1:
                    result.append(UInt32(base[offset]))
                case 2:
                    let value = UInt32(base[offset]) |
                                (UInt32(base[offset + 1]) << 8)
                    result.append(value)
                default:
                    let value = UInt32(base[offset]) |
                                (UInt32(base[offset + 1]) << 8) |
                                (UInt32(base[offset + 2]) << 16) |
                                (UInt32(base[offset + 3]) << 24)
                    result.append(value)
                }
            }
        }

        return result.count == indexCount ? result : nil
    }

    static func uint32Data(_ values: [UInt32]) -> Data {
        values.withUnsafeBufferPointer { buffer in
            guard let base = buffer.baseAddress else { return Data() }
            return Data(
                bytes: base,
                count: buffer.count * MemoryLayout<UInt32>.size
            )
        }
    }

    static func uniqueImportedPartName(
        _ requested: String,
        usedNames: inout Set<String>,
        suffix: Int
    ) -> String {
        let clean = requested.trimmingCharacters(in: .whitespacesAndNewlines)
        let base = clean.isEmpty ? "Part" : clean

        if usedNames.insert(base).inserted {
            return base
        }

        var n = max(2, suffix)
        var candidate = "\(base) \(n)"
        while !usedNames.insert(candidate).inserted {
            n += 1
            candidate = "\(base) \(n)"
        }
        return candidate
    }

    static func inferredPartName(
        material: SCNMaterial?,
        fallback: String
    ) -> String {
        guard let material else { return fallback }

        let name = material.name?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if !name.isEmpty { return name }

        // Give otherwise anonymous imported sections useful names. This does not
        // invent geometry; it only labels sections the source file already separated.
        if material.transparency < 0.98 || material.blendMode == .alpha {
            return "Glass / Transparent"
        }

        if let color = material.diffuse.contents as? UIColor,
           color.cgColor.alpha < 0.98 {
            return "Glass / Transparent"
        }

        if let color = material.emission.contents as? UIColor {
            var red: CGFloat = 0
            var green: CGFloat = 0
            var blue: CGFloat = 0
            var alpha: CGFloat = 0
            if color.getRed(&red, green: &green, blue: &blue, alpha: &alpha),
               max(red, max(green, blue)) > 0.03,
               alpha > 0.01 {
                return "Light / Emissive"
            }
        } else if material.emission.contents != nil {
            return "Light / Emissive"
        }

        return fallback
    }

}
