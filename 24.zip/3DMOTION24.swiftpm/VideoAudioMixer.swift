import Foundation
import AVFoundation

@MainActor
enum VideoAudioMixer {
    static func finish(_ session: AVAssetExportSession) async throws {
        await withTaskCancellationHandler(operation: {
            await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
                session.exportAsynchronously { continuation.resume() }
            }
        }, onCancel: { session.cancelExport() })
        try Task.checkCancellation()
        guard session.status == .completed else {
            throw session.error ?? StudioVideoFailure.problem("تعذر دمج الصوت / Audio export failed")
        }
    }

    static func combine(video: URL, output: URL, clips: [StudioAudioClip], masterVolume: Double,
                        duration: Double, folder: URL) async throws -> Bool {
        let active = clips.filter { $0.startTime < duration && $0.trimmedDuration > 0 }
        guard !active.isEmpty else { try FileManager.default.moveItem(at: video, to: output); return false }
        let composition = AVMutableComposition()
        var parameters: [AVAudioMixInputParameters] = []
        for clip in active {
            try Task.checkCancellation()
            let asset = AVURLAsset(url: clip.url)
            guard let source = try await asset.loadTracks(withMediaType: .audio).first,
                  let target = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) else {
                throw StudioVideoFailure.problem("تعذر قراءة الصوت: \(clip.name) / Audio unavailable")
            }
            let available = CMTimeGetSeconds(try await asset.load(.duration))
            guard available.isFinite, available + 0.05 >= clip.trimmedEnd else {
                throw StudioVideoFailure.problem("نطاق الصوت غير صالح: \(clip.name) / Invalid audio range")
            }
            var start = clip.startTime
            repeat {
                let length = min(clip.trimmedDuration, duration - start)
                let range = CMTimeRange(start: CMTime(seconds: clip.sourceStart, preferredTimescale: 48_000),
                    duration: CMTime(seconds: length, preferredTimescale: 48_000))
                try target.insertTimeRange(range, of: source, at: CMTime(seconds: start, preferredTimescale: 48_000))
                start += length
                try Task.checkCancellation()
            } while clip.loops && start < duration - 0.000001
            let volume = AVMutableAudioMixInputParameters(track: target)
            volume.setVolume(Float(max(0, min(1, clip.volume * masterVolume))), at: .zero)
            parameters.append(volume)
        }
        let mix = AVMutableAudioMix(); mix.inputParameters = parameters
        let audioURL = folder.appendingPathComponent("mixed.m4a")
        guard let audioExport = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetAppleM4A) else {
            throw StudioVideoFailure.problem("تعذر تجهيز الصوت / Audio export unavailable")
        }
        audioExport.outputURL = audioURL; audioExport.outputFileType = .m4a; audioExport.audioMix = mix
        try await finish(audioExport)

        let final = AVMutableComposition(), videoAsset = AVURLAsset(url: video), audioAsset = AVURLAsset(url: audioURL)
        guard let videoSource = try await videoAsset.loadTracks(withMediaType: .video).first,
              let audioSource = try await audioAsset.loadTracks(withMediaType: .audio).first,
              let videoTrack = final.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid),
              let audioTrack = final.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            throw StudioVideoFailure.problem("تعذر دمج الفيديو والصوت / Video and audio merge unavailable")
        }
        try videoTrack.insertTimeRange(CMTimeRange(start: .zero, duration: try await videoAsset.load(.duration)), of: videoSource, at: .zero)
        videoTrack.preferredTransform = try await videoSource.load(.preferredTransform)
        try audioTrack.insertTimeRange(CMTimeRange(start: .zero, duration: try await audioAsset.load(.duration)), of: audioSource, at: .zero)
        guard let mux = AVAssetExportSession(asset: final, presetName: AVAssetExportPresetPassthrough) else {
            throw StudioVideoFailure.problem("تعذر تجهيز الملف النهائي / Final export unavailable")
        }
        mux.outputURL = output; mux.outputFileType = .mp4; mux.shouldOptimizeForNetworkUse = true
        try await finish(mux)
        return true
    }
}
