import Foundation
import SwiftUI
import UIKit
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

@MainActor
struct InspectorPanel: View {
    @EnvironmentObject var studio: StudioStore

    var body: some View {
        VStack(spacing: 0) {
            panelHeader("الخصائص / Inspector", icon: "slider.horizontal.3")
            InspectorTabBar()
            ScrollView {
                InspectorContent()
                    .padding(10)
            }
        }
        .background(Color(red: 0.105, green: 0.135, blue: 0.175).opacity(0.97))
    }
}

@MainActor
private struct InspectorTabBar: View {
    @EnvironmentObject var studio: StudioStore

    private let primary: [InspectorSection] = [
        .transform, .material, .object, .modeling, .animation, .advanced
    ]
    private let secondary: [InspectorSection] = [
        .audio, .light, .camera, .fx, .scene
    ]

    var body: some View {
        HStack(spacing: 6) {
            ForEach(primary, id: \.self) { section in
                InspectorTabButton(section: section)
            }
            Menu {
                ForEach(secondary, id: \.self) { section in
                    Button {
                        studio.activeInspector = section
                    } label: {
                        Label(section.title, systemImage: section.icon)
                    }
                }
            } label: {
                VStack(spacing: 3) {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 13, weight: .bold))
                    Text(studio.appLanguage == .arabic ? "المزيد" : "More")
                        .font(.system(size: 8, weight: .semibold))
                }
                .frame(width: 44, height: 42)
                .background(
                    secondary.contains(studio.activeInspector)
                        ? Color.accentColor.opacity(0.28)
                        : Color.white.opacity(0.045),
                    in: RoundedRectangle(cornerRadius: 9)
                )
            }
            .studioTooltip(studio.appLanguage == .arabic ? "المزيد من أدوات الخصائص" : "More inspector tools")
        }
        .padding(.horizontal, 9)
        .padding(.vertical, 8)
    }
}

@MainActor
private struct InspectorTabButton: View {
    @EnvironmentObject var studio: StudioStore
    let section: InspectorSection

    var body: some View {
        Button {
            studio.activeInspector = section
        } label: {
            VStack(spacing: 3) {
                Image(systemName: section.icon)
                    .font(.system(size: 13, weight: .semibold))
                Text(section.title)
                    .font(.system(size: 8, weight: .semibold))
            }
            .frame(maxWidth: .infinity)
            .frame(height: 42)
            .background(
                studio.activeInspector == section
                    ? Color.accentColor.opacity(0.28)
                    : Color.white.opacity(0.045),
                in: RoundedRectangle(cornerRadius: 9)
            )
        }
        .buttonStyle(.plain)
        .studioTooltip(section.title)
    }
}

@MainActor
private struct InspectorContent: View {
    @EnvironmentObject var studio: StudioStore

    var body: some View {
        Group {
            if studio.selectedNode == nil && ![InspectorSection.audio, .scene, .fx].contains(studio.activeInspector) {
                Text("حدد عنصرًا من المشهد")
                    .foregroundStyle(.secondary)
                    .padding(.top, 40)
            } else {
                erasedInspector
            }
        }
    }

    private var erasedInspector: AnyView {
        switch studio.activeInspector {
        case .transform: return AnyView(TransformInspector())
        case .material: return AnyView(MaterialInspector())
        case .object: return AnyView(ObjectInspector())
        case .modeling: return AnyView(ModelingInspector())
        case .animation: return AnyView(AnimationInspector())
        case .advanced: return AnyView(AdvancedToolsInspector())
        case .audio: return AnyView(AudioInspector())
        case .light: return AnyView(LightInspector())
        case .camera: return AnyView(CameraInspector())
        case .fx: return AnyView(FXInspector())
        case .scene: return AnyView(SceneInspector())
        }
    }
}

