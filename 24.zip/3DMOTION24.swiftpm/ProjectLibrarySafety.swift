import Foundation
import SceneKit

enum ProjectSwitchRequest {
    case new(String)
    case library(StudioStore.ProjectCard)
    case document(Data)
}

@MainActor
extension StudioStore {
    /// All editor and library switch actions use the same save-before-switch
    /// contract. The destination is never touched when saving fails.
    @discardableResult
    func performProjectSwitch(_ request: ProjectSwitchRequest, savingCurrent: Bool) -> Bool {
        guard !workshopIsRunning, !isExporting, !importIsRunning, !audioImportRunning, !isAutosaving, !isTransformGestureActive else {
            reportProjectError(ProjectFailure.busy); return false
        }
        stopPlayback()
        if savingCurrent && !saveNamedProject() { return false }
        switch request {
        case .new(let name): newProject(named: name); return true
        case .library(let card): return openProject(card)
        case .document(let data):
            do { try importPortableProject(data); return true }
            catch { reportProjectError(error); return false }
        }
    }

    func reportProjectError(_ error: Error) {
        let message = (appLanguage == .arabic ? "تعذر إكمال العملية: " : "Operation failed: ") + error.localizedDescription
        toast = message; projectErrorDetails = message
    }

    func projectFolder(id: String) -> URL {
        projectsFolderURL.appendingPathComponent(id, isDirectory: true)
    }

    func writeProjectLabel(_ name: String, in folder: URL) throws {
        try Data(name.utf8).write(to: folder.appendingPathComponent("ProjectName.txt"), options: .atomic)
    }

    func updateProjectPreview(in folder: URL) {
        // Preview capture is optional and never changes the save result.
        let presentation = RenderPresentationState(store: self)
        defer { presentation.restore() }
        if let data = scnView?.snapshot().jpegData(compressionQuality: 0.65) {
            try? data.write(to: folder.appendingPathComponent("Preview.jpg"), options: .atomic)
        }
    }

    @discardableResult
    func renameProject(_ card: ProjectCard, to name: String) -> Bool {
        let name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, card.id != "autosave://last", ProjectFileStore.safeComponent(card.id) else { return false }
        do {
            let folder = projectFolder(id: card.id), url = folder.appendingPathComponent("Project.3dmotion")
            var package = try ProjectFileStore.decode(Data(contentsOf: url))
            package.name = name; package.seal()
            let data = try verifiedProjectData(package)
            try ProjectFileStore.commit(data, to: url)
            try writeProjectLabel(name, in: folder)
            if currentProjectLibraryID == card.id { currentProjectName = name }
            return true
        } catch { reportProjectError(error); return false }
    }

    @discardableResult
    func duplicateProject(_ card: ProjectCard) -> Bool {
        guard card.id != "autosave://last", ProjectFileStore.safeComponent(card.id) else { return false }
        do {
            let original = projectFolder(id: card.id)
            var package = try ProjectFileStore.decode(Data(contentsOf: original.appendingPathComponent("Project.3dmotion")))
            package.name += appLanguage == .arabic ? " نسخة" : " Copy"
            let id = UUID().uuidString
            var metadata = try JSONDecoder().decode(StudioAutosaveMetadata.self, from: package.metadata)
            metadata.projectLibraryID = id; package.metadata = try JSONEncoder().encode(metadata)
            package.seal()
            let data = try verifiedProjectData(package)
            let folder = projectFolder(id: id)
            try ProjectFileStore.commit(data, to: folder.appendingPathComponent("Project.3dmotion"))
            try writeProjectLabel(package.name, in: folder)
            let preview = original.appendingPathComponent("Preview.jpg")
            if FileManager.default.fileExists(atPath: preview.path) { try? FileManager.default.copyItem(at: preview, to: folder.appendingPathComponent("Preview.jpg")) }
            return true
        } catch { reportProjectError(error); return false }
    }

    func deletedProjectCards() -> [ProjectCard] {
        let trash = autosaveFolderURL.appendingPathComponent("DeletedProjects", isDirectory: true)
        let urls = (try? FileManager.default.contentsOfDirectory(at: trash, includingPropertiesForKeys: [.contentModificationDateKey, .isDirectoryKey])) ?? []
        return urls.compactMap { url in
            let isFolder = (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true
            let file = isFolder ? url.appendingPathComponent("Project.3dmotion") : url
            guard FileManager.default.fileExists(atPath: file.path) else { return nil }
            let values = try? file.resourceValues(forKeys: [.contentModificationDateKey, .fileSizeKey])
            let name = (try? String(contentsOf: url.appendingPathComponent("ProjectName.txt"), encoding: .utf8)) ?? url.lastPathComponent
            return ProjectCard(id: url.lastPathComponent, name: name, modified: values?.contentModificationDate ?? .distantPast, size: Int64(values?.fileSize ?? 0))
        }.sorted { $0.modified > $1.modified }
    }

    @discardableResult
    func restoreDeletedProject(_ card: ProjectCard) -> Bool {
        guard ProjectFileStore.safeComponent(card.id) else { return false }
        do {
            let original = autosaveFolderURL.appendingPathComponent("DeletedProjects", isDirectory: true).appendingPathComponent(card.id)
            let isFolder = try original.resourceValues(forKeys: [.isDirectoryKey]).isDirectory == true
            let file = isFolder ? original.appendingPathComponent("Project.3dmotion") : original
            var package = try ProjectFileStore.decode(Data(contentsOf: file))
            let id = UUID().uuidString, folder = projectFolder(id: id)
            var metadata = try JSONDecoder().decode(StudioAutosaveMetadata.self, from: package.metadata)
            metadata.projectLibraryID = id; package.metadata = try JSONEncoder().encode(metadata); package.seal()
            try ProjectFileStore.commit(verifiedProjectData(package), to: folder.appendingPathComponent("Project.3dmotion"))
            try writeProjectLabel(package.name, in: folder)
            try FileManager.default.removeItem(at: original)
            return true
        } catch { reportProjectError(error); return false }
    }
}
