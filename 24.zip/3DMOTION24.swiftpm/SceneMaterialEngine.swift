import Foundation
import SwiftUI
import UIKit
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

@MainActor
extension StudioStore {
// MARK: Look / Scene Settings

    // MARK: - Scene Environment

    func setEnvironmentPreset(_ preset: SceneEnvironmentPreset) {
        pushUndoSnapshot("Environment")
        environmentPreset = preset
        applySceneEnvironment()
    }

    func setCustomEnvironmentImage(_ image: UIImage) {
        pushUndoSnapshot("Custom Environment")
        customEnvironmentImage = image
        environmentPreset = .custom
        applySceneEnvironment()
        saveAutosave(showToast: false)
    }

    func applySceneEnvironment() {
        let contents: Any?

        switch environmentPreset {
        case .none:
            let colors: [UIColor] = [.init(white: 0.12, alpha: 1), .black, .init(white: 0.22, alpha: 1), .init(white: 0.55, alpha: 1), .init(white: 0.92, alpha: 1), .init(red: 0.035, green: 0.07, blue: 0.13, alpha: 1)]
            contents = colors[max(0, min(colors.count - 1, viewportBackgroundIndex))]

        case .day:
            contents = makeEnvironmentGradient(
                top: UIColor(red: 0.30, green: 0.60, blue: 0.94, alpha: 1),
                bottom: UIColor(red: 0.84, green: 0.91, blue: 0.98, alpha: 1)
            )

        case .sunset:
            contents = makeEnvironmentGradient(
                top: UIColor(red: 0.18, green: 0.10, blue: 0.30, alpha: 1),
                bottom: UIColor(red: 0.98, green: 0.35, blue: 0.12, alpha: 1)
            )

        case .overcast:
            contents = makeEnvironmentGradient(
                top: UIColor(white: 0.43, alpha: 1),
                bottom: UIColor(white: 0.76, alpha: 1)
            )

        case .night:
            contents = makeEnvironmentGradient(
                top: UIColor(red: 0.015, green: 0.025, blue: 0.09, alpha: 1),
                bottom: UIColor(red: 0.05, green: 0.07, blue: 0.18, alpha: 1)
            )

        case .custom:
            contents = customEnvironmentImage ?? UIColor(white: 0.12, alpha: 1)
        }

        scene.background.contents = contents

        if environmentPreset == .none {
            scene.lightingEnvironment.contents = nil
            scene.lightingEnvironment.intensity = 0
        } else {
            scene.lightingEnvironment.contents = contents
            scene.lightingEnvironment.intensity = CGFloat(environmentIntensity)
        }

        objectWillChange.send()
    }

    func makeEnvironmentGradient(
        top: UIColor,
        bottom: UIColor
    ) -> UIImage {
        let size = CGSize(width: 1024, height: 512)
        let renderer = UIGraphicsImageRenderer(size: size)

        return renderer.image { context in
            let colors = [
                top.cgColor,
                bottom.cgColor
            ] as CFArray

            let locations: [CGFloat] = [0, 1]

            if let gradient = CGGradient(
                colorsSpace: CGColorSpaceCreateDeviceRGB(),
                colors: colors,
                locations: locations
            ) {
                context.cgContext.drawLinearGradient(
                    gradient,
                    start: CGPoint(x: size.width * 0.5, y: 0),
                    end: CGPoint(x: size.width * 0.5, y: size.height),
                    options: []
                )
            }
        }
    }

    func exportSceneFile() -> URL? {
        guard !importIsRunning, !isTransformGestureActive, !isAutosaving else {
            toast = "انتظر انتهاء العملية الحالية / Wait for the current operation"
            return nil
        }
        stopPlayback()
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd_HH-mm-ss"

        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent(
                "5Ln_3D_Scene_\(formatter.string(from: Date())).scn"
            )

        let savedOutline = selectionOutline
        let outlineParent = savedOutline?.parent
        savedOutline?.removeFromParentNode()
        selectionGizmo?.isHidden = true

        let editorWasAttached = editorRoot.parent != nil
        let helpersWereAttached = helpersRoot.parent != nil

        if editorWasAttached {
            editorRoot.removeFromParentNode()
        }

        if helpersWereAttached {
            helpersRoot.removeFromParentNode()
        }

        defer {
            if editorWasAttached,
               editorRoot.parent == nil {
                scene.rootNode.addChildNode(editorRoot)
            }

            if helpersWereAttached,
               helpersRoot.parent == nil {
                scene.rootNode.addChildNode(helpersRoot)
            }

            if let savedOutline, let outlineParent {
                outlineParent.addChildNode(savedOutline)
            }
            selectionGizmo?.isHidden = false
        }

        // Export the live scene graph. Building a second deep copy of a large
        // imported model before export was an unnecessary out-of-memory risk.
        let ok = scene.write(
            to: url,
            options: nil,
            delegate: nil,
            progressHandler: nil
        )

        if ok {
            toast = "Scene exported"
            return url
        } else {
            toast = "تعذر تصدير المشهد"
            return nil
        }
    }

    func applySceneSettings() {
        scene.fogStartDistance = fogEnabled ? 3 : 100000
        scene.fogEndDistance = fogEnabled ? max(6, 42 - fogDensity * 30) : 100001
        scene.fogDensityExponent = fogEnabled ? max(0.2, fogDensity * 2.2) : 0

        let ui = UIColor(fogColor)
        scene.fogColor = ui

        if let ambient = lightsRoot.childNode(withName: "Ambient", recursively: false) {
            ambient.light?.intensity = CGFloat(ambientStrength)
        }
    }

    // MARK: Materials

    enum ReadyMaterialPreset: String, CaseIterable, Identifiable {
        case matte, plastic, metal, chrome, gold, glass, wood, stone, asphalt, rubber, fabric, leather, carbon, water, neonBlue, neonPink, neonGreen
        var id: String { rawValue }
    }

    func applyReadyMaterial(_ preset: ReadyMaterialPreset) {
        guard let selectedNode else { return }

        func configure(_ material: SCNMaterial) {
            // Every preset starts from a clean render state. Glass/water/neon change
            // depth, transparency and emission flags; if those flags are left behind,
            // the next material looks like it is layered on top of the previous one.
            material.lightingModel = .physicallyBased
            material.blendMode = .alpha
            material.transparencyMode = .aOne
            material.transparency = 1
            material.writesToDepthBuffer = true
            material.readsFromDepthBuffer = true
            material.isDoubleSided = false
            material.cullMode = .back
            material.diffuse.intensity = 1
            material.multiply.contents = UIColor.white
            material.transparent.contents = UIColor.white
            material.emission.contents = UIColor.black
            material.emission.intensity = 0

            switch preset {
            case .matte:
                material.diffuse.contents = UIColor(white: 0.45, alpha: 1)
                material.metalness.contents = 0.0
                material.roughness.contents = 0.88
                material.transparency = 1
            case .plastic:
                material.diffuse.contents = UIColor(white: 0.28, alpha: 1)
                material.metalness.contents = 0.0
                material.roughness.contents = 0.28
                material.transparency = 1
            case .metal:
                material.diffuse.contents = UIColor(white: 0.48, alpha: 1)
                material.metalness.contents = 0.92
                material.roughness.contents = 0.24
                material.transparency = 1
            case .chrome:
                material.diffuse.contents = UIColor(white: 0.72, alpha: 1)
                material.metalness.contents = 1.0
                material.roughness.contents = 0.06
                material.transparency = 1
            case .gold:
                material.diffuse.contents = UIColor(red: 1.0, green: 0.64, blue: 0.12, alpha: 1)
                material.metalness.contents = 0.95
                material.roughness.contents = 0.16
                material.transparency = 1
            case .glass:
                material.diffuse.contents = UIColor(white: 0.82, alpha: 1)
                material.metalness.contents = 0.05
                material.roughness.contents = 0.05
                // Opacity is controlled in one place only. Using both diffuse alpha
                // and material.transparency multiplied the value twice.
                material.transparency = 0.30
                material.transparencyMode = .dualLayer
                material.writesToDepthBuffer = false
                material.isDoubleSided = true
            case .wood:
                material.diffuse.contents = UIColor(red: 0.34, green: 0.16, blue: 0.07, alpha: 1); material.metalness.contents = 0.0; material.roughness.contents = 0.72; material.transparency = 1
            case .stone:
                material.diffuse.contents = UIColor(white: 0.42, alpha: 1); material.metalness.contents = 0.0; material.roughness.contents = 0.90; material.transparency = 1
            case .asphalt:
                material.diffuse.contents = UIColor(white: 0.12, alpha: 1); material.metalness.contents = 0.0; material.roughness.contents = 0.96; material.transparency = 1
            case .rubber:
                material.diffuse.contents = UIColor(white: 0.06, alpha: 1); material.metalness.contents = 0.0; material.roughness.contents = 0.78; material.transparency = 1
            case .fabric:
                material.diffuse.contents = UIColor(red: 0.24, green: 0.28, blue: 0.34, alpha: 1); material.metalness.contents = 0.0; material.roughness.contents = 1.0; material.transparency = 1
            case .leather:
                material.diffuse.contents = UIColor(red: 0.20, green: 0.075, blue: 0.04, alpha: 1); material.metalness.contents = 0.0; material.roughness.contents = 0.58; material.transparency = 1
            case .carbon:
                material.diffuse.contents = UIColor(white: 0.035, alpha: 1); material.metalness.contents = 0.55; material.roughness.contents = 0.25; material.transparency = 1
            case .water:
                material.diffuse.contents = UIColor(red: 0.05, green: 0.32, blue: 0.48, alpha: 1); material.metalness.contents = 0.0; material.roughness.contents = 0.04; material.transparency = 0.52; material.transparencyMode = .dualLayer; material.writesToDepthBuffer = false; material.isDoubleSided = true
            case .neonBlue:
                let c = UIColor(red: 0.05, green: 0.75, blue: 1.0, alpha: 1)
                material.diffuse.contents = c
                material.emission.contents = c
                material.emission.intensity = 4.5
                material.metalness.contents = 0.05
                material.roughness.contents = 0.18
                material.transparency = 1
            case .neonPink:
                let c = UIColor(red: 1.0, green: 0.05, blue: 0.58, alpha: 1)
                material.diffuse.contents = c
                material.emission.contents = c
                material.emission.intensity = 4.5
                material.metalness.contents = 0.05
                material.roughness.contents = 0.18
                material.transparency = 1
            case .neonGreen:
                let c = UIColor(red: 0.1, green: 1.0, blue: 0.32, alpha: 1)
                material.diffuse.contents = c
                material.emission.contents = c
                material.emission.intensity = 4.5
                material.metalness.contents = 0.05
                material.roughness.contents = 0.18
                material.transparency = 1
            }
        }

        var allMaterials: [SCNMaterial] = []
        if let geometry = selectedNode.geometry {
            if geometry.materials.isEmpty { geometry.materials = [SCNMaterial()] }
            allMaterials.append(contentsOf: geometry.materials)
        }
        selectedNode.enumerateChildNodes { child, _ in
            guard let geometry = child.geometry else { return }
            if geometry.materials.isEmpty { geometry.materials = [SCNMaterial()] }
            allMaterials.append(contentsOf: geometry.materials)
        }

        if !allMaterials.isEmpty {
            recordMaterialEdit(label: "Material Preset", key: "material-preset", materials: allMaterials) {
                allMaterials.forEach { configure($0) }
            }
            if preset == .neonBlue || preset == .neonPink || preset == .neonGreen {
                let camera = scnView?.pointOfView?.camera
                camera?.wantsHDR = true
                camera?.bloomIntensity = max(camera?.bloomIntensity ?? 0, 1.2)
                camera?.bloomThreshold = min(camera?.bloomThreshold ?? 1, 0.35)
                camera?.bloomBlurRadius = max(camera?.bloomBlurRadius ?? 0, 10)
            }
            toast = "تم تطبيق الخامة / Material applied"
            objectWillChange.send()
        }
    }

    private func editableMaterialsForSelectedPart() -> [SCNMaterial] {
        guard let geometry = selectedNode?.geometry else { return [] }
        if geometry.materials.isEmpty {
            geometry.materials = [SCNMaterial()]
        }
        return geometry.materials
    }

    func setMaterialColor(_ color: Color) {
        let materials = editableMaterialsForSelectedPart()
        guard !materials.isEmpty else { return }

        // Color and opacity are separate controls. Always write an opaque RGB base
        // color so repeated color changes replace one another instead of multiplying
        // alpha from an earlier glass/water state.
        let uiColor = UIColor(color).withAlphaComponent(1)
        recordMaterialEdit(label: "Material Color", key: "material-color", materials: materials) {
            materials.forEach { material in
                material.diffuse.contents = uiColor
                material.diffuse.intensity = 1
                material.multiply.contents = UIColor.white

                // Preserve an intentional emissive/neon material, but keep its glow the
                // same hue as the newly selected base color instead of mixing old/new hues.
                if material.emission.intensity > 0 {
                    material.emission.contents = uiColor
                } else {
                    material.emission.contents = UIColor.black
                }
            }
        }
        objectWillChange.send()
    }

    func setMetalness(_ value: Double) {
        let materials = editableMaterialsForSelectedPart()
        guard !materials.isEmpty else { return }

        let clamped = max(0, min(1, value))
        recordMaterialEdit(label: "Metalness", key: "metalness", materials: materials) {
            materials.forEach { $0.metalness.contents = clamped }
        }
        objectWillChange.send()
    }

    func setRoughness(_ value: Double) {
        let materials = editableMaterialsForSelectedPart()
        guard !materials.isEmpty else { return }

        let clamped = max(0, min(1, value))
        recordMaterialEdit(label: "Roughness", key: "roughness", materials: materials) {
            materials.forEach { $0.roughness.contents = clamped }
        }
        objectWillChange.send()
    }

    func setEmissionColor(_ color: Color) {
        let materials = editableMaterialsForSelectedPart()
        guard !materials.isEmpty else { return }

        let uiColor = UIColor(color)
        recordMaterialEdit(label: "Emission Color", key: "emission-color", materials: materials) {
            materials.forEach { $0.emission.contents = uiColor }
        }
        objectWillChange.send()
    }

    func setEmissionStrength(_ value: Double) {
        let materials = editableMaterialsForSelectedPart()
        guard !materials.isEmpty else { return }

        let strength = max(0, min(12, value))
        recordMaterialEdit(label: "Emission Strength", key: "emission-strength", materials: materials) {
            materials.forEach { material in
                material.emission.intensity = CGFloat(strength)
                if strength > 0, material.emission.contents == nil {
                    material.emission.contents = material.diffuse.contents ?? UIColor.white
                }
            }
        }

        if strength > 0 {
            let camera = scnView?.pointOfView?.camera
            camera?.wantsHDR = true
            camera?.bloomIntensity = max(camera?.bloomIntensity ?? 0, 1.0)
            camera?.bloomThreshold = min(camera?.bloomThreshold ?? 1, 0.45)
            camera?.bloomBlurRadius = max(camera?.bloomBlurRadius ?? 0, 8)
        }

        objectWillChange.send()
    }

    func resetSelectedMaterialToOriginal() {
        let materials = editableMaterialsForSelectedPart()
        resetMaterialsToOriginal(materials)
        objectWillChange.send()
    }

    // Kept for compatibility with older UI code/builds.
    func setEmission(_ value: Double) {
        setEmissionStrength(max(0, min(1, value)) * 4.0)
    }

    func setMaterialOpacity(_ value: Double) {
        let materials = editableMaterialsForSelectedPart()
        guard !materials.isEmpty else { return }

        let opacity = max(0, min(1, value))
        recordMaterialEdit(label: "Material Opacity", key: "material-opacity", materials: materials) {
            materials.forEach { material in
                material.transparency = CGFloat(opacity)
                if opacity < 0.999 {
                    material.blendMode = .alpha
                    material.transparencyMode = .aOne
                    material.writesToDepthBuffer = opacity > 0.82
                } else {
                    material.writesToDepthBuffer = true
                }
            }
        }
        objectWillChange.send()
    }

}
