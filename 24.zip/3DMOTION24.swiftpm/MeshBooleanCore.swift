import Foundation

extension WorkshopMesh {
    enum BooleanOperation: String, CaseIterable { case union, subtract, intersect }
    func isClosedSolid() throws -> Bool {
        let mesh=try welded(tolerance:1e-8,preserveUV:false)
        var edges:[String:(count:Int,balance:Int)]=[:]
        for f in mesh.faces {
            if Self.length(Self.cross(mesh.vertices[f.b].p-mesh.vertices[f.a].p,mesh.vertices[f.c].p-mesh.vertices[f.a].p))<1e-12 { return false }
            for e in 0..<3 {
                let a=f.indices[e],b=f.indices[(e+1)%3],key="\(min(a,b)):\(max(a,b))"
                var value=edges[key] ?? (0,0); value.count += 1; value.balance += a<b ? 1 : -1; edges[key]=value
            }
        }
        return edges.values.allSatisfy { $0.count==2 && $0.balance==0 }
    }
    func boolean(_ operation: BooleanOperation, with other: WorkshopMesh) throws -> WorkshopMesh {
        _=try checked(); _=try other.checked()
        guard faces.count+other.faces.count<=12_000 else { throw MeshWorkshopError.limit }
        guard try isClosedSolid(), try other.isClosedSolid() else { throw MeshWorkshopError.unsupported }
        let budget=BSPBudget()
        let a=try BSPTree(polygons:polygons(),budget:budget), b=try BSPTree(polygons:other.polygons(),budget:budget)
        switch operation {
        case .union:
            try a.clip(to:b); try b.clip(to:a); b.invert(); try b.clip(to:a); b.invert(); try a.build(b.allPolygons())
        case .subtract:
            a.invert(); try a.clip(to:b); try b.clip(to:a); b.invert(); try b.clip(to:a); b.invert(); try a.build(b.allPolygons()); a.invert()
        case .intersect:
            a.invert(); try b.clip(to:a); b.invert(); try a.clip(to:b); try b.clip(to:a); try a.build(b.allPolygons()); a.invert()
        }
        var output=WorkshopMesh(vertices:[],faces:[])
        for polygon in a.allPolygons() where polygon.vertices.count>=3 {
            let base=output.vertices.count; output.vertices += polygon.vertices
            for i in 1..<(polygon.vertices.count-1) { output.faces.append(Face(a:base,b:base+i,c:base+i+1,material:polygon.material)) }
            guard output.faces.count<=Self.maximumFaces,output.vertices.count<=Self.maximumVertices else { throw MeshWorkshopError.limit }
        }
        return try output.conformingEdges()
    }
    // BSP splits can create a T junction on a neighboring triangle. Split both
    // sides at every shared point so a result remains a closed editable solid.
    private func conformingEdges() throws -> WorkshopMesh {
        _=try checked()
        let (lo,hi)=bounds,epsilon=max(1e-9,Self.length(hi-lo)*1e-9)
        let unique=try welded(tolerance:epsilon,preserveUV:false).vertices.map(\.p)
        let sorted=(0..<3).map {axis in unique.sorted {$0[axis]<$1[axis]}}
        var result=WorkshopMesh(vertices:[],faces:[]),work=0
        for face in faces {
            try Task.checkCancellation()
            var boundary:[Vertex]=[],split=false
            for e in 0..<3 {
                let a=vertices[face.indices[e]],b=vertices[face.indices[(e+1)%3]],d=b.p-a.p,length2=Self.dot(d,d)
                guard length2>epsilon*epsilon else {continue}
                let axis=(0..<3).max {abs(d[$0])<abs(d[$1])}!,points=sorted[axis],minValue=min(a.p[axis],b.p[axis])-epsilon,maxValue=max(a.p[axis],b.p[axis])+epsilon
                var lower=0,upper=points.count
                while lower<upper {let middle=(lower+upper)/2;if points[middle][axis]<minValue {lower=middle+1}else{upper=middle}}
                var interior:[(Double,WorkshopMesh.V)]=[],i=lower
                while i<points.count,points[i][axis]<=maxValue {
                    work += 1;guard work<=8_000_000 else {throw MeshWorkshopError.limit}
                    let p=points[i],t=Self.dot(p-a.p,d)/length2
                    if t>epsilon/sqrt(length2),t<1-epsilon/sqrt(length2),Self.length(p-(a.p+d*t))<=epsilon {interior.append((t,p))}
                    i += 1
                }
                boundary.append(a)
                for (t,p) in interior.sorted(by:{$0.0<$1.0}) {var v=Vertex.interpolate(a,b,t);v.p=p;boundary.append(v);split=true}
            }
            if split {
                let a=vertices[face.a],b=vertices[face.b],c=vertices[face.c],base=result.vertices.count
                result.vertices.append(Vertex(p:(a.p+b.p+c.p)/3,n:Self.unit(a.n+b.n+c.n),uv:(a.uv+b.uv+c.uv)/3));result.vertices += boundary
                for e in boundary.indices {result.faces.append(Face(a:base,b:base+1+e,c:base+1+(e+1)%boundary.count,material:face.material))}
            } else {
                let base=result.vertices.count;result.vertices += face.indices.map {vertices[$0]};result.faces.append(Face(a:base,b:base+1,c:base+2,material:face.material))
            }
            guard result.faces.count<=Self.maximumFaces,result.vertices.count<=Self.maximumVertices else {throw MeshWorkshopError.limit}
        }
        return try result.checked()
    }
    private func polygons() -> [BSPPolygon] { faces.map { BSPPolygon(vertices:$0.indices.map {vertices[$0]},material:$0.material) } }
}

private final class BSPBudget {
    var fragments=0
    func add(_ amount:Int) throws { try Task.checkCancellation(); fragments += amount; if fragments>500_000 { throw MeshWorkshopError.limit } }
}
private struct BSPPlane {
    var normal:WorkshopMesh.V
    var distance:Double
    static let epsilon=1e-7
    mutating func invert() { normal *= -1; distance *= -1 }
    func split(_ polygon:BSPPolygon,coplanarFront:inout [BSPPolygon],coplanarBack:inout [BSPPolygon],front:inout [BSPPolygon],back:inout [BSPPolygon]) {
        var types:[Int]=[],kind=0
        for vertex in polygon.vertices {
            let d=WorkshopMesh.dot(normal,vertex.p)-distance
            let type=d < -Self.epsilon ? 2 : (d > Self.epsilon ? 1 : 0)
            types.append(type); kind |= type
        }
        switch kind {
        case 0: if WorkshopMesh.dot(normal,polygon.plane.normal)>0 { coplanarFront.append(polygon) } else { coplanarBack.append(polygon) }
        case 1: front.append(polygon)
        case 2: back.append(polygon)
        default:
            var f:[WorkshopMesh.Vertex]=[],b:[WorkshopMesh.Vertex]=[]
            for i in polygon.vertices.indices {
                let j=(i+1)%polygon.vertices.count,a=polygon.vertices[i],next=polygon.vertices[j],ta=types[i],tb=types[j]
                if ta != 2 { f.append(a) }; if ta != 1 { b.append(a) }
                if (ta | tb)==3 {
                    let divisor=WorkshopMesh.dot(normal,next.p-a.p)
                    let t=(distance-WorkshopMesh.dot(normal,a.p))/divisor
                    let v=WorkshopMesh.Vertex.interpolate(a,next,max(0,min(1,t))); f.append(v); b.append(v)
                }
            }
            if f.count>=3 { front.append(BSPPolygon(vertices:f,material:polygon.material,plane:polygon.plane)) }
            if b.count>=3 { back.append(BSPPolygon(vertices:b,material:polygon.material,plane:polygon.plane)) }
        }
    }
}
private struct BSPPolygon {
    var vertices:[WorkshopMesh.Vertex]
    var material:Int
    var plane:BSPPlane
    init(vertices:[WorkshopMesh.Vertex],material:Int,plane:BSPPlane?=nil) {
        self.vertices=vertices; self.material=material
        let n=WorkshopMesh.unit(WorkshopMesh.cross(vertices[1].p-vertices[0].p,vertices[2].p-vertices[0].p))
        self.plane=plane ?? BSPPlane(normal:n,distance:WorkshopMesh.dot(n,vertices[0].p))
    }
    mutating func invert() { vertices.reverse(); for i in vertices.indices { vertices[i].n *= -1 }; plane.invert() }
}
private final class BSPTree {
    var plane:BSPPlane?, polygons:[BSPPolygon]=[], front:BSPTree?,back:BSPTree?
    let budget:BSPBudget
    let depth:Int
    init(polygons:[BSPPolygon]=[],budget:BSPBudget,depth:Int=0) throws {
        self.budget=budget; self.depth=depth; try build(polygons)
    }
    func invert() {
        for i in polygons.indices { polygons[i].invert() }; plane?.invert(); front?.invert(); back?.invert(); swap(&front,&back)
    }
    func allPolygons() -> [BSPPolygon] { polygons+(front?.allPolygons() ?? [])+(back?.allPolygons() ?? []) }
    func build(_ input:[BSPPolygon]) throws {
        if input.isEmpty { return }
        guard depth<192 else { throw MeshWorkshopError.limit }; try budget.add(input.count)
        if plane==nil { plane=input[input.count/2].plane }
        var f:[BSPPolygon]=[],b:[BSPPolygon]=[],cf:[BSPPolygon]=[],cb:[BSPPolygon]=[]
        for polygon in input { plane!.split(polygon,coplanarFront:&cf,coplanarBack:&cb,front:&f,back:&b) }
        polygons += cf+cb
        if !f.isEmpty { if front==nil { front=try BSPTree(budget:budget,depth:depth+1) }; try front!.build(f) }
        if !b.isEmpty { if back==nil { back=try BSPTree(budget:budget,depth:depth+1) }; try back!.build(b) }
    }
    func clipped(_ input:[BSPPolygon]) throws -> [BSPPolygon] {
        guard let plane else { return input }; try budget.add(input.count)
        var f:[BSPPolygon]=[],b:[BSPPolygon]=[],cf:[BSPPolygon]=[],cb:[BSPPolygon]=[]
        for polygon in input { plane.split(polygon,coplanarFront:&cf,coplanarBack:&cb,front:&f,back:&b) }
        f += cf; b += cb
        if let front { f=try front.clipped(f) }; if let back { b=try back.clipped(b) } else { b=[] }
        return f+b
    }
    func clip(to other:BSPTree) throws { polygons=try other.clipped(polygons); try front?.clip(to:other); try back?.clip(to:other) }
}
