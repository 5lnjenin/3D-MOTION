import Foundation
import SceneKit
import UIKit
import simd

extension GLTFImporter {
    func buildSkins(nodes:[SCNNode],root:SCNNode) throws {
        let definitions=json["nodes"] as? [[String:Any]] ?? [],skins=json["skins"] as? [[String:Any]] ?? [],meshes=json["meshes"] as? [[String:Any]] ?? []
        guard skins.count<=1024 else {throw GLTFImportError.resourceLimit}
        for i in definitions.indices {
            guard let skinIndex=definitions[i]["skin"] as? Int else {continue}
            try Task.checkCancellation()
            guard skins.indices.contains(skinIndex),let meshIndex=definitions[i]["mesh"] as? Int,meshes.indices.contains(meshIndex),
                  let meshRoot=nodes[i].childNodes.first(where: {$0.geometry==nil && !$0.isStudioMetadata}),
                  let joints=skins[skinIndex]["joints"] as? [Int],!joints.isEmpty,joints.count<=512,Set(joints).count==joints.count,joints.allSatisfy(nodes.indices.contains) else {throw GLTFImportError.invalidMesh}
            let bones=joints.map {nodes[$0]}
            // Keep off-scene skeleton roots needed by a visible mesh.
            for bone in bones {
                var top=bone
                while let parent=top.parent,parent !== root {top=parent}
                if top.parent==nil {root.addChildNode(top)}
            }
            var inverse:[NSValue]=[]
            if let accessor=skins[skinIndex]["inverseBindMatrices"] as? Int {
                let layout=try accessorLayout(accessor)
                guard layout.components==16,layout.componentType==5126,layout.count==bones.count else {throw GLTFImportError.invalidAccessor}
                let values=try readFloatAccessor(accessor).values
                for bone in bones.indices {
                    let f=Array(values[(bone*16)..<(bone*16+16)]),m=simd_float4x4(columns:(SIMD4(f[0],f[1],f[2],f[3]),SIMD4(f[4],f[5],f[6],f[7]),SIMD4(f[8],f[9],f[10],f[11]),SIMD4(f[12],f[13],f[14],f[15])))
                    guard abs(simd_determinant(m))>1e-12 else {throw GLTFImportError.invalidAccessor}
                    inverse.append(NSValue(scnMatrix4:SCNMatrix4(m)))
                }
            } else {inverse=bones.map {_ in NSValue(scnMatrix4:SCNMatrix4Identity)}}
            let primitives=meshes[meshIndex]["primitives"] as? [[String:Any]] ?? []
            let primitiveNodes=meshRoot.childNodes.filter {$0.geometry != nil}
            guard primitiveNodes.count==primitives.count else {throw GLTFImportError.invalidMesh}
            for (pi,primitive) in primitives.enumerated() {
                guard let attrs=primitive["attributes"] as? [String:Any],let ji=attrs["JOINTS_0"] as? Int,let wi=attrs["WEIGHTS_0"] as? Int,
                      let geometry=primitiveNodes[pi].geometry,let vertexCount=geometry.sources(for:.vertex).first?.vectorCount else {throw GLTFImportError.invalidMesh}
                let jointLayout=try accessorLayout(ji)
                guard [5121,5123].contains(jointLayout.componentType),!jointLayout.normalized else {throw GLTFImportError.invalidAccessor}
                let j=try readFloatAccessor(ji),w=try readFloatAccessor(wi)
                guard j.count==vertexCount,w.count==vertexCount,j.components==4,w.components==4,vertexCount<=1_000_000 else {throw GLTFImportError.invalidMesh}
                var jointValues=j.values,weightValues=w.values,influences=4
                if let ji1=attrs["JOINTS_1"] as? Int,let wi1=attrs["WEIGHTS_1"] as? Int {
                    let layout=try accessorLayout(ji1),j1=try readFloatAccessor(ji1),w1=try readFloatAccessor(wi1)
                    guard [5121,5123].contains(layout.componentType),!layout.normalized,j1.count==vertexCount,w1.count==vertexCount,j1.components==4,w1.components==4 else {throw GLTFImportError.invalidAccessor}
                    jointValues=[];weightValues=[];influences=8
                    for row in 0..<vertexCount {jointValues += Array(j.values[row*4..<(row*4+4)])+Array(j1.values[row*4..<(row*4+4)]);weightValues += Array(w.values[row*4..<(row*4+4)])+Array(w1.values[row*4..<(row*4+4)])}
                } else if attrs["JOINTS_1"] != nil || attrs["WEIGHTS_1"] != nil {throw GLTFImportError.invalidAccessor}
                guard jointValues.allSatisfy({$0>=0 && $0<Float(bones.count) && $0.rounded()==$0}),weightValues.allSatisfy({$0>=0}) else {throw GLTFImportError.invalidAccessor}
                for row in 0..<vertexCount {
                    let start=row*influences,sum=weightValues[start..<(start+influences)].reduce(0,+)
                    guard sum>1e-9,sum.isFinite else {throw GLTFImportError.invalidAccessor}
                    for k in 0..<influences {weightValues[start+k] /= sum}
                }
                let ids=jointValues.map {UInt16($0)},weights=SCNGeometrySource(data:weightValues.withUnsafeBytes {Data($0)},semantic:.boneWeights,vectorCount:vertexCount,usesFloatComponents:true,componentsPerVector:influences,bytesPerComponent:4,dataOffset:0,dataStride:influences*4)
                let indices=SCNGeometrySource(data:ids.withUnsafeBytes {Data($0)},semantic:.boneIndices,vectorCount:vertexCount,usesFloatComponents:false,componentsPerVector:influences,bytesPerComponent:2,dataOffset:0,dataStride:influences*2)
                let skinner=SCNSkinner(baseGeometry:geometry,bones:bones,boneInverseBindTransforms:inverse,boneWeights:weights,boneIndices:indices)
                skinner.baseGeometryBindTransform=SCNMatrix4Identity
                if let skeleton=skins[skinIndex]["skeleton"] as? Int {guard nodes.indices.contains(skeleton) else {throw GLTFImportError.invalidHierarchy};skinner.skeleton=nodes[skeleton]}
                else {skinner.skeleton=root}
                primitiveNodes[pi].skinner=skinner
            }
        }
    }

    func applyTransformAnimations(to nodes:[SCNNode],root:SCNNode) throws {
        let definitions=json["animations"] as? [[String:Any]] ?? []
        guard !definitions.isEmpty else {return};guard definitions.count<=256 else {throw GLTFImportError.resourceLimit}
        func target(_ node:SCNNode) -> String {
            if let id=node.importedGLTFTarget {return id}
            let id=UUID().uuidString;node.importedGLTFTarget=id;return id
        }
        var clips:[ImportedAnimationClip]=[]
        for (index,definition) in definitions.enumerated() {
            try Task.checkCancellation()
            let samplers=definition["samplers"] as? [[String:Any]] ?? [],channels=definition["channels"] as? [[String:Any]] ?? []
            guard channels.count<=20_000 else {throw GLTFImportError.resourceLimit}
            var curves:[ImportedAnimationCurve]=[]
            for channel in channels {
                guard let si=channel["sampler"] as? Int,samplers.indices.contains(si),let destination=channel["target"] as? [String:Any],
                      let ni=destination["node"] as? Int,nodes.indices.contains(ni),let path=destination["path"] as? String,
                      let input=samplers[si]["input"] as? Int,let output=samplers[si]["output"] as? Int else {throw GLTFImportError.invalidAccessor}
                let t=try readFloatAccessor(input),v=try readFloatAccessor(output)
                guard t.components==1,let interpolation=ImportedAnimationCurve.Interpolation(rawValue:samplers[si]["interpolation"] as? String ?? "LINEAR") else {throw GLTFImportError.unsupportedAccessor}
                if path=="weights" {
                    let morphs=ProjectSceneCodec.nodes(in:nodes[ni]).filter {$0.morpher != nil}
                    guard !morphs.isEmpty else {throw GLTFImportError.invalidMesh}
                    for morph in morphs {
                        let curve=ImportedAnimationCurve(target:target(morph),path:path,times:t.values.map(Double.init),values:v.values.map(Double.init),components:morph.morpher!.targets.count,interpolation:interpolation)
                        try curve.validate();curves.append(curve)
                    }
                } else {
                    let curve=ImportedAnimationCurve(target:target(nodes[ni]),path:path,times:t.values.map(Double.init),values:v.values.map(Double.init),components:v.components,interpolation:interpolation)
                    try curve.validate();curves.append(curve)
                }
            }
            clips.append(.init(name:definition["name"] as? String ?? "Animation \(index+1)",channels:curves))
        }
        let rest=ProjectSceneCodec.nodes(in:root).compactMap {node -> ImportedRestPose? in
            guard let id=node.importedGLTFTarget else {return nil}
            let p=node.simdPosition,q=node.simdOrientation.vector,s=node.simdScale
            return ImportedRestPose(target:id,translation:[Double(p.x),Double(p.y),Double(p.z)],rotation:[Double(q.x),Double(q.y),Double(q.z),Double(q.w)],scale:[Double(s.x),Double(s.y),Double(s.z)],weights:node.morpher.map {m in (0..<m.targets.count).map {Double(m.weight(forTargetAt:$0))}} ?? [])
        }
        try root.setImportedLibrary(ImportedAnimationLibrary(clips:clips,rest:rest))
        warnings.append("تم تحميل \(clips.count) مقطع حركة؛ اختر المقطع من خصائص الحركة / Loaded \(clips.count) animation clips; choose one in Animation.")
    }
}
