import Foundation
import UIKit
import SceneKit
import AVFoundation
import CoreImage

/// Offline rendering decodes movies on the authored time grid. AVPlayer's
/// wall-clock playback cannot advance an offline renderer deterministically.
@MainActor
final class VideoMaterialFrames {
    private let properties: [(SCNNode, SCNMaterial, SCNMaterialProperty)]
    private(set) var activePlayers: [AVPlayer] = []
    private var displayed: [ObjectIdentifier: (SCNMaterialProperty, AVPlayer, UIImage)] = [:]
    private var readers: [ObjectIdentifier: MovieReader] = [:]
    private let context: CIContext

    init(scene: SCNScene, context: CIContext) {
        self.context = context
        var seen = Set<ObjectIdentifier>(), collected: [(SCNNode, SCNMaterial, SCNMaterialProperty)] = []
        for node in ProjectSceneCodec.nodes(in: scene.rootNode) {
            for material in node.geometry?.materials ?? [] {
                for (_, property) in ProjectSceneCodec.properties(material) {
                    // Keep owners: shared materials can be visible on one node
                    // while another instance is hidden.
                    collected.append((node, material, property))
                }
            }
        }
        properties = collected
    }

    func restore() {
        for (property, player, image) in displayed.values where (property.contents as? UIImage) === image {
            property.contents = player
        }
        displayed.removeAll()
    }

    @discardableResult
    func render(at time: Double) async throws -> [SCNMaterial] {
        var images: [ObjectIdentifier: UIImage] = [:]
        var changed: [SCNMaterial] = [], seen = Set<ObjectIdentifier>()
        activePlayers.removeAll()
        var audioSeen = Set<ObjectIdentifier>()
        for (node, material, property) in properties {
            let propertyID = ObjectIdentifier(property)
            // Leave the previous decoded image in place between frames. Rebinding
            // AVPlayer each time rebuilds SceneKit's movie texture provider.
            let previous = displayed[propertyID]
            let carried = previous.flatMap { (property.contents as? UIImage) === $0.2 ? $0.1 : nil }
            guard let player = (property.contents as? AVPlayer) ?? carried else {
                displayed.removeValue(forKey: propertyID); continue
            }
            try Task.checkCancellation()
            let id = ObjectIdentifier(player)
            var visible = true, ancestor: SCNNode? = node
            while let current = ancestor {
                if current.isHidden || current.opacity <= 0 { visible = false; break }
                ancestor = current.parent
            }
            if visible && audioSeen.insert(id).inserted { activePlayers.append(player) }
            let image: UIImage
            if let existing = images[id] { image = existing }
            else {
                let reader: MovieReader
                if let existing = readers[id] { reader = existing }
                else { reader = try await MovieReader(player: player); readers[id] = reader }
                image = try reader.image(at: time, context: context)
                images[id] = image
            }
            SCNTransaction.begin(); SCNTransaction.disableActions = true
            property.contents = image
            SCNTransaction.commit()
            displayed[propertyID] = (property, player, image)
            if seen.insert(ObjectIdentifier(material)).inserted { changed.append(material) }
        }
        return changed
    }

    @MainActor
    private final class MovieReader {
        let asset: AVAsset
        let track: AVAssetTrack
        let duration: Double
        let transform: CGAffineTransform
        let timing: VideoClipTiming
        private var reader: AVAssetReader!
        private var output: AVAssetReaderTrackOutput!
        private var current: CMSampleBuffer?
        private var next: CMSampleBuffer?
        private var previousTime = -Double.infinity

        init(player: AVPlayer) async throws {
            guard let asset = player.currentItem?.asset,
                  let track = try await asset.loadTracks(withMediaType: .video).first else {
                throw StudioVideoFailure.problem("الفيديو بلا صور / Missing movie track")
            }
            self.asset = asset; self.track = track
            timing = player.authoredMovieTiming
            duration = CMTimeGetSeconds(try await asset.load(.duration))
            transform = try await track.load(.preferredTransform)
            guard duration.isFinite, duration > 0 else { throw StudioVideoFailure.problem("مدة فيديو غير صالحة / Invalid movie duration") }
            try timing.validate()
            guard timing.sourceIn < duration, timing.sourceOut.map({ $0 <= duration + 0.000001 }) != false else {
                throw StudioVideoFailure.problem("القص خارج مدة الفيديو / Trim exceeds movie duration")
            }
            try restart()
        }

        private func restart() throws {
            reader?.cancelReading()
            reader = try AVAssetReader(asset: asset)
            output = AVAssetReaderTrackOutput(track: track, outputSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA])
            output.alwaysCopiesSampleData = false
            guard reader.canAdd(output) else { throw StudioVideoFailure.problem("تعذر قراءة الفيديو / Movie reader unavailable") }
            reader.add(output)
            guard reader.startReading() else { throw reader.error ?? StudioVideoFailure.problem("تعذر بدء قراءة الفيديو / Movie decoding failed") }
            current = nil; next = output.copyNextSampleBuffer(); previousTime = -Double.infinity
        }

        func image(at requested: Double, context: CIContext) throws -> UIImage {
            let time = timing.sourceTime(at: requested, duration: duration)
            if time < previousTime { try restart() }
            while let sample = next, current == nil || CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sample)) <= time + 0.000001 {
                current = sample; next = output.copyNextSampleBuffer()
            }
            guard reader.status != .failed, let sample = current, let pixels = CMSampleBufferGetImageBuffer(sample) else {
                throw reader.error ?? StudioVideoFailure.problem("إطار فيديو مفقود / Missing movie frame")
            }
            previousTime = time
            let transformed = CIImage(cvPixelBuffer: pixels).transformed(by: transform)
            let image = transformed.transformed(by: CGAffineTransform(translationX: -transformed.extent.minX, y: -transformed.extent.minY))
            guard let cg = context.createCGImage(image, from: image.extent) else {
                throw StudioVideoFailure.problem("تعذر رسم الفيديو / Movie image unavailable")
            }
            return UIImage(cgImage: cg)
        }
    }
}
