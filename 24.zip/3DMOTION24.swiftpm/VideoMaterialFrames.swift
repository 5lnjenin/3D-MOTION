import Foundation
import UIKit
import SceneKit
import AVFoundation
import CoreImage

/// Offline rendering decodes movies on the authored time grid. AVPlayer's
/// wall-clock playback cannot advance an offline renderer deterministically.
@MainActor
final class VideoMaterialFrames {
    private let properties: [SCNMaterialProperty]
    private var displayed: [(SCNMaterialProperty, AVPlayer, UIImage)] = []
    private var readers: [ObjectIdentifier: MovieReader] = [:]
    private let context: CIContext

    init(scene: SCNScene, context: CIContext) {
        self.context = context
        var seen = Set<ObjectIdentifier>(), collected: [SCNMaterialProperty] = []
        for node in ProjectSceneCodec.nodes(in: scene.rootNode) {
            for material in node.geometry?.materials ?? [] {
                for (_, property) in ProjectSceneCodec.properties(material) {
                    if seen.insert(ObjectIdentifier(property)).inserted { collected.append(property) }
                }
            }
        }
        properties = collected
    }

    func restore() {
        for (property, player, image) in displayed where (property.contents as? UIImage) === image {
            property.contents = player
        }
        displayed.removeAll()
    }

    func render(at time: Double) async throws {
        var images: [ObjectIdentifier: UIImage] = [:]
        for property in properties {
            guard let player = property.contents as? AVPlayer else { continue }
            try Task.checkCancellation()
            let id = ObjectIdentifier(player)
            let image: UIImage
            if let existing = images[id] { image = existing }
            else {
                let reader: MovieReader
                if let existing = readers[id] { reader = existing }
                else { reader = try await MovieReader(player: player); readers[id] = reader }
                image = try reader.image(at: time, context: context)
                images[id] = image
            }
            property.contents = image
            displayed.append((property, player, image))
        }
    }

    @MainActor
    private final class MovieReader {
        let asset: AVAsset
        let track: AVAssetTrack
        let duration: Double
        let transform: CGAffineTransform
        private var reader: AVAssetReader!
        private var output: AVAssetReaderTrackOutput!
        private var current: CMSampleBuffer?
        private var next: CMSampleBuffer?
        private var previousTime = -Double.infinity

        init(player: AVPlayer) async throws {
            guard let asset = player.currentItem?.asset,
                  let track = try await asset.loadTracks(withMediaType: .video).first else {
                throw StudioVideoFailure.problem("الفيديو بلا صور / Missing movie track")
            }
            self.asset = asset; self.track = track
            duration = CMTimeGetSeconds(try await asset.load(.duration))
            transform = try await track.load(.preferredTransform)
            guard duration.isFinite, duration > 0 else { throw StudioVideoFailure.problem("مدة فيديو غير صالحة / Invalid movie duration") }
            try restart()
        }

        private func restart() throws {
            reader?.cancelReading()
            reader = try AVAssetReader(asset: asset)
            output = AVAssetReaderTrackOutput(track: track, outputSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA])
            output.alwaysCopiesSampleData = false
            guard reader.canAdd(output) else { throw StudioVideoFailure.problem("تعذر قراءة الفيديو / Movie reader unavailable") }
            reader.add(output)
            guard reader.startReading() else { throw reader.error ?? StudioVideoFailure.problem("تعذر بدء قراءة الفيديو / Movie decoding failed") }
            current = nil; next = output.copyNextSampleBuffer(); previousTime = -Double.infinity
        }

        func image(at requested: Double, context: CIContext) throws -> UIImage {
            let time = min(max(0, requested), max(0, duration - 0.000001))
            if time < previousTime { try restart() }
            while let sample = next, current == nil || CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sample)) <= time + 0.000001 {
                current = sample; next = output.copyNextSampleBuffer()
            }
            guard reader.status != .failed, let sample = current, let pixels = CMSampleBufferGetImageBuffer(sample) else {
                throw reader.error ?? StudioVideoFailure.problem("إطار فيديو مفقود / Missing movie frame")
            }
            previousTime = time
            let transformed = CIImage(cvPixelBuffer: pixels).transformed(by: transform)
            let image = transformed.transformed(by: CGAffineTransform(translationX: -transformed.extent.minX, y: -transformed.extent.minY))
            guard let cg = context.createCGImage(image, from: image.extent) else {
                throw StudioVideoFailure.problem("تعذر رسم الفيديو / Movie image unavailable")
            }
            return UIImage(cgImage: cg)
        }
    }
}
