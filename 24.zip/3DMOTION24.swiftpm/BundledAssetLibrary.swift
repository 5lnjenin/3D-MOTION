import Foundation
import SwiftUI
import UIKit
import SceneKit

enum BundledAssetKind: String, CaseIterable, Identifiable {
    case dryGrass
    case grassFree
    case grassBasic
    case grassPack9
    case grassRealistic06
    case grass2
    case coniferTree
    case birchPack
    case firPack
    case lowPolyTrees
    case snowdropPack
    case ivyA
    case ivyB
    case forestRoadNight
    case forestMountains
    case streetCity7
    case palestineFlag
    case snowFX
    case smokeFX
    case ultrako

    var id: String { rawValue }

    static let grass: [BundledAssetKind] = [
        .dryGrass, .grassFree, .grassBasic, .grassPack9, .grassRealistic06, .grass2
    ]

    static let trees: [BundledAssetKind] = [
        .coniferTree, .birchPack, .firPack, .lowPolyTrees
    ]

    static let plants: [BundledAssetKind] = [
        .snowdropPack, .ivyA, .ivyB
    ]

    static let environments: [BundledAssetKind] = [
        .forestRoadNight, .forestMountains, .streetCity7
    ]

    static let effects: [BundledAssetKind] = [
        .snowFX, .smokeFX, .ultrako
    ]

    static let props: [BundledAssetKind] = [
        .palestineFlag
    ]

    var resourceBaseName: String {
        switch self {
        case .dryGrass: return "asset_dry_grass"
        case .grassFree: return "asset_grass_free"
        case .grassBasic: return "asset_grass_basic"
        case .grassPack9: return "asset_grass_pack9"
        case .grassRealistic06: return "asset_grass_realistic06"
        case .grass2: return "asset_grass_2"
        case .coniferTree: return "asset_conifer_tree"
        case .birchPack: return "asset_birch_pack"
        case .firPack: return "asset_fir_pack"
        case .lowPolyTrees: return "asset_low_poly_trees"
        case .snowdropPack: return "asset_snowdrop_pack"
        case .ivyA: return "asset_ivy_a"
        case .ivyB: return "asset_ivy_b"
        case .forestRoadNight: return "asset_forest_road_night"
        case .forestMountains: return "asset_forest_mountains"
        case .streetCity7: return "asset_street_city_7"
        case .palestineFlag: return "asset_palestine_flag"
        case .snowFX: return "asset_snow_fx"
        case .smokeFX: return "asset_smoke_fx"
        case .ultrako: return "asset_ultrako"
        }
    }

    var thumbnailBaseName: String {
        resourceBaseName.replacingOccurrences(of: "asset_", with: "thumb_")
    }

    func title(for language: StudioLanguage) -> String {
        if language == .arabic {
            switch self {
            case .dryGrass: return "عشب جاف"
            case .grassFree: return "عشب 01"
            case .grassBasic: return "عشب 02"
            case .grassPack9: return "حزمة عشب ×9"
            case .grassRealistic06: return "عشب واقعي 06"
            case .grass2: return "عشب واقعي 02"
            case .coniferTree: return "شجرة صنوبر كثيفة"
            case .birchPack: return "حزمة أشجار البتولا"
            case .firPack: return "حزمة أشجار التنوب"
            case .lowPolyTrees: return "أشجار خفيفة"
            case .snowdropPack: return "زهور Snowdrop"
            case .ivyA: return "لبلاب A"
            case .ivyB: return "لبلاب B"
            case .forestRoadNight: return "غابة وطريق ليلي"
            case .forestMountains: return "غابة وجبال"
            case .streetCity7: return "شارع مدينة 07"
            case .palestineFlag: return "علم فلسطين"
            case .snowFX: return "مؤثر ثلج"
            case .smokeFX: return "مؤثر دخان"
            case .ultrako: return "مؤثر Ultrako"
            }
        }
        switch self {
        case .dryGrass: return "Dry Grass"
        case .grassFree: return "Grass 01"
        case .grassBasic: return "Grass 02"
        case .grassPack9: return "Grass Pack ×9"
        case .grassRealistic06: return "Realistic Grass 06"
        case .grass2: return "Realistic Grass 02"
        case .coniferTree: return "Dense Conifer"
        case .birchPack: return "Birch Trees Pack"
        case .firPack: return "Fir Trees Pack"
        case .lowPolyTrees: return "Low-Poly Trees"
        case .snowdropPack: return "Snowdrop Pack"
        case .ivyA: return "Ivy A"
        case .ivyB: return "Ivy B"
        case .forestRoadNight: return "Night Forest Road"
        case .forestMountains: return "Forest & Mountains"
        case .streetCity7: return "Street City 07"
        case .palestineFlag: return "Palestine Flag"
        case .snowFX: return "Snow FX"
        case .smokeFX: return "Smoke FX"
        case .ultrako: return "Ultrako FX"
        }
    }

    var baseName: String {
        switch self {
        case .dryGrass: return "Dry Grass"
        case .grassFree: return "Grass 01"
        case .grassBasic: return "Grass 02"
        case .grassPack9: return "Grass Pack 9"
        case .grassRealistic06: return "Realistic Grass 06"
        case .grass2: return "Realistic Grass 02"
        case .coniferTree: return "Dense Conifer"
        case .birchPack: return "Birch Trees Pack"
        case .firPack: return "Fir Trees Pack"
        case .lowPolyTrees: return "Low Poly Trees"
        case .snowdropPack: return "Snowdrop Pack"
        case .ivyA: return "Ivy A"
        case .ivyB: return "Ivy B"
        case .forestRoadNight: return "Night Forest Road"
        case .forestMountains: return "Forest Mountains"
        case .streetCity7: return "Street City 07"
        case .palestineFlag: return "Palestine Flag"
        case .snowFX: return "Snow FX"
        case .smokeFX: return "Smoke FX"
        case .ultrako: return "Ultrako FX"
        }
    }

    var fileName: String { resourceBaseName + ".glb" }

    var remoteFileName: String {
        switch self {
        case .dryGrass: return "dry-grass.glb"
        case .grassFree: return "grass-free-download.glb"
        case .grassBasic: return "grass.glb"
        case .grassPack9: return "grass-pack-of-9-vars-lowpoly-game-ready.glb"
        case .grassRealistic06: return "realistics-grass-06.glb"
        case .grass2: return "grass-2.glb"
        case .coniferTree: return "conifer-tree-high-poly.glb"
        case .birchPack: return "five-birch-trees-pack-lowpoly-lods.glb"
        case .firPack: return "realistic-fir-trees-pack-lods-gameready.glb"
        case .lowPolyTrees: return "low-poly-trees.glb"
        case .snowdropPack: return "snowdrop-pack-lowpoly-gameready-lod.glb"
        case .ivyA: return "lvy-a.glb"
        case .ivyB: return "lvy-b.glb"
        case .forestRoadNight: return "a-forest-3-with-a-road-at-night-for-game.glb"
        case .forestMountains: return "landscape-forest-mountains.glb"
        case .streetCity7: return "street-city-7-for-games-free.glb"
        case .palestineFlag: return "palestine-flag.glb"
        case .snowFX: return "snow-fx-test.glb"
        case .smokeFX: return "smoke-effect-test.glb"
        case .ultrako: return "ultrako.glb"
        }
    }

    @MainActor
    func installedModelURL() -> URL? {
        AssetDownloadManager.shared.installedURL(for: self)
    }

    func thumbnailImage() -> UIImage? {
        // Swift Playgrounds can preserve Resources as a folder or flatten/copy it
        // differently depending on how the project is imported. Try all supported
        // bundle lookup paths so the real preview is always used.
        let candidates: [URL?] = [
            Bundle.main.url(forResource: thumbnailBaseName, withExtension: "jpg"),
            Bundle.main.url(forResource: thumbnailBaseName, withExtension: "jpg", subdirectory: "Resources"),
            Bundle.main.resourceURL?.appendingPathComponent("Resources/\(thumbnailBaseName).jpg"),
            Bundle.main.resourceURL?.appendingPathComponent("\(thumbnailBaseName).jpg")
        ]

        for candidate in candidates {
            if let url = candidate, FileManager.default.fileExists(atPath: url.path),
               let image = UIImage(contentsOfFile: url.path) {
                return image
            }
        }

        // Asset-catalog/name based fallback for Playgrounds builds.
        return UIImage(named: thumbnailBaseName)
            ?? UIImage(named: "Resources/\(thumbnailBaseName)")
            ?? UIImage(named: "\(thumbnailBaseName).jpg")
    }
}

@MainActor
extension StudioStore {
    func addBundledModel(_ asset: BundledAssetKind) {
        guard let url = asset.installedModelURL() else {
            let message = appLanguage == .arabic
                ? "الموديل غير منزّل بعد. اضغط تنزيل أولاً."
                : "This model is not downloaded yet. Tap Download first."
            statusText = message
            toast = message
            return
        }

        statusText = appLanguage == .arabic
            ? "جاري تحميل \(asset.title(for: .arabic))…"
            : "Loading \(asset.title(for: .english))…"

        // Full environments can contain thousands of nodes and large textures.
        // Never parse those files on the UI actor: doing so freezes the whole editor.
        if BundledAssetKind.environments.contains(asset) {
            let arabicTitle = asset.title(for: .arabic)
            let englishTitle = asset.title(for: .english)
            let baseName = asset.baseName
            Task {
                do {
                    let importedBox = try await Task.detached(priority: .userInitiated) {
                        try AssetNodeLoader.load(url: url)
                    }.value
                    finishBundledModelImport(importedBox, baseName: baseName,
                                             arabicTitle: arabicTitle, englishTitle: englishTitle,
                                             autoFrame: false)
                } catch {
                    let message = appLanguage == .arabic
                        ? "تعذر تحميل \(arabicTitle): \(error.localizedDescription)"
                        : "Could not load \(englishTitle): \(error.localizedDescription)"
                    statusText = message
                    toast = message
                }
            }
            return
        }

        do {
            let importedBox = try AssetNodeLoader.load(url: url)
            finishBundledModelImport(importedBox, baseName: asset.baseName,
                                     arabicTitle: asset.title(for: .arabic),
                                     englishTitle: asset.title(for: .english), autoFrame: true)
        } catch {
            let message = appLanguage == .arabic
                ? "تعذر تحميل \(asset.title(for: .arabic)): \(error.localizedDescription)"
                : "Could not load \(asset.title(for: .english)): \(error.localizedDescription)"
            statusText = message
            toast = message
        }
    }

    private func finishBundledModelImport(_ importedBox: ImportedNodeBox,
                                          baseName: String,
                                          arabicTitle: String,
                                          englishTitle: String,
                                          autoFrame: Bool) {
        let imported = importedBox.node
        imported.name = baseName
        pushUndoSnapshot("Add Bundled Model")
        let workspace = workspaceWrappedImportedAsset(imported)
        workspace.name = nextName(baseName)
        contentRoot.addChildNode(workspace)
        placeImportedWorkspaceAtOrigin(workspace)
        select(workspace)

        // Large environment bounds can make frameNode perform an enormous camera jump.
        // Keep the current editor camera stable; the user can frame it manually.
        if autoFrame { frameNode(workspace) }

        let warningSuffix = importedBox.warnings.isEmpty
            ? "" : " • \(importedBox.warnings.joined(separator: " • "))"
        statusText = appLanguage == .arabic
            ? "تمت إضافة \(arabicTitle)\(warningSuffix)"
            : "Added \(englishTitle)\(warningSuffix)"
        toast = statusText
    }
}

