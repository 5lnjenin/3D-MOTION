import Foundation
import SceneKit
import SwiftUI
import simd

enum WorkshopTool: String, CaseIterable, Identifiable {
    case subdivide, smooth, flat, mirror, solidify, extrude, inset, weld, twist, bend, taper, uvBox, uvPlanar, uvCylinder, uvSphere, sculpt
    var id: String { rawValue }
    func title(_ arabic: Bool) -> String {
        switch self {
        case .subdivide: return arabic ? "تقسيم المثلثات" : "Subdivide triangles"
        case .smooth: return arabic ? "تنعيم السطح" : "Smooth surface"
        case .flat: return arabic ? "تظليل مسطح" : "Shade flat"
        case .mirror: return arabic ? "عكس الهندسة" : "Mirror geometry"
        case .solidify: return arabic ? "إضافة سماكة" : "Solidify"
        case .extrude: return arabic ? "بثق منطقة" : "Extrude region"
        case .inset: return arabic ? "إطار لكل مثلث" : "Inset individual triangles"
        case .weld: return arabic ? "دمج الرؤوس المتقاربة" : "Merge by distance"
        case .twist: return arabic ? "التواء" : "Twist"
        case .bend: return arabic ? "انحناء" : "Bend"
        case .taper: return arabic ? "تضييق" : "Taper"
        case .uvBox: return arabic ? "UV إسقاط صندوق" : "UV box projection"
        case .uvPlanar: return arabic ? "UV إسقاط مستوٍ" : "UV planar projection"
        case .uvCylinder: return arabic ? "UV أسطواني" : "UV cylindrical"
        case .uvSphere: return arabic ? "UV كروي" : "UV spherical"
        case .sculpt: return arabic ? "فرشاة نفخ / خفض" : "Inflate / deflate brush"
        }
    }
}

@MainActor
enum WorkshopGeometry {
    static func components(_ source: SCNGeometrySource) throws -> [[Double]] {
        guard source.vectorCount <= WorkshopMesh.maximumVertices,source.vectorCount>=0,
              source.componentsPerVector>0,source.componentsPerVector<=4,source.usesFloatComponents,
              [2,4,8].contains(source.bytesPerComponent),source.dataOffset>=0,source.dataStride>0 else { throw MeshWorkshopError.unsupported }
        let width=source.componentsPerVector*source.bytesPerComponent
        guard source.dataStride>=width else { throw MeshWorkshopError.invalid }
        if source.vectorCount>0 {
            guard source.dataOffset<=source.data.count, (source.vectorCount-1)<=(source.data.count-source.dataOffset)/source.dataStride,
                  source.dataOffset+(source.vectorCount-1)*source.dataStride+width<=source.data.count else { throw MeshWorkshopError.invalid }
        }
        return try source.data.withUnsafeBytes { raw in
            try (0..<source.vectorCount).map { row in
                try (0..<source.componentsPerVector).map { column in
                    let offset=source.dataOffset+row*source.dataStride+column*source.bytesPerComponent
                    let value:Double
                    switch source.bytesPerComponent {
                    case 2: value=Double(Float16(bitPattern:UInt16(littleEndian:raw.loadUnaligned(fromByteOffset:offset,as:UInt16.self))))
                    case 4: value=Double(Float(bitPattern:UInt32(littleEndian:raw.loadUnaligned(fromByteOffset:offset,as:UInt32.self))))
                    default: value=Double(bitPattern:UInt64(littleEndian:raw.loadUnaligned(fromByteOffset:offset,as:UInt64.self)))
                    }
                    guard value.isFinite else { throw MeshWorkshopError.invalid }; return value
                }
            }
        }
    }
    static func mesh(_ node: SCNNode) throws -> WorkshopMesh {
        guard node.skinner==nil,node.morpher==nil,let geometry=node.geometry,
              let source=geometry.sources(for:.vertex).first else { throw MeshWorkshopError.unsupported }
        // Never silently drop color or additional UV channels.
        guard geometry.sources.allSatisfy({ [.vertex,.normal,.texcoord,.tangent].contains($0.semantic) }),
              geometry.sources(for:.texcoord).count<=1 else { throw MeshWorkshopError.unsupported }
        let positions=try components(source),normal=try geometry.sources(for:.normal).first.map(components),uv=try geometry.sources(for:.texcoord).first.map(components)
        guard source.componentsPerVector>=3,normal==nil || (normal!.count==positions.count && normal!.allSatisfy {$0.count>=3}),uv==nil || (uv!.count==positions.count && uv!.allSatisfy {$0.count>=2}) else { throw MeshWorkshopError.invalid }
        var vertices:[WorkshopMesh.Vertex]=[]
        for i in positions.indices {
            let p=positions[i],n=normal?[i],t=uv?[i]
            vertices.append(.init(p:.init(p[0],p[1],p[2]),n:n.map { .init($0[0],$0[1],$0[2]) } ?? .init(0,1,0),uv:t.map { .init($0[0],$0[1]) } ?? .zero))
        }
        var faces:[WorkshopMesh.Face]=[]
        for (slot,element) in geometry.elements.enumerated() {
            guard [.triangles,.triangleStrip].contains(element.primitiveType),[1,2,4].contains(element.bytesPerIndex),element.primitiveCount>=0,
                  element.primitiveCount<=WorkshopMesh.maximumFaces else { throw MeshWorkshopError.unsupported }
            let count=element.primitiveType == .triangles ? element.primitiveCount*3 : (element.primitiveCount>0 ? element.primitiveCount+2 : 0)
            let data=element.data
            guard data.count>=count*element.bytesPerIndex else { throw MeshWorkshopError.invalid }
            let ids:[Int]=data.withUnsafeBytes { raw in
                (0..<count).map { i in
                    switch element.bytesPerIndex {
                    case 1:return Int(raw[i])
                    case 2:return Int(UInt16(littleEndian:raw.loadUnaligned(fromByteOffset:i*2,as:UInt16.self)))
                    default:return Int(UInt32(littleEndian:raw.loadUnaligned(fromByteOffset:i*4,as:UInt32.self)))
                    }
                }
            }
            guard ids.allSatisfy(vertices.indices.contains) else { throw MeshWorkshopError.invalid }
            let range=element.primitiveRange,start=range.location==NSNotFound ? 0 : range.location
            guard start>=0,start<=element.primitiveCount else {throw MeshWorkshopError.invalid}
            let length=range.location==NSNotFound || range.length==NSNotFound ? element.primitiveCount-start : range.length
            guard length>=0,length<=element.primitiveCount-start else {throw MeshWorkshopError.invalid}
            for i in start..<(start+length) {
                let indices=element.primitiveType == .triangles ? Array(ids[(i*3)..<(i*3+3)]) : (i%2==0 ? [ids[i],ids[i+1],ids[i+2]] : [ids[i+1],ids[i],ids[i+2]])
                if Set(indices).count==3,WorkshopMesh.length(WorkshopMesh.cross(vertices[indices[1]].p-vertices[indices[0]].p,vertices[indices[2]].p-vertices[indices[0]].p))>1e-12 {
                    faces.append(.init(a:indices[0],b:indices[1],c:indices[2],material:slot % max(1,geometry.materials.count)))
                }
            }
        }
        return try WorkshopMesh(vertices:vertices,faces:faces).checked()
    }
    static func geometry(_ mesh:WorkshopMesh, materials:[SCNMaterial],name:String?=nil) throws -> SCNGeometry {
        _=try mesh.checked()
        var positions:[Float]=[],normals:[Float]=[],uv:[Float]=[]
        for v in mesh.vertices {
            guard (0..<3).allSatisfy({abs(v.p[$0])<=Double(Float.greatestFiniteMagnitude)}) else { throw MeshWorkshopError.invalid }
            positions += [Float(v.p.x),Float(v.p.y),Float(v.p.z)]; normals += [Float(v.n.x),Float(v.n.y),Float(v.n.z)]; uv += [Float(v.uv.x),Float(v.uv.y)]
        }
        func source(_ values:[Float],semantic:SCNGeometrySource.Semantic,width:Int) -> SCNGeometrySource {
            SCNGeometrySource(data:values.withUnsafeBytes { Data($0) },semantic:semantic,vectorCount:mesh.vertices.count,usesFloatComponents:true,componentsPerVector:width,bytesPerComponent:4,dataOffset:0,dataStride:width*4)
        }
        let slots=max(materials.count,(mesh.faces.map(\.material).max() ?? 0)+1)
        guard slots<=256 else { throw MeshWorkshopError.limit }
        var elements:[SCNGeometryElement]=[]
        for slot in 0..<slots {
            let ids:[UInt32]=mesh.faces.filter {$0.material==slot}.flatMap {$0.indices.map(UInt32.init)}
            elements.append(SCNGeometryElement(data:ids.withUnsafeBytes {Data($0)},primitiveType:.triangles,primitiveCount:ids.count/3,bytesPerIndex:4))
        }
        let geometry=SCNGeometry(sources:[source(positions,semantic:.vertex,width:3),source(normals,semantic:.normal,width:3),source(uv,semantic:.texcoord,width:2)],elements:elements)
        geometry.materials=materials; geometry.name=name
        return geometry
    }
    static func transformed(_ mesh:WorkshopMesh, matrix:simd_float4x4) throws -> WorkshopMesh {
        let determinant=simd_determinant(matrix)
        guard determinant.isFinite,abs(determinant)>1e-9 else { throw MeshWorkshopError.invalid }
        let normalMatrix=simd_transpose(simd_inverse(matrix)); var result=mesh
        for i in result.vertices.indices {
            let v=mesh.vertices[i],p=matrix*SIMD4<Float>(Float(v.p.x),Float(v.p.y),Float(v.p.z),1),n=normalMatrix*SIMD4<Float>(Float(v.n.x),Float(v.n.y),Float(v.n.z),0)
            result.vertices[i].p = .init(Double(p.x),Double(p.y),Double(p.z)); result.vertices[i].n=WorkshopMesh.unit(.init(Double(n.x),Double(n.y),Double(n.z)))
        }
        if determinant<0 { for i in result.faces.indices { let b=result.faces[i].b; result.faces[i].b=result.faces[i].c; result.faces[i].c=b } }
        return try result.checked()
    }
}

@MainActor
extension StudioStore {
    func runWorkshop(_ tool:WorkshopTool, axis:Int=1, amount:Double=0.2, faces:Set<Int>?=nil, brushCenter:WorkshopMesh.V = .zero, radius:Double=1) {
        guard !workshopIsRunning,!isExporting,!importIsRunning,let node=selectedNode,!isNodeLocked(node) else { return }
        do {
            let mesh=try WorkshopGeometry.mesh(node), material=node.geometry?.materials ?? [],name=node.geometry?.name
            let selection=faces ?? Set(mesh.faces.indices)
            workshopIsRunning=true
            Task {
                do {
                    let result=try await Task.detached(priority:.userInitiated) {
                        switch tool {
                        case .subdivide:return try mesh.subdivided()
                        case .smooth:return try mesh.smoothed(iterations:2,strength:max(0,min(1,amount)))
                        case .flat:return try mesh.normals(smooth:false).checked()
                        case .mirror:return try mesh.mirrored(axis:axis)
                        case .solidify:return try mesh.solidified(thickness:amount)
                        case .extrude:return try mesh.extruded(selected:selection,distance:amount)
                        case .inset:return try mesh.inset(selected:selection,fraction:amount)
                        case .weld:return try mesh.welded(tolerance:amount)
                        case .twist:return try mesh.deformed(.twist,axis:axis,amount:amount)
                        case .bend:return try mesh.deformed(.bend,axis:axis,amount:amount)
                        case .taper:return try mesh.deformed(.taper,axis:axis,amount:amount)
                        case .uvBox:return try mesh.mappedUV(.box,axis:axis,tiling:amount)
                        case .uvPlanar:return try mesh.mappedUV(.planar,axis:axis,tiling:amount)
                        case .uvCylinder:return try mesh.mappedUV(.cylindrical,axis:axis,tiling:amount)
                        case .uvSphere:return try mesh.mappedUV(.spherical,axis:axis,tiling:amount)
                        case .sculpt:return try mesh.sculpted(center:brushCenter,radius:radius,strength:amount)
                        }
                    }.value
                    guard node.parent != nil,node === selectedNode else { throw MeshWorkshopError.invalid }
                    let geometry=try WorkshopGeometry.geometry(result,materials:material,name:name)
                    geometry.subdivisionLevel=node.geometry?.subdivisionLevel ?? 0
                    pushUndoSnapshot(tool.title(false)); node.geometry=geometry
                    refreshSelectionGizmo(); objectWillChange.send(); toast=tool.title(appLanguage == .arabic)
                } catch { reportProjectError(error) }
                workshopIsRunning=false
            }
        } catch { reportProjectError(error) }
    }
    func workshopBoolean(_ operation:WorkshopMesh.BooleanOperation) {
        guard !workshopIsRunning,!isExporting,!importIsRunning,let target=selectedNode,!isNodeLocked(target) else {return}
        let others=editingNodes.filter { $0 !== target }
        guard others.count==1,let cutter=others.first,!isNodeLocked(cutter) else { toast="حدد جسمين؛ الجسم النشط هو الهدف / Select two meshes; the active mesh is the target";return }
        do {
            let a=try WorkshopGeometry.mesh(target), transform=simd_inverse(target.simdWorldTransform)*cutter.simdWorldTransform
            var b=try WorkshopGeometry.transformed(WorkshopGeometry.mesh(cutter),matrix:transform)
            let materials=(target.geometry?.materials ?? [])+(cutter.geometry?.materials ?? [])
            let offset=target.geometry?.materials.count ?? 0
            for i in b.faces.indices { b.faces[i].material += offset }
            workshopIsRunning=true
            Task {
                do {
                    let result=try await Task.detached(priority:.userInitiated) { [b] in try a.boolean(operation,with:b) }.value
                    guard target.parent != nil,cutter.parent != nil else {throw MeshWorkshopError.invalid}
                    let geometry=try WorkshopGeometry.geometry(result,materials:materials)
                    geometry.subdivisionLevel=target.geometry?.subdivisionLevel ?? 0
                    pushUndoSnapshot("Boolean \(operation.rawValue)"); target.geometry=geometry
                    // Keep the cutter as an editable hidden object; Undo restores both.
                    cutter.isHidden=true; select(target);refreshSelectionGizmo();objectWillChange.send()
                    toast="Boolean • \(operation.rawValue)"
                } catch {reportProjectError(error)}
                workshopIsRunning=false
            }
        } catch {reportProjectError(error)}
    }
    func bevelSelectedBox(_ radius:Double) {
        guard let node=selectedNode,let box=node.geometry as? SCNBox,radius.isFinite,radius>=0 else {toast="حدد صندوقًا / Select a box primitive";return}
        pushUndoSnapshot("Bevel box")
        let copy=box.copy() as! SCNBox
        copy.chamferRadius=min(CGFloat(radius),min(box.width,min(box.height,box.length))/2)
        copy.chamferSegmentCount=3;node.geometry=copy;objectWillChange.send()
    }
}
