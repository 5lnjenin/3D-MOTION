Actual native media/editor validation — 2026-10-13
Xcode 16.4; iPad simulator selected from available installed runtimes.
https://github.com/5lnjenin/3D-MOTION/actions/runs/38419708904
Input commit: 70dc0470ccb69ad6c32420fa8de2c49307ab2bf5
Input ZIP SHA256: 88d54917ad539cbf4b026095146422d5b1e9e4e6f2dab0bc7a7dc0df83d0153d

Executed 55 tests, with 0 failures (0 unexpected) in 1070.478 (1071.059) seconds
Executed 55 tests, with 0 failures (0 unexpected) in 1070.478 (1071.060) seconds
Executed 55 tests, with 0 failures (0 unexpected) in 1070.478 (1071.084) seconds
Previous 47 cases retained; eight movie/editor regression cases added.
Separate eight-case preflight and HDR preflight passed before the full suite.
All 24 original export options/audio, 24 PBR color checks, 24 single-frame
settings and 12 explicit Photos copies passed. Full 21s 4K90/4K60 regression passed.
Movie playback advanced, reached end twice, restarted and honored paused/latest seeks.
Fresh store restored movie bytes after source and import-copy deletion.
Movies changed red/green/blue phases at every export FPS instead of freezing;
cancelled exports restored AVPlayer and portable video resource type/bytes.
Portrait/square/rotation dimensions, 12 selection edges, five clean duplicates,
explicit camera symbol materials and rigid marker pose were checked.
Full app/hosted tests and simulator ad-hoc signature verified; arm64 IPA uploaded.
Physical iPad/SideStore/Photos, imported movie audio in exported MP4 and unknown
mesh distortion after deselection are not claimed as tested/fixed.
All 90 compiled source/resource inputs match the tested ZIP;
final packaging changes documentation/results only.

Historical validation follows.

Current lighting/Photos timing regression — 2026-10-11

Actual Apple validation — 2026-10-11
Xcode 15.4, Build 15F31d; iPad iOS 17.5 simulator.
https://github.com/5lnjenin/3D-MOTION/actions/runs/38129484258
Input commit: 20b0bb3624bdfb1511e07edb4a125cb2a9bdfd51
Input ZIP SHA256: 1a5dc53868c85030ac9cff2313375c34a1827ecf95fdddef70ee7057a3299b80

Executed 47 tests, with 0 failures (0 unexpected) in 443.429 (443.455) seconds
Executed 47 tests, with 0 failures (0 unexpected) in 443.429 (443.456) seconds

The previous 40 tests remain; seven regression cases were added.
24 original export combinations with audio and 24 textured PBR combinations passed.
12 explicit high-FPS -> 60 FPS Photos copies passed with identical dimensions/duration,
valid frame times and unchanged original bytes. 24/30/60 uses the original file. All 24 single-frame settings passed exact
count, 1/FPS duration and color checks. Snapshot/video comparison covers
yellow, gray and warm textured PBR materials, with HDR both on and off.
LONG_EXPORT_PASS 4K 90FPS 21s 1890 frames; Photos copy 4K 60FPS 21s 1260 frames; audio and PBR color preserved
Full app/hosted XCTest build and macOS simulator ad-hoc signing passed.
Physical Photos library imports, permissions, SideStore install/upgrade, device
thermal/memory stress and background interruption remain untested.
All 87 compiled inputs match the tested ZIP byte for byte;
final packaging changes only documentation/result files.
The public GitHub summary was truncated at 4096 bytes. Full per-case stdout,
including all 24 single-frame rows and six HDR/color rows, remains in
apple-validation-results / motion-tests.log and motion-hdr-tests.log.
The complete 47-case successful run and the separate HDR step are verified;
missing truncated rows were not invented or represented as downloaded logs.

Historical validation and setup follow.

Current layout/duration/export update — 2026-10-10

40 native XCTest tests passed, zero failures. The previous 30 cases remain.
All 4 resolutions x 6 FPS values (24 combinations) produced real MP4s with
project audio. Production metadata checks and actual decoded-frame counts,
nonblank pixels and audio tracks passed. All seven filters passed; all six
effect strengths zero/half/full affected actual saved image and video outputs.
Timeline length, imported animation/video, cancellation, scene/project file
outputs, and 150 viewport control placement cases passed.

Apple: https://github.com/5lnjenin/3D-MOTION/actions/runs/38088293965
Device IPA: https://github.com/5lnjenin/3D-MOTION/actions/runs/38088293900
Source input: 1d95445b9b195ac4586323e5aea3bdeb7b561cb6
Detailed native and matrix evidence: Tests/AppleValidation.result.txt and
Tests/VideoExportMatrix.result.txt. Device evidence: Tests/DeviceIPABuild.result.txt.
The 17 portable container tests also passed in this session on Swift 6.0.3 Linux.

Physical device UI gestures, Photos authorization/save, SideStore signing and
installation, long heavy-scene exports, thermal/memory behavior and background
export interruptions are not validated by these short simulator samples.
All final compiled sources, fixtures, resources and generator are identical
to the successful input. Only documentation/result summaries changed afterwards.

Historical and setup instructions follow.

The complete app is `3DMOTION24.swiftpm` inside `24.zip`, for Swift
Playgrounds on iPadOS 17 or later. Extract to a new folder before opening.
Version 24 retains the original custom icon and processes Resources rather
than copying a top-level directory with that reserved name. Lookup supports
both Bundle.module and Bundle.main.

Actual Apple validation on October 10, 2026

- Full app and hosted XCTest target built with Xcode 15.4/iOS simulator SDK.
- All 17 ScenePersistenceTests passed on an iPad simulator: OBJ/MTL/images,
  distinct MTL folders with colliding image names, colors/map options,
  GLB/glTF materials/UV, PBR, hierarchy/transforms, keyframes/native animation
  timing/speed/blend, cameras/lights, recovery, file relocation/repeated saves,
  legacy keyframes and failed/corrupt saves preserving the healthy workspace.
  The three added tests verified the installed document type and original PNG,
  opening a relocated file URL, and invalid-file rejection without clearing the
  current workspace. All 17 passed with zero failures in 14.958 seconds.
- A separate arm64 device build produced an actual unsigned IPA and verified
  the production bundle identifier, version 24, document registration, original
  PNG and ZIP integrity. The IPA was uploaded as a GitHub Actions artifact.
- All 17 actual XCTest container/storage tests passed on October 9 using Swift 6.0.3/Linux,
  compiling production ProjectContainer.swift with Apple's swift-crypto.
  Their scene bytes are placeholders; these tests alone do not test SceneKit.
  Production ProjectContainer.swift has not changed since this recorded run.
- Simulator app ad-hoc signing and strict codesign verification passed on macOS.
- Production Foundation compile/behavior probe and icon checks passed.
- A real SwiftPM resource build verified all 21 original bundled images and
  their exact bytes, with no reserved Resources directory in the bundle.

Apple run: https://github.com/5lnjenin/3D-MOTION/actions/runs/38081393207
Device IPA: https://github.com/5lnjenin/3D-MOTION/actions/runs/38081393224
Actual summaries are in Tests/AppleValidation.result.txt and
Tests/PortableCoreTests.result.txt. Full Apple logs/xcresult artifacts are
retained by the run. Final documentation/result-only packaging leaves the
tested app sources, fixtures and project-generation script unchanged; the
Playgrounds manifest only adds exclusions for the two new Markdown documents.
Both builds report the existing app_logo.png/JPEG extension mismatch warning;
the build succeeds. The audit records that correction as future work.

Reproduce portable checks with Swift 6 installed

```sh
python3 Tests/run_portable_tests.py
python3 Tests/check_foundation_compile.py
python3 Tests/check_app_icon.py
python3 Tests/check_resource_bundle.py
```

Reproduce Apple validation

The repository workflow .github/workflows/apple-validation.yml builds and
runs the actual sources on macOS. The generated Xcode harness is distinct
from the Swift Playgrounds AppleProductTypes manifest builder. On macOS
with Xcode and an installed iPad simulator:

```sh
python3 Tests/create_apple_project.py
xcrun simctl list devices available
xcodebuild -project Tests/AppleValidation.xcodeproj \
  -scheme MotionValidation -sdk iphonesimulator \
  -destination 'platform=iOS Simulator,id=REPLACE_WITH_SIMULATOR_UDID' \
  -derivedDataPath /tmp/3DMotion24DerivedData \
  -resultBundlePath /tmp/3DMotion24Results.xcresult \
  CODE_SIGNING_ALLOWED=YES CODE_SIGN_IDENTITY=- test
```

Use a new result-bundle path on each run. Ad-hoc simulator signing requires
no paid developer certificate. It does not prove physical iPad signing.

Build the device IPA locally on macOS

```sh
python3 Tests/create_apple_project.py --distribution
xcodebuild -project Tests/3DMotion.xcodeproj -scheme 3DMOTION \
  -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath /tmp/3DMotionIPA \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' build
```

The workflow packages the resulting .app under Payload inside the .ipa.
Neither a successful device build nor simulator signing proves SideStore
signing/installation. Follow SIDESTORE.md for the uploaded artifact.

Physical iPad Pro acceptance: not executed here

1. Open the extracted project in Swift Playgrounds. Verify icon, logo and
   thumbnails, then import the original failing car and all MTL/images (or ZIP).
2. Compare body/glass/wheels after Save, Save & Exit and reopening. Repeat with
   multi-material GLB, several models, groups, Move/Rotate/Scale and keyframes.
3. Verify geometry material slots, PBR maps, UV, transforms, camera and light
   settings, native animation timing, blend and speed.
4. Finish a save, fully terminate the app, relaunch and open its autosave or
   named project. A fresh StudioStore unit test does not replace this check.
5. Export .3dmotion, remove original model/image sources, move the document to
   another folder/device, import and repeat five save/open cycles.
6. With missing/unreadable image/audio or insufficient storage, Save must
   fail visibly, Save & Exit must keep the editor open, and the previous
   healthy file must still open.
7. Check peak memory with large real assets. JSON/base64 and detached scene
   validation increase memory. iPadOS termination during saving can recover
   only the last committed document.
8. Install the new IPA through SideStore. Export a .3dmotion document and verify
   its Files icon, warm/cold file opening, Save/Discard/Cancel and invalid-file
   handling. Check upgrading the installed app without losing local projects.

Audio/video synchronization, all Undo categories, rigged glTF characters,
accessibility and multiple window sizes are audit acceptance items not covered
by the current persistence tests. AUDIT_AR.md contains the evidence and plan.

Previously omitted image bytes in damaged v23 files require reimporting the
original resources. Keep existing projects while testing this revision.
