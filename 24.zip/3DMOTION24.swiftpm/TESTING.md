The delivered app is a Swift Playgrounds project: unzip `24.zip` and open
`3DMOTION24.swiftpm` on iPad. It targets iOS/iPadOS 17 or later.

Validation performed on Linux

- Swift 6.0.3 compiled the actual `ProjectContainer.swift`, using Apple's
  swift-crypto implementation of SHA256 where CryptoKit is unavailable.
- All 14 XCTest container/storage tests passed. These use placeholder scene
  bytes to test the container; they do not validate SceneKit scene decoding.
- Swift compiler syntax parsing passed for all app and test Swift files.
  Syntax parsing is not type checking against the iOS SDK.
- ZIP, JSON/plist resources, generated GLB structure, and scheme XML were checked.

The October 8 compile-error correction also compiled and executed the actual
`projectCards()` declaration and implementation in a Foundation-only harness.
It checks filtering, legacy/new project listing, autosave sorting and localized
names, plus the production save-failure message assignments. This does not
compile SceneKit/UIKit, nor validate the complete app against the iOS SDK.
The original 14 XCTest results were not rerun for this correction because the
container/storage code was unchanged.

Reproduce the targeted Foundation compile check with Swift installed:

```sh
python3 Tests/check_foundation_compile.py
```

The subsequent iPad screenshot reported OSStatus -67072 during code signing,
with a component path naming the generated iPad app icon. The icon catalog now
contains 18 explicit iPhone/iPad/marketing sizes using standard opaque RGB PNGs.
The original artwork's RGB samples are retained in the 1024px master. The
document icon remains unchanged. Archive regular files use mode 0644.

The following standard-library check passed for catalog completeness, pixel
dimensions, PNG checksums/scanlines, RGB encoding and icon file permissions:

```sh
python3 Tests/check_app_icon.py
```

Apple asset compilation and device signing remain unverified. The error number
alone does not establish transparency as its cause. Extract the revised project
to a new folder before opening it in Playgrounds, to obtain a fresh build rather
than reuse the previous project's DerivedData, then try Run on the iPad again.

Reproduce container tests with Swift 6 installed:

```sh
cd 3DMOTION24.swiftpm
python3 Tests/run_portable_tests.py
```

The script copies the actual container source into an isolated temporary Swift
package, obtains the pinned `apple/swift-crypto` 3.10.0 dependency, and preserves
`swift test`'s exit status. The XCTest result contains 14 executed tests. Swift
Testing also emits a separate zero-test line; that is not the XCTest outcome.

Apple tests (included, NOT executed in this Linux environment)

`Tests/ScenePersistenceTests.swift` contains 13 SceneKit integration tests:
full PBR channels and geometry slots; synthetic OBJ car with nested MTL/images
after removing its source files; GLB and glTF with multiple materials/UV sets;
groups/transforms/keyframes/camera/light/native animation layers; identically
named models; repeated opens and moved files; fresh-store autosave recovery;
failed texture saves; corrupt imports; explicit saves of large scenes; corrupt
autosave protection; legacy keyframe maps; and reordered siblings.

The fixtures are deterministic synthetic models, not the user's original car.
The full app is compiled by the hosted XCTest target, so this step also checks
app Swift types and APIs against the real iOS SDK. On macOS with Xcode and an
installed iOS simulator:

```sh
cd 3DMOTION24.swiftpm
python3 Tests/create_apple_project.py
xcrun simctl list devices available
xcodebuild -project Tests/AppleValidation.xcodeproj \
  -scheme MotionValidation \
  -destination 'platform=iOS Simulator,id=REPLACE_WITH_AVAILABLE_SIMULATOR_UDID' \
  -derivedDataPath /tmp/3DMotion24DerivedData \
  -resultBundlePath /tmp/3DMotion24Results.xcresult \
  CODE_SIGNING_ALLOWED=NO test
```

Choose an iPad simulator when available. Use a new result-bundle path if that
path already exists. A new store instance tests reconstruction from disk;
it does not simulate iPadOS terminating the real app process.

Required acceptance on an actual iPad Pro

1. Import the real failing car together with its MTL/images, or its complete ZIP.
   Compare body/glass/wheels before and after Save, Save & Exit, and reopening.
2. Repeat with a multi-material GLB and multiple models, including duplicate
   names, groups, local/world Move/Rotate/Scale and animation/keyframes.
3. Add a user camera and lights. Verify transforms, FOV, intensity, colors,
   hierarchy, material UV mapping and every PBR map after opening.
4. Complete a save, fully terminate the app, relaunch and open Last autosave or
   the named project. Confirm appearance and animation. Hard termination before
   a save completes can only recover the last committed document.
5. Export `.3dmotion`, remove the original model/image files, move the exported
   file to another directory/device and import it. Repeat five save/open cycles.
6. Test missing/unreadable texture/audio and insufficient free storage. Save
   must fail visibly, Save & Exit must stay in the editor when the named save
   fails, and the previously saved project must still open.
7. Repeat with large real assets and monitor memory. The container uses JSON
   base64 and validation decodes a detached scene; peak memory can be significant.
   Background autosave cannot guarantee completion if iPadOS kills the process.

No device/simulator result or full iOS type-check is claimed until these Apple
checks execute successfully. Previously omitted images in damaged v23 files
cannot be reconstructed from missing bytes; reimport the original asset once.
