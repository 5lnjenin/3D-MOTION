The complete app is `3DMOTION24.swiftpm` inside `24.zip`, for Swift
Playgrounds on iPadOS 17 or later. Extract to a new folder before opening.
The current manifest keeps the original custom app icon and processes
Resources instead of copying a top-level directory with that reserved name.
Resource lookup handles both Bundle.module and Bundle.main. The application version remains 24.

Actual validation

- 14 XCTest storage/container tests passed on Swift 6.0.3/Linux on October 8.
  They compile the actual ProjectContainer.swift using Apple's swift-crypto.
  They use placeholder scene bytes; they do not validate SceneKit decoding.
  This unchanged code was not retested for the later packaging corrections.
- The Foundation compile probe compiles and exercises the production
  projectCards() declaration plus the nonoptional save-failure assignments.
- Icon metadata/PNG checks and Swift syntax parsing passed. These checks
  cannot verify Apple asset compilation, signing or the whole app's types.
- GitHub Actions on October 9 compiled the full app and hosted XCTest target
  with Xcode 15.4/iOS SDK. The first signed test run after flattening resources
  executed 13 tests: 11 passed and two failed. The fixture setup and animation
  crash are being investigated; the failed tests are not claimed to pass.

Portable checks, with Swift installed

```sh
python3 Tests/run_portable_tests.py
python3 Tests/check_foundation_compile.py
python3 Tests/check_app_icon.py
python3 Tests/check_resource_bundle.py
```

Apple validation

The repository workflow `.github/workflows/apple-validation.yml` uses macOS,
an iPad simulator and the generated Xcode project. It publishes actual failures
and XCTest counts as run annotations and retains logs/xcresult artifacts:
https://github.com/5lnjenin/3D-MOTION/actions

The Xcode harness compiles all app sources. It is not the Swift Playgrounds
AppleProductTypes manifest builder, and simulator signing does not establish
that Playgrounds can sign the same app on a physical iPad.

The 13 ScenePersistenceTests use deterministic synthetic OBJ/MTL/PNG/GLB/glTF
fixtures. On macOS with Xcode and an installed iPad simulator:

```sh
python3 Tests/create_apple_project.py
xcrun simctl list devices available
xcodebuild -project Tests/AppleValidation.xcodeproj \
  -scheme MotionValidation -sdk iphonesimulator \
  -destination 'platform=iOS Simulator,id=REPLACE_WITH_SIMULATOR_UDID' \
  -derivedDataPath /tmp/3DMotion24DerivedData \
  -resultBundlePath /tmp/3DMotion24Results.xcresult \
  CODE_SIGNING_ALLOWED=YES CODE_SIGN_IDENTITY=- test
```

Use a new result-bundle path on every run. The local simulator signing identity
requires no paid developer certificate. A fresh StudioStore instance checks
reconstruction from files, not the real app process being terminated by iPadOS.

Physical iPad Pro acceptance (not executed here)

1. Import the original failing car and all MTL/images, or its complete ZIP.
   Compare body/glass/wheels before and after Save, Save & Exit, and reopening.
2. Repeat with a multi-material GLB, multiple/identically named models, groups,
   local/world Move/Rotate/Scale and animation/keyframes.
3. Add cameras/lights. Verify transforms, hierarchy, FOV, intensity, colors,
   material-slot ordering, every PBR map and UV mapping after reopening.
4. Finish a save, fully terminate the app, relaunch and open Last autosave or
   the named project. Killing the process during a save can only recover the
   last committed document.
5. Export .3dmotion, remove the source model/images, move the document to
   another folder/device, import and repeat five save/open cycles.
6. Test missing/unreadable texture/audio and insufficient storage. Save must
   fail visibly, Save & Exit must stay in the editor, and the healthy file must
   still open.
7. Monitor memory with large real assets. JSON/base64 and detached validation
   increase peak memory. Background autosave cannot guarantee completion if
   iPadOS terminates the process.

Previously omitted image bytes in damaged v23 files cannot be reconstructed
without reimporting their original resources.
