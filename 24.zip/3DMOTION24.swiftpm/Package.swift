// swift-tools-version: 5.9
import PackageDescription
import AppleProductTypes

let package = Package(
    name: "3D MOTION",
    platforms: [.iOS("17.0")],
    products: [
        .iOSApplication(
            name: "3D MOTION",
            targets: ["AppModule"],
            bundleIdentifier: "app.5ln.studio",
            displayVersion: "1.0",
            bundleVersion: "25",
            appIcon: .asset("AppIcon"),
            accentColor: .presetColor(.blue),
            supportedDeviceFamilies: [.pad, .phone],
            supportedInterfaceOrientations: [.portrait, .landscapeLeft, .landscapeRight, .portraitUpsideDown],
            capabilities: [
                .photoLibrary(purposeString: "Import reference images for your 3D projects."),
                .photoLibraryAdd(purposeString: "Save rendered images and videos to Photos.")
            ]
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: ".",
            exclude: ["Tests", "REPORT_AR.md", "TESTING.md", "PROJECT_FILE_SETUP.md", "AUDIT_AR.md", "AUDIT_CURRENT_AR.md", "SIDESTORE.md", "CHANGES_AUDIO_AR.md", "CHANGES_EXPORT_AR.md", "CHANGES_RENDER_AR.md", "CHANGES_MEDIA_AR.md", "CHANGES_VIDEO_IMPORT_AR.md", "RESULTS_24_AR.md", "WORKSHOP_GUIDE_AR.md", "ProjectFileTypes.plist", "ProjectFileIcon.png"],
            // Explicit membership also lets Swift Playgrounds resolve editor previews.
            sources: [
                "AddObjectUI.swift",
                "AnimationEngine.swift",
                "AnimationUI.swift",
                "AssetDownloadManager.swift",
                "AudioClipEditing.swift",
                "AudioEditingUI.swift",
                "AudioTimelineEngine.swift",
                "BundledAssetLibrary.swift",
                "CameraFXEngine.swift",
                "DownloadedAssetValidation.swift",
                "EditorObjectSymbols.swift",
                "GLTFAdvancedImport.swift",
                "GLTFImporter.swift",
                "GeometryNormals.swift",
                "ImportEngine.swift",
                "ImportedAnimationCore.swift",
                "ImportedAnimationEngine.swift",
                "InspectorUI.swift",
                "LaunchSplashView.swift",
                "MediaExportCancellation.swift",
                "MeshBooleanCore.swift",
                "MeshWorkshopCore.swift",
                "MeshWorkshopEngine.swift",
                "OBJMaterialResources.swift",
                "PlacementTransformEngine.swift",
                "PortableProject.swift",
                "ProductInterfaceText.swift",
                "ProjectContainer.swift",
                "ProjectHelpUI.swift",
                "ProjectLibrarySafety.swift",
                "ProjectPersistence.swift",
                "ProjectSceneCodec.swift",
                "ProjectTimelineDuration.swift",
                "ReadyModelsEngine.swift",
                "RenderPresentationState.swift",
                "RenderSnapshotEngine.swift",
                "RootUI.swift",
                "SceneMaterialEngine.swift",
                "SceneVideoPlayback.swift",
                "SettingsUI.swift",
                "Shared.swift",
                "StudioCore.swift",
                "TimelineEditing.swift",
                "TransformUI.swift",
                "VideoAudioMixer.swift",
                "VideoClipEditing.swift",
                "VideoClipTiming.swift",
                "VideoExportEngine.swift",
                "VideoFrameRateConverter.swift",
                "VideoFrameRenderer.swift",
                "VideoImportFile.swift",
                "VideoImportJournal.swift",
                "VideoMaterialFrames.swift",
                "VideoPhotoLibraryExport.swift",
                "ViewportControlLayout.swift",
                "ViewportStability.swift",
                "WorkshopAssetLibrary.swift",
                "WorkshopRigTools.swift",
                "WorkshopUI.swift",
            ],
            resources: [.process("Resources"), .process("Assets.xcassets")]
        )
    ],
    swiftLanguageVersions: [.v5]
)
