// swift-tools-version: 5.9
import PackageDescription
import AppleProductTypes

let package = Package(
    name: "3D MOTION",
    platforms: [.iOS("17.0")],
    products: [
        .iOSApplication(
            name: "3D MOTION",
            targets: ["AppModule"],
            bundleIdentifier: "app.5ln.studio",
            displayVersion: "24",
            bundleVersion: "24",
            appIcon: .asset("AppIcon"),
            accentColor: .presetColor(.blue),
            supportedDeviceFamilies: [.pad, .phone],
            supportedInterfaceOrientations: [.portrait, .landscapeLeft, .landscapeRight, .portraitUpsideDown],
            capabilities: [
                .photoLibrary(purposeString: "Import reference images for your 3D projects."),
                .photoLibraryAdd(purposeString: "Save rendered images and videos to Photos.")
            ]
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: ".",
            exclude: ["Tests", "REPORT_AR.md", "TESTING.md", "PROJECT_FILE_SETUP.md", "AUDIT_AR.md", "SIDESTORE.md", "CHANGES_AUDIO_AR.md", "CHANGES_EXPORT_AR.md", "CHANGES_RENDER_AR.md", "ProjectFileTypes.plist", "ProjectFileIcon.png"],
            resources: [.process("Resources"), .process("Assets.xcassets")]
        )
    ],
    swiftLanguageVersions: [.v5]
)
