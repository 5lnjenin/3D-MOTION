import SceneKit
import UIKit
import simd

enum EditorObjectSymbols {
    static func selectionBox(size: SCNVector3) -> SCNGeometry {
        let x = size.x * 0.5, y = size.y * 0.5, z = size.z * 0.5
        let vertices = [SCNVector3(-x,-y,-z), SCNVector3(x,-y,-z), SCNVector3(-x,y,-z), SCNVector3(x,y,-z),
                        SCNVector3(-x,-y,z), SCNVector3(x,-y,z), SCNVector3(-x,y,z), SCNVector3(x,y,z)]
        // Only the twelve box edges. A triangulated SCNBox in line fill mode
        // exposes face diagonals which look like cuts through the actual mesh.
        let indices: [UInt32] = [0,1,0,2,0,4,1,3,1,5,2,3,2,6,3,7,4,5,4,6,5,7,6,7]
        let element = SCNGeometryElement(data: indices.withUnsafeBytes { Data($0) }, primitiveType: .line,
            primitiveCount: 12, bytesPerIndex: 4)
        return SCNGeometry(sources: [SCNGeometrySource(vertices: vertices)], elements: [element])
    }

    static func cameraMarker(category: Int) -> SCNNode {
        let root = SCNNode()
        func part(_ geometry: SCNGeometry, name: String, color: UIColor, at position: SCNVector3) -> SCNNode {
            let material = SCNMaterial(); material.diffuse.contents = color; material.lightingModel = .constant
            geometry.materials = [material]
            let node = SCNNode(geometry: geometry); node.name = name; node.position = position
            node.categoryBitMask = category; node.castsShadow = false; root.addChildNode(node)
            return node
        }
        _ = part(SCNBox(width: 0.48, height: 0.30, length: 0.24, chamferRadius: 0.035),
            name: "_CameraBody", color: UIColor(red: 0.14, green: 0.47, blue: 0.80, alpha: 1), at: SCNVector3Zero)
        _ = part(SCNBox(width: 0.15, height: 0.09, length: 0.14, chamferRadius: 0.015),
            name: "_CameraViewfinder", color: .systemBlue, at: SCNVector3(-0.09, 0.19, 0.015))
        let lens = part(SCNCylinder(radius: 0.115, height: 0.15), name: "_CameraLens",
            color: UIColor(white: 0.13, alpha: 1), at: SCNVector3(0.065, 0, -0.195))
        lens.eulerAngles.x = -.pi / 2
        let rim = part(SCNTorus(ringRadius: 0.10, pipeRadius: 0.012), name: "_CameraLensRim",
            color: .lightGray, at: SCNVector3(0.065, 0, -0.277))
        rim.eulerAngles.x = -.pi / 2
        let glass = part(SCNCylinder(radius: 0.085, height: 0.006), name: "_CameraGlass",
            color: UIColor(red: 0.08, green: 0.24, blue: 0.38, alpha: 1), at: SCNVector3(0.065, 0, -0.276))
        glass.eulerAngles.x = -.pi / 2
        return root
    }

    static func rigidMarkerTransform(for target: SCNNode) -> SCNMatrix4 {
        let pose = target.presentation
        var matrix = simd_float4x4(simd_normalize(pose.simdWorldOrientation))
        matrix.columns.3 = SIMD4(pose.simdWorldPosition, 1)
        return SCNMatrix4(matrix)
    }
}
