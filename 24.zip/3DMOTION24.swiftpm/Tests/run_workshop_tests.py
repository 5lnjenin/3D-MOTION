#!/usr/bin/env python3
"""Run actual mesh/CSG/animation kernels with Swift on Linux or macOS."""
import os, pathlib, shutil, subprocess, tempfile
root=pathlib.Path(__file__).resolve().parent.parent
with tempfile.TemporaryDirectory(prefix='motion-workshop-') as directory:
    package=pathlib.Path(directory)
    sources=package/'Sources/MotionWorkshopCore';sources.mkdir(parents=True)
    tests=package/'Tests/MotionWorkshopCoreTests';tests.mkdir(parents=True)
    for name in ['MeshWorkshopCore.swift','MeshBooleanCore.swift','ImportedAnimationCore.swift']:shutil.copy2(root/name,sources)
    shutil.copy2(root/'Tests/WorkshopCoreTests.swift',tests)
    (package/'Package.swift').write_text('''// swift-tools-version: 6.0
import PackageDescription
let package=Package(name:"MotionWorkshopCore",targets:[.target(name:"MotionWorkshopCore"),.testTarget(name:"MotionWorkshopCoreTests",dependencies:["MotionWorkshopCore"])],swiftLanguageModes:[.v5])
''')
    env=os.environ.copy();env['SWIFTPM_MODULECACHE_OVERRIDE']=str(package/'ModuleCache');env['CLANG_MODULE_CACHE_PATH']=str(package/'ModuleCache')
    raise SystemExit(subprocess.call(['swift','test','--package-path',str(package),'--cache-path',str(package/'Cache'),'--config-path',str(package/'Config'),'--security-path',str(package/'Security'),'--jobs','4'],env=env))
