#!/usr/bin/env python3
"""Generate an iOS app + hosted XCTest project from the delivered sources."""
from pathlib import Path
import hashlib
import plistlib

here = Path(__file__).resolve().parent
root = here.parent
project = here / "AppleValidation.xcodeproj"
project.mkdir(exist_ok=True)
objects = {}

def identifier(name):
    return hashlib.sha256(name.encode()).hexdigest()[:24].upper()

def add(name, value):
    key = identifier(name)
    objects[key] = value
    return key

def array(values):
    return "(" + ",".join(values) + ")"

def file(name, path, kind):
    return add("file-" + name, '{isa=PBXFileReference; lastKnownFileType=' + kind + '; path="' + path + '"; sourceTree="<group>";}')

def build_file(name, ref):
    return add("build-" + name, "{isa=PBXBuildFile; fileRef=" + ref + ";}")

app_sources = []
refs = []
for source in sorted(root.glob("*.swift")):
    if source.name == "Package.swift":
        continue
    ref = file(source.name, "../" + source.name, "sourcecode.swift")
    refs.append(ref)
    app_sources.append(build_file(source.name, ref))
test_ref = file("tests", "ScenePersistenceTests.swift", "sourcecode.swift")
refs.append(test_ref)
tests = [build_file("tests", test_ref)]
resource_builds = []
for resource in sorted((root / "Resources").iterdir()):
    if resource.is_file():
        ref = file("resource-" + resource.name, "../Resources/" + resource.name,
                   "image.png" if resource.suffix == ".png" else "image.jpeg")
        refs.append(ref)
        resource_builds.append(build_file("resource-" + resource.name, ref))
assets_ref = file("assets", "../Assets.xcassets", "folder.assetcatalog")
fixtures_ref = file("fixtures", "Fixtures", "folder")
refs += [assets_ref, fixtures_ref]
app_product = add("app-product", '{isa=PBXFileReference; explicitFileType=wrapper.application; path=MotionValidation.app; sourceTree=BUILT_PRODUCTS_DIR;}')
test_product = add("test-product", '{isa=PBXFileReference; explicitFileType=wrapper.cfbundle; path=MotionValidationTests.xctest; sourceTree=BUILT_PRODUCTS_DIR;}')
products = add("products", '{isa=PBXGroup; children=' + array([app_product, test_product]) + '; name=Products; sourceTree="<group>";}')
main_group = add("group", '{isa=PBXGroup; children=' + array(refs + [products]) + '; sourceTree="<group>";}')

def phase(name, kind, files):
    return add(name, '{isa=' + kind + '; buildActionMask=2147483647; files=' + array(files) + '; runOnlyForDeploymentPostprocessing=0;}')

app_phases = [phase("app-sources", "PBXSourcesBuildPhase", app_sources),
              phase("app-frameworks", "PBXFrameworksBuildPhase", []),
              phase("app-resources", "PBXResourcesBuildPhase", resource_builds + [build_file("assets", assets_ref)])]
test_phases = [phase("test-sources", "PBXSourcesBuildPhase", tests),
               phase("test-frameworks", "PBXFrameworksBuildPhase", []),
               phase("test-resources", "PBXResourcesBuildPhase", [build_file("fixtures", fixtures_ref)])]

common = '''CLANG_ENABLE_MODULES=YES; SDKROOT=iphoneos; IPHONEOS_DEPLOYMENT_TARGET=17.0;
SWIFT_VERSION=5.0; TARGETED_DEVICE_FAMILY="1,2"; CODE_SIGNING_ALLOWED=YES;
CODE_SIGN_IDENTITY="-"; CODE_SIGNING_REQUIRED=YES;
SWIFT_OPTIMIZATION_LEVEL="-Onone"; ENABLE_TESTABILITY=YES; GENERATE_INFOPLIST_FILE=NO;'''

def configs(name, settings):
    items = []
    for mode in ["Debug", "Release"]:
        items.append(add(name + mode, '{isa=XCBuildConfiguration; buildSettings={' + common + settings + '}; name=' + mode + ';}'))
    return add(name + "-list", '{isa=XCConfigurationList; buildConfigurations=' + array(items) + '; defaultConfigurationIsVisible=0; defaultConfigurationName=Debug;}')

project_configs = configs("project", "")
app_configs = configs("app", '''PRODUCT_NAME=MotionValidation; PRODUCT_MODULE_NAME=MotionApp;
PRODUCT_BUNDLE_IDENTIFIER=app.5ln.studio.validation; MARKETING_VERSION=24; CURRENT_PROJECT_VERSION=24;
INFOPLIST_FILE="MotionValidation-App.plist";
ASSETCATALOG_COMPILER_APPICON_NAME=AppIcon; INFOPLIST_KEY_UILaunchScreen_Generation=YES;
INFOPLIST_KEY_NSPhotoLibraryUsageDescription="Import reference images";
INFOPLIST_KEY_NSPhotoLibraryAddUsageDescription="Save rendered images";''')
test_configs = configs("test", '''PRODUCT_NAME=MotionValidationTests;
PRODUCT_BUNDLE_IDENTIFIER=app.5ln.studio.validation.tests;
INFOPLIST_FILE="MotionValidation-Tests.plist";
TEST_HOST="$(BUILT_PRODUCTS_DIR)/MotionValidation.app/MotionValidation"; BUNDLE_LOADER="$(TEST_HOST)";
LD_RUNPATH_SEARCH_PATHS="$(inherited) @executable_path/Frameworks @loader_path/Frameworks";''')
app_id = identifier("app-target")
project_id = identifier("project")
proxy = add("proxy", '{isa=PBXContainerItemProxy; containerPortal=' + project_id + '; proxyType=1; remoteGlobalIDString=' + app_id + '; remoteInfo=MotionValidation;}')
dependency = add("dependency", '{isa=PBXTargetDependency; target=' + app_id + '; targetProxy=' + proxy + ';}')
add("app-target", '{isa=PBXNativeTarget; buildConfigurationList=' + app_configs + '; buildPhases=' + array(app_phases) + '; buildRules=(); dependencies=(); name=MotionValidation; productName=MotionValidation; productReference=' + app_product + '; productType="com.apple.product-type.application";}')
test_id = add("test-target", '{isa=PBXNativeTarget; buildConfigurationList=' + test_configs + '; buildPhases=' + array(test_phases) + '; buildRules=(); dependencies=' + array([dependency]) + '; name=MotionValidationTests; productName=MotionValidationTests; productReference=' + test_product + '; productType="com.apple.product-type.bundle.unit-test";}')
add("project", '{isa=PBXProject; attributes={LastUpgradeCheck=1600; TargetAttributes={' + test_id + '={TestTargetID=' + app_id + ';};};}; buildConfigurationList=' + project_configs + '; compatibilityVersion="Xcode 14.0"; developmentRegion=en; knownRegions=(en,Base); mainGroup=' + main_group + '; productRefGroup=' + products + '; projectDirPath=""; projectRoot=""; targets=' + array([app_id, test_id]) + ';}')
(project / "project.pbxproj").write_text('// !$*UTF8*$!\n{archiveVersion=1; classes={}; objectVersion=56; objects={\n' + '\n'.join(key + '=' + value + ';' for key, value in objects.items()) + '\n}; rootObject=' + project_id + ';}\n')
base_plist = {
    'CFBundleDevelopmentRegion': '$(DEVELOPMENT_LANGUAGE)',
    'CFBundleExecutable': '$(EXECUTABLE_NAME)',
    'CFBundleIdentifier': '$(PRODUCT_BUNDLE_IDENTIFIER)',
    'CFBundleInfoDictionaryVersion': '6.0',
    'CFBundleName': '$(PRODUCT_NAME)',
    'CFBundleShortVersionString': '1.0',
    'CFBundleVersion': '1',
}
app_plist = dict(base_plist,
    CFBundlePackageType='APPL', CFBundleDisplayName='3D MOTION',
    CFBundleShortVersionString='$(MARKETING_VERSION)', CFBundleVersion='$(CURRENT_PROJECT_VERSION)',
    LSRequiresIPhoneOS=True, UILaunchScreen={},
    NSPhotoLibraryUsageDescription='Import reference images',
    NSPhotoLibraryAddUsageDescription='Save rendered images',
    UIApplicationSceneManifest={'UIApplicationSupportsMultipleScenes': True, 'UISceneConfigurations': {}},
    UISupportedInterfaceOrientations=['UIInterfaceOrientationPortrait', 'UIInterfaceOrientationPortraitUpsideDown',
                                    'UIInterfaceOrientationLandscapeLeft', 'UIInterfaceOrientationLandscapeRight'])
test_plist = dict(base_plist, CFBundlePackageType='BNDL')
for filename, contents in [('MotionValidation-App.plist', app_plist), ('MotionValidation-Tests.plist', test_plist)]:
    with (here / filename).open('wb') as target:
        plistlib.dump(contents, target)
schemes = project / "xcshareddata/xcschemes"
schemes.mkdir(parents=True, exist_ok=True)
(schemes / "MotionValidation.xcscheme").write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
 <BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries>
  <BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">
   <BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{app_id}" BuildableName="MotionValidation.app" BlueprintName="MotionValidation" ReferencedContainer="container:AppleValidation.xcodeproj"/>
  </BuildActionEntry>
 </BuildActionEntries></BuildAction>
 <TestAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv="YES"><Testables>
  <TestableReference skipped="NO"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{test_id}" BuildableName="MotionValidationTests.xctest" BlueprintName="MotionValidationTests" ReferencedContainer="container:AppleValidation.xcodeproj"/></TestableReference>
 </Testables></TestAction>
 <LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{app_id}" BuildableName="MotionValidation.app" BlueprintName="MotionValidation" ReferencedContainer="container:AppleValidation.xcodeproj"/></BuildableProductRunnable></LaunchAction>
</Scheme>
''')
print(project)
