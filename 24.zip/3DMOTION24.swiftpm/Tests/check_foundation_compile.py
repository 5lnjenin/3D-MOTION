#!/usr/bin/env python3
"""Compile production Foundation-only snippets involved in the v24 errors.

This does not compile UIKit/SceneKit and is not an iOS SDK validation.
The actual ProjectCard declaration and projectCards() implementation are read
from StudioCore.swift, rather than reimplemented in the test.
"""
import pathlib
import subprocess
import tempfile

root = pathlib.Path(__file__).resolve().parent.parent
source = (root / "StudioCore.swift").read_text()


def declaration(marker):
    start = source.index(marker)
    opening = source.index("{", start)
    depth = 0
    for index in range(opening, len(source)):
        if source[index] == "{":
            depth += 1
        elif source[index] == "}":
            depth -= 1
            if depth == 0:
                return source[start:index + 1]
    raise RuntimeError("Incomplete declaration: " + marker)


persistence = (root / "ProjectPersistence.swift").read_text()
message_start = persistence.index('let message = "تعذر حفظ المشروع / Save failed: "')
message_end = persistence.index("return false", message_start)
message_assignments = persistence[message_start:message_end]

probe = '''import Foundation
enum ProbeLanguage { case arabic, english }
final class StudioStore {
    let projectsFolderURL: URL
    let autosaveProjectURL: URL
    var appLanguage: ProbeLanguage = .arabic
    init(root: URL) {
        projectsFolderURL = root.appendingPathComponent("Projects", isDirectory: true)
        autosaveProjectURL = root.appendingPathComponent("Autosave.3dmotion")
    }
'''
probe += declaration("struct ProjectCard:") + "\n"
probe += declaration("func projectCards()") + "\n}\n"
probe += '''
func checkFailureMessage(_ error: Error) {
    var toast: String?
    var lastAutosaveText: String = ""
'''
probe += message_assignments
probe += '''
    precondition(toast == lastAutosaveText && !lastAutosaveText.isEmpty)
}
let root = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
let store = StudioStore(root: root)
let fm = FileManager.default
try fm.createDirectory(at: store.projectsFolderURL, withIntermediateDirectories: true)
func fixture(_ name: String, file: String, modified: TimeInterval) throws {
    let folder = store.projectsFolderURL.appendingPathComponent(name, isDirectory: true)
    try fm.createDirectory(at: folder, withIntermediateDirectories: true)
    let url = folder.appendingPathComponent(file)
    try Data("fixture".utf8).write(to: url)
    try fm.setAttributes([.modificationDate: Date(timeIntervalSince1970: modified)], ofItemAtPath: url.path)
}
try fixture("New", file: "Project.3dmotion", modified: 300)
try fixture("Old", file: "Project.scn", modified: 100)
try fixture("Ignored", file: "Other.txt", modified: 400)
try Data("not a project directory".utf8).write(to: store.projectsFolderURL.appendingPathComponent("Loose.txt"))
precondition(store.projectCards().map(\\.id) == ["New", "Old"], "Filter/sort regression")
try Data("autosave".utf8).write(to: store.autosaveProjectURL)
try fm.setAttributes([.modificationDate: Date(timeIntervalSince1970: 200)], ofItemAtPath: store.autosaveProjectURL.path)
precondition(store.projectCards().map(\\.id) == ["New", "autosave://last", "Old"], "Autosave sorting regression")
precondition(store.projectCards().first { $0.id == "autosave://last" }?.name == "آخر حفظ تلقائي")
store.appLanguage = .english
precondition(store.projectCards().first { $0.id == "autosave://last" }?.name == "Last autosave")
checkFailureMessage(NSError(domain: "SaveProbe", code: 1))
print("PASS: production projectCards() compiles, filters/sorts legacy/new saves and autosave; failure message remains nonoptional.")
'''

with tempfile.TemporaryDirectory(prefix="motion-foundation-check-") as directory:
    folder = pathlib.Path(directory)
    swift = folder / "Probe.swift"
    swift.write_text(probe)
    executable = folder / "Probe"
    subprocess.run(["swiftc", "-swift-version", "5", "-module-cache-path", str(folder / "ModuleCache"),
                    str(swift), "-o", str(executable)], check=True)
    subprocess.run([str(executable), str(folder / "Fixtures")], check=True)
