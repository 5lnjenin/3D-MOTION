import XCTest
@testable import MotionWorkshopCore

final class WorkshopCoreTests:XCTestCase {
    func cube(offset:Double=0) -> WorkshopMesh {
        let p:[WorkshopMesh.V]=[.init(-1+offset,-1,-1),.init(1+offset,-1,-1),.init(1+offset,1,-1),.init(-1+offset,1,-1),.init(-1+offset,-1,1),.init(1+offset,-1,1),.init(1+offset,1,1),.init(-1+offset,1,1)]
        let ids=[[0,2,1],[0,3,2],[4,5,6],[4,6,7],[0,1,5],[0,5,4],[3,7,6],[3,6,2],[0,4,7],[0,7,3],[1,2,6],[1,6,5]]
        return WorkshopMesh(vertices:p.map {.init(p:$0)},faces:ids.map {.init(a:$0[0],b:$0[1],c:$0[2])}).normals(smooth:true)
    }
    func volume(_ mesh:WorkshopMesh) -> Double {mesh.faces.reduce(0) {$0+WorkshopMesh.dot(mesh.vertices[$1.a].p,WorkshopMesh.cross(mesh.vertices[$1.b].p,mesh.vertices[$1.c].p))/6}}
    func testClosedCubeAndSignedVolume() throws {let m=cube();XCTAssertTrue(try m.isClosedSolid());XCTAssertEqual(volume(m),8,accuracy:1e-9)}
    func testSubdivideKeepsVolumeAndManifold() throws {let m=try cube().subdivided();XCTAssertEqual(m.faces.count,48);XCTAssertEqual(volume(m),8,accuracy:1e-9);XCTAssertTrue(try m.isClosedSolid())}
    func testMirrorReversesWindingAndDoubleMirrorRestoresPositions() throws {let a=cube(),b=try a.mirrored(axis:0),c=try b.mirrored(axis:0);XCTAssertEqual(volume(b),8,accuracy:1e-9);XCTAssertEqual(c.vertices.map(\.p),a.vertices.map(\.p))}
    func testExtrudeRegionCreatesOnlyBoundaryWalls() throws {let m=try cube().extruded(selected:[6,7],distance:1);XCTAssertEqual(m.faces.count,20);XCTAssertEqual(volume(m),12,accuracy:1e-9);XCTAssertTrue(try m.isClosedSolid())}
    func testInsetPreservesVolumeAndMaterialSlots() throws {var m=cube();m.faces[0].material=2;let result=try m.inset(selected:[0],fraction:0.25);XCTAssertEqual(result.faces.count,18);XCTAssertEqual(volume(result),8,accuracy:1e-9);XCTAssertEqual(result.faces.filter {$0.material==2}.count,7)}
    func testSolidifyOpenQuadCreatesClosedShell() throws {
        let p:[WorkshopMesh.V]=[.init(0,0,0),.init(1,0,0),.init(1,1,0),.init(0,1,0)]
        let m=WorkshopMesh(vertices:p.map {.init(p:$0)},faces:[.init(a:0,b:1,c:2),.init(a:0,b:2,c:3)])
        let result=try m.solidified(thickness:0.5);XCTAssertEqual(result.faces.count,12);XCTAssertEqual(volume(result),0.5,accuracy:1e-9);XCTAssertTrue(try result.isClosedSolid())
    }
    func testMergeRespectsUVSeamsAndAdjacentSpatialCells() throws {
        var m=cube();var v=m.vertices[0];v.p.x += 0.0001;v.uv = .init(1,1);m.vertices.append(v);m.faces[0].a=8
        let keep=try m.welded(tolerance:0.001),merge=try m.welded(tolerance:0.001,preserveUV:false)
        XCTAssertEqual(keep.vertices.count,9);XCTAssertEqual(merge.vertices.count,8)
    }
    func testSmoothHasFiniteNormalsAndUVUnchanged() throws {let original=try cube().mappedUV(.box,axis:1,tiling:2),m=try original.smoothed(iterations:2,strength:0.1);XCTAssertEqual(m.vertices.map(\.uv),original.vertices.map(\.uv));XCTAssertLessThan(volume(m),volume(original));_=try m.checked()}
    func testDeformationsKeepTopologyAndProduceDistinctShape() throws {let original=try cube().subdivided();for kind in WorkshopMesh.Deform.allCases {let m=try original.deformed(kind,axis:1,amount:1);XCTAssertEqual(m.faces.count,original.faces.count);XCTAssertNotEqual(m.vertices.map(\.p),original.vertices.map(\.p));_=try m.checked()}}
    func testUVProjectionPreservesPositionsAndMaterials() throws {let m=cube();for mapping in WorkshopMesh.UV.allCases {let mapped=try m.mappedUV(mapping,axis:1,tiling:2);XCTAssertEqual(volume(mapped),8,accuracy:1e-9);XCTAssertEqual(mapped.faces.map(\.material),m.faces.map(\.material));_=try mapped.checked()}}
    func testSculptOnlyChangesVerticesWithinBrush() throws {let m=cube(),result=try m.sculpted(center:.init(-1,-1,-1),radius:0.5,strength:0.2);XCTAssertNotEqual(result.vertices[0].p,m.vertices[0].p);for i in 1..<m.vertices.count {XCTAssertEqual(result.vertices[i].p,m.vertices[i].p)}}
    func testBooleanVolumesForOverlappingBoxes() throws {
        let a=cube(),b=cube(offset:1)
        for (op,expected) in [(WorkshopMesh.BooleanOperation.union,12.0),(.subtract,4.0),(.intersect,4.0)] {let m=try a.boolean(op,with:b);XCTAssertEqual(volume(m),expected,accuracy:1e-6)}
    }
    func testBooleanIdenticalAndDisjointSolids() throws {let a=cube();XCTAssertEqual(volume(try a.boolean(.union,with:a)),8,accuracy:1e-6);XCTAssertThrowsError(try a.boolean(.subtract,with:a));XCTAssertThrowsError(try a.boolean(.intersect,with:cube(offset:5)))}
    func testOpenMeshAndInvalidInputRejectedWithoutMutation() throws {var a=cube();a.faces.removeLast();XCTAssertThrowsError(try a.boolean(.union,with:cube()));XCTAssertThrowsError(try a.extruded(selected:[999],distance:1));XCTAssertThrowsError(try a.deformed(.bend,axis:3,amount:1));XCTAssertThrowsError(try a.welded(tolerance:0));XCTAssertThrowsError(try a.solidified(thickness:.nan))}
    func testSubdivisionBudgetRejectsBeforeExpansion() {var a=cube();a.faces=Array(repeating:a.faces[0],count:25_001);XCTAssertThrowsError(try a.subdivided())}
    func curve(_ interpolation:ImportedAnimationCurve.Interpolation = .linear) -> ImportedAnimationCurve {
        ImportedAnimationCurve(target:"bone",path:"translation",times:[0,2],values:[0,0,0,2,0,0],components:3,interpolation:interpolation)
    }
    func testLinearAndStepChannelsRespectEndpoints() throws {var c=curve();try c.validate();XCTAssertEqual(c.sample(1),[1,0,0]);XCTAssertEqual(c.sample(-1),[0,0,0]);c.interpolation = .step;XCTAssertEqual(c.sample(1.9),[0,0,0]);XCTAssertEqual(c.sample(2),[2,0,0])}
    func testCubicUsesTangentsAndIntervalDurationExactly() throws {
        var c=curve(.cubic);c.values=[0,0,0, 0,0,0, 2,0,0, -2,0,0, 2,0,0, 0,0,0]
        try c.validate();XCTAssertEqual(c.sample(1)[0],2,accuracy:1e-12);XCTAssertEqual(c.sample(0.5)[0],1.0625,accuracy:1e-12)
    }
    func testQuaternionLinearUsesShortestSphericalPath() throws {
        let c=ImportedAnimationCurve(target:"bone",path:"rotation",times:[0,1],values:[0,0,0,1, 0,0,0,-1],components:4,interpolation:.linear)
        try c.validate();XCTAssertEqual(c.sample(0.5),[0,0,0,1])
        var q=c;q.values=[0,0,0,1,0,1,0,0];XCTAssertEqual(q.sample(0.5)[1],sqrt(0.5),accuracy:1e-12)
    }
    func testCubicQuaternionIsNormalizedWithoutTangentSignFlip() throws {
        let c=ImportedAnimationCurve(target:"bone",path:"rotation",times:[0,1],values:[0,0,0,0,0,0,0,1,0,2,0,0,0,-2,0,0,0,0,0,1,0,0,0,0],components:4,interpolation:.cubic)
        try c.validate();let q=c.sample(0.5);XCTAssertGreaterThan(q[1],0);XCTAssertEqual(q.reduce(0) {$0+$1*$1},1,accuracy:1e-12)
    }
    func testMalformedCurvesFailValidation() {var c=curve();c.times=[1,0];XCTAssertThrowsError(try c.validate());c=curve();c.values=[.nan];XCTAssertThrowsError(try c.validate());c=curve();c.components=4;XCTAssertThrowsError(try c.validate())}
    func testClipClockLoopStartSpeedFreezeAndRest() throws {
        var l=ImportedAnimationLibrary(clips:[.init(name:"Walk",channels:[curve()])],rest:[.init(target:"bone",translation:[0,0,0],rotation:[0,0,0,1],scale:[1,1,1],weights:[])])
        l.start=3;l.speed=2;try l.validate();XCTAssertNil(l.clipTime(2));XCTAssertEqual(l.timelineEnd,4);XCTAssertEqual(l.clipTime(3.25),0.5);XCTAssertEqual(l.clipTime(4.25),0.5)
        l.loops=false;XCTAssertEqual(l.clipTime(5),2);l.pausedAt=3.25;XCTAssertEqual(l.clipTime(9),0.5);l.selected=nil;XCTAssertNil(l.clipTime(4))
    }
    func testAnimationLibraryBinaryRoundTrip() throws {
        let library=ImportedAnimationLibrary(clips:[.init(name:"مشي",channels:[curve()])],rest:[.init(target:"bone",translation:[0,0,0],rotation:[0,0,0,1],scale:[1,1,1],weights:[])])
        let encoder=PropertyListEncoder();encoder.outputFormat = .binary;let data=try encoder.encode(library),restored=try PropertyListDecoder().decode(ImportedAnimationLibrary.self,from:data)
        try restored.validate();XCTAssertEqual(restored.clips[0].name,"مشي");XCTAssertEqual(restored.clips[0].channels[0].sample(1),[1,0,0])
    }
}
