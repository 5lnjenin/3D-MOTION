import XCTest
import UIKit
import SceneKit
import SwiftUI
@testable import MotionApp

@MainActor
extension ScenePersistenceTests {
    func writeMaterialMap(_ name: String, _ color: UIColor = .orange) throws -> URL {
        let url = root.appendingPathComponent(name)
        try XCTUnwrap(image(color).pngData()).write(to: url)
        return url
    }
    func testDevicePBRMapsDecodePackedChannelsAndLibraryPersists() async throws {
        try prepareStore()
        let color = try writeMaterialMap("Resin_BaseColor.png"), packed = try writeMaterialMap("Resin_ORM.png")
        let prepared = try MaterialImportFiles.prepare([color, packed])
        XCTAssertEqual(prepared.candidates.count, 1)
        let materials = try await MaterialImportDecoder.decode(prepared.candidates, maximumDimension: 2048)
        let original = try XCTUnwrap(materials.first?.1)
        XCTAssertEqual(original.roughness.textureComponents, .green); XCTAssertEqual(original.metalness.textureComponents, .blue)
        XCTAssertEqual(original.ambientOcclusion.textureComponents, .red)
        let location = root.appendingPathComponent("Personal")
        let library = UserMaterialLibrary(directory: location)
        let cards = try await library.add(materials, source: prepared.source)
        XCTAssertEqual(cards.count, 1)
        try FileManager.default.removeItem(at: color); try FileManager.default.removeItem(at: packed)
        let reopened = UserMaterialLibrary(directory: location)
        XCTAssertEqual(reopened.cards.count, 1)
        let material = try reopened.material(try XCTUnwrap(reopened.cards.first))
        XCTAssertTrue(material.diffuse.contents is UIImage); XCTAssertTrue(material.normal.contents == nil)
        XCTAssertEqual(material.roughness.textureComponents, .green); XCTAssertEqual(material.metalness.textureComponents, .blue)
        XCTAssertEqual(material.ambientOcclusion.textureComponents, .red)
        XCTAssertNotNil(reopened.thumbnail(cards[0]))
        print("PERSONAL_MATERIALS_PBR_PASS device maps, ORM masks, restart, source deletion, thumbnail")
    }
    func testPersonalMaterialBatchFailureAndCancellationKeepExistingLibrary() async throws {
        try prepareStore()
        let library = UserMaterialLibrary(directory: root.appendingPathComponent("Personal"))
        let material = SCNMaterial(); material.diffuse.contents = UIColor.cyan.cgColor
        let original = try await library.add([("Existing", material)], source: .init(label: "Device"))
        do {
            _ = try await library.add([("Good", material), ("  ", material)], source: .init(label: "Device"))
            XCTFail("Invalid second item must reject the entire batch")
        } catch { }
        XCTAssertEqual(library.cards.map(\.id), original.map(\.id))
        let task = Task { @MainActor in try await library.add([("Cancelled", material)], source: .init(label: "Device")) }
        task.cancel()
        do { _ = try await task.value; XCTFail("Cancelled batch committed") } catch { XCTAssertTrue(error is CancellationError) }
        try library.reload(); XCTAssertEqual(library.cards.map(\.id), original.map(\.id))
        XCTAssertFalse(try FileManager.default.contentsOfDirectory(atPath: library.directory.path).contains(where: { $0.hasSuffix(".staging") }))
        print("PERSONAL_MATERIALS_ATOMIC_PASS failure and cancellation expose no partial batch")
    }
    func testPersonalMaterialApplyRetainsUVSamplersUndoAndEmbeddedProjectAfterDelete() async throws {
        try prepareStore()
        let painted = mesh("Imported surface"), sibling = SCNNode(geometry: painted.geometry)
        sibling.name = "Shared unchanged"; store.contentRoot.addChildNode(sibling)
        let library = UserMaterialLibrary(directory: root.appendingPathComponent("Personal"))
        let imported = SCNMaterial(); imported.diffuse.contents = image(.cyan); imported.normal.contents = image(.blue)
        imported.diffuse.mappingChannel = 1; imported.diffuse.wrapS = .mirror; imported.diffuse.wrapT = .clamp
        imported.diffuse.minificationFilter = .nearest; imported.diffuse.maxAnisotropy = 4
        var transform = SCNMatrix4MakeScale(0.6, 0.8, 1); transform.m41 = 0.17; transform.m42 = 0.23
        imported.diffuse.contentsTransform = transform
        let added = try await library.add([("Portable cyan", imported)], source: .init(label: "Device"))
        let card = try XCTUnwrap(added.first)
        try library.rename(card, to: "Renamed cyan")
        let renamed = try XCTUnwrap(library.cards.first)
        XCTAssertEqual(try library.material(renamed).name, "Renamed cyan")
        store.select(painted); try store.applyUserMaterial(library.material(renamed), tiling: 2)
        XCTAssertTrue(painted.geometry !== sibling.geometry)
        let applied = try XCTUnwrap(painted.geometry?.firstMaterial)
        XCTAssertEqual(applied.diffuse.mappingChannel, 1); XCTAssertEqual(applied.diffuse.maxAnisotropy, 4)
        XCTAssertEqual(applied.diffuse.wrapS, .mirror); XCTAssertEqual(applied.diffuse.minificationFilter, .nearest)
        XCTAssertEqual(applied.diffuse.contentsTransform.m11, 1.2, accuracy: 1e-6)
        XCTAssertEqual(applied.diffuse.contentsTransform.m41, 0.17, accuracy: 1e-6)
        store.undoLast(); XCTAssertNotEqual(store.contentRoot.childNode(withName: "Imported surface", recursively: true)?.geometry?.firstMaterial?.name, "Renamed cyan")
        store.redoLast(); XCTAssertEqual(store.contentRoot.childNode(withName: "Imported surface", recursively: true)?.geometry?.firstMaterial?.name, "Renamed cyan")
        let data = try projectData(); try library.delete(renamed); XCTAssertTrue(library.cards.isEmpty)
        try store.importPortableProject(data)
        let reopened = try XCTUnwrap(store.contentRoot.childNode(withName: "Imported surface", recursively: true)?.geometry?.firstMaterial)
        XCTAssertTrue(reopened.diffuse.contents is UIImage); XCTAssertTrue(reopened.normal.contents is UIImage)
        XCTAssertEqual(reopened.diffuse.maxAnisotropy, 4); XCTAssertEqual(reopened.diffuse.contentsTransform.m41, 0.17, accuracy: 1e-6)
        print("PERSONAL_MATERIALS_PORTABLE_PASS rename/delete, UV samplers, shared geometry isolation, undo/redo, reopen")
    }
    func testPersonalMaterialMissingUVRefusesWithoutMutatingGeometry() throws {
        try prepareStore()
        let target = SCNNode(geometry: SCNBox(width: 1, height: 1, length: 1, chamferRadius: 0))
        store.contentRoot.addChildNode(target); store.select(target)
        let geometry = target.geometry, material = SCNMaterial(); material.diffuse.contents = image(.red); material.diffuse.mappingChannel = 7
        XCTAssertThrowsError(try store.applyUserMaterial(material)); XCTAssertTrue(target.geometry === geometry)
    }
    func testMaterialNormalDirectXAndGlossPixelsConvert() async throws {
        try prepareStore()
        let dx = try writeMaterialMap("Resin_NormalDX.png", UIColor(red: 0.2, green: 0.25, blue: 0.8, alpha: 1))
        let gloss = try writeMaterialMap("Resin_Gloss.png", UIColor(white: 0.25, alpha: 1))
        let prepared = try MaterialImportFiles.prepare([dx, gloss])
        let decoded = try await MaterialImportDecoder.decode(prepared.candidates, maximumDimension: 1024)
        let material = try XCTUnwrap(decoded.first?.1)
        for (property, channel) in [(material.normal, 1), (material.roughness, 0)] {
            let cg = try XCTUnwrap((property.contents as? UIImage)?.cgImage)
            var rgba = [UInt8](repeating: 0, count: 4)
            let context = try XCTUnwrap(CGContext(data: &rgba, width: 1, height: 1, bitsPerComponent: 8, bytesPerRow: 4,
                space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue))
            context.draw(cg, in: CGRect(x: 0, y: 0, width: 1, height: 1))
            XCTAssertEqual(Double(rgba[channel]), 191, accuracy: 3)
        }
    }
    func testMaterialImportLimitsQualityAndRejectsDuplicateMaps() async throws {
        try prepareStore()
        let url = root.appendingPathComponent("Big_Color.png")
        let format = UIGraphicsImageRendererFormat(); format.scale = 1
        let big = UIGraphicsImageRenderer(size: CGSize(width: 2100, height: 1100), format: format).image { context in
            UIColor.green.setFill(); context.fill(CGRect(x: 0, y: 0, width: 2100, height: 1100))
        }
        try XCTUnwrap(big.pngData()).write(to: url)
        let prepared = try MaterialImportFiles.prepare([url])
        let materials = try await MaterialImportDecoder.decode(prepared.candidates, maximumDimension: 1024)
        let cg = try XCTUnwrap((materials[0].1.diffuse.contents as? UIImage)?.cgImage)
        XCTAssertEqual(cg.width, 1024); XCTAssertLessThanOrEqual(cg.height, 1024)
        var duplicate = prepared.candidates[0]; duplicate.maps.append(duplicate.maps[0])
        do { _ = try await MaterialImportDecoder.decode([duplicate], maximumDimension: 1024); XCTFail("Duplicate channels accepted") } catch { }
    }
    func testMaterialOnlyGLTFKeepsTransformsAndRejectsMissingImage() async throws {
        try prepareStore()
        let png = try XCTUnwrap(image(.green).pngData()).base64EncodedString()
        var document: [String: Any] = ["asset": ["version": "2.0"], "extensionsRequired": ["KHR_draco_mesh_compression"],
            "images": [["uri": "data:image/png;base64," + png]], "textures": [["source": 0]],
            "materials": [["name": "Resin", "pbrMetallicRoughness": ["baseColorTexture": ["index": 0, "extensions": ["KHR_texture_transform": ["scale": [0.5, 0.75], "offset": [0.2, 0.3], "texCoord": 1]]], "metallicRoughnessTexture": ["index": 0], "metallicFactor": 0.3, "roughnessFactor": 0.4]]]]
        let url = root.appendingPathComponent("OnlyMaterials.gltf")
        try JSONSerialization.data(withJSONObject: document).write(to: url)
        let prepared = try MaterialImportFiles.prepare([url])
        let materials = try await MaterialImportDecoder.decode(prepared.candidates, maximumDimension: 2048)
        let material = try XCTUnwrap(materials.first?.1)
        XCTAssertTrue(material.diffuse.contents is UIImage); XCTAssertEqual(material.diffuse.mappingChannel, 1)
        XCTAssertEqual(material.diffuse.contentsTransform.m11, 0.5); XCTAssertEqual(material.diffuse.contentsTransform.m41, 0.2, accuracy: 1e-6)
        XCTAssertEqual(material.roughness.textureComponents, .green); XCTAssertEqual(material.metalness.textureComponents, .blue)
        XCTAssertEqual(material.roughness.intensity, 0.4, accuracy: 1e-6)
        XCTAssertTrue(store.contentRoot.childNodes.isEmpty)
        document["images"] = [["uri": "missing.png"]]; try JSONSerialization.data(withJSONObject: document).write(to: url)
        let missing = try MaterialImportFiles.prepare([url])
        do { _ = try await MaterialImportDecoder.decode(missing.candidates, maximumDimension: 2048); XCTFail("Missing map accepted") } catch { }
    }
    func testFiberglassHasDistinctMapsAndTravelsWithProject() throws {
        try prepareStore()
        XCTAssertEqual(WorkshopMaterial.fiberglass.title(true), "فايبر جلاس")
        XCTAssertEqual(WorkshopMaterial.fiberglass.metalness, 0)
        XCTAssertLessThan(WorkshopMaterial.fiberglass.roughness, 0.4)
        XCTAssertNotEqual(WorkshopTextures.image(.fiberglass).pngData(), WorkshopTextures.image(.canvas).pngData())
        let target = mesh("Fiberglass"); store.select(target); store.applyWorkshopMaterial(.fiberglass)
        let data = try projectData(); try store.importPortableProject(data)
        let material = try XCTUnwrap(store.contentRoot.childNode(withName: "Fiberglass", recursively: true)?.geometry?.firstMaterial)
        XCTAssertTrue(material.diffuse.contents is UIImage); XCTAssertTrue(material.normal.contents is UIImage)
        XCTAssertEqual((material.metalness.contents as? NSNumber)?.doubleValue, 0)
        XCTAssertEqual((material.roughness.contents as? NSNumber)?.doubleValue ?? -1, 0.28, accuracy: 1e-6)
        print("FIBERGLASS_PASS woven glass/resin maps, zero metalness, portable project")
    }
    func testMaterialSourcesPopupHostedArabicEnglishAndCompactLayouts() async throws {
        try prepareStore()
        let scene = try XCTUnwrap(UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first)
        let previous = scene.windows.first(where: \.isKeyWindow), window = UIWindow(windowScene: scene)
        defer { window.isHidden = true; window.rootViewController = nil; previous?.makeKey() }
        for arabic in [true, false] {
            for size in [CGSize(width: 390, height: 844), CGSize(width: 768, height: 1024)] {
                window.frame = CGRect(origin: .zero, size: size)
                let host = UIHostingController(rootView: MaterialSourcesGuide(arabic: arabic))
                window.rootViewController = host; window.makeKeyAndVisible(); host.view.layoutIfNeeded()
                try await Task.sleep(nanoseconds: 150_000_000)
                XCTAssertEqual(host.view.bounds.width, size.width, accuracy: 1)
                let screenshot = UIGraphicsImageRenderer(size: size).image { _ in host.view.drawHierarchy(in: host.view.bounds, afterScreenUpdates: true) }
                let attachment = XCTAttachment(image: screenshot); attachment.name = "MaterialSources-\(arabic)-\(Int(size.width))"; attachment.lifetime = .keepAlways; add(attachment)
            }
        }
        print("MATERIAL_SOURCES_UI_PASS Arabic/English popup on compact and iPad widths")
    }
    func testMaterialZIPStoredDeflatedEmptyAndCorruptArchives() async throws {
        try prepareStore()
        let fixtures = ["UEsDBBQAAAAAAP04Tl05YQprRgAAAEYAAAAUAAAAbWFwcy9SZXNpbl9Db2xvci5wbmeJUE5HDQoaCgAAAA1JSERSAAAAAQAAAAEIBgAAAB8VxIkAAAANSURBVHicY/jPwPAfAAUAAf+JmT0dAAAAAElFTkSuQmCCUEsDBBQAAAAAAP04Tl0AAAAAAAAAAAAAAAAJAAAAZW1wdHkudHh0UEsDBBQAAAAAAP04Tl05YQprRgAAAEYAAAANAAAALi4vdW5zYWZlLnBuZ4lQTkcNChoKAAAADUlIRFIAAAABAAAAAQgGAAAAHxXEiQAAAA1JREFUeJxj+M/A8B8ABQAB/4mZPR0AAAAASUVORK5CYIJQSwECFAMUAAAAAAD9OE5dOWEKa0YAAABGAAAAFAAAAAAAAAAAAAAAgAEAAAAAbWFwcy9SZXNpbl9Db2xvci5wbmdQSwECFAMUAAAAAAD9OE5dAAAAAAAAAAAAAAAACQAAAAAAAAAAAAAAgAF4AAAAZW1wdHkudHh0UEsBAhQDFAAAAAAA/ThOXTlhCmtGAAAARgAAAA0AAAAAAAAAAAAAAIABnwAAAC4uL3Vuc2FmZS5wbmdQSwUGAAAAAAMAAwC0AAAAEAEAAAAA","UEsDBBQAAAAIAP04Tl05YQprPwAAAEYAAAAUAAAAbWFwcy9SZXNpbl9Db2xvci5wbmfrDPBz5+WS4mJgYOD19HAJAtKMIMzBBiTlRY90giVcHEMq5iT/OH/ggzwDKwPj/86ZtrJACQZPVz+XdU4JTQBQSwMEFAAAAAgA/ThOXQAAAAACAAAAAAAAAAkAAABlbXB0eS50eHQDAFBLAwQUAAAACAD9OE5dOWEKaz8AAABGAAAADQAAAC4uL3Vuc2FmZS5wbmfrDPBz5+WS4mJgYOD19HAJAtKMIMzBBiTlRY90giVcHEMq5iT/OH/ggzwDKwPj/86ZtrJACQZPVz+XdU4JTQBQSwECFAMUAAAACAD9OE5dOWEKaz8AAABGAAAAFAAAAAAAAAAAAAAAgAEAAAAAbWFwcy9SZXNpbl9Db2xvci5wbmdQSwECFAMUAAAACAD9OE5dAAAAAAIAAAAAAAAACQAAAAAAAAAAAAAAgAFxAAAAZW1wdHkudHh0UEsBAhQDFAAAAAgA/ThOXTlhCms/AAAARgAAAA0AAAAAAAAAAAAAAIABmgAAAC4uL3Vuc2FmZS5wbmdQSwUGAAAAAAMAAwC0AAAABAEAAAAA"]
        for (index, fixture) in fixtures.enumerated() {
            let url = root.appendingPathComponent("Maps\(index).zip")
            let bytes = try XCTUnwrap(Data(base64Encoded: fixture)); try bytes.write(to: url)
            let prepared = try MaterialImportFiles.prepare([url])
            XCTAssertEqual(prepared.candidates.count, 1)
            XCTAssertFalse(FileManager.default.fileExists(atPath: prepared.directory.appendingPathComponent("unsafe.png").path))
            let decoded = try await MaterialImportDecoder.decode(prepared.candidates, maximumDimension: 1024)
            XCTAssertEqual(decoded.count, 1)
        }
        let bad = root.appendingPathComponent("bad.zip")
        try (Data(repeating: 0, count: 22) + Data([0x50, 0x4b, 0x05, 0x06])).write(to: bad)
        XCTAssertThrowsError(try MaterialImportFiles.prepare([bad]))
        var corrupt = try XCTUnwrap(Data(base64Encoded: fixtures[0])); corrupt[55] ^= 1; try corrupt.write(to: bad)
        XCTAssertThrowsError(try MaterialImportFiles.prepare([bad]))
        print("MATERIAL_ZIP_PASS stored/deflated, empty entry, traversal isolation, truncated EOCD and CRC rejection")
    }

}
