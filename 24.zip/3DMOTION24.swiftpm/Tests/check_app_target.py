#!/usr/bin/env python3
"""Check explicit Playgrounds membership and SwiftPM's resolved target sources.

AppleProductTypes is available in Swift Playgrounds, not Linux SwiftPM. For the
cross-platform describe probe ONLY, omit the Apple application product. Keep
the production target path, exclusions, sources and resources unchanged.
"""
from pathlib import Path
import json
import os
import re
import shutil
import subprocess
import tempfile


def declared_app_sources(root):
    manifest = (root / "Package.swift").read_text()
    match = re.search(r"\bsources:\s*\[([^]]*)\]", manifest, re.S)
    if not match:
        raise ValueError("AppModule must explicitly declare its source membership")
    names = re.findall(r'"([^"\n]+)"', match.group(1))
    physical = sorted(p.name for p in root.glob("*.swift") if p.name != "Package.swift")
    if len(names) != len(set(names)) or sorted(names) != physical:
        raise ValueError("Declared target files differ from delivered app files")
    if "AddObjectUI.swift" not in names or not any("@main" in (root / name).read_text() for name in names):
        raise ValueError("App entry point or AddObjectUI is outside AppModule")
    if not re.search(r'\bname:\s*"AppModule"', manifest):
        raise ValueError("Missing AppModule")
    if not re.search(r'\btargets:\s*\["AppModule"\]', manifest):
        raise ValueError("Apple application product does not reference AppModule")
    return names


def main():
    root = Path(__file__).resolve().parent.parent
    names = declared_app_sources(root)
    manifest = (root / "Package.swift").read_text()
    manifest, changes = re.subn(r"    products: \[.*?\n    \],\n", "", manifest, count=1, flags=re.S)
    assert changes == 1, "Cannot isolate the Apple product for the SwiftPM probe"
    manifest = manifest.replace("import AppleProductTypes\n", "")
    with tempfile.TemporaryDirectory(prefix="motion-target-check-") as folder:
        package = Path(folder) / "3DMotion.swiftpm"
        shutil.copytree(root, package, ignore=shutil.ignore_patterns("__pycache__", ".build"))
        (package / "Package.swift").write_text(manifest)
        env = os.environ.copy()
        env["SWIFTPM_MODULECACHE_OVERRIDE"] = str(Path(folder) / "ModuleCache")
        env["CLANG_MODULE_CACHE_PATH"] = str(Path(folder) / "ModuleCache")
        result = subprocess.run(["swift", "package", "--package-path", str(package),
            "--cache-path", str(Path(folder) / "Cache"), "--config-path", str(Path(folder) / "Config"),
            "--security-path", str(Path(folder) / "Security"), "describe", "--type", "json"],
            env=env, text=True, capture_output=True, check=True)
        document = json.loads(result.stdout)
        target = next(t for t in document["targets"] if t["name"] == "AppModule")
        assert sorted(target["sources"]) == sorted(names), target["sources"]
        assert not any("Tests/" in path for path in target["sources"])
        assert target["type"] == "executable"
        print("APP_TARGET_PASS SwiftPM resolves all", len(names), "application files; AddObjectUI and app entry point included; Tests excluded")


if __name__ == "__main__":
    main()
