#!/usr/bin/env python3
"""Deterministic synthetic OBJ car and glTF/GLB regression assets."""
from pathlib import Path
import base64
import json
import struct
import zlib

root = Path(__file__).resolve().parent / "Fixtures"
root.mkdir(exist_ok=True)

def png(color):
    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)
    pixels = b"".join(b"\0" + bytes(color) * 2 for _ in range(2))
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 2, 2, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(pixels)) + chunk(b"IEND", b"")

paint = png((205, 25, 45, 255))
packed = png((128, 80, 230, 255))
car = root / "OBJCar"
textures = car / "materials/textures"
textures.mkdir(parents=True, exist_ok=True)
(textures / "paint.png").write_bytes(paint)
(textures / "packed.png").write_bytes(packed)
(car / "materials/car.mtl").write_text('''newmtl paint
Kd 1 1 1
map_Kd textures/paint.png
newmtl glass
Kd 0.2 0.7 0.9
d 0.45
newmtl wheels
Kd 0.1 0.1 0.1
map_Kd textures/packed.png
''')
lines = ["mtllib materials/car.mtl", "vt 0 0", "vt 1 0", "vt 1 1", "vt 0 1"]
offset = 1
parts = [("body", "paint", (-2,0,-1), (2,0.7,1)),
         ("cab", "glass", (-0.8,0.7,-0.8), (1,1.5,0.8))]
for x in [-1.2, 1.2]:
    for z in [-1.05, 1.05]:
        parts.append((f"wheel_{x}_{z}", "wheels", (x-0.3,-0.3,z-0.15), (x+0.3,0.3,z+0.15)))
for name, material, lo, hi in parts:
    vertices = [(lo[0],lo[1],lo[2]),(hi[0],lo[1],lo[2]),(hi[0],hi[1],lo[2]),(lo[0],hi[1],lo[2]),
                (lo[0],lo[1],hi[2]),(hi[0],lo[1],hi[2]),(hi[0],hi[1],hi[2]),(lo[0],hi[1],hi[2])]
    lines += ["o " + name, "usemtl " + material]
    lines += ["v " + " ".join(map(str, v)) for v in vertices]
    for face in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(3,7,6,2),(0,4,7,3),(1,2,6,5)]:
        lines.append("f " + " ".join(f"{offset + index}/{uv + 1}" for uv, index in enumerate(face)))
    offset += 8
(car / "car.obj").write_text("\n".join(lines) + "\n")

binary = bytearray()
views = []
def view(data, target=None):
    while len(binary) % 4:
        binary.append(0)
    record = {"buffer":0,"byteOffset":len(binary),"byteLength":len(data)}
    if target:
        record["target"] = target
    views.append(record)
    binary.extend(data)
    return len(views) - 1

positions = [0,0,0, 1,0,0, 0,1,0, 2,0,0, 3,0,0, 2,1,0]
uv = [0,0, 1,0, 0,1, 0,0, 1,0, 0,1]
pv = view(struct.pack("<18f", *positions), 34962)
uv0 = view(struct.pack("<12f", *uv), 34962)
uv1 = view(struct.pack("<12f", *[v * 0.5 for v in uv]), 34962)
indices0 = view(struct.pack("<3H", 0,1,2), 34963)
indices1 = view(struct.pack("<3H", 3,4,5), 34963)
paint_view = view(paint)
packed_view = view(packed)
doc = {
    "asset":{"version":"2.0"}, "extensionsUsed":["KHR_texture_transform"],
    "extensionsRequired":["KHR_texture_transform"], "scene":0,
    "scenes":[{"nodes":[0]}], "nodes":[{"name":"multimaterial-car","mesh":0}],
    "meshes":[{"primitives":[{"attributes":{"POSITION":0,"TEXCOORD_0":1,"TEXCOORD_1":2},"indices":3,"material":0},
                              {"attributes":{"POSITION":0,"TEXCOORD_0":1,"TEXCOORD_1":2},"indices":4,"material":1}]}],
    "accessors":[{"bufferView":pv,"componentType":5126,"count":6,"type":"VEC3","min":[0,0,0],"max":[3,1,0]},
                 {"bufferView":uv0,"componentType":5126,"count":6,"type":"VEC2"},
                 {"bufferView":uv1,"componentType":5126,"count":6,"type":"VEC2"},
                 {"bufferView":indices0,"componentType":5123,"count":3,"type":"SCALAR"},
                 {"bufferView":indices1,"componentType":5123,"count":3,"type":"SCALAR"}],
    "materials":[{"name":"paint","pbrMetallicRoughness":{
        "baseColorTexture":{"index":0,"texCoord":1,"extensions":{"KHR_texture_transform":{"offset":[0.2,0.3],"scale":[0.6,0.8]}}},
        "metallicRoughnessTexture":{"index":1},"metallicFactor":0.6,"roughnessFactor":0.7},
        "normalTexture":{"index":1},"emissiveTexture":{"index":0}},
        {"name":"glass","alphaMode":"BLEND","doubleSided":True,
         "pbrMetallicRoughness":{"baseColorFactor":[1,1,1,0.4],"baseColorTexture":{"index":1}}}],
    "textures":[{"source":0,"sampler":0},{"source":1,"sampler":0}],
    "samplers":[{"wrapS":33648,"wrapT":10497,"magFilter":9728,"minFilter":9987}],
    "images":[{"bufferView":paint_view,"mimeType":"image/png"},{"bufferView":packed_view,"mimeType":"image/png"}],
    "buffers":[{"byteLength":len(binary)}], "bufferViews":views
}
encoded = json.dumps(doc, separators=(",", ":")).encode()
encoded += b" " * ((-len(encoded)) % 4)
bin_chunk = bytes(binary) + b"\0" * ((-len(binary)) % 4)
glb = struct.pack("<III", 0x46546c67, 2, 12 + 8 + len(encoded) + 8 + len(bin_chunk))
glb += struct.pack("<II", len(encoded), 0x4e4f534a) + encoded
glb += struct.pack("<II", len(bin_chunk), 0x004e4942) + bin_chunk
(root / "multi.glb").write_bytes(glb)
doc["buffers"][0]["uri"] = "data:application/octet-stream;base64," + base64.b64encode(binary).decode()
(root / "multi.gltf").write_text(json.dumps(doc, indent=2))
print("Generated synthetic OBJ/MTL/PNG and GLB/glTF fixtures in", root)
