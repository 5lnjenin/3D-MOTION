#!/usr/bin/env python3
"""Exercise the production resource lookup in a real SwiftPM resource bundle.

Requires Swift. This checks Foundation/SwiftPM resource paths, not iOS signing.
"""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile

root = Path(__file__).resolve().parent.parent
source = (root / "Shared.swift").read_text()
start = source.index("enum StudioResourceFiles {")
opening = source.index("{", start)
depth = 0
for index in range(opening, len(source)):
    if source[index] == "{":
        depth += 1
    elif source[index] == "}":
        depth -= 1
        if depth == 0:
            helper = source[start:index + 1]
            break
else:
    raise RuntimeError("Resource lookup declaration is incomplete")

with tempfile.TemporaryDirectory(prefix="motion-resource-check-") as folder:
    package = Path(folder)
    target = package / "Sources/ResourceProbe"
    target.mkdir(parents=True)
    shutil.copytree(root / "Resources", target / "Resources")
    (package / "Package.swift").write_text('''// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "ResourceProbe", targets: [
    .executableTarget(name: "ResourceProbe", resources: [.process("Resources")])
])
''')
    (target / "main.swift").write_text('import Foundation\n' + helper + '''
let expected = CommandLine.arguments.dropFirst()
for filename in expected {
    let file = URL(fileURLWithPath: filename)
    let candidates = StudioResourceFiles.candidates(name: file.deletingPathExtension().lastPathComponent,
        fileExtension: file.pathExtension)
    guard let found = candidates.first(where: { FileManager.default.fileExists(atPath: $0.path) }) else {
        fatalError("Production helper did not locate " + filename)
    }
    precondition(try! Data(contentsOf: found) == Data(contentsOf: file), "Resource bytes changed")
    precondition(found.deletingLastPathComponent().lastPathComponent != "Resources", "Reserved folder was copied")
}
print("PASS: production resource helper finds all \\(expected.count) original files in the flattened SwiftPM bundle, with exact bytes.")
''')
    environment = os.environ.copy()
    environment["SWIFTPM_MODULECACHE_OVERRIDE"] = str(package / "ModuleCache")
    environment["CLANG_MODULE_CACHE_PATH"] = str(package / "ModuleCache")
    resources = sorted(str(path) for path in (root / "Resources").iterdir() if path.is_file())
    subprocess.run(["swift", "run", "--package-path", str(package),
        "--cache-path", str(package / "Cache"), "--config-path", str(package / "Config"),
        "--security-path", str(package / "Security"), "ResourceProbe", *resources],
        env=environment, check=True)
