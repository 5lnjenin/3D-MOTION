import Foundation
import XCTest
@testable import ProjectCore

final class PortableCoreTests: XCTestCase {
    func testPBRMapNamesGroupCommonTexturePacks() {
        for (filename, role) in [("Wood001_2K_Color.jpg", MaterialMapRole.baseColor), ("Wood001_2K_NormalGL.png", .normal), ("Wood001_2K_Roughness.png", .roughness), ("Wood001_2K_Metalness.png", .metalness), ("Wood001_2K_AmbientOcclusion.png", .ambientOcclusion)] {
            let found = MaterialImportNames.classify(URL(fileURLWithPath: "/maps/" + filename))
            XCTAssertEqual(found.name, "Wood001"); XCTAssertEqual(found.role, role, filename)
        }
        XCTAssertEqual(MaterialImportNames.classify(URL(fileURLWithPath: "/maps/photo.jpg")).role, .baseColor)
    }
    func testDirectXGlossAndPackedMapsHaveExplicitAssignments() {
        let dx = MaterialImportNames.classify(URL(fileURLWithPath: "/maps/resin_NormalDX.png"))
        XCTAssertTrue(dx.flipGreen); XCTAssertEqual(dx.role, .normal)
        let gloss = MaterialImportNames.classify(URL(fileURLWithPath: "/maps/resin_Glossiness.png"))
        XCTAssertTrue(gloss.invert); XCTAssertEqual(gloss.role, .roughness)
        XCTAssertEqual(MaterialImportNames.classify(URL(fileURLWithPath: "/maps/resin_ORM.png")).role, .orm)
        XCTAssertEqual(MaterialImportNames.classify(URL(fileURLWithPath: "/maps/resin_MetallicRoughness.png")).role, .metallicRoughness)
    }
    func testMapOverlapRejectedBeforeLibraryCommit() throws {
        let url = URL(fileURLWithPath: "/maps/map.png")
        XCTAssertNoThrow(try MaterialImportNames.validate([.init(url: url, role: .baseColor), .init(url: url, role: .orm)]))
        XCTAssertThrowsError(try MaterialImportNames.validate([.init(url: url, role: .orm), .init(url: url, role: .roughness)]))
        XCTAssertThrowsError(try MaterialImportNames.validate([.init(url: url, role: .baseColor), .init(url: url, role: .baseColor)]))
        XCTAssertThrowsError(try MaterialImportNames.validate([.init(url: url, role: .ignore)]))
    }
    func testDeviceSourceCreditRoundTripsWithoutAccount() throws {
        let source = MaterialSourceCredit(label: "Device")
        XCTAssertEqual(try JSONDecoder().decode(MaterialSourceCredit.self, from: JSONEncoder().encode(source)), source)
        XCTAssertNil(source.author); XCTAssertNil(source.modelURL)
    }

    func testMaterialShaderFactorsRejectUnknownInvalidAndNonFiniteValues() throws {
        var record = ProjectMaterialRecord(archive:Data([1]),properties:[:])
        record.shaderFactors = ["studioAuthoredTint":[1,0.3,0]]
        XCTAssertNoThrow(try record.validateShaderFactors())
        for factors in [["unknown":[Float(1),0,0]], ["studioAuthoredTint":[Float(1)]], ["studioEmissionTint":[Float.nan,0,0]], ["studioAuthoredTint":[Float(2),0,0]]] {
            record.shaderFactors = factors; XCTAssertThrowsError(try record.validateShaderFactors())
        }
    }
    func testOldMaterialRecordStillDecodesWithoutShaderFactors() throws {
        let record = try JSONDecoder().decode(ProjectMaterialRecord.self,from:Data(#"{"archive":"AQ==","properties":{}}"#.utf8))
        XCTAssertNil(record.shaderFactors);XCTAssertNoThrow(try record.validateShaderFactors())
    }

    func testMovieSourceDurationIsOptionalForOldDocumentsAndValidatedForNewOnes() throws {
        let old = try JSONDecoder().decode(ProjectValue.self, from: Data(#"{"kind":"video","resourceID":"movie"}"#.utf8))
        XCTAssertNil(old.videoDuration)
        let resources = ["movie": ProjectResource(kind: "video", fileExtension: "mp4", data: Data([1]))]
        XCTAssertNoThrow(try old.validate(resources: resources))
        var value = old
        value.videoDuration = 1.5
        XCTAssertEqual(try JSONDecoder().decode(ProjectValue.self, from: JSONEncoder().encode(value)).videoDuration, 1.5)
        XCTAssertNoThrow(try value.validate(resources: resources))
        for invalid in [0.0, -1, Double.infinity, Double.nan] {
            value.videoDuration = invalid
            XCTAssertThrowsError(try value.validate(resources: resources))
        }
    }

    func fixture(name: String = "Car") -> StudioPortablePackage {
        let bytes = Data("texture-bytes".utf8)
        let id = ProjectIntegrity.hash(bytes)
        var p = StudioPortablePackage(version: 2, name: name, scene: Data("scene-bytes".utf8),
            metadata: Data("metadata-bytes".utf8), environment: Data("environment".utf8),
            audio: ["sound.wav": Data("sound".utf8)], textures: nil,
            resources: [id: ProjectResource(kind: "image", fileExtension: "png", data: bytes)],
            materials: [:], bindings: [], particles: [])
        p.sceneEncoding = "scenekit-keyed-archive"
        p.seal()
        return p
    }

    func temporaryFolder() throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        addTeardownBlock { try? FileManager.default.removeItem(at: url) }
        return url
    }

    func testCompleteContainerRoundTrip() throws {
        let p = fixture()
        let restored = try ProjectFileStore.decode(ProjectFileStore.encode(p))
        XCTAssertEqual(restored.scene, p.scene)
        XCTAssertEqual(restored.metadata, p.metadata)
        XCTAssertEqual(restored.environment, p.environment)
        XCTAssertEqual(restored.audio, p.audio)
        XCTAssertEqual(restored.resources?.values.first?.data, p.resources?.values.first?.data)
    }

    func testSHA256KnownVector() {
        XCTAssertEqual(ProjectIntegrity.hash(Data("abc".utf8)), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
    }

    func testCorruptSceneRejected() {
        var p = fixture(); p.scene.append(0)
        XCTAssertThrowsError(try p.validate())
    }

    func testCorruptResourceRejected() {
        var p = fixture(); let id = p.resources!.keys.first!
        p.resources![id]!.data.append(0)
        XCTAssertThrowsError(try p.validate())
        p.seal() // Even a recomputed outer seal cannot disguise a mismatched resource ID.
        XCTAssertThrowsError(try p.validate())
    }

    func testResourceDescriptorTamperingRejected() {
        var p = fixture(); let id = p.resources!.keys.first!
        p.resources![id]!.fileExtension = "jpg"
        XCTAssertThrowsError(try p.validate())
    }

    func testMissingMaterialBindingRejected() {
        var p = fixture()
        p.bindings = [ProjectGeometryBinding(nodeID: "car", materialIDs: ["missing"], elementSignatures: [], texcoordSignatures: [])]
        p.seal()
        XCTAssertThrowsError(try p.validate())
    }

    func testMissingImageRejected() {
        let value = ProjectValue(kind: "image", resourceID: "missing")
        XCTAssertThrowsError(try value.validate(resources: [:]))
    }

    func testTraversalRejected() {
        var p = fixture(); p.audio["../escape.wav"] = Data([1]); p.seal()
        XCTAssertThrowsError(try p.validate())
        XCTAssertFalse(ProjectFileStore.safeComponent(".."))
        XCTAssertFalse(ProjectFileStore.safeComponent("dir\\file"))
    }

    func testRepeatedAtomicSavesKeepCompletePreviousGeneration() throws {
        let url = try temporaryFolder().appendingPathComponent("Car.3dmotion")
        for i in 0..<10 {
            let data = try ProjectFileStore.encode(fixture(name: "Car-\(i)"))
            try ProjectFileStore.commit(data, to: url)
            XCTAssertEqual(try ProjectFileStore.decode(Data(contentsOf: url)).name, "Car-\(i)")
            if i > 0 {
                XCTAssertEqual(try ProjectFileStore.decode(Data(contentsOf: ProjectFileStore.previous(url))).name, "Car-\(i-1)")
            }
        }
    }

    func testInvalidSavePreservesHealthyFile() throws {
        let url = try temporaryFolder().appendingPathComponent("Car.3dmotion")
        let original = try ProjectFileStore.encode(fixture())
        try ProjectFileStore.commit(original, to: url)
        var bad = fixture(); bad.metadata.append(1)
        XCTAssertThrowsError(try ProjectFileStore.commit(JSONEncoder().encode(bad), to: url))
        XCTAssertEqual(try Data(contentsOf: url), original)
    }

    func testBackupWriteFailurePreservesHealthyFile() throws {
        let url = try temporaryFolder().appendingPathComponent("Car.3dmotion")
        let original = try ProjectFileStore.encode(fixture())
        try ProjectFileStore.commit(original, to: url)
        try FileManager.default.createDirectory(at: ProjectFileStore.previous(url), withIntermediateDirectories: false)
        XCTAssertThrowsError(try ProjectFileStore.commit(ProjectFileStore.encode(fixture(name: "new")), to: url))
        XCTAssertEqual(try Data(contentsOf: url), original)
        let files = try FileManager.default.contentsOfDirectory(atPath: url.deletingLastPathComponent().path)
        XCTAssertFalse(files.contains { $0.hasSuffix(".pending") })
    }

    func testMoveDocumentAndRemoveOriginal() throws {
        let source = try temporaryFolder().appendingPathComponent("Car.3dmotion")
        let destination = try temporaryFolder().appendingPathComponent("Moved.3dmotion")
        let p = fixture()
        try ProjectFileStore.commit(ProjectFileStore.encode(p), to: source)
        try FileManager.default.moveItem(at: source, to: destination)
        let restored = try ProjectFileStore.decode(Data(contentsOf: destination))
        XCTAssertEqual(restored.resources?.values.first?.data, p.resources?.values.first?.data)
        XCTAssertFalse(FileManager.default.fileExists(atPath: source.path))
    }

    func testLegacyV1StillDecodes() throws {
        let p = StudioPortablePackage(version: 1, name: "old", scene: Data([1]), metadata: Data([2]), environment: nil, audio: [:], textures: nil)
        XCTAssertEqual(try ProjectFileStore.decode(JSONEncoder().encode(p)).version, 1)
    }

    func testUnknownVersionRejected() {
        var p = fixture(); p.version = 99
        XCTAssertThrowsError(try p.validate())
    }

    func testAnimationPlayerSettingsRoundTripAndTampering() throws {
        var p = fixture()
        p.animations = [ProjectAnimationBinding(nodeID: "car", key: "spin", archive: Data([1,2]),
            encoding: "ca-animation", speed: 0.5, blendFactor: 0.7, paused: true,
            settings: ProjectAnimationSettings(blendInDuration: 0.25, blendOutDuration: 0.4, startDelay: 0.1, timeOffset: 0.2,
                removedOnCompletion: false, appliedOnCompletion: true, fillsForward: true, fillsBackward: false,
                usesSceneTimeBase: true, additive: true, cumulative: false))]
        p.seal()
        let restored = try ProjectFileStore.decode(ProjectFileStore.encode(p))
        XCTAssertEqual(restored.animations?.first?.speed, 0.5)
        XCTAssertEqual(restored.animations?.first?.blendFactor, 0.7)
        XCTAssertEqual(restored.animations?.first?.paused, true)
        XCTAssertEqual(restored.animations?.first?.settings?.blendInDuration, 0.25)
        XCTAssertEqual(restored.animations?.first?.settings?.usesSceneTimeBase, true)
        p.animations![0].settings!.startDelay = 2
        XCTAssertThrowsError(try p.validate())
    }

    func testInvalidAnimationEncodingAndBlendRejected() {
        var p = fixture()
        p.animations = [ProjectAnimationBinding(nodeID: "car", key: "spin", archive: Data([1]), encoding: "unknown")]
        p.seal(); XCTAssertThrowsError(try p.validate())
        p.animations![0].encoding = "ca-animation"; p.animations![0].blendFactor = 2
        p.seal(); XCTAssertThrowsError(try p.validate())
    }

    func testLegacyAnimationBindingWithOmittedSettingsStillDecodes() throws {
        var p = fixture()
        p.animations = [ProjectAnimationBinding(nodeID: "car", key: "spin", archive: Data([1]))]
        p.seal()
        let encoded = try ProjectFileStore.encode(p)
        XCTAssertFalse(String(decoding: encoded, as: UTF8.self).contains("blendFactor"))
        XCTAssertNil(try ProjectFileStore.decode(encoded).animations?.first?.encoding)
    }
}

final class VideoClipTimingTests: XCTestCase {
    func testLegacyClockAndFinalFrameHold() throws {
        let timing = VideoClipTiming()
        XCTAssertEqual(timing.sourceTime(at: 0.7, duration: 1.5), 0.7, accuracy: 0.000001)
        XCTAssertEqual(timing.sourceTime(at: 10, duration: 1.5), 1.499999, accuracy: 0.000001)
        XCTAssertFalse(timing.isActive(at: 1.5, duration: 1.5))
    }
    func testTrimDelayAndSpeedUseOneClock() throws {
        let timing = VideoClipTiming(start: 2, sourceIn: 0.5, sourceOut: 1.5, speed: 2)
        XCTAssertEqual(timing.timelineEnd(4), 2.5)
        XCTAssertEqual(timing.sourceTime(at: 2.2, duration: 4), 0.9, accuracy: 0.000001)
        XCTAssertFalse(timing.isActive(at: 1.9, duration: 4))
        XCTAssertTrue(timing.isActive(at: 2.1, duration: 4))
        let segments = try timing.audioSegments(sourceDuration: 4, audioStart: 0, audioEnd: 4, timelineDuration: 3)
        XCTAssertEqual(segments, [.init(sourceStart: 0.5, sourceDuration: 1, timelineStart: 2, timelineDuration: 0.5)])
    }
    func testAudioTrackOffsetAndEndArePreserved() throws {
        let timing = VideoClipTiming(start: 1, sourceIn: 0.5, sourceOut: 2, speed: 0.5)
        let segments = try timing.audioSegments(sourceDuration: 3, audioStart: 1, audioEnd: 1.75, timelineDuration: 5)
        XCTAssertEqual(segments, [.init(sourceStart: 1, sourceDuration: 0.75, timelineStart: 2, timelineDuration: 1.5)])
    }
    func testLoopAndVisibleWindowIntersection() throws {
        let timing = VideoClipTiming(start: 0.5, sourceIn: 0.2, sourceOut: 0.6, speed: 2, loops: true)
        XCTAssertEqual(timing.sourceTime(at: 1.0, duration: 2), 0.4, accuracy: 0.000001)
        let segments = try timing.audioSegments(sourceDuration: 2, audioStart: 0, audioEnd: 2, timelineDuration: 1.2, windowStart: 0.85, windowEnd: 1.1)
        XCTAssertEqual(segments.count, 2)
        XCTAssertEqual(segments[0].timelineStart, 0.85, accuracy: 0.000001)
        XCTAssertEqual(segments[0].sourceStart, 0.5, accuracy: 0.000001)
        XCTAssertEqual(segments[0].timelineDuration, 0.05, accuracy: 0.000001)
        XCTAssertEqual(segments[1].timelineStart, 0.9, accuracy: 0.000001)
        XCTAssertEqual(segments[1].timelineDuration, 0.2, accuracy: 0.000001)
    }
    func testNoOverlapAndSourceBeyondEndProduceNoAudio() throws {
        XCTAssertTrue(try VideoClipTiming(start: 5).audioSegments(sourceDuration: 2, audioStart: 0, audioEnd: 2, timelineDuration: 3).isEmpty)
        XCTAssertTrue(try VideoClipTiming(sourceIn: 3).audioSegments(sourceDuration: 2, audioStart: 0, audioEnd: 2, timelineDuration: 3).isEmpty)
    }
    func testInvalidSettingsRejectNonfiniteAndReversedTrim() {
        for timing in [VideoClipTiming(start: -.infinity), VideoClipTiming(sourceIn: -1), VideoClipTiming(sourceIn: 2, sourceOut: 1), VideoClipTiming(speed: 0), VideoClipTiming(volume: 2)] {
            XCTAssertThrowsError(try timing.validate())
        }
        XCTAssertThrowsError(try VideoClipTiming().audioSegments(sourceDuration: 2, audioStart: 0, audioEnd: 2, timelineDuration: 3, windowEnd: .nan))
    }
    func testMovieSettingsRoundTripAndLegacyValueDefaults() throws {
        let timing = VideoClipTiming(start: 3, sourceIn: 1, sourceOut: 2, speed: 0.5, loops: true, volume: 0.4, muted: true)
        let value = ProjectValue(kind: "video", resourceID: "movie", videoClip: timing, videoID: "clip")
        let restored = try JSONDecoder().decode(ProjectValue.self, from: JSONEncoder().encode(value))
        XCTAssertEqual(restored.videoClip, timing); XCTAssertEqual(restored.videoID, "clip")
        let legacy = try JSONDecoder().decode(ProjectValue.self, from: Data("{\"kind\":\"video\",\"resourceID\":\"movie\"}".utf8))
        XCTAssertNil(legacy.videoClip); XCTAssertNil(legacy.videoID)
    }
}

final class DownloadedAssetValidationTests: XCTestCase {
    func temporary(_ data: Data) throws -> URL {
        let file = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try data.write(to: file)
        addTeardownBlock { try? FileManager.default.removeItem(at: file) }
        return file
    }
    func glb() -> Data {
        var json = Data("{\"asset\":{\"version\":\"2.0\"}}".utf8)
        while json.count % 4 != 0 { json.append(32) }
        var result = Data("glTF".utf8)
        func append(_ value: UInt32) { var little = value.littleEndian; withUnsafeBytes(of: &little) { result.append(contentsOf: $0) } }
        append(2); append(UInt32(20 + json.count)); append(UInt32(json.count)); append(0x4E4F534A); result.append(json)
        return result
    }
    func testCompleteGLBAccepted() throws { let bytes = glb(); try DownloadedAssetValidation.validate(temporary(bytes), expectedBytes: Int64(bytes.count)) }
    func testTruncatedOrHTMLRejected() throws {
        XCTAssertThrowsError(try DownloadedAssetValidation.validate(temporary(Data(glb().dropLast()))))
        XCTAssertThrowsError(try DownloadedAssetValidation.validate(temporary(Data("<html>server error</html>".utf8))))
    }
    func testContentLengthAndBadJSONRejected() throws {
        let bytes = glb()
        XCTAssertThrowsError(try DownloadedAssetValidation.validate(temporary(bytes), expectedBytes: Int64(bytes.count + 1)))
        var corrupt = bytes; corrupt[20] = 0
        XCTAssertThrowsError(try DownloadedAssetValidation.validate(temporary(corrupt)))
    }
}
