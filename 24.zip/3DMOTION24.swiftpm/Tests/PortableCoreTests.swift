import Foundation
import XCTest
@testable import ProjectCore

final class PortableCoreTests: XCTestCase {
    func fixture(name: String = "Car") -> StudioPortablePackage {
        let bytes = Data("texture-bytes".utf8)
        let id = ProjectIntegrity.hash(bytes)
        var p = StudioPortablePackage(version: 2, name: name, scene: Data("scene-bytes".utf8),
            metadata: Data("metadata-bytes".utf8), environment: Data("environment".utf8),
            audio: ["sound.wav": Data("sound".utf8)], textures: nil,
            resources: [id: ProjectResource(kind: "image", fileExtension: "png", data: bytes)],
            materials: [:], bindings: [], particles: [])
        p.sceneEncoding = "scenekit-keyed-archive"
        p.seal()
        return p
    }

    func temporaryFolder() throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        addTeardownBlock { try? FileManager.default.removeItem(at: url) }
        return url
    }

    func testCompleteContainerRoundTrip() throws {
        let p = fixture()
        let restored = try ProjectFileStore.decode(ProjectFileStore.encode(p))
        XCTAssertEqual(restored.scene, p.scene)
        XCTAssertEqual(restored.metadata, p.metadata)
        XCTAssertEqual(restored.environment, p.environment)
        XCTAssertEqual(restored.audio, p.audio)
        XCTAssertEqual(restored.resources?.values.first?.data, p.resources?.values.first?.data)
    }

    func testSHA256KnownVector() {
        XCTAssertEqual(ProjectIntegrity.hash(Data("abc".utf8)), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
    }

    func testCorruptSceneRejected() {
        var p = fixture(); p.scene.append(0)
        XCTAssertThrowsError(try p.validate())
    }

    func testCorruptResourceRejected() {
        var p = fixture(); let id = p.resources!.keys.first!
        p.resources![id]!.data.append(0)
        XCTAssertThrowsError(try p.validate())
        p.seal() // Even a recomputed outer seal cannot disguise a mismatched resource ID.
        XCTAssertThrowsError(try p.validate())
    }

    func testResourceDescriptorTamperingRejected() {
        var p = fixture(); let id = p.resources!.keys.first!
        p.resources![id]!.fileExtension = "jpg"
        XCTAssertThrowsError(try p.validate())
    }

    func testMissingMaterialBindingRejected() {
        var p = fixture()
        p.bindings = [ProjectGeometryBinding(nodeID: "car", materialIDs: ["missing"], elementSignatures: [], texcoordSignatures: [])]
        p.seal()
        XCTAssertThrowsError(try p.validate())
    }

    func testMissingImageRejected() {
        let value = ProjectValue(kind: "image", resourceID: "missing")
        XCTAssertThrowsError(try value.validate(resources: [:]))
    }

    func testTraversalRejected() {
        var p = fixture(); p.audio["../escape.wav"] = Data([1]); p.seal()
        XCTAssertThrowsError(try p.validate())
        XCTAssertFalse(ProjectFileStore.safeComponent(".."))
        XCTAssertFalse(ProjectFileStore.safeComponent("dir\\file"))
    }

    func testRepeatedAtomicSavesKeepCompletePreviousGeneration() throws {
        let url = try temporaryFolder().appendingPathComponent("Car.3dmotion")
        for i in 0..<10 {
            let data = try ProjectFileStore.encode(fixture(name: "Car-\(i)"))
            try ProjectFileStore.commit(data, to: url)
            XCTAssertEqual(try ProjectFileStore.decode(Data(contentsOf: url)).name, "Car-\(i)")
            if i > 0 {
                XCTAssertEqual(try ProjectFileStore.decode(Data(contentsOf: ProjectFileStore.previous(url))).name, "Car-\(i-1)")
            }
        }
    }

    func testInvalidSavePreservesHealthyFile() throws {
        let url = try temporaryFolder().appendingPathComponent("Car.3dmotion")
        let original = try ProjectFileStore.encode(fixture())
        try ProjectFileStore.commit(original, to: url)
        var bad = fixture(); bad.metadata.append(1)
        XCTAssertThrowsError(try ProjectFileStore.commit(JSONEncoder().encode(bad), to: url))
        XCTAssertEqual(try Data(contentsOf: url), original)
    }

    func testBackupWriteFailurePreservesHealthyFile() throws {
        let url = try temporaryFolder().appendingPathComponent("Car.3dmotion")
        let original = try ProjectFileStore.encode(fixture())
        try ProjectFileStore.commit(original, to: url)
        try FileManager.default.createDirectory(at: ProjectFileStore.previous(url), withIntermediateDirectories: false)
        XCTAssertThrowsError(try ProjectFileStore.commit(ProjectFileStore.encode(fixture(name: "new")), to: url))
        XCTAssertEqual(try Data(contentsOf: url), original)
        let files = try FileManager.default.contentsOfDirectory(atPath: url.deletingLastPathComponent().path)
        XCTAssertFalse(files.contains { $0.hasSuffix(".pending") })
    }

    func testMoveDocumentAndRemoveOriginal() throws {
        let source = try temporaryFolder().appendingPathComponent("Car.3dmotion")
        let destination = try temporaryFolder().appendingPathComponent("Moved.3dmotion")
        let p = fixture()
        try ProjectFileStore.commit(ProjectFileStore.encode(p), to: source)
        try FileManager.default.moveItem(at: source, to: destination)
        let restored = try ProjectFileStore.decode(Data(contentsOf: destination))
        XCTAssertEqual(restored.resources?.values.first?.data, p.resources?.values.first?.data)
        XCTAssertFalse(FileManager.default.fileExists(atPath: source.path))
    }

    func testLegacyV1StillDecodes() throws {
        let p = StudioPortablePackage(version: 1, name: "old", scene: Data([1]), metadata: Data([2]), environment: nil, audio: [:], textures: nil)
        XCTAssertEqual(try ProjectFileStore.decode(JSONEncoder().encode(p)).version, 1)
    }

    func testUnknownVersionRejected() {
        var p = fixture(); p.version = 99
        XCTAssertThrowsError(try p.validate())
    }

    func testAnimationPlayerSettingsRoundTripAndTampering() throws {
        var p = fixture()
        p.animations = [ProjectAnimationBinding(nodeID: "car", key: "spin", archive: Data([1,2]),
            encoding: "scn-animation", speed: 0.5, blendFactor: 0.7, paused: true)]
        p.seal()
        let restored = try ProjectFileStore.decode(ProjectFileStore.encode(p))
        XCTAssertEqual(restored.animations?.first?.speed, 0.5)
        XCTAssertEqual(restored.animations?.first?.blendFactor, 0.7)
        XCTAssertEqual(restored.animations?.first?.paused, true)
        p.animations![0].speed = 2
        XCTAssertThrowsError(try p.validate())
    }

    func testInvalidAnimationEncodingAndBlendRejected() {
        var p = fixture()
        p.animations = [ProjectAnimationBinding(nodeID: "car", key: "spin", archive: Data([1]), encoding: "unknown")]
        p.seal(); XCTAssertThrowsError(try p.validate())
        p.animations![0].encoding = "scn-animation"; p.animations![0].blendFactor = 2
        p.seal(); XCTAssertThrowsError(try p.validate())
    }

    func testLegacyAnimationBindingWithOmittedSettingsStillDecodes() throws {
        var p = fixture()
        p.animations = [ProjectAnimationBinding(nodeID: "car", key: "spin", archive: Data([1]))]
        p.seal()
        let encoded = try ProjectFileStore.encode(p)
        XCTAssertFalse(String(decoding: encoded, as: UTF8.self).contains("blendFactor"))
        XCTAssertNil(try ProjectFileStore.decode(encoded).animations?.first?.encoding)
    }
}
