import XCTest
import SceneKit
import UIKit
import AVFoundation
import CoreMedia
import QuartzCore
@testable import MotionApp

@MainActor
extension ScenePersistenceTests {
    func audibleMovieFixture() async throws -> URL {
        let picture = try await movieFixture()
        let tone = root.appendingPathComponent(UUID().uuidString + ".wav")
        do {
            let file = try AVAudioFile(forWriting: tone, settings: [AVFormatIDKey: kAudioFormatLinearPCM,
                AVSampleRateKey: 48_000, AVNumberOfChannelsKey: 1, AVLinearPCMBitDepthKey: 16])
            let buffer = try XCTUnwrap(AVAudioPCMBuffer(pcmFormat: file.processingFormat, frameCapacity: 72_000))
            buffer.frameLength = 72_000
            let channel = try XCTUnwrap(buffer.floatChannelData?[0])
            for index in 0..<72_000 { channel[index] = Float(sin(Double(index) * 660 * 2 * .pi / 48_000) * 0.2) }
            try file.write(from: buffer)
        }
        let movie = root.appendingPathComponent(UUID().uuidString + ".mp4")
        let folder = root.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let clip = StudioAudioClip(name: "Reference tone", url: tone, sourceDuration: 1.5)
        let combined = try await VideoAudioMixer.combine(video: picture, output: movie, clips: [clip], masterVolume: 1, duration: 1.5, folder: folder)
        XCTAssertTrue(combined)
        return movie
    }

    func meanAudio(_ samples: [Float], at time: Double) throws -> Double {
        let first = Int(time * 48_000) * 2, last = first + 480 * 2
        guard first >= 0, last <= samples.count else { throw ProjectFailure.invalid("audio window at \(time), count \(samples.count)") }
        return samples[first..<last].reduce(0) { $0 + Double(abs($1)) } / Double(last - first)
    }

    func testImportedMovieAudioExportsOnceWithMasterVolume() async throws {
        try prepareVideoScene()
        let movie = try await audibleMovieFixture()
        let node = try await store.importVideoFile(movie)
        let player = try XCTUnwrap(node.geometry?.firstMaterial?.diffuse.contents as? StudioMoviePlayer)
        // Two material channels reference one player: the sound must occur once.
        node.geometry?.firstMaterial?.emission.contents = player
        store.setMasterAudioVolume(0.5)
        let result = try await store.renderProjectVideo(resolution: .p720, exportFPS: 30)
        defer { try? FileManager.default.removeItem(at: result.url) }
        XCTAssertTrue(result.hasAudio)
        let output = try await audioSamples(result.url), original = try await audioSamples(movie)
        let ratio = try meanAudio(output, at: 0.4) / meanAudio(original, at: 0.4)
        XCTAssertEqual(ratio, 0.5, accuracy: 0.06, "Movie missing or shared channels doubled its volume")
        let frames = try await decodedVideoFrames(result.url)
        XCTAssertEqual(frames.0, result.options.frameCount)
        XCTAssertTrue(node.geometry?.firstMaterial?.diffuse.contents as? AVPlayer === player)
        print("IMPORTED_AUDIO_PASS actual MP4 PCM; one shared player; master ratio=\(ratio)")
    }

    func testImportedMovieTrimDelaySpeedLoopAndSeparateAudioMix() async throws {
        try prepareVideoScene()
        let movie = try await audibleMovieFixture(), node = try await store.importVideoFile(movie)
        let player = try XCTUnwrap(node.geometry?.firstMaterial?.diffuse.contents as? StudioMoviePlayer)
        store.updateMovieClip(player) { $0.start = 0.2; $0.sourceIn = 0.3; $0.sourceOut = 0.8; $0.speed = 2; $0.loops = true; $0.volume = 0.5 }
        store.setMasterAudioVolume(0.5); store.setProjectDuration(1)
        let first = try await store.renderProjectVideo(resolution: .p720, exportFPS: 30)
        defer { try? FileManager.default.removeItem(at: first.url) }
        let samples = try await audioSamples(first.url)
        XCTAssertLessThan(try meanAudio(samples, at: 0.05), 0.004)
        XCTAssertGreaterThan(try meanAudio(samples, at: 0.3), 0.012)
        XCTAssertEqual(try meanAudio(samples, at: 0.3), try meanAudio(samples, at: 0.8), accuracy: 0.007)
        // A late independent timeline track remains mixed with the movie sound.
        let asset = try audioAsset(duration: 1); store.addAudioAssetToTimeline(asset.id)
        XCTAssertTrue(store.editAudioClip(store.audioClips[0].id, startTime: 0.5, sourceStart: 0.2, sourceEnd: 0.6, volume: 0.5, loops: false))
        let second = try await store.renderProjectVideo(resolution: .p720, exportFPS: 30)
        defer { try? FileManager.default.removeItem(at: second.url) }
        let mixed = try await audioSamples(second.url)
        XCTAssertGreaterThan(try meanAudio(mixed, at: 0.7), try meanAudio(samples, at: 0.7) * 1.4)
        let encodedDuration = try await AVURLAsset(url: second.url).load(.duration)
        XCTAssertEqual(CMTimeGetSeconds(encodedDuration), 1, accuracy: 0.001)
        print("IMPORTED_AUDIO_PASS delay/trim/2x/loop/volume and independent timeline audio; PCM measured")
    }

    func testMutedAndHiddenMoviesDoNotProduceExportAudio() async throws {
        try prepareVideoScene()
        let node = try await store.importVideoFile(audibleMovieFixture())
        let player = try XCTUnwrap(node.geometry?.firstMaterial?.diffuse.contents as? StudioMoviePlayer)
        player.isMuted = true
        for hidden in [false, true] {
            node.isHidden = hidden; player.isMuted = !hidden
            let result = try await store.renderProjectVideo(resolution: .p720, exportFPS: 30)
            defer { try? FileManager.default.removeItem(at: result.url) }
            XCTAssertFalse(result.hasAudio)
            let audioTracks = try await AVURLAsset(url: result.url).loadTracks(withMediaType: .audio)
            XCTAssertTrue(audioTracks.isEmpty)
        }
    }

    func testMovieClipSettingsSurviveTransferAndUndoRedo() async throws {
        try prepareStore()
        let movie = try await audibleMovieFixture(), node = try await store.importVideoFile(movie)
        let player = try XCTUnwrap(node.geometry?.firstMaterial?.diffuse.contents as? StudioMoviePlayer)
        store.updateMovieClip(player) { $0.start = 2; $0.sourceIn = 0.2; $0.sourceOut = 0.8; $0.speed = 0.5; $0.loops = true; $0.volume = 0.3; $0.muted = true }
        let expected = player.authoredMovieTiming
        store.undoLast(); XCTAssertEqual(try XCTUnwrap(store.sceneVideoPlayers().first).authoredMovieTiming.start, 0)
        store.redoLast(); XCTAssertEqual(try XCTUnwrap(store.sceneVideoPlayers().first).authoredMovieTiming, expected)
        let data = try projectData(), originalResource = try XCTUnwrap(store.sceneVideoPlayers().first?.currentItem?.asset as? AVURLAsset)
        try FileManager.default.removeItem(at: movie)
        try FileManager.default.removeItem(at: originalResource.url)
        let restored = try decoded(data)
        let restoredNode = try XCTUnwrap(restored.scene.rootNode.childNode(withName: node.name!, recursively: true))
        let restoredPlayer = try XCTUnwrap(restoredNode.geometry?.firstMaterial?.diffuse.contents as? StudioMoviePlayer)
        XCTAssertEqual(restoredPlayer.authoredMovieTiming, expected)
        XCTAssertTrue(FileManager.default.fileExists(atPath: try XCTUnwrap(restoredPlayer.currentItem?.asset as? AVURLAsset).url.path))
    }

    func testAnimationLayerEditsUndoRedoRestoreIndependentPlayerState() throws {
        try prepareStore(); let node = mesh("Animated")
        let animation = CABasicAnimation(keyPath: "position.x"); animation.fromValue = 0; animation.toValue = 1; animation.duration = 1
        let key = store.addAnimationLayer(animation, to: node, name: "Motion")
        store.undoLast(); XCTAssertTrue(store.animationLayers.isEmpty)
        store.redoLast(); XCTAssertEqual(store.animationLayers.count, 1)
        func current() throws -> SCNNode { try XCTUnwrap(store.contentRoot.childNode(withName: "Animated", recursively: true)) }
        store.setAnimationLayerWeight(0.4, key: key, on: try current())
        store.undoLast(); XCTAssertEqual(try current().animationPlayer(forKey: key)?.blendFactor, 1)
        store.redoLast(); XCTAssertEqual(try current().animationPlayer(forKey: key)?.blendFactor ?? -1, 0.4, accuracy: 0.0001)
        store.setAnimationLayerSpeed(2, key: key, on: try current())
        store.undoLast(); XCTAssertEqual(try current().animationPlayer(forKey: key)?.speed, 1)
        store.redoLast(); XCTAssertEqual(try current().animationPlayer(forKey: key)?.speed, 2)
        store.pauseAnimationLayer(key, on: try current()); store.undoLast()
        XCTAssertEqual(try current().animationPlayer(forKey: key)?.paused, false)
        store.redoLast(); XCTAssertEqual(try current().animationPlayer(forKey: key)?.paused, true)
        store.removeAnimationLayer(key, from: try current()); XCTAssertTrue(store.animationLayers.isEmpty)
        store.undoLast(); XCTAssertNotNil(try current().animationPlayer(forKey: key)); XCTAssertEqual(store.animationLayers.count, 1)
        store.redoLast(); XCTAssertNil(try current().animationPlayer(forKey: key))
    }

    func testProjectSwitchFailureKeepsWorkspaceAndAutosave() throws {
        try prepareStore(); let node = mesh("Unsaved")
        XCTAssertTrue(store.saveNamedProject("Safe"))
        let original = try Data(contentsOf: store.autosaveProjectURL)
        node.geometry?.firstMaterial?.diffuse.contents = root.appendingPathComponent("missing.png")
        XCTAssertFalse(store.performProjectSwitch(.new("Other"), savingCurrent: true))
        XCTAssertTrue(node.parent === store.contentRoot)
        XCTAssertEqual(store.currentProjectName, "Safe")
        XCTAssertEqual(try Data(contentsOf: store.autosaveProjectURL), original)
        XCTAssertFalse(store.projectErrorDetails.isEmpty)
        XCTAssertTrue(store.performProjectSwitch(.new("Other"), savingCurrent: false))
        XCTAssertEqual(store.currentProjectName, "Other")
    }

    func testSameNameSaveAsAndImportedProjectNeverReplaceExistingIdentity() throws {
        try prepareStore(); _ = mesh("Original")
        XCTAssertTrue(store.saveNamedProject("Same"))
        let firstID = try XCTUnwrap(store.currentProjectLibraryID), file = store.projectFolder(id: firstID).appendingPathComponent("Project.3dmotion")
        let original = try Data(contentsOf: file)
        let duplicate = try projectData()
        XCTAssertTrue(store.saveNamedProject("Same", saveAs: true))
        XCTAssertNotEqual(store.currentProjectLibraryID, firstID)
        XCTAssertEqual(try Data(contentsOf: file), original)
        try store.importPortableProject(duplicate)
        XCTAssertNotEqual(store.currentProjectLibraryID, firstID)
        XCTAssertEqual(try Data(contentsOf: file), original)
        let recovered = StudioStore(projectStorageURL: root, restoreSavedProject: true, startTimer: false)
        XCTAssertEqual(recovered.currentProjectLibraryID, store.currentProjectLibraryID)
        XCTAssertEqual(store.projectCards().filter { $0.name == "Same" }.count, 3)
    }

    func testProjectRenameDuplicateAndDeleteErrorsPreserveOtherProjects() throws {
        try prepareStore(); _ = mesh("Project")
        XCTAssertTrue(store.saveNamedProject("Old"))
        let card = try XCTUnwrap(store.projectCards().first { $0.id == store.currentProjectLibraryID })
        XCTAssertTrue(store.renameProject(card, to: "New"))
        XCTAssertEqual(store.projectCards().first { $0.id == card.id }?.name, "New")
        XCTAssertTrue(store.duplicateProject(card))
        XCTAssertEqual(store.projectCards().filter { $0.id != "autosave://last" }.count, 2)
        let invalid = StudioStore.ProjectCard(id: "../escape", name: "bad", modified: Date(), size: 0)
        XCTAssertFalse(store.deleteProject(invalid)); XCTAssertFalse(store.projectErrorDetails.isEmpty)
        XCTAssertTrue(store.deleteProject(card))
        XCTAssertNil(store.projectCards().first { $0.id == card.id })
        XCTAssertEqual(store.projectCards().filter { $0.id != "autosave://last" }.count, 1)
        let deleted = try XCTUnwrap(store.deletedProjectCards().first)
        XCTAssertTrue(store.restoreDeletedProject(deleted))
        XCTAssertTrue(store.deletedProjectCards().isEmpty)
        XCTAssertEqual(store.projectCards().filter { $0.id != "autosave://last" }.count, 2)
    }

    func testFlipNormalsReversesWindingWithoutChangingVerticesOrMaterials() throws {
        try prepareStore()
        let vertices = [SCNVector3(0,0,0), SCNVector3(1,0,0), SCNVector3(0,1,0)]
        let geometry = SCNGeometry(sources: [SCNGeometrySource(vertices: vertices), SCNGeometrySource(normals: [SCNVector3](repeating: SCNVector3(0,0,1), count: 3))],
            elements: [SCNGeometryElement(indices: [UInt16(0),1,2], primitiveType: .triangles)])
        let material = SCNMaterial(); geometry.materials = [material]
        let node = SCNNode(geometry: geometry); store.contentRoot.addChildNode(node); store.select(node)
        let vertexData = geometry.sources(for: .vertex)[0].data
        store.flipSelectedNormals()
        let flipped = try XCTUnwrap(node.geometry)
        XCTAssertEqual(flipped.sources(for: .vertex)[0].data, vertexData)
        XCTAssertTrue(flipped.materials[0] === material); XCTAssertFalse(material.isDoubleSided)
        XCTAssertEqual(flipped.elements[0].data, Data([1,0,0,0,2,0]))
        XCTAssertEqual(flipped.sources(for: .normal)[0].data[11] & 0x80, 0x80)
        store.undoLast()
        XCTAssertEqual(store.contentRoot.childNodes.first?.geometry?.elements.first?.data, geometry.elements[0].data)
    }
}
