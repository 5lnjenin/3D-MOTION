#!/usr/bin/env python3
"""Check icon metadata and resource layout configuration for iOS signing.

Validates metadata, pixel sizes, opaque RGB PNG encoding, chunk checksums and
ordinary file permissions. It cannot validate actool output or code signing.
"""
from decimal import Decimal
from pathlib import Path
import json
import struct
import zlib

root = Path(__file__).resolve().parent.parent
folder = root / "Assets.xcassets/AppIcon.appiconset"
catalog = json.loads((folder / "Contents.json").read_text())
required = {
    ("iphone", "20x20", "2x"), ("iphone", "20x20", "3x"),
    ("iphone", "29x29", "2x"), ("iphone", "29x29", "3x"),
    ("iphone", "40x40", "2x"), ("iphone", "40x40", "3x"),
    ("iphone", "60x60", "2x"), ("iphone", "60x60", "3x"),
    ("ipad", "20x20", "1x"), ("ipad", "20x20", "2x"),
    ("ipad", "29x29", "1x"), ("ipad", "29x29", "2x"),
    ("ipad", "40x40", "1x"), ("ipad", "40x40", "2x"),
    ("ipad", "76x76", "2x"),
    ("ipad", "83.5x83.5", "2x"), ("ios-marketing", "1024x1024", "1x"),
}
seen = set()
for entry in catalog["images"]:
    slot = (entry["idiom"], entry["size"], entry["scale"])
    assert slot not in seen, "Duplicate slot: " + repr(slot)
    seen.add(slot)
    name = entry["filename"]
    assert Path(name).name == name, "Unexpected icon path"
    path = folder / name
    assert not path.is_symlink() and not path.stat().st_mode & 0o111
    assert path.stat().st_mode & 0o444 == 0o444
    data = path.read_bytes()
    assert data[:8] == b"\x89PNG\r\n\x1a\n", "Invalid PNG signature"
    offset = 8
    chunks = []
    while offset < len(data):
        length = struct.unpack(">I", data[offset:offset + 4])[0]
        tag = data[offset + 4:offset + 8]
        payload = data[offset + 8:offset + 8 + length]
        crc = struct.unpack(">I", data[offset + 8 + length:offset + 12 + length])[0]
        assert len(payload) == length and zlib.crc32(tag + payload) & 0xffffffff == crc
        chunks.append((tag, payload))
        offset += length + 12
    assert offset == len(data) and chunks[0][0] == b"IHDR" and chunks[-1] == (b"IEND", b"")
    assert all(tag != b"tRNS" for tag, _ in chunks), "Transparency chunk found"
    width, height, depth, color, compression, filtering, interlacing = struct.unpack(">IIBBBBB", chunks[0][1])
    point_width, point_height = map(Decimal, entry["size"].split("x"))
    scale = Decimal(entry["scale"].removesuffix("x"))
    assert (width, height) == (int(point_width * scale), int(point_height * scale))
    assert (depth, color, compression, filtering, interlacing) == (8, 2, 0, 0, 0), "Expected standard 8-bit RGB PNG"
    raw = zlib.decompress(b"".join(payload for tag, payload in chunks if tag == b"IDAT"))
    assert len(raw) == height * (1 + width * 3), "Unexpected PNG scanline size"
    assert all(raw[row * (1 + width * 3)] in range(5) for row in range(height))
assert seen == required, "Incomplete or unexpected icon slots"
manifest = (root / "Package.swift").read_text()
assert 'appIcon: .asset("AppIcon")' in manifest
assert '.process("Assets.xcassets")' in manifest
assert '.process("Resources")' in manifest
assert '.copy("Resources")' not in manifest
print("PASS: original custom icon restored; app resources are processed rather than copied as a reserved Resources directory; all 17 icon slots have valid RGB PNGs and standard permissions.")
print("Apple asset compilation and device code signing were not run.")
