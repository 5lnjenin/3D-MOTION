import XCTest
import UIKit
import SceneKit
import SwiftUI
import Metal
@testable import MotionApp

@MainActor
extension ScenePersistenceTests {
    func richMaterialNode(_ name: String = "Material audit") -> SCNNode {
        let node = mesh(name)
        let m = node.geometry!.materials[0]
        for (index, entry) in ProjectSceneCodec.properties(m).enumerated() {
            entry.1.contents = image(UIColor(red: CGFloat(index+1)/15, green: 0.6, blue: 0.8, alpha: 1))
            entry.1.intensity = CGFloat(0.5 + Double(index)/30)
            entry.1.wrapS = .mirror; entry.1.wrapT = .repeat; entry.1.mappingChannel = 1
            entry.1.contentsTransform = SCNMatrix4MakeScale(1.7, 0.8, 1)
            entry.1.minificationFilter = .nearest; entry.1.maxAnisotropy = 4
        }
        m.specular.intensity = 0.73; m.shininess = 0.61
        m.lightingModel = .physicallyBased; m.isDoubleSided = false
        store.select(node)
        return node
    }
    func materialSignature(_ material: SCNMaterial) throws -> Data {
        var resources: [String: ProjectResource] = [:]
        let record = try ProjectSceneCodec.captureMaterial(store.authoredMaterialCopy(material), resources: &resources)
        let encoder = JSONEncoder(); encoder.outputFormatting = .sortedKeys
        return try encoder.encode(record.properties)
    }
    func onlyMaterial(_ name: String = "Material audit") throws -> SCNMaterial {
        try XCTUnwrap(store.contentRoot.childNode(withName: name, recursively: true)?.geometry?.materials.first)
    }
    func auditKey(_ node: SCNNode, time: Double, state: MaterialKeyframeState? = nil) -> StudioKeyframe {
        StudioKeyframe(nodeID: store.animationIdentity(node), nodeName: node.name!, time: time, position: SCNVector3(Float(time),0,0), euler: .init(), scale: .init(1,1,1), trackID: "audit", interpolation: .linear, materialStates: [state ?? MaterialKeyframeState(node.geometry!.materials[0])])
    }
    func testMaterialInspectorReadAndSelectionDoNotWriteAnyMapInAllModes() async throws {
        try prepareStore()
        let a = richMaterialNode("same"), b = richMaterialNode("same")
        let scene = try XCTUnwrap(UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first)
        let old = scene.windows.first(where: \.isKeyWindow), window = UIWindow(windowScene: scene)
        window.frame = CGRect(x: 0,y: 0,width: 500,height: 1000)
        let host = UIHostingController(rootView: ScrollView { MaterialInspector().environmentObject(store) })
        var writes = 0
        let observers = [a,b].flatMap { $0.geometry!.materials }.flatMap { ProjectSceneCodec.properties($0).map { $0.1.observe(\.contents, options: [.new]) { _, _ in writes += 1 } } }
        defer { withExtendedLifetime(observers) {}; window.isHidden = true; window.rootViewController = nil; old?.makeKey() }
        for mode in ViewportShadingMode.allCases {
            store.viewportShadingMode = mode; store.applyViewportSettings(updateProjectLights: false)
            window.rootViewController = host; window.makeKeyAndVisible(); host.view.layoutIfNeeded()
            for selected in [a,b,a] { store.select(selected); try await Task.sleep(nanoseconds: 120_000_000) }
        }
        XCTAssertEqual(writes, 0, "Displaying or loading controls must never mutate a map")
        print("MATERIAL_AUDIT_UI_PASS all shading modes, same-name selection switches, zero map writes")
    }
    func testMappedMaterialControlsKeepAllThirteenProvidersAndSamplers() throws {
        try prepareStore(); let node = richMaterialNode(); let material = node.geometry!.materials[0]
        let original = ProjectSceneCodec.properties(material).map { $0.1.contents as? UIImage }
        let transform = material.normal.contentsTransform
        for mode in ViewportShadingMode.allCases {
            store.viewportShadingMode = mode; store.applyViewportSettings(updateProjectLights: false)
            store.setMaterialColor(.red); store.setMetalness(0.31); store.setRoughness(0.62)
            store.setEmissionColor(.green); store.setEmissionStrength(2); store.setMaterialOpacity(0.7)
            for (index, entry) in ProjectSceneCodec.properties(material).enumerated() {
                XCTAssertTrue(entry.1.contents as? UIImage === original[index], entry.0)
                XCTAssertEqual(entry.1.mappingChannel, 1); XCTAssertEqual(entry.1.maxAnisotropy, 4)
            }
            XCTAssertEqual(material.normal.contentsTransform.m11, transform.m11)
            XCTAssertEqual(material.metalness.intensity, 0.31, accuracy: 1e-6); XCTAssertEqual(material.roughness.intensity, 0.62, accuracy: 1e-6)
        }
        print("MATERIAL_AUDIT_CONTROLS_PASS 13 providers, tint, mapped PBR factors, emission, opacity and UV")
    }
    func testPresetUndoAndOriginalRestoreRecoverAllMapsAndUV() throws {
        try prepareStore(); _ = richMaterialNode(); let original = try materialSignature(onlyMaterial())
        for preset in [StudioStore.ReadyMaterialPreset.glass, .neonBlue, .matte, .water] {
            store.applyReadyMaterial(preset); store.undoLast()
            XCTAssertEqual(try materialSignature(onlyMaterial()), original, preset.rawValue)
            store.redoLast(); store.undoLast()
            store.select(store.contentRoot.childNode(withName: "Material audit", recursively: true))
        }
        store.setUVTransform(scaleU: 3,scaleV: 2,offsetU: 0.2,offsetV: 0.1,rotation: 0.4)
        store.resetSelectedMaterialToOriginal()
        XCTAssertEqual(try materialSignature(onlyMaterial()), original)
        print("MATERIAL_AUDIT_RESET_PASS glass/neon/flat/water undo and complete original recovery")
    }
    func testUVEditUsesAllMappedChannelsAndUndoRedoPreservesContent() throws {
        try prepareStore(); _ = richMaterialNode(); let before = try materialSignature(onlyMaterial())
        store.setUVTransform(scaleU: 2,scaleV: 3,offsetU: 0.1,offsetV: 0.2,rotation: 0.3)
        let edited = try onlyMaterial(); let after = try materialSignature(edited)
        for (_, property) in ProjectSceneCodec.properties(edited) { XCTAssertTrue(property.contents is UIImage); XCTAssertEqual(property.wrapS, .repeat); XCTAssertNotEqual(property.contentsTransform.m11, 1.7) }
        store.undoLast(); XCTAssertEqual(try materialSignature(onlyMaterial()), before)
        store.redoLast(); XCTAssertEqual(try materialSignature(onlyMaterial()), after)
    }
    func testLightweightHistoryCloneOwnsMaterialsAndRetainsInternalGeometryLinks() throws {
        try prepareStore(); let a = richMaterialNode("A"), b = SCNNode(geometry: a.geometry); b.name = "B"; store.contentRoot.addChildNode(b)
        let snapshot = store.cleanDeepClone(store.contentRoot, copyGeometry: false)
        let ca = try XCTUnwrap(snapshot.childNode(withName: "A", recursively: true)), cb = try XCTUnwrap(snapshot.childNode(withName: "B", recursively: true))
        XCTAssertTrue(ca.geometry === cb.geometry); XCTAssertTrue(ca.geometry !== a.geometry)
        let old = try materialSignature(ca.geometry!.materials[0])
        a.geometry!.materials[0].normal.contents = UIColor.red; a.geometry!.materials[0].diffuse.contentsTransform = SCNMatrix4Identity
        XCTAssertEqual(try materialSignature(ca.geometry!.materials[0]), old)
        print("MATERIAL_AUDIT_HISTORY_PASS lightweight snapshots never share mutable material state with live objects")
    }
    func testMaterialUndoAfterSceneUndoTargetsRecreatedLiveMaterial() throws {
        try prepareStore(); let n = richMaterialNode(); let before = try materialSignature(onlyMaterial())
        store.setRoughness(0.2); let first = try materialSignature(onlyMaterial())
        store.pushUndoSnapshot("Hierarchy edit"); n.position.x = 2
        store.setMetalness(0.4); store.undoLast(); XCTAssertEqual(try materialSignature(onlyMaterial()), first)
        store.undoLast(); XCTAssertEqual(try materialSignature(onlyMaterial()), first)
        store.undoLast(); XCTAssertEqual(try materialSignature(onlyMaterial()), before)
        store.redoLast(); XCTAssertEqual(try materialSignature(onlyMaterial()), first)
        print("MATERIAL_AUDIT_MIXED_UNDO_PASS stable node/slot bindings through scene replacement")
    }
    func testMaterialEditCoalescingNeverCombinesDifferentObjects() throws {
        try prepareStore(); let a = richMaterialNode("A"), b = richMaterialNode("B")
        store.select(a); store.setRoughness(0.2); store.select(b); store.setRoughness(0.8)
        XCTAssertEqual(store.materialUndoStack.count, 2)
        store.undoLast(); XCTAssertEqual(a.geometry!.materials[0].roughness.intensity, 0.2, accuracy: 1e-6)
        XCTAssertNotEqual(b.geometry!.materials[0].roughness.intensity, 0.8)
    }
    func testStaticTransformKeysDoNotRestoreOldMapsAfterNewPreset() throws {
        try prepareStore(); let n = richMaterialNode()
        store.keyframes = [auditKey(n,time: 0), auditKey(n,time: 1)]
        store.applyWorkshopMaterial(.fiberglass)
        let signature = try materialSignature(n.geometry!.materials[0])
        for t in [0.0, 0.2, 0.8, 1.0] { store.seek(to: t); XCTAssertEqual(try materialSignature(n.geometry!.materials[0]), signature) }
        let data = try projectData(); try store.importPortableProject(data)
        store.seek(to: 0.5); XCTAssertEqual(try materialSignature(onlyMaterial()), signature)
        print("MATERIAL_AUDIT_TIMELINE_PASS position-only keys, replacement maps, seek and portable reopen")
    }
    func testGenuineColorAndMappedFactorAnimationStillInterpolates() throws {
        try prepareStore(); let n = richMaterialNode(); let m = n.geometry!.materials[0]
        m.diffuse.contents = UIColor.red; var first = MaterialKeyframeState(m)
        m.diffuse.contents = UIColor.blue; var last = MaterialKeyframeState(m)
        first.propertyFactors?["roughness"] = 0.2; last.propertyFactors?["roughness"] = 0.8
        store.keyframes = [auditKey(n,time: 0,state: first), auditKey(n,time: 1,state: last)]
        store.seek(to: 0.5)
        let color = try XCTUnwrap(m.diffuse.contents as? UIColor); var r:CGFloat=0,g:CGFloat=0,b:CGFloat=0,a:CGFloat=0
        color.getRed(&r,green:&g,blue:&b,alpha:&a); XCTAssertEqual(r,0.5,accuracy:1e-5); XCTAssertEqual(b,0.5,accuracy:1e-5)
        XCTAssertTrue(m.roughness.contents is UIImage); XCTAssertEqual(m.roughness.intensity,0.5,accuracy:1e-5)
        store.setMetalness(0.4); store.seek(to: 0); XCTAssertEqual(m.diffuse.contents as? UIColor, UIColor.red)
        let data = try projectData(); try store.importPortableProject(data); store.seek(to:0.5)
        XCTAssertEqual(try onlyMaterial().roughness.intensity,0.5,accuracy:1e-5)
    }
    func testIdenticalTextureKeyframesNeverRebindMapsDuringSeek() throws {
        try prepareStore(); let n = richMaterialNode(); let m = n.geometry!.materials[0]
        store.keyframes = [auditKey(n,time:0),auditKey(n,time:1)]
        var writes = 0
        let observers = ProjectSceneCodec.properties(m).map { $0.1.observe(\.contents, options:[.new]) { _,_ in writes += 1 } }
        for step in 0...40 { store.seek(to:Double(step)/40) }
        withExtendedLifetime(observers) {}
        XCTAssertEqual(writes,0)
    }
    func testDuplicateInEveryViewportModePreservesAuthoredMaterialOnSaveAndUndo() throws {
        for mode in ViewportShadingMode.allCases {
            try prepareStore(); let original = richMaterialNode("Source")
            let before = try materialSignature(original.geometry!.materials[0])
            store.viewportShadingMode = mode; store.applyViewportSettings(updateProjectLights:false)
            store.duplicateSelectedObjects()
            let duplicate = try XCTUnwrap(store.selectedNode); XCTAssertTrue(duplicate !== original)
            XCTAssertEqual(try materialSignature(duplicate.geometry!.materials[0]),before)
            let data=try projectData(); try store.importPortableProject(data)
            for node in store.contentRoot.childNodes where node.geometry != nil { XCTAssertEqual(try materialSignature(node.geometry!.materials[0]),before) }
        }
        print("MATERIAL_AUDIT_DUPLICATE_PASS all modes, author shading, samplers and portable save")
    }
    func testMixedEnvironmentEditCyclesKeepEveryMapThroughUndoAndReopen() throws {
        try prepareStore(); _ = richMaterialNode(); let before = try materialSignature(onlyMaterial())
        for pass in 0..<5 {
            store.setEnvironmentPreset([.day,.night,.sunset,.overcast,.none][pass]); store.setViewportBackground(pass)
            store.showGrid.toggle(); store.rebuildHelpers(); store.applySceneSettings()
            store.viewportShadingMode = ViewportShadingMode.allCases[pass % ViewportShadingMode.allCases.count]
            store.applyViewportSettings(updateProjectLights:false)
            XCTAssertEqual(try materialSignature(onlyMaterial()),before)
            let data=try projectData(); try store.importPortableProject(data)
            XCTAssertEqual(try materialSignature(onlyMaterial()),before)
        }
        print("MATERIAL_AUDIT_CYCLES_PASS sky, background, grid, fog, preview and five portable reopen cycles")
    }
    func testMappedTintShaderActuallyRendersAndSurvivesPortableOpen() throws {
        try prepareStore()
        let n=SCNNode(geometry:SCNPlane(width:3,height:3));n.name="Tint"
        let m=SCNMaterial();m.lightingModel = .constant;m.diffuse.contents=image(.white);m.multiply.contents=image(.white);n.geometry!.materials=[m]
        store.contentRoot.addChildNode(n);store.select(n);store.setMaterialColor(.red)
        let camera=SCNNode();camera.camera=SCNCamera();camera.position=SCNVector3(0,0,5);store.scene.rootNode.addChildNode(camera)
        func pixel(_ scene:SCNScene,_ camera:SCNNode) throws -> [UInt8] {
            let renderer=SCNRenderer(device:MTLCreateSystemDefaultDevice(),options:nil);renderer.scene=scene;renderer.pointOfView=camera
            scene.background.contents=UIColor.black
            let cg=try XCTUnwrap(renderer.snapshot(atTime:0,with:CGSize(width:96,height:96),antialiasingMode:.none).cgImage)
            var bytes=[UInt8](repeating:0,count:4)
            let context=try XCTUnwrap(CGContext(data:&bytes,width:1,height:1,bitsPerComponent:8,bytesPerRow:4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue|CGBitmapInfo.byteOrder32Big.rawValue))
            let crop=try XCTUnwrap(cg.cropping(to:CGRect(x:48,y:48,width:1,height:1)));context.draw(crop,in:CGRect(x:0,y:0,width:1,height:1));return bytes
        }
        store.editorRoot.isHidden=true;store.helpersRoot.isHidden=true;store.select(nil)
        let before=try pixel(store.scene,camera);XCTAssertGreaterThan(before[0],160);XCTAssertLessThan(before[1],50);XCTAssertLessThan(before[2],50)
        let data=try projectData();try store.importPortableProject(data)
        let reopened=try XCTUnwrap(store.contentRoot.childNode(withName:"Tint",recursively:true)?.geometry?.firstMaterial)
        XCTAssertEqual(MaterialEditingSafety.shaderFactors(reopened)[MaterialEditingSafety.tintKey],[1,0,0])
        XCTAssertTrue(reopened.diffuse.contents is UIImage);XCTAssertTrue(reopened.multiply.contents is UIImage)
        print("MATERIAL_AUDIT_SHADER_PASS real Metal pixels, both maps intact, persisted tint factor")
    }
    func testTextStylesKeepMappedChannelsExceptExplicitGradientAndUndoRestoresAll() throws {
        try prepareStore(); _ = richMaterialNode(); let original = try materialSignature(onlyMaterial())
        for style in StudioStore.TextMaterialStyle.allCases {
            let material = try onlyMaterial()
            store.recordMaterialEdit(label:"Text style",key:"text-style",materials:[material]) {
                store.applyTextMaterialStyle(style,to:material,color:.orange)
            }
            for (channel, property) in ProjectSceneCodec.properties(material) { XCTAssertTrue(property.contents is UIImage,channel) }
            store.undoLast(); XCTAssertEqual(try materialSignature(onlyMaterial()),original)
        }
        print("MATERIAL_AUDIT_TEXT_PASS text styles retain map channels and full material undo")
    }
    func testMeshEditAndPortableReopenKeepMaterialChannelsAndSlotAssignments() async throws {
        try prepareStore(); let n = richMaterialNode(); let signatures=try n.geometry!.materials.map(materialSignature)
        store.runWorkshop(.subdivide);try await waitForWorkshop()
        XCTAssertEqual(try n.geometry!.materials.map(materialSignature),signatures)
        store.undoLast();store.redoLast()
        let data=try projectData();try store.importPortableProject(data)
        let geometry=try XCTUnwrap(store.contentRoot.childNode(withName:"Material audit",recursively:true)?.geometry)
        XCTAssertEqual(try geometry.materials.map(materialSignature),signatures)
        XCTAssertEqual(Set(geometry.elements.indices.map {$0 % geometry.materials.count}),[0,1])
        print("MATERIAL_AUDIT_MESH_PASS subdivision, material slots, undo/redo, portable transfer")
    }
    func testVideoExportAndCancellationRestoreEveryMaterialChannelAndPreviewState() async throws {
        try prepareStore(); _ = richMaterialNode();let before=try materialSignature(onlyMaterial())
        store.setProjectDuration(2.0/24);store.viewportShadingMode = .lit;store.applyViewportSettings(updateProjectLights:false)
        let result=try await store.renderProjectVideo(resolution:.p720,exportFPS:24)
        defer {try? FileManager.default.removeItem(at:result.url)}
        XCTAssertEqual(try materialSignature(onlyMaterial()),before)
        XCTAssertEqual(try onlyMaterial().lightingModel,.blinn)
        store.setProjectDuration(10)
        let task=Task { @MainActor in try await store.renderProjectVideo(resolution:.p4K,exportFPS:144) }
        try await Task.sleep(nanoseconds:100_000_000);task.cancel()
        do {_ = try await task.value;XCTFail("cancelled export succeeded")} catch is CancellationError {}
        XCTAssertEqual(try materialSignature(onlyMaterial()),before)
        let data=try projectData();try store.importPortableProject(data)
        XCTAssertEqual(try materialSignature(onlyMaterial()),before)
        print("MATERIAL_AUDIT_EXPORT_PASS all13 channels, successful export, cancel and reopened editor state")
    }

    func testObjectWireAndDepthDisplaySurviveViewportTransitionsAndUndo() throws {
        try prepareStore(); _ = richMaterialNode();let before = try materialSignature(onlyMaterial())
        store.setSelectedWireframe(true);store.setSelectedDepthRead(false)
        for mode in ViewportShadingMode.allCases {
            store.viewportShadingMode=mode;store.applyViewportSettings(updateProjectLights:false)
            XCTAssertEqual(try materialSignature(onlyMaterial()),before)
        }
        let snapshot=try store.makePersistenceSceneSnapshot()
        let material=try XCTUnwrap(snapshot.rootNode.childNode(withName:"Material audit",recursively:true)?.geometry?.firstMaterial)
        XCTAssertEqual(material.fillMode,.lines);XCTAssertFalse(material.readsFromDepthBuffer)
        store.undoLast();store.undoLast();XCTAssertEqual(try materialSignature(onlyMaterial()),before)
        print("MATERIAL_AUDIT_DISPLAY_PASS object wire/depth flags, all viewport modes, snapshot and undo")
    }

}
