import XCTest
import SceneKit
import UIKit
import UniformTypeIdentifiers
import AVFoundation
@testable import MotionApp

@MainActor
final class ScenePersistenceTests: XCTestCase {
    var root: URL!
    var store: StudioStore!

    func testTechnicalBackendNamesDoNotReachProductMessages() throws {
        try prepareStore()
        store.toast = "Open failed: SceneKitErrorDomain / Model I/O / AVFoundation / CoreImage"
        let message = try XCTUnwrap(store.toast)
        for name in ["SceneKit", "Model I/O", "AVFoundation", "CoreImage"] { XCTAssertFalse(message.contains(name)) }
        XCTAssertTrue(message.contains("Open failed"))
    }

    func audioAsset(_ name: String = "Music", duration: Double = 4) throws -> StudioAudioAsset {
        let url = root.appendingPathComponent(UUID().uuidString + ".wav")
        let settings: [String: Any] = [AVFormatIDKey: kAudioFormatLinearPCM, AVSampleRateKey: 8_000,
            AVNumberOfChannelsKey: 1, AVLinearPCMBitDepthKey: 16, AVLinearPCMIsFloatKey: false,
            AVLinearPCMIsBigEndianKey: false]
        do {
            let file = try AVAudioFile(forWriting: url, settings: settings)
            let frames = AVAudioFrameCount(duration * 8_000)
            let buffer = try XCTUnwrap(AVAudioPCMBuffer(pcmFormat: file.processingFormat, frameCapacity: frames))
            buffer.frameLength = frames
            let channel = try XCTUnwrap(buffer.floatChannelData?[0])
            for index in 0..<Int(frames) { channel[index] = Float(index) / Float(frames) * 0.8 }
            try file.write(from: buffer)
        }
        let asset = StudioAudioAsset(name: name, url: url, duration: try AudioPreviewCache.duration(of: url))
        store.audioAssets.append(asset)
        return asset
    }

    func testTrimmedAudioPreviewContainsOnlyChosenSamplesAndPreservesSource() throws {
        try prepareStore()
        let asset = try audioAsset()
        store.addAudioAssetToTimeline(asset.id)
        let id = try XCTUnwrap(store.audioClips.first?.id)
        XCTAssertTrue(store.editAudioClip(id, startTime: 2, sourceStart: 1, sourceEnd: 2, volume: 0.4, loops: true))
        let clip = store.audioClips[0]
        let source = try Data(contentsOf: asset.url)
        let cache = root.appendingPathComponent("preview")
        let rendered = try AudioPreviewCache.render(clip, folder: cache)
        let file = try AVAudioFile(forReading: rendered)
        XCTAssertEqual(file.length, 8_000)
        let buffer = try XCTUnwrap(AVAudioPCMBuffer(pcmFormat: file.processingFormat, frameCapacity: 8_000))
        try file.read(into: buffer)
        let samples = try XCTUnwrap(buffer.floatChannelData?[0])
        XCTAssertEqual(samples[0], 0.2, accuracy: 0.001)
        XCTAssertEqual(samples[7_999], 0.4, accuracy: 0.001)
        let player = try AVAudioPlayer(contentsOf: rendered)
        XCTAssertEqual(player.duration, 1, accuracy: 0.001)
        XCTAssertEqual(try Data(contentsOf: asset.url), source)
        XCTAssertEqual(try AudioPreviewCache.render(clip, folder: cache), rendered)
    }

    func testAudioSplitPreservesSourceContinuityAndUndoRedo() throws {
        try prepareStore()
        let asset = try audioAsset()
        store.addAudioAssetToTimeline(asset.id)
        let id = store.audioClips[0].id
        XCTAssertTrue(store.editAudioClip(id, startTime: 2, sourceStart: 0.5, sourceEnd: 3.5, volume: 0.7, loops: false))
        XCTAssertTrue(store.splitAudioClip(id, at: 3.5))
        let left = store.audioClips[0], right = store.audioClips[1]
        XCTAssertNotEqual(left.id, right.id); XCTAssertEqual(left.trackID, right.trackID)
        XCTAssertEqual(left.endTime, right.startTime, accuracy: 0.0001)
        XCTAssertEqual(left.trimmedEnd, right.sourceStart, accuracy: 0.0001)
        XCTAssertEqual(left.trimmedDuration + right.trimmedDuration, 3, accuracy: 0.0001)
        store.undoLast(); XCTAssertEqual(store.audioClips.count, 1)
        XCTAssertEqual(store.audioClips[0].trimmedDuration, 3)
        store.redoLast(); XCTAssertEqual(store.audioClips.count, 2)
        XCTAssertEqual(store.audioClips[1].id, right.id)
    }

    func testAudioCopyCutPasteDuplicateShareOneOriginalFile() throws {
        try prepareStore()
        let asset = try audioAsset()
        store.addAudioAssetToTimeline(asset.id)
        let id = store.audioClips[0].id
        XCTAssertTrue(store.editAudioClip(id, startTime: 2, sourceStart: 1, sourceEnd: 3, volume: 0.6, loops: false))
        store.copyAudioClip(id); store.currentTime = 8; store.pasteAudioClip()
        XCTAssertEqual(store.audioAssets.count, 1)
        XCTAssertEqual(store.audioClips[1].sourceStart, 1); XCTAssertEqual(store.audioClips[1].startTime, 8)
        XCTAssertNotEqual(store.audioClips[1].id, id)
        store.duplicateAudioClip(id)
        XCTAssertEqual(store.audioClips.last?.startTime, 4)
        XCTAssertEqual(Set(store.audioClips.map(\.id)).count, 3)
        store.cutAudioClip(id); XCTAssertEqual(store.audioClips.count, 2)
        store.currentTime = 12; store.pasteAudioClip()
        XCTAssertEqual(store.audioClips.last?.startTime, 12)
        XCTAssertEqual(Set(store.audioClips.map { $0.url }).count, 1)
        XCTAssertEqual(try ProjectFileStore.decode(projectData()).audio.count, 1)
    }

    func testDeletingClipKeepsFileWhileDeletingFileRemovesAllClipsAndSupportsUndo() throws {
        try prepareStore()
        let asset = try audioAsset()
        store.addAudioAssetToTimeline(asset.id)
        store.removeAudioClip(store.audioClips[0].id)
        XCTAssertTrue(store.audioClips.isEmpty); XCTAssertEqual(store.audioAssets.count, 1)
        XCTAssertEqual(try ProjectFileStore.decode(projectData()).audio.count, 1)
        store.addAudioAssetToTimeline(asset.id); store.duplicateAudioClip(store.audioClips[0].id)
        store.removeAudioAsset(asset.id)
        XCTAssertTrue(store.audioClips.isEmpty); XCTAssertTrue(store.audioAssets.isEmpty)
        XCTAssertTrue(try ProjectFileStore.decode(projectData()).audio.isEmpty)
        XCTAssertTrue(FileManager.default.fileExists(atPath: asset.url.path))
        store.undoLast(); XCTAssertEqual(store.audioClips.count, 2); XCTAssertEqual(store.audioAssets.count, 1)
        store.redoLast(); XCTAssertTrue(store.audioClips.isEmpty); XCTAssertTrue(store.audioAssets.isEmpty)
    }

    func testTrimAudioLibraryAndMasterVolumeSurviveRelocationAndMissingSources() throws {
        try prepareStore(); _ = mesh("Car")
        let used = try audioAsset("Used"), unused = try audioAsset("Unused")
        store.addAudioAssetToTimeline(used.id)
        let id = store.audioClips[0].id, track = store.audioClips[0].trackID
        XCTAssertTrue(store.editAudioClip(id, startTime: 5, sourceStart: 0.75, sourceEnd: 2.25, volume: 0.8, loops: true))
        store.setMasterAudioVolume(0.3)
        let data = try projectData()
        try FileManager.default.removeItem(at: used.url); try FileManager.default.removeItem(at: unused.url)
        store.newProject(named: "Fresh")
        try store.importPortableProject(data)
        XCTAssertEqual(store.audioAssets.count, 2); XCTAssertEqual(store.audioClips.count, 1)
        XCTAssertEqual(store.audioClips[0].id, id); XCTAssertEqual(store.audioClips[0].trackID, track)
        XCTAssertEqual(store.audioClips[0].sourceStart, 0.75); XCTAssertEqual(store.audioClips[0].trimmedEnd, 2.25)
        XCTAssertEqual(store.audioClips[0].startTime, 5); XCTAssertTrue(store.audioClips[0].loops)
        XCTAssertEqual(store.masterAudioVolume, 0.3)
        XCTAssertTrue(FileManager.default.fileExists(atPath: store.audioClips[0].url.path))
        XCTAssertNotNil(store.contentRoot.childNode(withName: "Car", recursively: true))
    }

    func testLegacyAudioDocumentsMigrateToFileLibrary() throws {
        try prepareStore()
        let asset = try audioAsset(); store.addAudioAssetToTimeline(asset.id)
        var package = try ProjectFileStore.decode(projectData())
        var metadata = try JSONDecoder().decode(StudioAutosaveMetadata.self, from: package.metadata)
        metadata.audioAssets = nil; metadata.masterAudioVolume = nil
        metadata.audioClips?[0].id = nil; metadata.audioClips?[0].assetID = nil; metadata.audioClips?[0].trackID = nil
        metadata.audioClips?[0].sourceStart = nil; metadata.audioClips?[0].sourceEnd = nil
        package.metadata = try JSONEncoder().encode(metadata); package.seal()
        let prepared = try store.prepareProject(package)
        defer { try? FileManager.default.removeItem(at: prepared.runtimeFolder) }
        XCTAssertEqual(prepared.audioAssets.count, 1)
        XCTAssertEqual(prepared.audio[0].assetID, prepared.audioAssets[0].id)
        XCTAssertEqual(prepared.audio[0].trimmedDuration, 4)
    }

    func testInvalidAudioTrimAndTamperedBindingsKeepHealthyWorkspace() throws {
        try prepareStore()
        let asset = try audioAsset(); store.addAudioAssetToTimeline(asset.id)
        let id = store.audioClips[0].id
        XCTAssertFalse(store.editAudioClip(id, startTime: 0, sourceStart: 3, sourceEnd: 2, volume: 1, loops: false))
        XCTAssertFalse(store.editAudioClip(id, startTime: .nan, sourceStart: 0, sourceEnd: 4, volume: 1, loops: false))
        XCTAssertEqual(store.audioClips[0].trimmedDuration, 4)
        var package = try ProjectFileStore.decode(projectData())
        var metadata = try JSONDecoder().decode(StudioAutosaveMetadata.self, from: package.metadata)
        metadata.audioClips?[0].assetID = UUID()
        package.metadata = try JSONEncoder().encode(metadata); package.seal()
        XCTAssertThrowsError(try store.importPortableProject(JSONEncoder().encode(package)))
        XCTAssertEqual(store.audioClips[0].id, id); XCTAssertEqual(store.audioAssets.count, 1)
    }

    func testAudioHistoryAndSceneHistoryUndoInOrder() throws {
        try prepareStore()
        let car = mesh("Car"), asset = try audioAsset()
        store.addAudioAssetToTimeline(asset.id)
        store.pushUndoSnapshot("Move Car"); car.position.x = 3
        store.updateAudioClip(id: store.audioClips[0].id, volume: 0.2)
        store.undoLast(); XCTAssertEqual(store.audioClips[0].volume, 1)
        XCTAssertEqual(store.contentRoot.childNode(withName: "Car", recursively: true)?.position.x, 3)
        store.undoLast(); XCTAssertEqual(store.contentRoot.childNode(withName: "Car", recursively: true)?.position.x, 0)
        store.redoLast(); XCTAssertEqual(store.contentRoot.childNode(withName: "Car", recursively: true)?.position.x, 3)
        store.redoLast(); XCTAssertEqual(store.audioClips[0].volume, 0.2)
    }

    func testAudioUndoWorksWithoutCloningLargeSceneAndNewEditClearsRedo() throws {
        try prepareStore()
        for _ in 0..<6_000 { store.contentRoot.addChildNode(SCNNode()) }
        let asset = try audioAsset(); store.addAudioAssetToTimeline(asset.id)
        XCTAssertEqual(store.audioClips.count, 1)
        store.undoLast(); XCTAssertTrue(store.audioClips.isEmpty)
        XCTAssertEqual(store.redoCount, 1)
        store.addAudioAssetToTimeline(asset.id); XCTAssertEqual(store.redoCount, 0)
        XCTAssertTrue(store.audioRedoStack.isEmpty)
    }

    func testDuplicateMotionTrackHasFreshKeyframeIDsAndUndoRestoresTrackMetadata() throws {
        try prepareStore(); let car = mesh("Car"); store.select(car)
        store.currentTime = 0; store.addKeyframe(); store.currentTime = 2; car.position.x = 2; store.addKeyframe()
        let track = try XCTUnwrap(store.keyframes.first?.trackID)
        store.renameMotionTrack(track, to: "Drive"); store.duplicateMotionTrack(track, for: car)
        XCTAssertEqual(store.keyframes.count, 4); XCTAssertEqual(Set(store.keyframes.map(\.id)).count, 4)
        XCTAssertEqual(store.motionTrackNames.count, 2)
        store.undoLast(); XCTAssertEqual(store.keyframes.count, 2); XCTAssertEqual(store.motionTrackNames.count, 1)
        XCTAssertEqual(store.motionTrackNames[track], "Drive")
    }

    func testKeyframeCutCopyPasteUsesFreshIdentityAndAuthoredState() throws {
        try prepareStore(); let car = mesh("Car"); store.select(car)
        store.currentTime = 1; car.position.x = 2; store.addKeyframe()
        let original = store.keyframes[0].id
        store.copySelectedKeyframe(); store.currentTime = 4; store.pasteKeyframe()
        XCTAssertEqual(store.keyframes.count, 2); XCTAssertNotEqual(store.keyframes.last?.id, original)
        XCTAssertEqual(store.keyframes.last?.position.x, 2)
        store.cutSelectedKeyframe(); XCTAssertEqual(store.keyframes.count, 1)
        store.undoLast(); XCTAssertEqual(store.keyframes.count, 2)
    }

    func testInstalledDocumentTypeAndOriginalFileIcon() throws {
        let declarations = try XCTUnwrap(Bundle.main.object(forInfoDictionaryKey: "UTExportedTypeDeclarations") as? [[String: Any]])
        let declaration = try XCTUnwrap(declarations.first { $0["UTTypeIdentifier"] as? String == "app.5ln.studio.project" })
        let tags = try XCTUnwrap(declaration["UTTypeTagSpecification"] as? [String: Any])
        XCTAssertEqual(tags["public.filename-extension"] as? [String], ["3dmotion"])
        XCTAssertEqual(UTType(filenameExtension: "3dmotion")?.identifier, UTType.studioProject.identifier)
        let documents = try XCTUnwrap(Bundle.main.object(forInfoDictionaryKey: "CFBundleDocumentTypes") as? [[String: Any]])
        XCTAssertTrue(documents.contains { $0["CFBundleTypeIconFiles"] as? [String] == ["ProjectFileIcon.png"] })
        let url = try XCTUnwrap(Bundle.main.url(forResource: "ProjectFileIcon", withExtension: "png"))
        let icon = try XCTUnwrap(UIImage(contentsOfFile: url.path))
        XCTAssertEqual(icon.size.width, 1024); XCTAssertEqual(icon.size.height, 1024)
    }

    func testOpeningProjectURLRestoresPortableDocument() throws {
        try prepareStore()
        _ = mesh("Saved car")
        let url = root.appendingPathComponent("Moved project.3DMOTION")
        try projectData().write(to: url)
        store.newProject(named: "Another project")
        try store.openProjectDocument(at: url)
        XCTAssertNotNil(store.contentRoot.childNode(withName: "Saved car", recursively: true))
    }

    func testBadProjectURLKeepsCurrentWorkspace() throws {
        try prepareStore()
        let car = mesh("Healthy car")
        let bad = root.appendingPathComponent("Broken.3dmotion")
        try Data("broken".utf8).write(to: bad)
        XCTAssertThrowsError(try store.openProjectDocument(at: bad))
        XCTAssertTrue(car.parent === store.contentRoot)
        XCTAssertThrowsError(try store.openProjectDocument(at: bad.deletingPathExtension().appendingPathExtension("png")))
    }

    func prepareStore() throws {
        root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        store = StudioStore(projectStorageURL: root, restoreSavedProject: false, startTimer: false)
        store.showGrid = false; store.showAxes = false; store.showWorkPoint = false
        store.contentRoot.childNodes.forEach { $0.removeFromParentNode() }
        let storage = root!
        addTeardownBlock { try? FileManager.default.removeItem(at: storage) }
    }

    func image(_ color: UIColor) -> UIImage {
        let format = UIGraphicsImageRendererFormat(); format.scale = 1
        return UIGraphicsImageRenderer(size: CGSize(width: 8, height: 8), format: format).image { context in
            color.setFill(); context.fill(CGRect(x: 0, y: 0, width: 8, height: 8))
        }
    }

    func mesh(_ name: String, color: UIColor = .red) -> SCNNode {
        let vertices = [SCNVector3(0,0,0),SCNVector3(1,0,0),SCNVector3(0,1,0),SCNVector3(1,1,0)]
        let uv = [CGPoint(x: 0,y: 0),CGPoint(x: 1,y: 0),CGPoint(x: 0,y: 1),CGPoint(x: 1,y: 1)]
        let first: [UInt32] = [0,1,2], second: [UInt32] = [1,3,2]
        let elements = [first,second].map { indices in
            SCNGeometryElement(data: indices.withUnsafeBytes { Data($0) }, primitiveType: .triangles, primitiveCount: 1, bytesPerIndex: 4)
        }
        let geometry = SCNGeometry(sources: [SCNGeometrySource(vertices: vertices), SCNGeometrySource(textureCoordinates: uv), SCNGeometrySource(textureCoordinates: uv)], elements: elements)
        let paint = SCNMaterial(); paint.name = name + " paint"; paint.lightingModel = .physicallyBased
        paint.diffuse.contents = image(color)
        paint.normal.contents = image(UIColor(red: 0.5,green: 0.5,blue: 1,alpha: 1)).cgImage!
        paint.roughness.contents = image(.gray); paint.roughness.textureComponents = .green
        paint.metalness.contents = image(.white); paint.metalness.textureComponents = .blue
        paint.emission.contents = image(.orange); paint.emission.intensity = 0.37
        paint.transparent.contents = image(.white); paint.transparency = 0.72
        paint.diffuse.mappingChannel = 1; paint.diffuse.wrapS = .mirror; paint.diffuse.wrapT = .repeat
        paint.diffuse.contentsTransform = SCNMatrix4MakeScale(0.6,0.8,1)
        paint.diffuse.minificationFilter = .nearest; paint.diffuse.maxAnisotropy = 4
        let glass = SCNMaterial(); glass.name = name + " glass"; glass.diffuse.contents = UIColor.cyan
        glass.isDoubleSided = true; glass.transparencyMode = .dualLayer; glass.transparency = 0.24
        geometry.materials = [paint,glass]
        let node = SCNNode(geometry: geometry); node.name = name
        store.contentRoot.addChildNode(node)
        return node
    }

    func projectData() throws -> Data { try store.exportPortableProject() }
    func decoded(_ data: Data) throws -> PreparedStudioProject { try store.prepareProject(ProjectFileStore.decode(data)) }
    func node(_ name: String, in project: PreparedStudioProject) throws -> SCNNode {
        try XCTUnwrap(project.scene.rootNode.childNode(withName: name, recursively: true))
    }

    func testEveryRequiredMaterialChannelAndGeometrySlot() throws {
        try prepareStore()
        let source = mesh("car")
        let project = try decoded(projectData())
        defer { try? FileManager.default.removeItem(at: project.runtimeFolder) }
        let restored = try node("car", in: project)
        let geometry = try XCTUnwrap(restored.geometry)
        XCTAssertEqual(geometry.elements.count, 2)
        XCTAssertEqual(geometry.materials.map(\.name), source.geometry!.materials.map(\.name))
        let m = geometry.materials[0]
        for p in [m.diffuse,m.normal,m.roughness,m.metalness,m.emission,m.transparent] { XCTAssertTrue(p.contents is UIImage) }
        XCTAssertEqual(m.diffuse.mappingChannel, 1); XCTAssertEqual(m.diffuse.wrapS, .mirror)
        XCTAssertEqual(m.diffuse.wrapT, .repeat); XCTAssertEqual(m.diffuse.minificationFilter, .nearest)
        XCTAssertEqual(m.diffuse.maxAnisotropy, 4); XCTAssertEqual(m.metalness.textureComponents, .blue)
        XCTAssertEqual(m.roughness.textureComponents, .green)
        XCTAssertEqual(ProjectSceneCodec.matrix(m.diffuse.contentsTransform), ProjectSceneCodec.matrix(source.geometry!.materials[0].diffuse.contentsTransform))
        XCTAssertEqual(m.transparency, 0.72, accuracy: 0.0001)
        XCTAssertEqual(geometry.materials[1].transparency, 0.24, accuracy: 0.0001)
    }

    func fixture(_ name: String) throws -> URL {
        let bundle = Bundle(for: Self.self)
        return try XCTUnwrap(bundle.url(forResource: name, withExtension: nil, subdirectory: "Fixtures"))
    }

    func testOBJCarMTLAndImagesSurviveDeletedSources() throws {
        try prepareStore()
        let source = root.appendingPathComponent("OBJSource", isDirectory: true)
        try FileManager.default.copyItem(at: fixture("OBJCar"), to: source)
        let staged = try ImportFileStager.stage([source.appendingPathComponent("car.obj")])
        let url = try XCTUnwrap(staged.first { $0.pathExtension == "obj" })
        XCTAssertTrue(staged.contains { $0.lastPathComponent == "paint.png" })
        let imported = try AssetNodeLoader.load(url: url)
        let materials = ProjectSceneCodec.nodes(in: imported.node).flatMap { $0.geometry?.materials ?? [] }
        XCTAssertTrue(try XCTUnwrap(materials.first { $0.name == "paint" }).diffuse.contents is UIImage)
        XCTAssertTrue(try XCTUnwrap(materials.first { $0.name == "wheels" }).diffuse.contents is UIImage)
        imported.node.name = "ImportedCar"
        store.contentRoot.addChildNode(imported.node)
        let before = try projectData()
        let baseline = try ProjectFileStore.decode(before)
        XCTAssertFalse(baseline.resources!.isEmpty)
        try FileManager.default.removeItem(at: source)
        // Delete the complete staging session, including its texture sidecars.
        var session = url.deletingLastPathComponent()
        while !session.lastPathComponent.hasPrefix("FiveLnImportSession-") && session.path != "/" { session.deleteLastPathComponent() }
        XCTAssertNotEqual(session.path, "/")
        if session.path != "/" { try FileManager.default.removeItem(at: session) }
        try store.importPortableProject(before)
        XCTAssertEqual(store.currentProjectName, baseline.name)
        let after = try ProjectFileStore.decode(projectData())
        XCTAssertEqual(Set(after.resources!.keys), Set(baseline.resources!.keys))
    }

    func testGLBAndGLTFMultipleMaterialsAndUVChannels() throws {
        try prepareStore()
        for name in ["multi.glb", "multi.gltf"] {
            store.contentRoot.childNodes.forEach { $0.removeFromParentNode() }
            let imported = try AssetNodeLoader.load(url: fixture(name))
            imported.node.name = "multi"
            store.contentRoot.addChildNode(imported.node)
            let p = try decoded(projectData())
            defer { try? FileManager.default.removeItem(at: p.runtimeFolder) }
            let materials = ProjectSceneCodec.nodes(in: p.scene.rootNode).flatMap { $0.geometry?.materials ?? [] }
            XCTAssertTrue(materials.contains { $0.name == "paint" && $0.diffuse.contents is UIImage })
            XCTAssertTrue(materials.contains { $0.name == "glass" && $0.diffuse.contents is UIImage })
            let paint = try XCTUnwrap(materials.first { $0.name == "paint" })
            XCTAssertEqual(paint.diffuse.mappingChannel, 1)
            XCTAssertEqual(paint.diffuse.wrapS, .mirror)
            XCTAssertNotEqual(paint.diffuse.contentsTransform.m41, 0)
            XCTAssertEqual(paint.metalness.textureComponents, .blue)
            XCTAssertEqual(paint.roughness.textureComponents, .green)
        }
    }

    func testOBJMaterialFoldersWithCollidingImageNamesAndMapOptions() throws {
        try prepareStore()
        let source = root.appendingPathComponent("OBJSource", isDirectory: true)
        try FileManager.default.copyItem(at: fixture("OBJCar"), to: source)
        let other = source.appendingPathComponent("other/textures", isDirectory: true)
        try FileManager.default.createDirectory(at: other, withIntermediateDirectories: true)
        try FileManager.default.copyItem(at: source.appendingPathComponent("materials/textures/packed.png"), to: other.appendingPathComponent("paint.png"))
        try FileManager.default.copyItem(at: source.appendingPathComponent("materials/textures/paint.png"), to: source.appendingPathComponent("materials/textures/paint copy.png"))
        let obj = source.appendingPathComponent("car.obj")
        let objectText = try String(contentsOf: obj, encoding: .utf8)
            .replacingOccurrences(of: "mtllib materials/car.mtl", with: "mtllib materials/car.mtl other/wheels.mtl")
        try objectText.write(to: obj, atomically: true, encoding: .utf8)
        try """
        newmtl paint
        Kd 1 1 1
        map_Kd -s 0.5 0.75 -o 0.1 0.2 -clamp on "textures/paint copy.png"
        newmtl glass
        Kd 0.2 0.7 0.9
        d 0.45
        """.write(to: source.appendingPathComponent("materials/car.mtl"), atomically: true, encoding: .utf8)
        try "newmtl wheels\nKd 1 1 1\nmap_Kd textures/paint.png\n".write(to: source.appendingPathComponent("other/wheels.mtl"), atomically: true, encoding: .utf8)
        let staged = try ImportFileStager.stage([obj])
        let url = try XCTUnwrap(staged.first { $0.pathExtension == "obj" })
        defer { try? FileManager.default.removeItem(at: url.deletingLastPathComponent()) }
        let imported = try AssetNodeLoader.load(url: url)
        store.contentRoot.addChildNode(imported.node)
        let project = try decoded(projectData())
        defer { try? FileManager.default.removeItem(at: project.runtimeFolder) }
        let materials = ProjectSceneCodec.nodes(in: project.scene.rootNode).flatMap { $0.geometry?.materials ?? [] }
        let paint = try XCTUnwrap(materials.first { $0.name == "paint" })
        let wheels = try XCTUnwrap(materials.first { $0.name == "wheels" })
        let glass = try XCTUnwrap(materials.first { $0.name == "glass" })
        let glassColor = try XCTUnwrap(glass.diffuse.contents as? UIColor)
        var red: CGFloat = 0, green: CGFloat = 0, blue: CGFloat = 0, alpha: CGFloat = 0
        XCTAssertTrue(glassColor.getRed(&red, green: &green, blue: &blue, alpha: &alpha))
        XCTAssertGreaterThan(green, red + 0.2); XCTAssertGreaterThan(blue, red + 0.3)
        XCTAssertNotEqual(try XCTUnwrap(paint.diffuse.contents as? UIImage).pngData(), try XCTUnwrap(wheels.diffuse.contents as? UIImage).pngData())
        XCTAssertEqual(paint.diffuse.wrapS, .clamp)
        XCTAssertEqual(paint.diffuse.contentsTransform.m11, 0.5, accuracy: 0.001)
        XCTAssertEqual(paint.diffuse.contentsTransform.m22, 0.75, accuracy: 0.001)
        XCTAssertEqual(paint.diffuse.contentsTransform.m41, 0.1, accuracy: 0.001)
        XCTAssertEqual(paint.diffuse.contentsTransform.m42, 0.2, accuracy: 0.001)
    }

    func testGroupsTransformsKeyframesCameraAndLight() throws {
        try prepareStore()
        let car = mesh("car")
        let group = SCNNode(); group.name = "group"; group.position = SCNVector3(3,4,5)
        group.eulerAngles = SCNVector3(0.1,0.2,0.3); group.scale = SCNVector3(2,3,4)
        store.contentRoot.addChildNode(group); group.addChildNode(car)
        car.position = SCNVector3(0.3,0.4,0.5)
        let camera = SCNNode(); camera.name = "Camera"; camera.camera = SCNCamera(); camera.camera!.fieldOfView = 41
        store.camerasRoot.addChildNode(camera); store.projectOpeningCamera = camera
        let light = SCNNode(); light.name = "Key Light"; light.light = SCNLight(); light.light!.intensity = 1234
        store.lightsRoot.addChildNode(light)
        let identity = store.animationIdentity(car)
        store.keyframes = [0.0,2.0].map { time in StudioKeyframe(nodeID: identity, nodeName: "car", time: time,
            position: SCNVector3(Float(time),0,0), euler: SCNVector3(0,Float(time),0), scale: SCNVector3(1,1,1),
            trackID: "drive", interpolation: .linear, materialStates: car.geometry!.materials.map(MaterialKeyframeState.init)) }
        store.motionTrackNames = ["drive":"Drive"]; store.activeMotionTrackByNode = [identity:"drive"]
        store.loopingMotionTrackIDs = ["drive"]
        let a = CABasicAnimation(keyPath: "eulerAngles.y"); a.fromValue = 0; a.toValue = 1; a.duration = 2
        store.addAnimationLayer(a, to: car, name: "Spin", weight: 0.6, speed: 0.8, repeatForever: true)
        let animationKey = try XCTUnwrap(car.animationKeys.first)
        let animation = try XCTUnwrap(car.animationPlayer(forKey: animationKey)).animation
        animation.blendInDuration = 0.25; animation.blendOutDuration = 0.4
        animation.usesSceneTimeBase = true
        let data = try projectData()
        try store.importPortableProject(data)
        let restored = try XCTUnwrap(store.contentRoot.childNode(withName: "car", recursively: true))
        XCTAssertEqual(restored.parent?.name, "group")
        XCTAssertEqual(ProjectSceneCodec.matrix(restored.parent!.transform), ProjectSceneCodec.matrix(group.transform))
        XCTAssertEqual(store.keyframes.count, 2)
        XCTAssertEqual(store.animationLayers.count, 1)
        let restoredPlayer = try XCTUnwrap(restored.animationPlayer(forKey: animationKey))
        XCTAssertEqual(restoredPlayer.speed, 0.8, accuracy: 0.001)
        XCTAssertEqual(restoredPlayer.blendFactor, 0.6, accuracy: 0.001)
        XCTAssertEqual(restoredPlayer.animation.duration, 2, accuracy: 0.001)
        XCTAssertGreaterThan(restoredPlayer.animation.repeatCount, 100)
        XCTAssertFalse(restoredPlayer.animation.isRemovedOnCompletion)
        XCTAssertTrue(restoredPlayer.animation.fillsForward)
        XCTAssertTrue(restoredPlayer.animation.usesSceneTimeBase)
        XCTAssertEqual(restoredPlayer.animation.blendInDuration, 0.25, accuracy: 0.001)
        XCTAssertEqual(restoredPlayer.animation.blendOutDuration, 0.4, accuracy: 0.001)
        XCTAssertEqual(store.motionTrackNames["drive"], "Drive")
        XCTAssertEqual(store.lightsRoot.childNodes.first?.light?.intensity, 1234)
        XCTAssertEqual(store.projectOpeningCamera?.camera?.fieldOfView, 41)
        store.applyTimeline(at: 1)
        XCTAssertEqual(restored.position.x, 1, accuracy: 0.001)
        XCTAssertTrue(restored.geometry!.materials[0].diffuse.contents is UIImage)
        XCTAssertTrue(restored.geometry!.materials[0].roughness.contents is UIImage)
    }

    func testDifferentModelsWithSameNamesUseStableIdentities() throws {
        try prepareStore()
        let red = mesh("same", color: .red), blue = mesh("same", color: .blue)
        let data = try projectData()
        let p = try decoded(data)
        defer { try? FileManager.default.removeItem(at: p.runtimeFolder) }
        let nodes = ProjectSceneCodec.nodes(in: p.scene.rootNode)
        let a = try XCTUnwrap(nodes.first { $0.studioAnimationID == red.studioAnimationID })
        let b = try XCTUnwrap(nodes.first { $0.studioAnimationID == blue.studioAnimationID })
        XCTAssertNotEqual(a.studioAnimationID, b.studioAnimationID)
        let ai = try XCTUnwrap(a.geometry!.materials[0].diffuse.contents as? UIImage)
        let bi = try XCTUnwrap(b.geometry!.materials[0].diffuse.contents as? UIImage)
        XCTAssertNotEqual(ai.pngData(), bi.pngData())
    }

    func testSaveOpenRepeatedlyAndMoveDocument() throws {
        try prepareStore()
        _ = mesh("car")
        var data = try projectData()
        let expected = Set(try ProjectFileStore.decode(data).resources!.keys)
        for _ in 0..<5 {
            try store.importPortableProject(data)
            data = try projectData()
            XCTAssertEqual(Set(try ProjectFileStore.decode(data).resources!.keys), expected)
        }
        let url = root.appendingPathComponent("Export.3dmotion")
        let moved = root.appendingPathComponent("OtherFolder/Moved.3dmotion")
        try data.write(to: url, options: .atomic)
        try FileManager.default.createDirectory(at: moved.deletingLastPathComponent(), withIntermediateDirectories: true)
        try FileManager.default.moveItem(at: url, to: moved)
        try store.importPortableProject(Data(contentsOf: moved))
        XCTAssertEqual(Set(try ProjectFileStore.decode(projectData()).resources!.keys), expected)
    }

    func testAutosaveRecoveryInFreshStoreInstance() throws {
        try prepareStore()
        _ = mesh("car")
        XCTAssertTrue(store.saveAutosave(force: true))
        let data = try Data(contentsOf: store.autosaveProjectURL)
        store = nil
        store = StudioStore(projectStorageURL: root, restoreSavedProject: true, startTimer: false)
        XCTAssertNotNil(store.contentRoot.childNode(withName: "car", recursively: true))
        XCTAssertEqual(Set(try ProjectFileStore.decode(projectData()).resources!.keys), Set(try ProjectFileStore.decode(data).resources!.keys))
    }

    func testFailedTextureSaveDoesNotReplaceHealthyNamedProject() throws {
        try prepareStore()
        let car = mesh("car")
        XCTAssertTrue(store.saveNamedProject("healthy"))
        let file = store.projectFolder(named: "healthy").appendingPathComponent("Project.3dmotion")
        let previous = try Data(contentsOf: file)
        car.geometry!.materials[0].diffuse.contents = root.appendingPathComponent("missing.png")
        XCTAssertFalse(store.saveNamedProject("healthy"))
        XCTAssertEqual(try Data(contentsOf: file), previous)
        XCTAssertTrue(try XCTUnwrap(store.toast).contains("Save failed"))
    }

    func testCorruptImportDoesNotReplaceCurrentWorkspace() throws {
        try prepareStore()
        let car = mesh("car")
        var p = try ProjectFileStore.decode(projectData()); p.resources!.removeAll()
        p.seal()
        XCTAssertThrowsError(try store.importPortableProject(JSONEncoder().encode(p)))
        XCTAssertTrue(car.parent === store.contentRoot)
    }

    func testExplicitSaveDoesNotUseAutosaveLargeSceneSkip() throws {
        try prepareStore()
        _ = mesh("car")
        for _ in 0..<5_000 { store.contentRoot.addChildNode(SCNNode()) }
        XCTAssertFalse(store.saveAutosave())
        XCTAssertTrue(store.saveNamedProject("large"))
        let p = try ProjectFileStore.decode(Data(contentsOf: store.projectFolder(named: "large").appendingPathComponent("Project.3dmotion")))
        XCTAssertGreaterThan(p.scene.count, 0)
    }
    func testCorruptAutosaveCannotBeOverwrittenByStarterScene() throws {
        try prepareStore()
        let invalid = Data("truncated".utf8)
        try invalid.write(to: store.autosaveProjectURL)
        store = StudioStore(projectStorageURL: root, restoreSavedProject: true, startTimer: false)
        XCTAssertFalse(store.saveAutosave(force: true))
        XCTAssertEqual(try Data(contentsOf: store.autosaveProjectURL), invalid)
    }

    func testLegacyKeyframeMissingMapsLeaveCurrentTextureIntact() throws {
        try prepareStore()
        let car = mesh("car")
        let material = car.geometry!.materials[0]
        var saved = SavedMaterialKeyframeState(MaterialKeyframeState(material))
        saved.values = nil
        let decoded = saved.materialState
        decoded.apply(to: material)
        XCTAssertTrue(material.diffuse.contents is UIImage)
        XCTAssertTrue(material.roughness.contents is UIImage)
    }

    func testReorderedSiblingNodesKeepTheirMaterialBindings() throws {
        try prepareStore()
        let red = mesh("same", color: .red), blue = mesh("same", color: .blue)
        var package = try ProjectFileStore.decode(projectData())
        let prepared = try decoded(ProjectFileStore.encode(package))
        defer { try? FileManager.default.removeItem(at: prepared.runtimeFolder) }
        let content = try XCTUnwrap(prepared.scene.rootNode.childNode(withName: "Scene", recursively: false))
        let children = content.childNodes
        children.forEach { $0.removeFromParentNode() }
        for child in children.reversed() { content.addChildNode(child) }
        package.scene = try NSKeyedArchiver.archivedData(withRootObject: prepared.scene, requiringSecureCoding: true)
        package.seal()
        let restored = try decoded(ProjectFileStore.encode(package))
        defer { try? FileManager.default.removeItem(at: restored.runtimeFolder) }
        let nodes = ProjectSceneCodec.nodes(in: restored.scene.rootNode)
        let a = try XCTUnwrap(nodes.first { $0.studioAnimationID == red.studioAnimationID })
        let b = try XCTUnwrap(nodes.first { $0.studioAnimationID == blue.studioAnimationID })
        XCTAssertNotEqual((a.geometry!.materials[0].diffuse.contents as? UIImage)?.pngData(), (b.geometry!.materials[0].diffuse.contents as? UIImage)?.pngData())
    }

}
