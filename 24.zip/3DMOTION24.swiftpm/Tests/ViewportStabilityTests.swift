import XCTest
import UIKit
import SceneKit
import Metal
import SwiftUI
@testable import MotionApp

@MainActor
extension ScenePersistenceTests {
    func testInitialProjectSwitchSkipsSavingPlaceholderButProtectsActiveWork() throws {
        try prepareStore()
        XCTAssertFalse(store.hasActiveProject)
        // The library bypasses the dialog and explicitly requests no save
        // when hasActiveProject is false. An explicit save request stays strict.
        XCTAssertTrue(store.performProjectSwitch(.new("First"), savingCurrent: false))
        XCTAssertTrue(store.hasActiveProject)
        XCTAssertEqual(store.editorViewportCamera?.camera?.zNear ?? 0, 0.05, accuracy: 0.0001)
        XCTAssertEqual(store.currentProjectName, "First")
        XCTAssertTrue(store.projectCards().filter { $0.id != "autosave://last" }.isEmpty)
        XCTAssertTrue(store.performProjectSwitch(.new("Second"), savingCurrent: true))
        XCTAssertEqual(store.currentProjectName, "Second")
        XCTAssertEqual(store.projectCards().filter { $0.id != "autosave://last" }.map(\.name), ["First"])
        print("VIEWPORT_FIRST_PROJECT_PASS no placeholder save; active project saved before switch")
    }

    func testSaveDoesNotClearVisibleMapsOrDetachViewportLighting() throws {
        try prepareStore()
        let node = mesh("Stable material")
        store.contentRoot.addChildNode(node)
        let material = try XCTUnwrap(node.geometry?.firstMaterial)
        let diffuse = try XCTUnwrap(material.diffuse.contents as? UIImage)
        let normal = material.normal.contents
        let key = try XCTUnwrap(store.editorRoot.childNode(withName: "_ViewportKeyLight", recursively: false))
        var mapWrites = 0, editorMoves = 0
        let observer = material.diffuse.observe(\.contents, options: [.new]) { _, _ in mapWrites += 1 }
        let parentObserver = store.editorRoot.observe(\.parent, options: [.new]) { _, _ in editorMoves += 1 }
        defer { observer.invalidate(); parentObserver.invalidate() }
        let data = try projectData()
        XCTAssertEqual(mapWrites, 0, "Save changed a visible material provider")
        XCTAssertEqual(editorMoves, 0, "Save detached the live viewport light rig")
        XCTAssertTrue(material.diffuse.contents as? UIImage === diffuse)
        XCTAssertTrue(key.parent === store.editorRoot)
        XCTAssertTrue(store.editorRoot.parent === store.scene.rootNode)
        XCTAssertNotNil(normal); XCTAssertNotNil(material.normal.contents)
        try store.importPortableProject(data)
        XCTAssertTrue(store.contentRoot.childNode(withName: "Stable material", recursively: true)?.geometry?.firstMaterial?.diffuse.contents is UIImage)
        print("VIEWPORT_SAVE_PASS zero live map writes; zero light rig detach; portable maps preserved")
    }

    func testSkyIntensityReusesImageAndBackgroundChangesKeepAuthoredMaps() throws {
        try prepareStore()
        let node = mesh("Sky material"); store.contentRoot.addChildNode(node)
        let material = try XCTUnwrap(node.geometry?.firstMaterial)
        let diffuse = try XCTUnwrap(material.diffuse.contents as? UIImage)
        material.lightingModel = .physicallyBased; material.specular.intensity = 0.73; material.shininess = 0.61
        store.environmentPreset = .day; store.applySceneEnvironment()
        let sky = try XCTUnwrap(store.scene.background.contents as? UIImage)
        var replacements = 0
        let observer = store.scene.lightingEnvironment.observe(\.contents, options: [.new]) { _, _ in replacements += 1 }
        defer { observer.invalidate() }
        for step in 0...20 { store.environmentIntensity = Double(step) / 10; store.applySceneEnvironment() }
        XCTAssertEqual(replacements, 0)
        XCTAssertTrue(store.scene.background.contents as? UIImage === sky)
        for preset in [SceneEnvironmentPreset.sunset, .night, .overcast, .none, .day] {
            store.setEnvironmentPreset(preset); store.setViewportBackground(3); store.applyViewportSettings()
            XCTAssertTrue(material.diffuse.contents as? UIImage === diffuse)
            XCTAssertEqual(material.lightingModel, .physicallyBased)
            XCTAssertEqual(material.specular.intensity, 0.73, accuracy: 0.0001)
            XCTAssertEqual(material.shininess, 0.61, accuracy: 0.0001)
        }
        let data = try projectData(); try store.importPortableProject(data)
        let reopened = try XCTUnwrap(store.contentRoot.childNode(withName: "Sky material", recursively: true)?.geometry?.firstMaterial)
        XCTAssertEqual(reopened.lightingModel, .physicallyBased)
        XCTAssertTrue(reopened.diffuse.contents is UIImage)
        print("VIEWPORT_ENVIRONMENT_PASS 21 intensity edits with zero texture rebinds; maps/model retained")
    }

    func testLitPreviewAndSnapshotRestoreAuthoredMaterialValues() throws {
        try prepareStore(); let node = mesh("Preview material"); store.contentRoot.addChildNode(node)
        let material = try XCTUnwrap(node.geometry?.firstMaterial)
        material.specular.intensity = 0.73; material.shininess = 0.61; material.isDoubleSided = false
        store.viewportShadingMode = .lit; store.backfaceCullingEnabled = false; store.applyViewportSettings()
        XCTAssertEqual(material.lightingModel, .blinn)
        XCTAssertTrue(material.isDoubleSided)
        let snapshot = try store.makePersistenceSceneSnapshot()
        let authored = try XCTUnwrap(snapshot.rootNode.childNode(withName: "Preview material", recursively: true)?.geometry?.firstMaterial)
        XCTAssertEqual(authored.lightingModel, .physicallyBased); XCTAssertFalse(authored.isDoubleSided)
        XCTAssertEqual(authored.specular.intensity, 0.73, accuracy: 0.0001)
        XCTAssertEqual(authored.shininess, 0.61, accuracy: 0.0001)
        store.viewportShadingMode = .rendered; store.backfaceCullingEnabled = true; store.applyViewportSettings()
        XCTAssertEqual(material.lightingModel, .physicallyBased); XCTAssertFalse(material.isDoubleSided)
        XCTAssertEqual(material.specular.intensity, 0.73, accuracy: 0.0001)
        XCTAssertEqual(material.shininess, 0.61, accuracy: 0.0001)
        print("VIEWPORT_SHADING_PASS preview overrides restore authored settings; save uses authored values")
    }

    func testDetachedSnapshotRetainsLinkedMeshesAndConstraintTargets() throws {
        try prepareStore()
        let geometry = SCNBox(width: 1, height: 1, length: 1, chamferRadius: 0)
        let a = SCNNode(geometry: geometry), b = SCNNode(geometry: geometry)
        a.name = "Linked A"; b.name = "Linked B"; b.position.x = 3
        a.constraints = [SCNLookAtConstraint(target: b), SCNDistanceConstraint(target: b)]
        store.contentRoot.addChildNode(a); store.contentRoot.addChildNode(b)
        let snapshot = try store.makePersistenceSceneSnapshot()
        let ca = try XCTUnwrap(snapshot.rootNode.childNode(withName: "Linked A", recursively: true))
        let cb = try XCTUnwrap(snapshot.rootNode.childNode(withName: "Linked B", recursively: true))
        XCTAssertTrue(ca.geometry === cb.geometry); XCTAssertTrue(ca.geometry !== geometry)
        XCTAssertTrue((ca.constraints?.first as? SCNLookAtConstraint)?.target === cb)
        XCTAssertTrue((ca.constraints?.last as? SCNDistanceConstraint)?.target === cb)
        XCTAssertTrue((a.constraints?.first as? SCNLookAtConstraint)?.target === b)
        let data = try projectData(); try store.importPortableProject(data)
        let reopenedA = try XCTUnwrap(store.contentRoot.childNode(withName: "Linked A", recursively: true))
        let reopenedB = try XCTUnwrap(store.contentRoot.childNode(withName: "Linked B", recursively: true))
        XCTAssertTrue(reopenedA.geometry === reopenedB.geometry)
        XCTAssertTrue((reopenedA.constraints?.first as? SCNLookAtConstraint)?.target === reopenedB)
        print("VIEWPORT_GRAPH_PASS linked geometry and constraint targets isolated and preserved on reopen")
    }

    func testGridRendersStableFramesWithDepthOcclusionAndSubpixelFade() throws {
        try prepareStore(); store.addStarterObject(); store.showGrid = true; store.rebuildHelpers()
        let grid = try XCTUnwrap(store.helpersRoot.childNode(withName: "_Grid", recursively: false))
        XCTAssertTrue(grid.geometry is SCNPlane)
        let material = try XCTUnwrap(grid.geometry?.firstMaterial)
        XCTAssertFalse(material.writesToDepthBuffer); XCTAssertTrue(material.readsFromDepthBuffer)
        SCNTransaction.flush()
        let renderer = SCNRenderer(device: MTLCreateSystemDefaultDevice(), options: nil)
        renderer.scene = store.scene; renderer.pointOfView = store.editorViewportCamera
        let size = CGSize(width: 512, height: 384)
        let first = renderer.snapshot(atTime: 0, with: size, antialiasingMode: .multisampling4X)
        let second = renderer.snapshot(atTime: 1, with: size, antialiasingMode: .multisampling4X)
        let third = renderer.snapshot(atTime: 2, with: size, antialiasingMode: .multisampling4X)
        func pixels(_ image: UIImage) throws -> [UInt8] {
            let cg = try XCTUnwrap(image.cgImage)
            var data = [UInt8](repeating: 0, count: cg.width * cg.height * 4)
            let context = try XCTUnwrap(CGContext(data: &data, width: cg.width, height: cg.height, bitsPerComponent: 8, bytesPerRow: cg.width * 4, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue))
            context.draw(cg, in: CGRect(x: 0, y: 0, width: cg.width, height: cg.height)); return data
        }
        let a = try pixels(first), b = try pixels(second), c = try pixels(third)
        let differences = zip(b, c).map { abs(Int($0) - Int($1)) }
        let mean = Double(differences.reduce(0,+)) / Double(differences.count)
        XCTAssertLessThan(mean, 0.2, "Static viewport shimmer/flash")
        let colors = Set(stride(from: 0, to: a.count, by: 4).map { UInt32(a[$0]) << 16 | UInt32(a[$0 + 1]) << 8 | UInt32(a[$0 + 2]) })
        XCTAssertGreaterThan(colors.count, 5, "The camera did not show the scene")
        let attachment = XCTAttachment(image: third); attachment.name = "Stable grid"; attachment.lifetime = .keepAlways; add(attachment)
        SCNTransaction.begin(); SCNTransaction.disableActions = true
        grid.isHidden = true
        SCNTransaction.commit(); SCNTransaction.flush()
        let withoutGrid = try pixels(renderer.snapshot(atTime: 3, with: size, antialiasingMode: .multisampling4X))
        let changed = zip(c, withoutGrid).filter { $0 != $1 }.count
        XCTAssertGreaterThan(changed, 50, "Grid shader produced no visible pixels")
        print("VIEWPORT_GRID_PASS static mean pixel delta \(mean); grid pixels changed \(changed)")
    }

    func testVideoExportReturnsToSameMaterialMapsAndProjectTime() async throws {
        try prepareStore(); store.addStarterObject()
        let cube = try XCTUnwrap(store.contentRoot.childNode(withName: "Cube", recursively: false)); store.select(cube)
        store.currentTime = 0; store.addKeyframe()
        store.applyWorkshopMaterial(.oak, tiling: 2)
        let material = try XCTUnwrap(cube.geometry?.firstMaterial)
        let diffuse = try XCTUnwrap(material.diffuse.contents as? UIImage), normal = try XCTUnwrap(material.normal.contents as? UIImage)
        store.setProjectDuration(0.2); store.currentTime = 0.1
        let result = try await store.renderProjectVideo(resolution: .p720, exportFPS: 24)
        defer { try? FileManager.default.removeItem(at: result.url) }
        XCTAssertTrue(material.diffuse.contents as? UIImage === diffuse)
        XCTAssertTrue(material.normal.contents as? UIImage === normal)
        XCTAssertEqual(material.diffuse.contentsTransform.m11, 2)
        XCTAssertEqual(store.currentTime, 0.1, accuracy: 0.0001)
        XCTAssertFalse(store.isExporting); XCTAssertNil(store.exportViewportPreview)
        let data = try projectData(); try store.importPortableProject(data)
        let reopened = try XCTUnwrap(store.contentRoot.childNode(withName: "Cube", recursively: false)?.geometry?.firstMaterial)
        XCTAssertTrue(reopened.normal.contents is UIImage); XCTAssertTrue(reopened.diffuse.contents is UIImage)
        print("VIEWPORT_EXPORT_PASS maps and UV tiling restored; time restored; portable reopen retained maps")
    }
}
