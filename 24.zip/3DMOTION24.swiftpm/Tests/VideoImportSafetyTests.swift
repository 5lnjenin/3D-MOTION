import Foundation
import XCTest
#if canImport(VideoImportCore)
@testable import VideoImportCore
#else
@testable import MotionApp
#endif

final class VideoImportSafetyTests: XCTestCase {
    func folder() throws -> URL {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        addTeardownBlock { try? FileManager.default.removeItem(at: root) }
        return root
    }

    func testStreamingCopyRetainsExactBytesAndSource() async throws {
        let root = try folder(), source = root.appendingPathComponent("فيديو original.mov")
        let destination = root.appendingPathComponent("Video/copied.mov")
        let bytes = Data((0..<8_388_613).map { UInt8($0 % 251) })
        try bytes.write(to: source)
        try await Task.detached { try VideoImportFile.copy(source, to: destination) }.value
        XCTAssertEqual(try Data(contentsOf: destination), bytes)
        XCTAssertEqual(try Data(contentsOf: source), bytes)
    }

    func testSourceFailuresLeaveNoOutputAndKeepHealthyFiles() throws {
        let root = try folder(), healthy = root.appendingPathComponent("healthy.mov")
        let bytes = Data("healthy resource".utf8); try bytes.write(to: healthy)
        for source in [root.appendingPathComponent("missing.mov"), root] {
            let destination = root.appendingPathComponent("Video/failed.mov")
            XCTAssertThrowsError(try VideoImportFile.copy(source, to: destination))
            XCTAssertFalse(FileManager.default.fileExists(atPath: destination.path))
            XCTAssertEqual(try Data(contentsOf: healthy), bytes)
        }
    }

    func testExistingDestinationCannotBeOverwritten() throws {
        let root = try folder(), source = root.appendingPathComponent("source.mov"), target = root.appendingPathComponent("saved.mov")
        let saved = Data("keep the saved file".utf8)
        try Data("new source".utf8).write(to: source); try saved.write(to: target)
        XCTAssertThrowsError(try VideoImportFile.copy(source, to: target))
        XCTAssertEqual(try Data(contentsOf: target), saved)
    }

    func testCancellationDuringStreamingRemovesPartialCopy() async throws {
        let root = try folder(), source = root.appendingPathComponent("large.mov"), target = root.appendingPathComponent("copy.mov")
        XCTAssertTrue(FileManager.default.createFile(atPath: source.path, contents: nil))
        let handle = try FileHandle(forWritingTo: source)
        let size: UInt64 = 536_870_912
        try handle.truncate(atOffset: size); try handle.close()
        let operation = VideoImportFile.Operation()
        let copying = Task.detached(priority: .userInitiated) { try operation.copy(source, to: target) }
        defer { operation.cancel(); copying.cancel() }
        let deadline = Date().addingTimeInterval(10)
        var written: UInt64 = 0
        while Date() < deadline {
            written = (try? FileManager.default.attributesOfItem(atPath: target.path)[.size] as? NSNumber)?.uint64Value ?? 0
            if written > 0 { break }
            try await Task.sleep(nanoseconds: 100_000)
        }
        XCTAssertGreaterThan(written, 0); XCTAssertLessThan(written, size)
        operation.cancel(); copying.cancel()
        do { try await copying.value; XCTFail("Cancelled streaming copy completed") }
        catch is CancellationError { }
        XCTAssertFalse(FileManager.default.fileExists(atPath: target.path))
        XCTAssertEqual(try source.resourceValues(forKeys: [.fileSizeKey]).fileSize, Int(size))
    }

    func testCancelledOperationCannotCopyWithoutSwiftTaskContext() async throws {
        let root = try folder(), source = root.appendingPathComponent("source.mov"), target = root.appendingPathComponent("copy.mov")
        try Data("original".utf8).write(to: source)
        let operation = VideoImportFile.Operation(); operation.cancel()
        do {
            try await withCheckedThrowingContinuation { (completion: CheckedContinuation<Void, Error>) in
                DispatchQueue.global(qos: .userInitiated).async {
                    do { try operation.copy(source, to: target); completion.resume() }
                    catch { completion.resume(throwing: error) }
                }
            }
            XCTFail("Cancelled file-provider callback copied the source")
        } catch is CancellationError { }
        XCTAssertFalse(FileManager.default.fileExists(atPath: target.path))
        XCTAssertEqual(try Data(contentsOf: source), Data("original".utf8))
    }

    func testInterruptedJournalSurvivesFreshInstanceAndAcknowledgesOnce() throws {
        let root = try folder(), journal = VideoImportJournal(folder: root)
        let id = journal.begin(filename: "movie.mp4"); journal.advance(id, to: .preparing)
        let fresh = VideoImportJournal(folder: root)
        let interrupted = try XCTUnwrap(fresh.consumeInterrupted())
        XCTAssertEqual(interrupted.attempt, id); XCTAssertEqual(interrupted.stage, .preparing)
        XCTAssertEqual(interrupted.filename, "movie.mp4")
        XCTAssertEqual(fresh.read()?.state, .interrupted)
        XCTAssertNil(fresh.consumeInterrupted())
        XCTAssertTrue(try XCTUnwrap(fresh.report()).contains("preparing"))
    }

    func testFinishedImportsAreNotReportedAsCrashes() throws {
        let journal = VideoImportJournal(folder: try folder())
        for state in [VideoImportJournal.State.completed, .failed, .cancelled] {
            let id = journal.begin(filename: "movie.mp4")
            journal.finish(id, state: state, error: state == .failed ? CocoaError(.fileReadCorruptFile) : nil)
            XCTAssertNil(journal.consumeInterrupted())
            XCTAssertEqual(journal.read()?.state, state)
            if state == .failed { XCTAssertNotNil(journal.read()?.error) }
        }
    }

    func testOlderAttemptCannotOverwriteNewAttempt() throws {
        let journal = VideoImportJournal(folder: try folder())
        let old = journal.begin(filename: "old.mov"), current = journal.begin(filename: "new.mov")
        journal.advance(old, to: .starting); journal.finish(old, state: .failed)
        XCTAssertEqual(journal.read()?.attempt, current)
        XCTAssertEqual(journal.read()?.stage, .copying)
        XCTAssertEqual(journal.read()?.state, .active)
    }

    func testCorruptJournalCanBeReplacedWithoutThrowing() throws {
        let journal = VideoImportJournal(folder: try folder())
        try Data("broken diagnostic".utf8).write(to: journal.url)
        XCTAssertNil(journal.read()); XCTAssertNil(journal.consumeInterrupted())
        let id = journal.begin(filename: "healthy.mov"); journal.finish(id, state: .completed)
        XCTAssertEqual(journal.read()?.attempt, id); XCTAssertEqual(journal.read()?.state, .completed)
    }
}
