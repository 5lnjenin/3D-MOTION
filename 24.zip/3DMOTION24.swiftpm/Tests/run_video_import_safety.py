#!/usr/bin/env python3
"""Run the production streaming-copy and persistent-diagnostic code on Linux/macOS.

No SceneKit, file-provider download or iPad/Playgrounds behavior is claimed here.
"""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile

root = Path(__file__).resolve().parent.parent
with tempfile.TemporaryDirectory(prefix="motion-video-import-tests-") as directory:
    package = Path(directory)
    source = package / "Sources/VideoImportCore"
    tests = package / "Tests/VideoImportCoreTests"
    source.mkdir(parents=True); tests.mkdir(parents=True)
    for name in ("VideoImportFile.swift", "VideoImportJournal.swift"):
        shutil.copyfile(root / name, source / name)
    shutil.copyfile(root / "Tests/VideoImportSafetyTests.swift", tests / "VideoImportSafetyTests.swift")
    (package / "Package.swift").write_text('''// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "VideoImportSafety", targets: [
    .target(name: "VideoImportCore"),
    .testTarget(name: "VideoImportCoreTests", dependencies: ["VideoImportCore"])
], swiftLanguageModes: [.v5])
''')
    environment = os.environ.copy()
    environment["SWIFTPM_MODULECACHE_OVERRIDE"] = str(package / "ModuleCache")
    environment["CLANG_MODULE_CACHE_PATH"] = str(package / "ModuleCache")
    raise SystemExit(subprocess.call(["swift", "test", "--package-path", str(package),
        "--cache-path", str(package / "Cache"), "--config-path", str(package / "Config"),
        "--security-path", str(package / "Security"), "--jobs", "4"], env=environment))
