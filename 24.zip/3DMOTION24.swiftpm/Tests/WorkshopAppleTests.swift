import XCTest
import UIKit
import SceneKit
import Metal
import CoreText
import simd
import SwiftUI
@testable import MotionApp

@MainActor
extension ScenePersistenceTests {
    func waitForWorkshop() async throws {
        let deadline=Date().addingTimeInterval(30)
        while store.workshopIsRunning {guard Date()<deadline else {throw ProjectFailure.invalid("workshop timeout")};try await Task.sleep(nanoseconds:1_000_000)}
        XCTAssertNil(store.projectErrorDetails)
    }
    func testWorkshopMeshEditsUndoRedoAndPortableOpen() async throws {
        try prepareStore();let node=SCNNode(geometry:SCNBox(width:2,height:2,length:2,chamferRadius:0));node.name="Workshop cube";store.contentRoot.addChildNode(node);store.select(node)
        let before=try WorkshopGeometry.mesh(node).faces.count
        store.runWorkshop(.subdivide);try await waitForWorkshop();XCTAssertEqual(try WorkshopGeometry.mesh(node).faces.count,before*4)
        store.undoLast();let undone=try XCTUnwrap(store.contentRoot.childNode(withName:"Workshop cube",recursively:true));XCTAssertEqual(try WorkshopGeometry.mesh(undone).faces.count,before)
        store.redoLast();let redone=try XCTUnwrap(store.contentRoot.childNode(withName:"Workshop cube",recursively:true));XCTAssertEqual(try WorkshopGeometry.mesh(redone).faces.count,before*4)
        store.select(redone);store.runWorkshop(.uvBox,amount:2);try await waitForWorkshop()
        let data=try projectData();try store.importPortableProject(data)
        let reopened=try XCTUnwrap(store.contentRoot.childNode(withName:"Workshop cube",recursively:true));XCTAssertEqual(try WorkshopGeometry.mesh(reopened).faces.count,before*4)
        print("WORKSHOP_MESH_PASS subdivide/UV/undo/redo/portable reopen")
    }
    func testWorkshopBooleanRetainsHiddenCutterAndUndoRestoresBoth() async throws {
        try prepareStore();let a=SCNNode(geometry:SCNBox(width:2,height:2,length:2,chamferRadius:0)),b=SCNNode(geometry:SCNBox(width:2,height:2,length:2,chamferRadius:0))
        a.name="Target";b.name="Cutter";b.position.x=1;store.contentRoot.addChildNode(a);store.contentRoot.addChildNode(b);store.select(a);store.multiSelectedNodes=[a,b]
        store.workshopBoolean(.subtract);try await waitForWorkshop();XCTAssertTrue(b.isHidden);XCTAssertNotNil(b.parent);XCTAssertFalse(a.geometry is SCNBox)
        store.undoLast();XCTAssertFalse(try XCTUnwrap(store.contentRoot.childNode(withName:"Cutter",recursively:true)).isHidden)
        XCTAssertTrue(store.contentRoot.childNode(withName:"Target",recursively:true)?.geometry is SCNBox)
    }
    func testWorkshopMaterialsTravelAndSharedGeometryIsIsolated() throws {
        try prepareStore();let box=SCNBox(width:2,height:2,length:2,chamferRadius:0),a=SCNNode(geometry:box),b=SCNNode(geometry:box)
        a.name="Painted";b.name="Unchanged";store.contentRoot.addChildNode(a);store.contentRoot.addChildNode(b);store.select(a)
        let previous=b.geometry?.firstMaterial?.diffuse.contents
        for preset in WorkshopMaterial.allCases {
            store.applyWorkshopMaterial(preset,tiling:2)
            let material=try XCTUnwrap(a.geometry?.firstMaterial);XCTAssertTrue(material.diffuse.contents is UIImage);XCTAssertTrue(material.normal.contents is UIImage)
            XCTAssertEqual(material.diffuse.wrapS,.repeat);XCTAssertEqual(material.diffuse.contentsTransform.m11,2)
        }
        XCTAssertTrue(a.geometry !== b.geometry);XCTAssertTrue(b.geometry === box)
        if let previous=previous as? UIColor {XCTAssertEqual(b.geometry?.firstMaterial?.diffuse.contents as? UIColor,previous)}
        let data=try projectData();try store.importPortableProject(data)
        let material=try XCTUnwrap(store.contentRoot.childNode(withName:"Painted",recursively:true)?.geometry?.firstMaterial)
        XCTAssertTrue(material.normal.contents is UIImage);XCTAssertTrue(material.diffuse.contents is UIImage);XCTAssertEqual(material.diffuse.contentsTransform.m11,2)
        print("WORKSHOP_MATERIALS_PASS 24 local maps; portable textures; isolated shared mesh")
    }
    func testWorkshopBundledFontsRegisterAndContainArabicGlyphs() throws {
        WorkshopFonts.register()
        for name in WorkshopFonts.names {XCTAssertNotNil(UIFont(name:name,size:24),name)}
        let font=CTFontCreateWithName("NotoSansArabic-Regular" as CFString,24,nil)
        let chars=Array("مرحبا".utf16);var glyphs=[CGGlyph](repeating:0,count:chars.count)
        XCTAssertTrue(CTFontGetGlyphsForCharacters(font,chars,&glyphs,chars.count));XCTAssertTrue(glyphs.allSatisfy {$0 != 0})
        print("WORKSHOP_FONTS_PASS six embedded fonts and Arabic glyph coverage")
    }
    func testWorkshopLookIsUndoableAndDoesNotDeleteExistingLights() throws {
        try prepareStore();let authored=SCNNode();authored.name="Authored light";authored.light=SCNLight();store.lightsRoot.addChildNode(authored)
        store.applyWorkshopLook(.neon);XCTAssertNotNil(authored.parent)
        let rig=try XCTUnwrap(store.lightsRoot.childNodes.first {$0.name?.hasPrefix("Workshop Rig •")==true});XCTAssertEqual(rig.childNodes.filter {$0.light != nil}.count,3)
        store.undoLast();XCTAssertNil(store.lightsRoot.childNodes.first {$0.name?.hasPrefix("Workshop Rig •")==true});XCTAssertNotNil(store.lightsRoot.childNode(withName:"Authored light",recursively:true))
    }
    func riggedGLTFFixture(eightWeights:Bool=false,malformed:Bool=false) throws -> URL {
        var binary=Data(),views:[[String:Any]]=[],accessors:[[String:Any]]=[]
        func accessor(_ bytes:Data,type:String,component:Int,count:Int) -> Int {
            while binary.count%4 != 0 {binary.append(0)};let offset=binary.count;binary.append(bytes)
            let view=views.count;views.append(["buffer":0,"byteOffset":offset,"byteLength":bytes.count]);let i=accessors.count;accessors.append(["bufferView":view,"componentType":component,"count":count,"type":type]);return i
        }
        func floats(_ values:[Float],_ type:String,_ count:Int) -> Int {accessor(values.withUnsafeBytes {Data($0)},type:type,component:5126,count:count)}
        let positions=floats([0,0,0,1,0,0,0,1,0],"VEC3",3)
        let ids:[UInt8]=[0,0,0,0,0,0,0,0,malformed ? 8 : 1,0,0,0],j=accessor(Data(ids),type:"VEC4",component:5121,count:3)
        let weight:Float=eightWeights ? 0.5 : 1,w=floats([weight,0,0,0,weight,0,0,0,weight,0,0,0],"VEC4",3)
        let ibm=floats([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1, 1,0,0,0,0,1,0,0,0,0,1,0,0,-1,0,1],"MAT4",2)
        let t=floats([0,1],"SCALAR",2)
        let cubic=floats([0,0,0, 0,1,0, 4,0,0, -4,0,0, 2,1,0, 0,0,0],"VEC3",6),linear=floats([0,1,0,0,3,0],"VEC3",2)
        var attributes:[String:Any]=["POSITION":positions,"JOINTS_0":j,"WEIGHTS_0":w]
        if eightWeights {attributes["JOINTS_1"]=j;attributes["WEIGHTS_1"]=w}
        let animations:[[String:Any]]=[
            ["name":"Cubic","samplers":[["input":t,"output":cubic,"interpolation":"CUBICSPLINE"]],"channels":[["sampler":0,"target":["node":1,"path":"translation"]]]],
            ["name":"Lift","samplers":[["input":t,"output":linear,"interpolation":"LINEAR"]],"channels":[["sampler":0,"target":["node":1,"path":"translation"]]]]]
        let document:[String:Any]=["asset":["version":"2.0"],"scene":0,"scenes":[["nodes":[0,2]]],
            "nodes":[["name":"Hip","children":[1]],["name":"Tip","translation":[0,1,0]],["name":"Character mesh","mesh":0,"skin":0]],
            "meshes":[["primitives":[["attributes":attributes,"material":0]]]],
            "materials":[["doubleSided":true,"pbrMetallicRoughness":["baseColorFactor":[1,0,0,1],"metallicFactor":0]]],
            "skins":[["joints":[0,1],"skeleton":0,"inverseBindMatrices":ibm]],"animations":animations,
            "buffers":[["byteLength":binary.count,"uri":"data:application/octet-stream;base64,"+binary.base64EncodedString()]],"bufferViews":views,"accessors":accessors]
        let url=root.appendingPathComponent(UUID().uuidString+".gltf");try JSONSerialization.data(withJSONObject:document).write(to:url);return url
    }
    func testImportedSkinCubicAndClipChoiceProduceExactPose() throws {
        try prepareStore();let rig=try AssetNodeLoader.load(url:riggedGLTFFixture()).node;rig.name="Reference rig";store.contentRoot.addChildNode(rig);store.select(rig)
        let tip=try XCTUnwrap(rig.childNode(withName:"Tip",recursively:true)),skinned=try XCTUnwrap(ProjectSceneCodec.nodes(in:rig).first {$0.skinner != nil})
        XCTAssertEqual(skinned.skinner?.bones.count,2);XCTAssertEqual(skinned.skinner?.boneWeights.componentsPerVector,4)
        store.currentTime=0.5;store.applyTimeline(at:0.5);XCTAssertEqual(tip.position.x,2,accuracy:1e-6);XCTAssertEqual(tip.position.y,1,accuracy:1e-6)
        store.editImportedClip {$0.selected=1;$0.loops=false};XCTAssertEqual(tip.position.x,0,accuracy:1e-6);XCTAssertEqual(tip.position.y,2,accuracy:1e-6)
        store.undoLast();let restored=try XCTUnwrap(store.contentRoot.childNode(withName:"Tip",recursively:true));store.applyTimeline(at:0.5);XCTAssertEqual(restored.position.x,2,accuracy:1e-6)
        let data=try projectData();try store.importPortableProject(data);store.applyTimeline(at:0.5)
        XCTAssertEqual(store.contentRoot.childNode(withName:"Tip",recursively:true)?.position.x ?? -1,2,accuracy:1e-6)
    }
    func testImportedRigPortableOpenAndCloneBindToOwnBones() throws {
        try prepareStore();let url=try riggedGLTFFixture(),rig=try AssetNodeLoader.load(url:url).node;rig.name="Reference rig";store.contentRoot.addChildNode(rig);store.select(rig)
        store.editImportedClip {$0.selected=1;$0.speed=2;$0.start=0.25;$0.loops=false}
        let clone=store.cleanDeepClone(rig);clone.name="Independent rig";store.contentRoot.addChildNode(clone)
        let originalSkin=try XCTUnwrap(ProjectSceneCodec.nodes(in:rig).first {$0.skinner != nil}?.skinner),clonedSkin=try XCTUnwrap(ProjectSceneCodec.nodes(in:clone).first {$0.skinner != nil}?.skinner)
        XCTAssertTrue(originalSkin.bones[1] !== clonedSkin.bones[1]);XCTAssertTrue(clonedSkin.bones[1] === clone.childNode(withName:"Tip",recursively:true))
        let data=try projectData();try FileManager.default.removeItem(at:url);try store.importPortableProject(data);store.applyTimeline(at:0.5)
        for name in ["Reference rig","Independent rig"] {
            let reopened=try XCTUnwrap(store.contentRoot.childNode(withName:name,recursively:true)),library=try XCTUnwrap(reopened.importedLibrary())
            XCTAssertEqual(library.selected,1);XCTAssertEqual(library.speed,2);let tip=try XCTUnwrap(reopened.childNode(withName:"Tip",recursively:true));XCTAssertEqual(tip.position.y,2,accuracy:1e-6)
        }
        print("WORKSHOP_RIG_PASS skin bindings/independent clone/clip clock/portable reopen after deleting source")
    }
    func testImportedSkinEightWeightsAndInvalidJoints() throws {
        try prepareStore();let rig=try AssetNodeLoader.load(url:riggedGLTFFixture(eightWeights:true)).node
        XCTAssertEqual(ProjectSceneCodec.nodes(in:rig).first {$0.skinner != nil}?.skinner?.boneWeights.componentsPerVector,8)
        XCTAssertThrowsError(try AssetNodeLoader.load(url:riggedGLTFFixture(malformed:true)))
    }
    func testImportedSkinActuallyDeformsRenderedMesh() throws {
        try prepareStore();let rig=try AssetNodeLoader.load(url:riggedGLTFFixture()).node;store.contentRoot.addChildNode(rig)
        let skinned=try XCTUnwrap(ProjectSceneCodec.nodes(in:rig).first {$0.skinner != nil}),material=try XCTUnwrap(skinned.geometry?.firstMaterial)
        material.lightingModel = .constant;material.diffuse.contents=UIColor.red;material.isDoubleSided=true
        let camera=SCNNode();camera.camera=SCNCamera();camera.camera!.usesOrthographicProjection=true;camera.camera!.orthographicScale=4;camera.position=SCNVector3(1,0.5,5);camera.look(at:SCNVector3(1,0.5,0));store.scene.rootNode.addChildNode(camera)
        let renderer=SCNRenderer(device:MTLCreateSystemDefaultDevice(),options:nil);renderer.scene=store.scene;renderer.pointOfView=camera;store.scene.background.contents=UIColor.black
        func center(_ image:UIImage) throws -> Double {
            let cg=try XCTUnwrap(image.cgImage),width=cg.width,height=cg.height;var bytes=[UInt8](repeating:0,count:width*height*4)
            let context=try XCTUnwrap(CGContext(data:&bytes,width:width,height:height,bitsPerComponent:8,bytesPerRow:width*4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue));context.draw(cg,in:CGRect(x:0,y:0,width:width,height:height))
            var sum=0.0,count=0
            for y in 0..<height {for x in 0..<width {let i=(y*width+x)*4;if bytes[i]>100 && bytes[i+1]<80 && bytes[i+2]<80 {sum += Double(x);count += 1}}}
            XCTAssertGreaterThan(count,80);return sum/Double(max(1,count))
        }
        store.applyTimeline(at:0);SCNTransaction.flush();let before=try center(renderer.snapshot(atTime:0,with:CGSize(width:240,height:240),antialiasingMode:.none))
        store.applyTimeline(at:0.5);SCNTransaction.flush();let after=try center(renderer.snapshot(atTime:0.5,with:CGSize(width:240,height:240),antialiasingMode:.none))
        XCTAssertGreaterThan(after-before,20);print("WORKSHOP_SKIN_RENDER_PASS actual triangle centroid shift: \(after-before)")
    }
    func testWorkshopRigPhysicsUsesParentBonesAndUndoRedoRestoresBindings() throws {
        try prepareStore();let rig=try AssetNodeLoader.load(url:riggedGLTFFixture()).node;rig.name="Physics rig";store.contentRoot.addChildNode(rig)
        XCTAssertEqual(store.bones(in:rig).count,2);store.makeRagdoll(root:rig)
        XCTAssertEqual(store.scene.physicsWorld.allBehaviors.count,1)
        let before=try XCTUnwrap(store.scene.physicsWorld.allBehaviors.first as? SCNPhysicsBallSocketJoint)
        XCTAssertEqual(before.anchorA.y,1,accuracy:1e-6)
        store.undoLast();XCTAssertEqual(store.scene.physicsWorld.allBehaviors.count,0)
        XCTAssertTrue(ProjectSceneCodec.nodes(in:store.contentRoot).allSatisfy {$0.physicsBody==nil})
        store.redoLast();XCTAssertEqual(store.scene.physicsWorld.allBehaviors.count,1)
        let reopenedRig=try XCTUnwrap(store.contentRoot.childNode(withName:"Physics rig",recursively:true)),boneBodies=store.rigBoneNodes(in:reopenedRig).compactMap(\.physicsBody)
        let joint=try XCTUnwrap(store.scene.physicsWorld.allBehaviors.first as? SCNPhysicsBallSocketJoint)
        XCTAssertTrue(boneBodies.contains {$0 === joint.bodyA});XCTAssertTrue(boneBodies.contains {$0 === joint.bodyB})
        store.makeRagdoll(root:reopenedRig);XCTAssertEqual(store.scene.physicsWorld.allBehaviors.count,1)
    }
    func testWorkshopIKTargetPersistsAndClonedChainUsesOwnRoot() throws {
        try prepareStore();let rig=try AssetNodeLoader.load(url:riggedGLTFFixture()).node;rig.name="IK rig";store.contentRoot.addChildNode(rig)
        let hip=try XCTUnwrap(rig.childNode(withName:"Hip",recursively:true)),tip=try XCTUnwrap(rig.childNode(withName:"Tip",recursively:true)),target=SCNNode();target.name="IK target";target.position=SCNVector3(2,2,0);store.contentRoot.addChildNode(target)
        store.addIKConstraint(to:tip,chainRoot:hip,target:target);XCTAssertNotNil(tip.studioIKBinding)
        let clone=store.cleanDeepClone(rig),clonedEnd=try XCTUnwrap(clone.childNode(withName:"Tip",recursively:true)),ik=try XCTUnwrap(clonedEnd.constraints?.first as? SCNIKConstraint)
        XCTAssertTrue(ik.chainRootNode === clone.childNode(withName:"Hip",recursively:true))
        let data=try projectData();try store.importPortableProject(data);store.updateIKTargets()
        let end=try XCTUnwrap(store.contentRoot.childNode(withName:"Tip",recursively:true)),savedTarget=try XCTUnwrap(store.contentRoot.childNode(withName:"IK target",recursively:true));savedTarget.position.x=3;store.updateIKTargets()
        XCTAssertEqual(try XCTUnwrap(end.constraints?.first as? SCNIKConstraint).targetPosition.x,3,accuracy:1e-6)
        store.removeRigIK(in:try XCTUnwrap(store.contentRoot.childNode(withName:"IK rig",recursively:true)));XCTAssertFalse(end.constraints?.contains {$0 is SCNIKConstraint} ?? false)
    }
    func testWorkshopLookRestoresRenderFilterOnUndo() throws {
        try prepareStore();store.renderFilterPreset = .none;store.renderFilterIntensity=0.1
        store.applyWorkshopLook(.cinematic);XCTAssertEqual(store.renderFilterPreset,.cinematic)
        store.undoLast();XCTAssertEqual(store.renderFilterPreset,.none);XCTAssertEqual(store.renderFilterIntensity,0.1)
    }
    func testWorkshopResponsiveLibrarySnapshots() async throws {
        try prepareStore()
        let windowScene=try XCTUnwrap(UIApplication.shared.connectedScenes.compactMap {$0 as? UIWindowScene}.first),previous=windowScene.windows.first(where:\.isKeyWindow),window=UIWindow(windowScene:windowScene)
        defer {window.isHidden=true;window.rootViewController=nil;previous?.makeKey()}
        for language in [StudioLanguage.arabic,.english] {
            store.appLanguage=language
            for size in [CGSize(width:390,height:844),CGSize(width:768,height:1024),CGSize(width:1180,height:820)] {
                window.frame=CGRect(origin:.zero,size:size)
                let host=UIHostingController(rootView:WorkshopLibraryView().environmentObject(store).environment(\.dynamicTypeSize,.large))
                window.rootViewController=host;window.makeKeyAndVisible();host.view.layoutIfNeeded();try await Task.sleep(nanoseconds:150_000_000)
                let image=UIGraphicsImageRenderer(size:size).image {_ in host.view.drawHierarchy(in:host.view.bounds,afterScreenUpdates:true)}
                XCTAssertNotNil(image.cgImage)
                let attachment=XCTAttachment(image:image);attachment.name="Workshop-\(language.rawValue)-\(Int(size.width))x\(Int(size.height))";attachment.lifetime = .keepAlways;add(attachment)
            }
        }
        print("WORKSHOP_UI_PASS six hosted layouts; Arabic/English; phone/iPad portrait/landscape screenshots attached")
    }
}
