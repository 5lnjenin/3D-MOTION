#!/usr/bin/env python3
"""Compile the actual ProjectContainer.swift in an isolated Swift package.

Requires Swift 6 (Linux or macOS). First run fetches Apple's swift-crypto.
This validates container/atomic storage, not SceneKit or UIKit.
"""
import pathlib
import os
import shutil
import subprocess
import tempfile

root = pathlib.Path(__file__).resolve().parent.parent
with tempfile.TemporaryDirectory(prefix="motion-core-tests-") as folder:
    package = pathlib.Path(folder)
    (package / "Sources/ProjectCore").mkdir(parents=True)
    (package / "Tests/ProjectCoreTests").mkdir(parents=True)
    shutil.copy2(root / "ProjectContainer.swift", package / "Sources/ProjectCore")
    shutil.copy2(root / "Tests/PortableCoreTests.swift", package / "Tests/ProjectCoreTests")
    (package / "Package.swift").write_text('''// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "ProjectCoreTests", products: [.library(name: "ProjectCore", targets: ["ProjectCore"])],
    dependencies: [.package(url: "https://github.com/apple/swift-crypto.git", exact: "3.10.0")],
    targets: [.target(name: "ProjectCore", dependencies: [.product(name: "Crypto", package: "swift-crypto")]),
              .testTarget(name: "ProjectCoreTests", dependencies: ["ProjectCore"])],
    swiftLanguageModes: [.v5])
''')
    process_environment = os.environ.copy()
    process_environment["SWIFTPM_MODULECACHE_OVERRIDE"] = str(package / "ModuleCache")
    process_environment["CLANG_MODULE_CACHE_PATH"] = str(package / "ModuleCache")
    raise SystemExit(subprocess.call(["swift", "test", "--package-path", str(package),
        "--cache-path", str(package / "Cache"), "--config-path", str(package / "Config"),
        "--security-path", str(package / "Security"), "--jobs", "4"], env=process_environment))
