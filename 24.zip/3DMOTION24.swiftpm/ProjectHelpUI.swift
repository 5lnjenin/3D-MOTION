import SwiftUI
import SceneKit
import AVFoundation

@MainActor
struct ProjectQuickStartView: View {
    @EnvironmentObject var studio: StudioStore
    @Environment(\.dismiss) private var dismiss
    private var instructions: [String] {
        studio.appLanguage == .arabic ? [
            "ابدأ بمشروع جديد. المكعب المبدئي مثال بسيط لتجربة أدوات التحريك.",
            "أضف مجسمًا أو صورة أو فيديو من شريط الإضافة. حدّد العنصر لتعديل خصائصه.",
            "للفيديو: حدّد سطحه وافتح الخصائص لضبط البداية والقص والسرعة والتكرار والصوت.",
            "حرّك مؤشر الوقت، غيّر وضع العنصر ثم أضف نقطة حركة. كرّر في وقت آخر واضغط تشغيل.",
            "افتح ورشة الأدوات للنمذجة وBoolean وUV والخامات والخطوط والإضاءة الجاهزة. للشخصيات، اختر مقطع الحركة من خصائص الحركة.",
            "احفظ بزر الحفظ أو Cmd-S. اضغط مطولًا على الحفظ لاختيار حفظ باسم وإنشاء نسخة مستقلة.",
            "من مشاريعي يمكنك البحث والترتيب وإعادة التسمية والتكرار. المحذوفات تبقى قابلة للاستعادة.",
            "صدّر المشروع لنقله مع موارده، أو صدّر فيديو لاختيار الدقة ومعدل الإطارات. صوت الفيديو ومقاطع الصوت يدخلان التصدير معًا."
        ] : [
            "Start a new project. The starter cube is a simple example for trying animation tools.",
            "Add a model, image or video from the toolbar. Select it to edit its properties.",
            "For a video, select its surface and open the inspector to edit start, trim, speed, loop and sound.",
            "Move the playhead, change the object's pose and add a keyframe. Repeat at another time, then press Play.",
            "Save with the save button or Cmd-S. Hold the save button for Save As to create an independent copy.",
            "My Projects supports search, sorting, rename and duplicate. Deleted projects can be restored.",
            "Export a project to transfer it with its resources, or export a video at your chosen resolution and frame rate. Movie sound and timeline audio are mixed together."
        ]
    }
    var body: some View {
        NavigationStack {
            List(Array(instructions.enumerated()), id: \.offset) { index, text in
                HStack(alignment: .top) { Text("\(index + 1).").bold(); Text(text) }.padding(.vertical, 8)
            }
            .navigationTitle(studio.appLanguage == .arabic ? "دليل البداية" : "Quick start")
            .toolbar { Button(studio.appLanguage == .arabic ? "تم" : "Done") { dismiss() } }
        }.environment(\.layoutDirection, studio.appLanguage.direction)
    }
}

@MainActor
struct DeletedProjectsView: View {
    @EnvironmentObject var studio: StudioStore
    @Environment(\.dismiss) private var dismiss
    @State private var refresh = UUID()
    var body: some View {
        NavigationStack {
            List(studio.deletedProjectCards()) { card in
                HStack {
                    Text(card.name).lineLimit(2)
                    Spacer()
                    Button(studio.appLanguage == .arabic ? "استعادة" : "Restore") {
                        studio.restoreDeletedProject(card); refresh = UUID()
                    }.buttonStyle(.bordered)
                }
            }.id(refresh)
            .navigationTitle(studio.appLanguage == .arabic ? "المشاريع المحذوفة" : "Deleted projects")
            .toolbar { Button(studio.appLanguage == .arabic ? "تم" : "Done") { dismiss() } }
        }.environment(\.layoutDirection, studio.appLanguage.direction)
    }
}

@MainActor
struct MovieResourceLibraryView: View {
    @EnvironmentObject var studio: StudioStore
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List(studio.sceneVideoPlayers().compactMap { $0 as? StudioMoviePlayer }, id: \.clipID) { player in
                if let asset = player.currentItem?.asset as? AVURLAsset {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(asset.url.lastPathComponent).lineLimit(2)
                        let bytes = (try? asset.url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
                        Text(ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file)).font(.caption).foregroundStyle(.secondary)
                        Button(studio.appLanguage == .arabic ? "إضافة نسخة إلى المشهد" : "Add a copy to the scene") {
                            Task { do { _ = try await studio.importVideoFile(asset.url) } catch { studio.reportProjectError(error) } }
                        }.buttonStyle(.bordered).disabled(studio.importIsRunning || studio.isExporting)
                    }.padding(.vertical, 8)
                }
            }
            .navigationTitle(studio.appLanguage == .arabic ? "ملفات الفيديو في المشروع" : "Project movie files")
            .toolbar { Button(studio.appLanguage == .arabic ? "تم" : "Done") { dismiss() } }
        }.environment(\.layoutDirection, studio.appLanguage.direction)
    }
}
