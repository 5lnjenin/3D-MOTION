import Foundation
import SceneKit
import AVFoundation

@MainActor
extension StudioStore {
    // A loop contributes one authored cycle; an explicit extension can keep it
    // playing longer. Static meshes have no invented 60-second tail.
    var contentTimelineEnd: Double {
        let audioEnd = audioClips.map(\.endTime).filter(\.isFinite).max() ?? 0
        let nodes = [contentRoot, camerasRoot, lightsRoot].flatMap { ProjectSceneCodec.nodes(in: $0) }
        let ids = Set(nodes.compactMap(\.studioAnimationID)), names = Set(nodes.compactMap(\.name))
        let keyEnd = keyframes.filter { key in
            key.nodeID.map { ids.contains($0) } ?? names.contains(key.nodeName)
        }.map(\.time).filter(\.isFinite).max() ?? 0
        var mediaEnd = 0.0
        for root in [contentRoot, camerasRoot, lightsRoot] {
            for node in ProjectSceneCodec.nodes(in: root) {
                if let library = try? node.importedLibrary() { mediaEnd = max(mediaEnd, library.timelineEnd) }
                for key in node.animationKeys {
                    guard let player = node.animationPlayer(forKey: key) else { continue }
                    let animation = player.animation
                    let cycle = animation.duration * (animation.autoreverses ? 2 : 1)
                    let repeats = animation.repeatCount.isFinite && animation.repeatCount > 0 && animation.repeatCount < 10_000
                        ? Double(animation.repeatCount) : 1
                    let speed = abs(Double(player.speed))
                    let end = max(0, animation.startDelay) + cycle * repeats / max(0.0001, speed)
                    if end.isFinite { mediaEnd = max(mediaEnd, end) }
                }
                for material in node.geometry?.materials ?? [] {
                    for (_, property) in ProjectSceneCodec.properties(material) {
                        guard let player = property.contents as? AVPlayer,
                              let asset = player.currentItem?.asset else { continue }
                        if let seconds = player.loadedMovieSourceDuration {
                            mediaEnd = max(mediaEnd, player.authoredMovieTiming.timelineEnd(seconds))
                        } else {
                            requestMovieDuration(player, asset: asset)
                        }
                    }
                }
            }
        }
        return max(audioEnd, keyEnd, mediaEnd)
    }

    // Older documents do not contain a cached source duration. Load it once
    // and reconcile when ready, without delaying the main actor or retaining
    // a discarded project's store through an in-flight read.
    private func requestMovieDuration(_ player: AVPlayer, asset: AVAsset) {
        let id = ObjectIdentifier(asset)
        guard movieDurationLoads[id] == nil else { return }
        switch asset.status(of: .duration) {
        case .notYetLoaded, .loading: break
        case .loaded, .failed: return
        }
        movieDurationLoads[id] = Task { @MainActor [weak self, weak player] in
            let loaded = try? await asset.load(.duration)
            guard !Task.isCancelled, let self else { return }
            movieDurationLoads.removeValue(forKey: id)
            guard let loaded, let player, player.currentItem?.asset === asset,
                  sceneVideoPlayers().contains(where: { $0 === player }) else { return }
            (player as? StudioMoviePlayer)?.rememberSourceDuration(CMTimeGetSeconds(loaded))
            reconcileTimelineDuration()
        }
    }

    func prepareMovieTimelineDuration() async throws {
        for player in sceneVideoPlayers() {
            guard let asset = player.currentItem?.asset else { continue }
            let seconds = CMTimeGetSeconds(try await asset.load(.duration))
            try Task.checkCancellation()
            guard player.currentItem?.asset === asset else { throw CancellationError() }
            (player as? StudioMoviePlayer)?.rememberSourceDuration(seconds)
        }
    }

    func reconcileTimelineDuration() {
        let end = contentTimelineEnd
        let next = max(end, timelineMinimumDuration > 0 ? timelineMinimumDuration : (end > 0 ? end : 1))
        if abs(next - duration) > 0.000001 { duration = next }
    }

    func setProjectDuration(_ seconds: Double) {
        guard seconds.isFinite, seconds >= 0 else { return }
        timelineMinimumDuration = seconds
        reconcileTimelineDuration()
    }

    func useAutomaticProjectDuration() { setProjectDuration(0) }
}
