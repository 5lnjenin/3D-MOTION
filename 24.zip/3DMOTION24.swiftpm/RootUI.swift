import Foundation
import SwiftUI
import UIKit
import QuartzCore
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

// MARK: - Root UI

@MainActor
struct StudioRootView: View {
    @EnvironmentObject var studio: StudioStore
    @Binding var incomingProjectURL: URL?
    @Environment(\.horizontalSizeClass) private var sizeClass
    @State private var availableWidth: CGFloat = 1024
    private var compact: Bool { sizeClass == .compact || availableWidth < 850 }
    @State private var showAddMenu = false
    @State private var showPortableImport = false
    @State private var portableDocument: StudioPortableDocument?

    @State private var showSettings = false
    @State private var showViewportSettings = false
    @State private var showSceneEnvironment = false
    @State private var showExportPanel = false
    @State private var showLeftPanel = false
    @State private var showRightPanel = false
    @State private var showTimeline = false
    @State private var showProjectLibrary = true
    @State private var showExitConfirmation = false
    @State private var showTextEditor = false
    @State private var showIncomingProjectConfirmation = false

    var body: some View {
        ZStack {
            Color(red: 0.075, green: 0.105, blue: 0.146).ignoresSafeArea()

            VStack(spacing: 0) {
                topBar

                HStack(spacing: 0) {
                    if showLeftPanel && !compact {
                        HierarchyPanel()
                            .disabled(studio.isExporting)
                            .environment(\.layoutDirection, studio.appLanguage.direction)
                            .frame(width: 195)
                            .transition(.move(edge: .leading))
                    }

                    if !compact {
                        EdgeCollapseButton(side: .left, isPanelVisible: showLeftPanel) {
                            withAnimation(.easeInOut(duration: 0.22)) { showLeftPanel.toggle() }
                        }
                    }

                    VStack(spacing: 0) {
                        // Keep VIEW / OBJECT controls in a fixed toolbar above the viewport.
                        // It never covers the scene and never changes its height when modes switch.
                        // Two independent physical zones: quick tools are permanently
                        // anchored on the left, while VIEW / OBJECT owns the remaining
                        // margin. Language direction can never move or overlap the tools.
                        HStack(spacing: 12) {
                            quickToolsBar
                                .fixedSize(horizontal: true, vertical: false)

                            Divider()
                                .frame(height: 36)
                                .overlay(Color.white.opacity(0.10))

                            DirectManipulationHint(onEditText: {
                                showTextEditor = true
                            })
                            .environmentObject(studio)
                            .environment(\.layoutDirection, studio.appLanguage.direction)
                            .frame(maxWidth: .infinity, minHeight: 54, maxHeight: 54, alignment: .leading)
                        }
                        .environment(\.layoutDirection, .leftToRight)
                        .frame(maxWidth: .infinity, minHeight: 56, maxHeight: 56, alignment: .leading)
                        .padding(.horizontal, 8)
                        .background(Color(red: 0.10, green: 0.14, blue: 0.19).opacity(0.96))
                        // Keep toolbar hover labels above the SceneKit viewport. SceneKit is
                        // backed by a native view and otherwise can visually cover SwiftUI
                        // overlays that extend outside the toolbar's bounds.
                        .zIndex(1000)
                        Divider().overlay(Color.white.opacity(0.08)).zIndex(999)
                        viewport
                            .disabled(studio.isExporting)
                            .zIndex(0)
                        if showTimeline {
                            Divider().overlay(Color.white.opacity(0.10))
                            TimelinePanel()
                                .frame(height: studio.audioClips.isEmpty ? 160 : 220)
                                .disabled(studio.isExporting)
                                .transition(.move(edge: .bottom))
                        }
                    }

                    if !compact {
                        EdgeCollapseButton(side: .right, isPanelVisible: showRightPanel) {
                            withAnimation(.easeInOut(duration: 0.22)) { showRightPanel.toggle() }
                        }
                    }

                    if showRightPanel && !compact {
                        InspectorPanel()
                            .disabled(studio.isExporting)
                            .environment(\.layoutDirection, studio.appLanguage.direction)
                            .frame(width: 255)
                            .transition(.move(edge: .trailing))
                    }
                }
                // The workspace shell is spatial, not linguistic: the left edge must
                // always control the left/scene panel and the right edge must always
                // control the right/tools panel. Arabic only changes text/layout inside
                // the panels, never the physical side they occupy.
                .environment(\.layoutDirection, .leftToRight)
            }
            .disabled(studio.importIsRunning || studio.isExporting)
            .allowsHitTesting(!studio.importIsRunning)

            if studio.importIsRunning {
                VStack {
                    HStack(spacing: 12) {
                        ProgressView()
                        Text(ProductInterfaceText.message(studio.statusText, arabic: studio.appLanguage == .arabic)).font(.caption).lineLimit(2)
                        Spacer()
                        Button(studio.importCancellationRequested ? (studio.appLanguage == .arabic ? "جارٍ الإيقاف…" : "Stopping…") : (studio.appLanguage == .arabic ? "إيقاف" : "Stop")) {
                            studio.cancelImport()
                        }.disabled(studio.importCancellationRequested)
                    }
                    .padding(12).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14))
                    .padding(.horizontal, 12).padding(.top, 56)
                    Spacer()
                }
            }

            if let toast = studio.toast {
                VStack {
                    Spacer()
                    Text(toast)
                        .font(.system(size: 13, weight: .semibold))
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(.ultraThinMaterial, in: Capsule())
                        .padding(.bottom, showTimeline ? 205 : 18)
                        .onAppear {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                                if studio.toast == toast {
                                    studio.toast = nil
                                }
                            }
                        }
                }
            }
        }
        .overlayPreferenceValue(StudioTooltipPreferenceKey.self) { tips in
            GeometryReader { proxy in
                if let tip = tips.last {
                    let rect = proxy[tip.anchor]
                    let tooltipX = min(max(rect.midX, 78), max(78, proxy.size.width - 78))
                    let showBelow = rect.midY < proxy.size.height * 0.72
                    Text(tip.title)
                        .environment(\.layoutDirection, studio.appLanguage.direction)
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                        .fixedSize(horizontal: true, vertical: false)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 7)
                        .background(
                            Color(red: 0.055, green: 0.075, blue: 0.105).opacity(0.98),
                            in: RoundedRectangle(cornerRadius: 8, style: .continuous)
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 8, style: .continuous)
                                .stroke(Color.white.opacity(0.16), lineWidth: 1)
                        )
                        .shadow(radius: 5, y: 2)
                        .position(
                            x: tooltipX,
                            y: showBelow ? rect.maxY + 24 : rect.minY - 24
                        )
                        .allowsHitTesting(false)
                        .zIndex(100_000)
                }
            }
            // Anchor coordinates and .position(x:y:) must stay in one physical
            // left-to-right coordinate space. Otherwise RTL mirrors the tooltip
            // away from the control that is actually under the pointer.
            .environment(\.layoutDirection, .leftToRight)
            .allowsHitTesting(false)
        }
        .background(GeometryReader { proxy in
            Color.clear.onAppear { availableWidth = proxy.size.width }
                .onChange(of: proxy.size.width) { _, width in availableWidth = width }
        })
        .environment(\.locale, studio.appLanguage.locale)
        .environment(\.layoutDirection, studio.appLanguage.direction)
        .sheet(isPresented: Binding(get: { compact && showLeftPanel }, set: { showLeftPanel = $0 })) {
            NavigationStack {
                HierarchyPanel().navigationTitle(studio.appLanguage == .arabic ? "المشهد" : "Scene")
                    .toolbar { ToolbarItem(placement: .confirmationAction) { Button(studio.appLanguage == .arabic ? "تم" : "Done") { showLeftPanel = false } } }
            }.environmentObject(studio).presentationDetents([.medium, .large])
        }
        .sheet(isPresented: Binding(get: { compact && showRightPanel }, set: { showRightPanel = $0 })) {
            NavigationStack {
                InspectorPanel().navigationTitle(studio.appLanguage == .arabic ? "الأدوات" : "Tools")
                    .toolbar { ToolbarItem(placement: .confirmationAction) { Button(studio.appLanguage == .arabic ? "تم" : "Done") { showRightPanel = false } } }
            }.environmentObject(studio).presentationDetents([.medium, .large])
        }
        .onChange(of: compact) { _, value in
            if value { showLeftPanel = false; showRightPanel = false }
        }
        // Export a real .3dmotion URL. A FileDocument exporter may fall back to
        // .data when the host Playgrounds app has not registered our UTType.
        .fileImporter(isPresented: $showPortableImport, allowedContentTypes: [.item, .data]) { result in
            do {
                let url = try result.get()
                let scoped = url.startAccessingSecurityScopedResource()
                defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                let data = try Data(contentsOf: url)
                try studio.importPortableProject(data)
                showProjectLibrary = false
            } catch { studio.toast = "تعذر فتح المشروع: \(error.localizedDescription)" }
        }
        .fileImporter(
            isPresented: $studio.isImporterPresented,
            allowedContentTypes: [.item],
            allowsMultipleSelection: true
        ) { result in
            switch result {
            case .success(let urls):
                studio.importFiles(urls)
            case .failure(let error):
                studio.importerMessage = error.localizedDescription
            }
        }
        .fileImporter(
            isPresented:
                $studio.isAudioImporterPresented,
            allowedContentTypes: [.audio],
            allowsMultipleSelection: true
        ) { result in
            switch result {
            case .success(let urls):
                studio.importAudioFiles(urls)

            case .failure(let error):
                studio.toast =
                    error.localizedDescription
            }
        }
        .fileImporter(
            isPresented: $studio.isVideoImporterPresented,
            allowedContentTypes: [.movie],
            allowsMultipleSelection: true
        ) { result in
            switch result {
            case .success(let urls):
                studio.importVideoFiles(urls)
            case .failure(let error):
                studio.toast = error.localizedDescription
            }
        }
        .alert(studio.appLanguage == .arabic ? "الاستيراد" : "Import", isPresented: Binding(
            get: { !studio.importerMessage.isEmpty },
            set: { if !$0 { studio.importerMessage = "" } }
        )) {
            Button("OK") { studio.importerMessage = "" }
        } message: {
            Text(ProductInterfaceText.message(studio.importerMessage, arabic: studio.appLanguage == .arabic))
        }
        .confirmationDialog(
            studio.appLanguage == .arabic ? "الخروج من المشروع" : "Exit Project",
            isPresented: $showExitConfirmation,
            titleVisibility: .visible
        ) {
            Button(studio.appLanguage == .arabic ? "حفظ والخروج" : "Save & Exit") {
                studio.stopPlayback()
                if studio.saveNamedProject() { showProjectLibrary = true }
            }
            Button(
                studio.appLanguage == .arabic ? "خروج بدون حفظ" : "Exit Without Saving",
                role: .destructive
            ) {
                studio.stopPlayback()
                showProjectLibrary = true
            }
            Button(studio.appLanguage == .arabic ? "إلغاء" : "Cancel", role: .cancel) {}
        } message: {
            Text(studio.appLanguage == .arabic
                 ? "يمكنك حفظ المشروع قبل الرجوع إلى قائمة المشاريع."
                 : "You can save the project before returning to the project library.")
        }
        .fullScreenCover(isPresented: $showProjectLibrary) {
            ProjectLibraryView(isPresented: $showProjectLibrary).environmentObject(studio)
        }
        .sheet(isPresented: $showAddMenu) {
            AddObjectSheet()
                .presentationDetents([.medium])
                .environmentObject(studio)
        }
        .sheet(isPresented: $showTextEditor) {
            TextStudioSheet(editingSelected: true)
                .environmentObject(studio)
                .presentationDetents([.large])
        }
        .sheet(isPresented: $showSettings) {
            StudioSettingsSheet()
                .environmentObject(studio)
                .presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $studio.isImportMonitorPresented) {
            ImportMonitorSheet()
                .environmentObject(studio)
                .presentationDetents([.medium, .large])
        }
        // Reset every held/continuous viewport control as soon as iOS starts
        // deactivating the app. A DragGesture is not guaranteed to deliver
        // onEnded when the user goes Home / switches apps while still touching.
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willResignActiveNotification)) { _ in
            studio.cancelContinuousViewportInput()
            studio.scnView?.isPlaying = false
        }
        .onReceive(
            NotificationCenter.default.publisher(
                for: UIApplication.didEnterBackgroundNotification
            )
        ) { _ in
            studio.cancelContinuousViewportInput()
            studio.stopPlayback()
            studio.scnView?.isPlaying = false
            studio.saveAutosave(showToast: false, force: true)
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
            studio.scnView?.isPlaying = true
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didReceiveMemoryWarningNotification)) { _ in
            studio.handleMemoryPressure()
        }
        .onAppear { presentIncomingProjectIfNeeded() }
        .onChange(of: incomingProjectURL) { _, _ in presentIncomingProjectIfNeeded() }
        .onChange(of: studio.audioAssets.count) { oldCount, newCount in
            if newCount > oldCount && !compact { showLeftPanel = true }
        }
        .confirmationDialog(
            studio.appLanguage == .arabic ? "فتح مشروع من تطبيق الملفات" : "Open project from Files",
            isPresented: $showIncomingProjectConfirmation,
            titleVisibility: .visible
        ) {
            Button(studio.appLanguage == .arabic ? "حفظ العمل الحالي وفتح الملف" : "Save current work and open") {
                openIncomingProject(savingCurrent: true)
            }
            Button(studio.appLanguage == .arabic ? "فتح دون حفظ العمل الحالي" : "Open without saving current work", role: .destructive) {
                openIncomingProject(savingCurrent: false)
            }
            Button(studio.appLanguage == .arabic ? "إلغاء" : "Cancel", role: .cancel) { incomingProjectURL = nil }
        } message: {
            Text(incomingProjectURL?.lastPathComponent ?? "")
        }
    }

    private func presentIncomingProjectIfNeeded() {
        guard incomingProjectURL != nil else { return }
        showProjectLibrary = false
        // Dismiss the library cover before presenting the document-open choices.
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            if incomingProjectURL != nil { showIncomingProjectConfirmation = true }
        }
    }

    private func openIncomingProject(savingCurrent: Bool) {
        guard let url = incomingProjectURL else { return }
        incomingProjectURL = nil
        studio.stopPlayback()
        if savingCurrent && !studio.saveNamedProject() { return }
        do {
            try studio.openProjectDocument(at: url)
            showProjectLibrary = false
        } catch {
            studio.toast = (studio.appLanguage == .arabic ? "تعذر فتح المشروع: " : "Could not open project: ") + error.localizedDescription
        }
    }

    private var topBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
        HStack(spacing: 8) {
            Button {
                showExitConfirmation = true
            } label: {
                Label(
                    studio.appLanguage == .arabic ? "خروج" : "Exit",
                    systemImage: "rectangle.portrait.and.arrow.forward"
                )
            }
            .buttonStyle(StudioToolbarButtonStyle())
            .disabled(studio.isExporting)
            .studioTooltip(studio.appLanguage == .arabic ? "الخروج إلى المشاريع" : "Exit to projects")

            Button {
                withAnimation(.easeInOut(duration: 0.2)) { showLeftPanel.toggle() }
            } label: {
                Image(systemName: "sidebar.left")
            }
            .buttonStyle(StudioToolbarButtonStyle())
            .studioTooltip(studio.appLanguage == .arabic ? "إظهار أو إخفاء قائمة المشهد" : "Toggle scene panel")

            HStack(spacing: 6) {
                Text("3D MOTION")
                    .font(.system(size: 15, weight: .heavy, design: .rounded))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.cyan, .blue, .purple, .pink],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )

                Text("24")
                    .font(.caption2.bold())
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(Color.white.opacity(0.08), in: Capsule())
            }
            .studioTooltip(studio.appLanguage == .arabic ? "اسم التطبيق ورقم الإصدار" : "App name and build number")

            Divider().frame(height: 22)

            HStack(spacing: 6) {
                Button { studio.undoLast() } label: {
                    Image(systemName: "arrow.uturn.backward")
                }
                .buttonStyle(StudioToolbarButtonStyle())
                .disabled(studio.undoCount == 0 || studio.isExporting)
                .opacity(studio.undoCount == 0 ? 0.42 : 1)
                .studioTooltip(studio.appLanguage == .arabic ? "تراجع" : "Undo")

                Button { studio.redoLast() } label: {
                    Image(systemName: "arrow.uturn.forward")
                }
                .buttonStyle(StudioToolbarButtonStyle())
                .disabled(studio.redoCount == 0 || studio.isExporting)
                .opacity(studio.redoCount == 0 ? 0.42 : 1)
                .studioTooltip(studio.appLanguage == .arabic ? "إعادة" : "Redo")
            }

            Spacer(minLength: 8)

            Button { showProjectLibrary = true } label: {
                Image(systemName: "square.grid.2x2")
            }.buttonStyle(StudioToolbarButtonStyle()).disabled(studio.isExporting).studioTooltip(studio.appLanguage == .arabic ? "المشاريع" : "Projects")

            Button { showAddMenu = true } label: {
                Label(studio.tr("add"), systemImage: "plus")
            }
            .buttonStyle(StudioToolbarButtonStyle())
            .disabled(studio.isExporting)
            .studioTooltip(studio.appLanguage == .arabic ? "إضافة عنصر" : "Add object")

            Button { studio.isImporterPresented = true } label: {
                Label(studio.tr("import"), systemImage: "square.and.arrow.down")
            }
            .buttonStyle(StudioToolbarButtonStyle())
            .disabled(studio.importIsRunning || studio.isExporting)
            .studioTooltip(studio.appLanguage == .arabic ? "استيراد ملفات" : "Import files")

            Button {
                showTimeline = true
                studio.isAudioImporterPresented = true
            } label: {
                Label(studio.appLanguage == .arabic ? "صوت" : "Audio", systemImage: "waveform")
            }
            .buttonStyle(StudioToolbarButtonStyle())
            .disabled(studio.isExporting)
            .studioTooltip(studio.appLanguage == .arabic ? "إضافة صوت" : "Add Audio")

            Button { studio.isVideoImporterPresented = true } label: {
                Label(studio.appLanguage == .arabic ? "فيديو" : "Video", systemImage: "film")
            }
            .buttonStyle(StudioToolbarButtonStyle())
            .disabled(studio.isExporting)
            .studioTooltip(studio.appLanguage == .arabic ? "إضافة فيديو" : "Add Video")

            Button { showPortableImport = true } label: { Image(systemName: "folder") }
                .buttonStyle(StudioToolbarButtonStyle())
                .disabled(studio.isExporting)
            .studioTooltip(studio.appLanguage == .arabic ? "فتح ملف مشروع محفوظ" : "Open project file")

            Button { studio.stopPlayback(); studio.saveNamedProject() } label: {
                Image(systemName: "tray.and.arrow.down")
            }.buttonStyle(StudioToolbarButtonStyle())
                .accessibilityLabel(studio.appLanguage == .arabic ? "حفظ المشروع" : "Save project")
                .studioTooltip(studio.appLanguage == .arabic ? "حفظ المشروع" : "Save project")
                .disabled(studio.importIsRunning || studio.isAutosaving || studio.isExporting)

            Button { showExportPanel = true } label: {
                Image(systemName: "square.and.arrow.up")
            }
            .buttonStyle(StudioToolbarButtonStyle())
            .accessibilityLabel(studio.appLanguage == .arabic ? "تصدير" : "Export")
            .studioTooltip(studio.appLanguage == .arabic ? "تصدير المشروع أو الفيديو" : "Export project or video")
            .popover(isPresented: $showExportPanel) {
                StudioExportPopover()
                    .environmentObject(studio)
                    .frame(width: 420, height: 480)
                    .presentationCompactAdaptation(.popover)
            }

            if !showTimeline {
            Button {
                showTimeline = true
                studio.togglePlayback()
            } label: {
                Image(systemName: studio.isPlaying ? "pause.fill" : "play.fill")
            }.buttonStyle(StudioToolbarButtonStyle())
                .disabled(studio.importIsRunning || studio.isExporting)
                .studioTooltip(studio.appLanguage == .arabic ? (studio.isPlaying ? "إيقاف التشغيل مؤقتًا" : "تشغيل") : (studio.isPlaying ? "Pause" : "Play"))

            }

            // Only secondary actions remain in the overflow menu. The actions used
            // while editing are pinned to the viewport edge so they are always visible.
            Menu {
                Button { showLeftPanel = false; showRightPanel = false; showTimeline = false } label: {
                    Label(studio.appLanguage == .arabic ? "تركيز مساحة العمل" : "Focus Workspace", systemImage: "arrow.up.left.and.arrow.down.right")
                }
                Button {
                    showTimeline = true
                    showLeftPanel = false
                    showRightPanel = !compact
                    studio.activeInspector = .animation
                } label: {
                    Label(studio.appLanguage == .arabic ? "مساحة التحريك" : "Animate Workspace", systemImage: "figure.run")
                }
                Button { studio.performanceMode.toggle() } label: {
                    Label(studio.appLanguage == .arabic ? "الأداء" : "Performance", systemImage: studio.performanceMode ? "bolt.fill" : "bolt")
                }
                Button { studio.saveSnapshotToPhotos() } label: {
                    Label(studio.appLanguage == .arabic ? "صورة للمشهد" : "Snapshot", systemImage: "camera")
                }
            } label: {
                Image(systemName: "ellipsis.circle")
            }
            .buttonStyle(StudioToolbarButtonStyle())
            .studioTooltip(studio.appLanguage == .arabic ? "المزيد من الأدوات" : "More tools")

            Button {
                withAnimation(.easeInOut(duration: 0.2)) { showRightPanel.toggle() }
            } label: {
                Image(systemName: "sidebar.right")
            }
            .buttonStyle(StudioToolbarButtonStyle())
            .studioTooltip(studio.appLanguage == .arabic ? "إظهار أو إخفاء لوحة الأدوات" : "Toggle tools panel")
        }
        .font(.system(size: 13, weight: .semibold))
        .padding(.horizontal, 10)
        .frame(height: 44)
        }
        // Keep the margin neutral; only the quick-tools cluster is blue.
        .background(Color(red: 0.085, green: 0.115, blue: 0.155).opacity(0.98))
        .environment(\.layoutDirection, .leftToRight)
    }

    private var quickToolsBar: some View {
        HStack(spacing: 9) {
            ViewportRoundButton(
                icon: "scope",
                title: studio.appLanguage == .arabic ? "تركيز على المحدد" : "Focus Selected"
            ) {
                studio.revealAndFrameSelected()
            }

            ViewportRoundButton(
                icon: studio.boxSelectionEnabled ? "rectangle.dashed.badge.record" : "rectangle.dashed",
                title: studio.appLanguage == .arabic ? "تحديد مربع" : "Box Select",
                active: studio.boxSelectionEnabled
            ) {
                studio.boxSelectionEnabled.toggle()
                studio.statusText = studio.boxSelectionEnabled
                    ? (studio.appLanguage == .arabic ? "تحديد مربع مفعّل" : "Box Select On")
                    : (studio.appLanguage == .arabic ? "تحديد مربع متوقف" : "Box Select Off")
            }

            ViewportRoundButton(
                icon: "trash",
                title: studio.appLanguage == .arabic ? "حذف المحدد" : "Delete Selected",
                destructive: true
            ) {
                studio.deleteSelected()
            }
            .disabled(studio.selectedNode == nil && studio.multiSelectedNodes.isEmpty)

            ViewportRoundButton(
                icon: "viewfinder",
                title: studio.appLanguage == .arabic ? "إظهار كل العناصر" : "Frame All"
            ) {
                studio.frameAllObjects()
            }

            ViewportRoundButton(
                icon: "timeline.selection",
                title: studio.appLanguage == .arabic ? "الخط الزمني" : "Timeline",
                active: showTimeline
            ) {
                withAnimation(.easeInOut(duration: 0.2)) { showTimeline.toggle() }
            }

            ViewportRoundButton(
                icon: "slider.horizontal.3",
                title: studio.appLanguage == .arabic ? "إعدادات المنظور" : "Viewport Settings"
            ) {
                showViewportSettings = true
            }
            .popover(isPresented: $showViewportSettings) {
                ViewportSettingsPopover()
                    .environmentObject(studio)
                    .frame(width: 390, height: 560)
                    .presentationCompactAdaptation(.popover)
            }

            ViewportRoundButton(
                icon: "gearshape",
                title: studio.appLanguage == .arabic ? "الإعدادات" : "Settings"
            ) {
                showSettings = true
            }
        }
    }

    // Move / Rotate / Scale belong to the scene itself rather than the global
    // app toolbar. Keeping them on the physical left edge makes the transform
    // controls immediately reachable without consuming horizontal top-bar space.
    private var transformToolsOverlay: some View {
        VStack(alignment: .leading, spacing: 8) {
            ToolModeButton(icon: "move.3d", title: studio.tr("move"), mode: .move)
            ToolModeButton(icon: "rotate.3d", title: studio.tr("rotate"), mode: .rotate)
            ToolModeButton(icon: "arrow.up.left.and.down.right.magnifyingglass", title: studio.tr("scale"), mode: .scale)

            if studio.transformMode == .scale && studio.viewportInteractionMode == .object {
                Divider()
                    .frame(width: 38)
                    .overlay(Color.white.opacity(0.10))

                HStack(spacing: 5) {
                    Button { studio.nudgeSelectedScale(-1) } label: {
                        Image(systemName: "minus")
                    }
                    .buttonStyle(StudioToolbarButtonStyle())
                    .disabled(studio.selectedNode == nil)
                    .studioTooltip(studio.appLanguage == .arabic ? "تصغير العنصر" : "Scale down")

                    Button { studio.nudgeSelectedScale(1) } label: {
                        Image(systemName: "plus")
                    }
                    .buttonStyle(StudioToolbarButtonStyle())
                    .disabled(studio.selectedNode == nil)
                    .studioTooltip(studio.appLanguage == .arabic ? "تكبير العنصر" : "Scale up")

                    Button { studio.resetSelectedScaleOnly() } label: {
                        Image(systemName: "arrow.counterclockwise")
                    }
                    .buttonStyle(StudioToolbarButtonStyle())
                    .disabled(studio.selectedNode == nil)
                    .studioTooltip(studio.appLanguage == .arabic ? "إعادة الحجم" : "Reset scale")
                }
            }
        }
        .fixedSize()
        .environment(\.layoutDirection, .leftToRight)
    }

    private var viewport: some View {
        ZStack(alignment: .topLeading) {
            SceneKitViewport()
                .environmentObject(studio)


            if studio.boxSelectionEnabled {
                BoxSelectionOverlay()
                    .environmentObject(studio)
                    // Scene-space gestures must never inherit Arabic RTL mirroring.
                    .environment(\.layoutDirection, .leftToRight)
            }

            // Navigation HUD uses absolute viewport coordinates. It is intentionally
            // LTR even when the app language is RTL, so saved control positions never
            // mirror or move when Arabic/English/Russian/Chinese is selected.
            GeometryReader { hudProxy in
                let h = hudProxy.size.height
                let w = hudProxy.size.width
                let layout = ViewportControlLayout(size: hudProxy.size,
                    joystickSize: CGFloat(studio.controlJoystickSize),
                    joystickOffset: CGPoint(x: studio.joystickOffsetX, y: studio.joystickOffsetY),
                    scaleTools: studio.transformMode == .scale && studio.viewportInteractionMode == .object)
                let joySize = CGFloat(studio.controlJoystickSize)

                ScrollView(.vertical, showsIndicators: false) {
                    transformToolsOverlay
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .frame(width: layout.tools.width, height: layout.tools.height)
                .position(x: layout.tools.midX, y: layout.tools.midY)

                CameraJoystick()
                    .environmentObject(studio)
                    .frame(width: joySize, height: joySize)
                    .scaleEffect(layout.joystick.width / joySize)
                    .position(x: layout.joystick.midX, y: layout.joystick.midY)

                ViewportZoomSlider()
                    .environmentObject(studio)
                    .scaleEffect(studio.zoomControlScale)
                    .position(
                        x: w - 126 + CGFloat(studio.zoomOffsetX),
                        y: h - 110 + CGFloat(studio.zoomOffsetY)
                    )

                CameraVerticalButton(icon: "chevron.up", value: 1)
                    .environmentObject(studio)
                    .position(
                        x: w - 58 + CGFloat(studio.verticalOffsetX + studio.upOffsetX),
                        y: h - 126 + CGFloat(studio.verticalOffsetY + studio.upOffsetY)
                    )

                CameraVerticalButton(icon: "chevron.down", value: -1)
                    .environmentObject(studio)
                    .position(
                        x: w - 58 + CGFloat(studio.verticalOffsetX + studio.downOffsetX),
                        y: h - 68 + CGFloat(studio.verticalOffsetY + studio.downOffsetY)
                    )
            }
            .environment(\.layoutDirection, .leftToRight)
            .zIndex(50)

            if studio.showViewportStatistics {
                ViewportStatisticsOverlay()
                    .environmentObject(studio)
                    .padding(.leading, 12)
                    .padding(.top, 74)
            }

            HStack(spacing: 7) {
                Menu {
                    ForEach(ViewportShadingMode.allCases, id: \.self) { mode in
                        Button {
                            studio.viewportShadingMode = mode
                            studio.applyViewportSettings()
                        } label: {
                            Label(mode.title, systemImage: mode.icon)
                        }
                    }
                } label: {
                    Image(systemName: studio.viewportShadingMode.icon)
                        .frame(width: 32, height: 32)
                        .background(Color.black.opacity(0.30), in: Circle())
                }
                .studioTooltip(studio.appLanguage == .arabic ? "نمط عرض المشهد" : "Viewport shading")

                Button { showSceneEnvironment.toggle() } label: {
                    Image(systemName: "photo.on.rectangle.angled")
                        .frame(width: 32, height: 32)
                        .background(Color.black.opacity(0.30), in: Circle())
                }
                .buttonStyle(.plain)
                .studioTooltip(studio.appLanguage == .arabic ? "بيئة المشهد والخلفية" : "Scene environment")
                .popover(isPresented: $showSceneEnvironment) {
                    SceneEnvironmentPopover()
                        .environmentObject(studio)
                        .frame(width: 420, height: 600)
                        .presentationCompactAdaptation(.popover)
                }

            }
            .padding(.top, 10)
            .padding(.leading, 190)

            VStack(alignment: .leading, spacing: 6) {
                Text(studio.selectedName)
                    .font(.system(size: 12, weight: .semibold))
                Text(ProductInterfaceText.message(studio.statusText, arabic: studio.appLanguage == .arabic))
                    .font(.system(size: 10))
                    .foregroundStyle(.secondary)
            }
            .padding(10)
            .background(Color(red: 0.18, green: 0.18, blue: 0.20).opacity(0.92), in: RoundedRectangle(cornerRadius: 10))
            .padding(10)

            // Camera preview is intentionally explicit and always visible when a camera
            // node is selected. This keeps camera workflow simple: select camera -> view.
            if studio.selectedNode?.camera != nil {
                Button {
                    studio.toggleSelectedCameraView()
                } label: {
                    Label(
                        studio.isUsingSelectedCamera ? (studio.appLanguage == .arabic ? "منظور المحرر" : "Editor View") : (studio.appLanguage == .arabic ? "منظور الكاميرا" : "Camera View"),
                        systemImage: studio.isUsingSelectedCamera ? "rectangle.on.rectangle.slash" : "video.fill"
                    )
                    .font(.system(size: 12, weight: .bold))
                    .padding(.horizontal, 12)
                    .frame(height: 34)
                    .background(studio.isUsingSelectedCamera ? Color.orange.opacity(0.88) : Color.cyan.opacity(0.88), in: Capsule())
                    .foregroundStyle(.black)
                }
                .buttonStyle(.plain)
                .studioTooltip(studio.appLanguage == .arabic ? "التبديل بين منظور الكاميرا والمحرر" : "Toggle camera/editor view")
                .padding(.top, 62)
                .padding(.leading, 10)
                .zIndex(80)
            }

            // Grid and axes stay on the lower-left scene edge. The main quick
            // tools now live inside the upper margin above the viewport.
            GeometryReader { toolProxy in
                VStack(spacing: 9) {
                    ViewportRoundButton(
                        icon: "square.grid.3x3",
                        title: studio.appLanguage == .arabic ? "الشبكة" : "Grid",
                        active: studio.showGrid
                    ) {
                        studio.showGrid.toggle()
                        studio.rebuildHelpers()
                    }

                    ViewportRoundButton(
                        icon: "move.3d",
                        title: studio.appLanguage == .arabic ? "المحاور" : "Axes",
                        active: studio.showAxes
                    ) {
                        studio.showAxes.toggle()
                        studio.rebuildHelpers()
                    }
                }
                .environment(\.layoutDirection, .leftToRight)
                .position(x: 32, y: max(110, toolProxy.size.height - 290))
                .zIndex(90)
            }
            .environment(\.layoutDirection, .leftToRight)
            .zIndex(90)
        }
    }
}

@MainActor
struct SceneEnvironmentPopover: View {
    @EnvironmentObject var studio: StudioStore
    @State private var photoItem: PhotosPickerItem?

    private let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]

    var body: some View {
        let currentEnvironmentPreset = studio.environmentPreset
        let currentCustomEnvironmentImage = studio.customEnvironmentImage

        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    LazyVGrid(columns: columns, spacing: 12) {
                        ForEach(SceneEnvironmentPreset.allCases.filter { $0 != .custom }, id: \.self) { preset in
                            environmentCard(preset)
                        }

                        PhotosPicker(
                            selection: $photoItem,
                            matching: .images
                        ) {
                            VStack(spacing: 7) {
                                RoundedRectangle(cornerRadius: 10)
                                    .fill(
                                        LinearGradient(
                                            colors: [.gray.opacity(0.35), .black.opacity(0.35)],
                                            startPoint: .top,
                                            endPoint: .bottom
                                        )
                                    )
                                    .frame(height: 74)
                                    .overlay {
                                        if let image = currentCustomEnvironmentImage {
                                            Image(uiImage: image)
                                                .resizable()
                                                .scaledToFill()
                                                .clipShape(RoundedRectangle(cornerRadius: 10))
                                        } else {
                                            Image(systemName: "photo.badge.plus")
                                                .font(.title2)
                                        }
                                    }

                                Text("Custom")
                                    .font(.caption.bold())
                            }
                            .padding(7)
                            .background(
                                currentEnvironmentPreset == .custom
                                    ? Color.accentColor.opacity(0.22)
                                    : Color.white.opacity(0.04),
                                in: RoundedRectangle(cornerRadius: 12)
                            )
                        }
                        .buttonStyle(.plain)
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Text("Environment Intensity")
                            .font(.caption.bold())

                        HStack {
                            Slider(
                                value: $studio.environmentIntensity,
                                in: 0...3
                            )
                            .onChange(of: studio.environmentIntensity) { _, _ in
                                studio.applySceneEnvironment()
                            }

                            Text(String(format: "%.2f", studio.environmentIntensity))
                                .font(.caption.monospacedDigit())
                                .frame(width: 42)
                        }
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Text(studio.appLanguage == .arabic ? "لون مساحة العمل" : "Workspace Background").font(.caption.bold())
                        HStack {
                            ForEach(0..<6, id: \.self) { index in
                                Button { studio.setViewportBackground(index) } label: {
                                    Circle().fill([Color(white:0.12), .black, Color(white:0.22), Color(white:0.55), Color(white:0.92), Color(red:0.035, green:0.07, blue:0.13)][index]).frame(width: 28, height: 28).overlay(Circle().stroke(studio.viewportBackgroundIndex == index ? Color.accentColor : .clear, lineWidth: 3))
                                }.buttonStyle(.plain)
                            }
                        }
                    }

                }
                .padding()
            }
            .navigationTitle(studio.appLanguage == .arabic ? "خلفية المشهد" : "Scene Background")
            .onChange(of: photoItem) { _, newItem in
                guard let newItem else { return }

                Task { @MainActor in
                    if let data = try? await newItem.loadTransferable(type: Data.self),
                       let image = UIImage(data: data) {
                        studio.setCustomEnvironmentImage(image)
                    }
                }
            }
        }
    }

    @ViewBuilder
    private func environmentCard(
        _ preset: SceneEnvironmentPreset
    ) -> some View {
        let isSelected = studio.environmentPreset == preset

        Button {
            studio.setEnvironmentPreset(preset)
        } label: {
            VStack(spacing: 7) {
                RoundedRectangle(cornerRadius: 10)
                    .fill(previewGradient(for: preset))
                    .frame(height: 74)
                    .overlay(alignment: .topTrailing) {
                        if isSelected {
                            Image(systemName: "checkmark.circle.fill")
                                .padding(6)
                        }
                    }

                Text(preset.title)
                    .font(.caption.bold())
            }
            .padding(7)
            .background(
                isSelected
                    ? Color.accentColor.opacity(0.22)
                    : Color.white.opacity(0.04),
                in: RoundedRectangle(cornerRadius: 12)
            )
        }
        .buttonStyle(.plain)
    }

    private func previewGradient(
        for preset: SceneEnvironmentPreset
    ) -> LinearGradient {
        let colors: [Color]

        switch preset {
        case .none:
            colors = [.gray.opacity(0.45), .gray.opacity(0.22)]
        case .day:
            colors = [.blue.opacity(0.65), .white.opacity(0.88)]
        case .sunset:
            colors = [.purple.opacity(0.65), .orange.opacity(0.85)]
        case .overcast:
            colors = [.gray.opacity(0.72), .gray.opacity(0.35)]
        case .night:
            colors = [.black, .blue.opacity(0.28)]
        case .custom:
            colors = [.gray, .black]
        }

        return LinearGradient(
            colors: colors,
            startPoint: .top,
            endPoint: .bottom
        )
    }
}


@MainActor
struct StudioExportPopover: View {
    @EnvironmentObject var studio: StudioStore
    @State private var exportedURL: URL?
    @State private var videoResolution: StudioVideoResolution = .p1080
    @State private var videoFPS: Int = 30

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text(studio.appLanguage == .arabic ? "تصدير المشروع" : "Project Export")
                        .font(.headline)

                    Button {
                        exportedURL = studio.exportProjectFile()
                    } label: {
                        Label(
                            studio.appLanguage == .arabic ? "تصدير المشروع (.3dmotion)" : "Export Project (.3dmotion)",
                            systemImage: "square.and.arrow.up"
                        )
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(studio.isExporting)

                    Button {
                        exportedURL = studio.exportSceneFile()
                    } label: {
                        Label(studio.appLanguage == .arabic ? "مشهد ثلاثي الأبعاد (.scn)" : "3D scene (.scn)", systemImage: "cube")
                    }
                    .buttonStyle(.bordered)
                    .disabled(studio.isExporting)

                    if let exportedURL {
                        ShareLink(item: exportedURL) {
                            Label(
                                studio.appLanguage == .arabic ? "مشاركة أو حفظ في الملفات" : "Share / Save to Files",
                                systemImage: "folder.badge.plus"
                            )
                        }
                        .buttonStyle(.bordered)
                    }

                    Divider()

                    Text(studio.appLanguage == .arabic ? "تصدير فيديو" : "Video Export")
                        .font(.headline)

                    Picker(studio.appLanguage == .arabic ? "الدقة" : "Resolution", selection: $videoResolution) {
                        ForEach(StudioVideoResolution.allCases) { value in
                            Text(value.rawValue).tag(value)
                        }
                    }
                    .pickerStyle(.segmented)
                    .disabled(studio.isExporting)

                    Picker(studio.appLanguage == .arabic ? "الإطارات" : "FPS", selection: $videoFPS) {
                        ForEach(StudioVideoExportOptions.frameRates, id: \.self) { value in
                            Text("\(value)").tag(value)
                        }
                    }
                    .pickerStyle(.segmented)
                    .disabled(studio.isExporting)

                    Text(String(format: studio.appLanguage == .arabic ? "مدة التصدير: %.2f ثانية، مع صوت المشروع" : "Export duration: %.2fs, including project audio", studio.duration))
                        .font(.caption).foregroundStyle(.secondary)

                    Button {
                        studio.exportVideo(resolution: videoResolution, exportFPS: videoFPS)
                    } label: {
                        Label(
                            studio.isExporting
                                ? (studio.appLanguage == .arabic ? "جاري التصدير…" : "Rendering…")
                                : (studio.appLanguage == .arabic ? "تصدير الفيديو" : "Export Video"),
                            systemImage: "film"
                        )
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(studio.isExporting || studio.importIsRunning)

                    if studio.isExporting {
                        ProgressView(value: studio.exportProgress)
                        HStack {
                            Text("\(Int(studio.exportProgress * 100))%")
                                .font(.caption.monospacedDigit())
                            Spacer()
                            Button(role: .destructive) {
                                studio.cancelVideoExport()
                            } label: {
                                Label(
                                    studio.appLanguage == .arabic ? "إلغاء" : "Cancel",
                                    systemImage: "xmark.circle.fill"
                                )
                            }
                            .buttonStyle(.bordered)
                        }
                    }

                    if let videoURL = studio.exportedVideoURL {
                        ShareLink(item: videoURL) {
                            Label(
                                studio.appLanguage == .arabic ? "مشاركة الفيديو" : "Share Video",
                                systemImage: "square.and.arrow.up"
                            )
                        }
                        .buttonStyle(.bordered)
                    }
                }
                .padding()
            }
            .navigationTitle(studio.appLanguage == .arabic ? "التصدير" : "Export")
        }
    }
}


@MainActor
struct ViewportStatisticsOverlay: View {
    @EnvironmentObject var studio: StudioStore

    var body: some View {
        let stats = studio.viewportStatistics()

        VStack(alignment: .leading, spacing: 2) {
            stat("Objects", stats.objects)
            stat("Vertices", stats.vertices)
            stat("Edges", stats.edges)
            stat("Faces", stats.faces)
            stat("Triangles", stats.triangles)
            stat("Textures", stats.textures)
        }
        .font(.system(size: 9.5, design: .monospaced))
        .foregroundStyle(.white.opacity(0.88))
        .padding(8)
        .background(
            Color.black.opacity(0.22),
            in: RoundedRectangle(cornerRadius: 8)
        )
        .allowsHitTesting(false)
    }

    private func stat(_ name: String, _ value: Int) -> some View {
        HStack(spacing: 12) {
            Text(name)
                .frame(width: 62, alignment: .leading)
            Text("\(value)")
                .frame(minWidth: 44, alignment: .trailing)
        }
    }
}

@MainActor
struct ViewportSettingsPopover: View {
    @EnvironmentObject var studio: StudioStore

    var body: some View {
        NavigationStack {
            Form {
                Section("DISPLAY") {
                    Toggle("Show grid", isOn: $studio.showGrid)
                        .onChange(of: studio.showGrid) { _, _ in
                            studio.rebuildHelpers()
                        }

                    Toggle("Show axes", isOn: $studio.showAxes)
                        .onChange(of: studio.showAxes) { _, _ in
                            studio.rebuildHelpers()
                        }

                    Toggle("Show statistics", isOn: $studio.showViewportStatistics)

                    Toggle("Backface culling", isOn: $studio.backfaceCullingEnabled)
                        .onChange(of: studio.backfaceCullingEnabled) { _, _ in
                            studio.applyViewportSettings()
                        }

                    HStack {
                        Text("Grid cell")
                        Slider(value: $studio.gridSpacing, in: 0.05...10)
                            .onChange(of: studio.gridSpacing) { _, _ in
                                studio.rebuildHelpers()
                            }
                        Text(String(format: "%.2f", studio.gridSpacing))
                            .font(.caption.monospacedDigit())
                            .frame(width: 42)
                    }
                }

                Section("SHADING") {
                    Picker("Mode", selection: $studio.viewportShadingMode) {
                        ForEach(ViewportShadingMode.allCases, id: \.self) { mode in
                            Label(mode.title, systemImage: mode.icon)
                                .tag(mode)
                        }
                    }
                    .pickerStyle(.segmented)
                    .onChange(of: studio.viewportShadingMode) { _, _ in
                        studio.applyViewportSettings()
                    }
                }

                Section("LIGHTING") {
                    HStack {
                        Text("Ambient")
                        Slider(value: $studio.ambientStrength, in: 0...1600)
                            .onChange(of: studio.ambientStrength) { _, _ in
                                studio.applyViewportSettings()
                            }
                        Text("\(Int(studio.ambientStrength))")
                            .font(.caption.monospacedDigit())
                            .frame(width: 42)
                    }

                    Picker("Lights", selection: $studio.viewportLightCount) {
                        Text("1").tag(1)
                        Text("2").tag(2)
                        Text("3").tag(3)
                    }
                    .pickerStyle(.segmented)
                    .onChange(of: studio.viewportLightCount) { _, _ in
                        studio.applyViewportSettings()
                    }

                    viewportSlider(
                        "Key",
                        value: $studio.viewportKeyStrength,
                        range: 0...1.5
                    )

                    viewportSlider(
                        "Fill",
                        value: $studio.viewportFillStrength,
                        range: 0...1.5
                    )

                    viewportSlider(
                        "Rim",
                        value: $studio.viewportRimStrength,
                        range: 0...1.5
                    )

                    viewportSlider(
                        "Specular",
                        value: $studio.viewportSpecularStrength,
                        range: 0...1
                    )

                    viewportSlider(
                        "Highlight size",
                        value: $studio.viewportHighlightSize,
                        range: 1...128
                    )
                }
            }
            .navigationTitle("Viewport")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Reset") {
                        studio.resetViewportSettings()
                    }
                }
            }
        }
    }

    private func viewportSlider(
        _ title: String,
        value: Binding<Double>,
        range: ClosedRange<Double>
    ) -> some View {
        HStack {
            Text(title)
                .frame(width: 90, alignment: .leading)

            Slider(value: value, in: range)
                .onChange(of: value.wrappedValue) { _, _ in
                    studio.applyViewportSettings()
                }

            Text(String(format: "%.2f", value.wrappedValue))
                .font(.caption.monospacedDigit())
                .frame(width: 44)
        }
    }
}


@MainActor
private struct CameraJoystick: View {
    @EnvironmentObject var studio: StudioStore
    // `vector` is the finger target. `smoothedVector` follows it with a short,
    // frame-rate-independent acceleration/deceleration so walking is fluid rather
    // than jumping one fixed camera step for every timer tick.
    @State private var vector = CGVector.zero
    @State private var smoothedVector = CGVector.zero
    @State private var lastTick: TimeInterval = CACurrentMediaTime()
    @State private var layoutStart = CGSize.zero
    private let timer = Timer.publish(every: 1.0 / 60.0, on: .main, in: .common).autoconnect()

    var body: some View {
        let size = CGFloat(studio.controlJoystickSize)
        let knob = size * 0.40
        let radius = size * 0.33
        ZStack {
            Circle().fill(Color(red: 0.08, green: 0.13, blue: 0.19).opacity(0.86)).frame(width: size, height: size)
            Circle().stroke(.white.opacity(0.22), lineWidth: 1).frame(width: size, height: size)
            Circle().fill(.ultraThinMaterial).frame(width: knob, height: knob)
                .offset(x: vector.dx * radius, y: vector.dy * radius)
        }
        .opacity(studio.controlOpacity)
        .contentShape(Circle())
        .gesture(DragGesture(minimumDistance: 0)
            .onChanged { value in
                guard !studio.controlEditLayout else { return }
                let center = CGFloat(studio.controlJoystickSize) / 2
                let maxRadius = max(20, center * 0.80)
                let x = value.location.x - center
                let y = value.location.y - center
                let len = max(0.0001, sqrt(x*x + y*y))
                let clamped = min(len, maxRadius)
                let nx = x / len
                let ny = y / len
                // Small center dead-zone stops micro drift. Remap the remaining
                // travel back to 0...1, then apply a mild curve for fine walking.
                let rawMagnitude = clamped / maxRadius
                let deadZone: CGFloat = 0.075
                let remapped = rawMagnitude <= deadZone
                    ? 0
                    : (rawMagnitude - deadZone) / (1 - deadZone)
                let curved = pow(remapped, 1.12)
                vector = CGVector(dx: nx * curved, dy: ny * curved)
            }
            .onEnded { _ in
                vector = .zero
                smoothedVector = .zero
                lastTick = CACurrentMediaTime()
            })
        .onChange(of: studio.inputResetGeneration) { _, _ in
            vector = .zero
            smoothedVector = .zero
            lastTick = CACurrentMediaTime()
        }
        // iOS may cancel the touch without calling DragGesture.onEnded when the
        // app resigns active while the finger is still on the joystick. Clear
        // the local vector on every lifecycle edge so it can never remain stuck.
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willResignActiveNotification)) { _ in
            vector = .zero
            smoothedVector = .zero
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didEnterBackgroundNotification)) { _ in
            vector = .zero
            smoothedVector = .zero
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
            vector = .zero
            smoothedVector = .zero
            lastTick = CACurrentMediaTime()
        }
        .onReceive(timer) { _ in
            guard UIApplication.shared.applicationState == .active else { return }

            let now = CACurrentMediaTime()
            let dt = max(1.0 / 120.0, min(now - lastTick, 1.0 / 20.0))
            lastTick = now

            // Exponential smoothing is independent of actual timer cadence. It
            // reaches the target quickly (~0.12 s) without abrupt starts/stops.
            let alpha = 1.0 - exp(-16.0 * dt)
            smoothedVector.dx += (vector.dx - smoothedVector.dx) * alpha
            smoothedVector.dy += (vector.dy - smoothedVector.dy) * alpha

            if abs(smoothedVector.dx) < 0.002 && abs(smoothedVector.dy) < 0.002 &&
                abs(vector.dx) < 0.002 && abs(vector.dy) < 0.002 {
                smoothedVector = .zero
                return
            }

            studio.moveViewportCamera(
                strafe: Float(smoothedVector.dx),
                forward: Float(-smoothedVector.dy),
                vertical: 0,
                frameScale: Float(dt * 60.0)
            )
        }
        .onDisappear {
            vector = .zero
            smoothedVector = .zero
        }
        .accessibilityLabel(studio.appLanguage == .arabic ? "عصا تحريك المنظور" : "Camera movement joystick")
    }
}

@MainActor
private struct CameraVerticalButton: View {
    @EnvironmentObject var studio: StudioStore
    let icon: String
    let value: Float
    @State private var pressed = false
    private let timer = Timer.publish(every: 1.0 / 60.0, on: .main, in: .common).autoconnect()

    var body: some View {
        Image(systemName: icon)
            .font(.system(size: 17, weight: .bold))
            .frame(width: studio.controlButtonSize, height: studio.controlButtonSize)
            .background(.black.opacity(0.40), in: Circle())
            .opacity(studio.controlOpacity)
            .contentShape(Circle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { _ in
                        guard !studio.controlEditLayout else { return }
                        pressed = true
                    }
                    .onEnded { _ in pressed = false }
            )
            .onChange(of: studio.inputResetGeneration) { _, _ in pressed = false }
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.willResignActiveNotification)) { _ in
                pressed = false
            }
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.didEnterBackgroundNotification)) { _ in
                pressed = false
            }
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
                pressed = false
            }
            .onReceive(timer) { _ in
                guard UIApplication.shared.applicationState == .active else { return }
                guard pressed, !studio.controlEditLayout else { return }
                studio.moveViewportCamera(strafe: 0, forward: 0, vertical: value)
            }
            .onDisappear { pressed = false }
    }
}

@MainActor
private struct ViewportZoomSlider: View {
    @EnvironmentObject var studio: StudioStore
    @State private var lastTranslationY: CGFloat = 0
    @State private var filteredDeltaY: CGFloat = 0

    var body: some View {
        VStack(spacing: 5) {
            Image(systemName: "plus.magnifyingglass").font(.caption2)
            Capsule().fill(.white.opacity(0.16)).frame(width: 8, height: 104)
                .overlay(Capsule().fill(.white.opacity(0.55)).frame(width: 3, height: 82))
            Image(systemName: "minus.magnifyingglass").font(.caption2)
        }
        .padding(.vertical, 8).padding(.horizontal, 18)
        .background(.black.opacity(0.28), in: Capsule())
        .contentShape(Rectangle())
        .opacity(studio.controlOpacity)
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { value in
                    guard !studio.controlEditLayout else { return }
                    let rawDelta = value.translation.height - lastTranslationY
                    // Low-pass the finger delta and cap single-frame spikes. This
                    // keeps the dolly continuous even when SwiftUI delivers uneven
                    // drag samples on iPad.
                    let clamped = max(-7.0, min(7.0, rawDelta))
                    filteredDeltaY += (clamped - filteredDeltaY) * 0.32
                    if abs(filteredDeltaY) > 0.015 {
                        // Up = zoom in, down = zoom out.
                        studio.zoomViewportCamera(Float(-filteredDeltaY) * 0.065)
                    }
                    lastTranslationY = value.translation.height
                }
                .onEnded { _ in
                    lastTranslationY = 0
                    filteredDeltaY = 0
                }
        )
        .onChange(of: studio.inputResetGeneration) { _, _ in
            lastTranslationY = 0
            filteredDeltaY = 0
        }
        .onDisappear {
            lastTranslationY = 0
            filteredDeltaY = 0
        }
        .accessibilityLabel(studio.appLanguage == .arabic ? "تقريب وإبعاد المنظور" : "VIEW Zoom")
    }
}

@MainActor
private struct BoxSelectionOverlay: View {
    @EnvironmentObject var studio: StudioStore
    @State private var start: CGPoint?
    @State private var current: CGPoint?

    var body: some View {
        GeometryReader { _ in
            ZStack {
                Color.clear
                    .contentShape(Rectangle())

                if let a = start, let b = current {
                    let minX = min(a.x, b.x)
                    let minY = min(a.y, b.y)
                    let width = abs(b.x - a.x)
                    let height = abs(b.y - a.y)

                    Rectangle()
                        .fill(Color.accentColor.opacity(0.12))
                        .overlay(
                            Rectangle().stroke(
                                Color.accentColor,
                                style: StrokeStyle(lineWidth: 1.5, dash: [6, 4])
                            )
                        )
                        .frame(width: width, height: height)
                        // Center-based positioning is physical screen space and does not
                        // depend on leading/trailing, so Arabic can never mirror X.
                        .position(x: minX + width / 2, y: minY + height / 2)
                        .allowsHitTesting(false)
                }
            }
            .coordinateSpace(name: "StudioViewportPhysicalSpace")
            .environment(\.layoutDirection, .leftToRight)
            .gesture(
                DragGesture(minimumDistance: 3, coordinateSpace: .named("StudioViewportPhysicalSpace"))
                    .onChanged { value in
                        if start == nil { start = value.startLocation }
                        current = value.location
                    }
                    .onEnded { value in
                        let a = start ?? value.startLocation
                        let b = value.location
                        let rect = CGRect(
                            x: min(a.x, b.x),
                            y: min(a.y, b.y),
                            width: abs(b.x - a.x),
                            height: abs(b.y - a.y)
                        )
                        studio.selectNodes(inViewportRect: rect)
                        start = nil
                        current = nil
                        studio.boxSelectionEnabled = false
                    }
            )
        }
        .environment(\.layoutDirection, .leftToRight)
    }
}

// MARK: - Viewport

@MainActor
struct SceneKitViewport: UIViewRepresentable {
    @EnvironmentObject var studio: StudioStore
    // Only the real project viewport may become StudioStore.scnView. Preview/editor
    // viewports must never replace that weak reference, otherwise HUD controls
    // keep drawing but have no camera to control after the editor is dismissed.
    var registerAsPrimary: Bool = true

    func makeCoordinator() -> Coordinator {
        Coordinator(studio: studio)
    }

    func makeUIView(context: Context) -> SCNView {
        let view = SCNView(frame: CGRect.zero)
        view.scene = studio.scene
        view.backgroundColor = UIColor(white: 0.12, alpha: 1)
        view.antialiasingMode = .multisampling2X
        // The concrete screen is available after the view joins a window.
        // Start with a safe value and refresh it in updateUIView.
        view.preferredFramesPerSecond = 60
        view.rendersContinuously = false
        view.isPlaying = true
        view.autoenablesDefaultLighting = false
        view.allowsCameraControl = false
        view.showsStatistics = false

        if let camera = studio.projectOpeningCamera, camera.camera != nil {
            view.pointOfView = camera
        } else if let camera = studio.editorViewportCamera, camera.camera != nil {
            // Always start from the private editor camera so the origin/cube is
            // centered instead of falling back to SceneKit's implicit far view.
            view.pointOfView = camera
            camera.camera?.zNear = 0.01
            camera.camera?.zFar = 100_000
        } else if let camera = studio.camerasRoot.childNodes.first(where: { $0.camera != nil }) {
            view.pointOfView = camera
            camera.camera?.zNear = 0.01
            camera.camera?.zFar = 100_000
        }

        let tap = UITapGestureRecognizer(
            target: context.coordinator,
            action: #selector(Coordinator.handleTap(_:))
        )
        tap.numberOfTapsRequired = 1
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)

        let doubleTap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleDoubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        doubleTap.cancelsTouchesInView = false
        view.addGestureRecognizer(doubleTap)
        tap.require(toFail: doubleTap)

        let additiveTap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleAdditiveTap(_:)))
        additiveTap.numberOfTouchesRequired = 2
        additiveTap.numberOfTapsRequired = 1
        additiveTap.cancelsTouchesInView = false
        view.addGestureRecognizer(additiveTap)

        // One finger:
        // VIEW = look around in place
        // OBJECT = drag selected object / gizmo axis
        let oneFingerPan = UIPanGestureRecognizer(
            target: context.coordinator,
            action: #selector(Coordinator.handleOneFingerPan(_:))
        )
        oneFingerPan.minimumNumberOfTouches = 1
        oneFingerPan.maximumNumberOfTouches = 1
        oneFingerPan.cancelsTouchesInView = true
        view.addGestureRecognizer(oneFingerPan)
        tap.require(toFail: oneFingerPan)
        doubleTap.require(toFail: oneFingerPan)

        // Two fingers = free camera strafe/pan, never touches the model.
        let twoFingerPan = UIPanGestureRecognizer(
            target: context.coordinator,
            action: #selector(Coordinator.handleTwoFingerPan(_:))
        )
        twoFingerPan.minimumNumberOfTouches = 2
        twoFingerPan.maximumNumberOfTouches = 2
        twoFingerPan.cancelsTouchesInView = true
        view.addGestureRecognizer(twoFingerPan)

        // Pinch = free dolly forward/backward along current camera direction.
        let pinch = UIPinchGestureRecognizer(
            target: context.coordinator,
            action: #selector(Coordinator.handlePinch(_:))
        )
        pinch.cancelsTouchesInView = true
        view.addGestureRecognizer(pinch)

        tap.require(toFail: oneFingerPan)
        doubleTap.require(toFail: oneFingerPan)
        additiveTap.require(toFail: twoFingerPan)
        context.coordinator.view = view
        if registerAsPrimary {
            studio.scnView = view

            // Selection is created before SCNView exists on a fresh launch, so its
            // first gizmo cannot know the camera distance yet. Re-size it as soon as
            // the real viewport is mounted and make sure the editor camera is active.
            DispatchQueue.main.async { [weak view] in
                guard let view else { return }
                if view.pointOfView == nil, let camera = studio.editorViewportCamera {
                    view.pointOfView = camera
                }
                studio.updateSelectionGizmoScreenScale()
            }
        }
        return view
    }

    static func dismantleUIView(_ view: SCNView, coordinator: Coordinator) {
        view.isPlaying = false
        view.scene = nil
        coordinator.studio.isTransformGestureActive = false
        coordinator.studio.setPressedTransformAxis(nil)
        coordinator.studio.stopPlayback()
        coordinator.view = nil
    }

    func updateUIView(_ view: SCNView, context: Context) {
        // Re-assert the real viewport reference after sheets/full-screen covers.
        // This also self-heals if UIKit recreated the underlying SCNView.
        if registerAsPrimary, studio.scnView !== view {
            studio.scnView = view
        }
        if view.scene !== studio.scene {
            view.scene = studio.scene
        }
        if registerAsPrimary, view.pointOfView == nil, let camera = studio.editorViewportCamera {
            view.pointOfView = camera
        }
        if registerAsPrimary {
            studio.updateSelectionGizmoScreenScale()
        }

        if let screen = view.window?.windowScene?.screen {
            // Editing at 120 Hz doubles SceneKit work for almost no modeling benefit.
            // Keep the viewport smooth at 60 fps and temporarily drop to 30 while
            // importing/processing a large asset.
            let targetFPS = (studio.importIsRunning || studio.performanceMode)
                ? 30
                : min(screen.maximumFramesPerSecond, 60)
            if view.preferredFramesPerSecond != targetFPS {
                view.preferredFramesPerSecond = targetFPS
            }
        }
    }

    @MainActor
    final class Coordinator: NSObject {
        let studio: StudioStore
        weak var view: SCNView?

        // Camera look state
        private var lookStartPoint: CGPoint = .zero
        private var lookStartEuler = SCNVector3(0, 0, 0)

        // Camera pan state
        private var panStartPoint: CGPoint = .zero
        private var panStartCamera = SCNVector3(0, 0, 0)

        // Zoom state
        private var zoomStartCamera = SCNVector3(0, 0, 0)

        // Object manipulation state
        private var dragStartPoint: CGPoint = .zero
        private var dragStartPosition = SCNVector3(0, 0, 0)
        private var dragStartEuler = SCNVector3(0, 0, 0)
        private var dragStartScale = SCNVector3(1, 1, 1)
        private weak var manipulatedNode: SCNNode?
        private var manipulatedNodes: [SCNNode] = []
        private var activeAxis: TransformAxis = .free
        private var lastTransformUIRefresh: TimeInterval = 0
        private struct DragState {
            let node: SCNNode
            let position: SCNVector3
            let orientation: simd_quatf
            let scale: SCNVector3
        }
        private var dragStates: [DragState] = []
        private var dragWorldAxis = SCNVector3Zero
        private var dragRight = SCNVector3(1, 0, 0)
        private var dragUp = SCNVector3(0, 1, 0)
        private var dragUnitsPerPoint: Float = 0.005
        private var previousWorldDelta = SCNVector3Zero
        private var dragMode: TransformMode = .move

        init(studio: StudioStore) {
            self.studio = studio
        }

        // MARK: Hit Testing

        private func gizmoAxis(at point: CGPoint) -> TransformAxis? {
            guard let view else { return nil }

            let hits = view.hitTest(point, options: [
                SCNHitTestOption.searchMode: SCNHitTestSearchMode.all.rawValue,
                SCNHitTestOption.ignoreHiddenNodes: true
            ])

            for hit in hits {
                var node: SCNNode? = hit.node

                while let current = node {
                    guard let name = current.name else {
                        node = current.parent
                        continue
                    }

                    if name == "GizmoHandle_X" { return .x }
                    if name == "GizmoHandle_Y" { return .y }
                    if name == "GizmoHandle_Z" { return .z }

                    node = current.parent
                }
            }

            return nil
        }

        private func selectableNode(at point: CGPoint) -> SCNNode? {
            guard let view else { return nil }

            let hits = view.hitTest(point, options: [
                SCNHitTestOption.searchMode: SCNHitTestSearchMode.all.rawValue,
                SCNHitTestOption.ignoreHiddenNodes: true,
                SCNHitTestOption.backFaceCulling: false
            ])

            for hit in hits {
                let node = hit.node
                let name = node.name ?? ""

                // Ignore editor overlays completely and continue to the real mesh behind them.
                if name == "_SelectionOutline" { continue }
                if name == "_TransformGizmo" { continue }
                if name.hasPrefix("GizmoHandle_") { continue }
                var ancestor: SCNNode? = node
                var editorOnly = false
                while let current = ancestor {
                    if current === studio.helpersRoot || current === studio.editorRoot {
                        editorOnly = true; break
                    }
                    ancestor = current.parent
                }
                if editorOnly { continue }

                // Starter floor is treated as empty workspace, not an editable project part.
                if name == "Ground", node.parent === studio.contentRoot {
                    continue
                }

                if studio.isNodeLocked(node) {
                    continue
                }

                // Select the exact part that was touched, including imported assets.
                // The Workspace wrapper is only a placement container and must never
                // swallow viewport selection for its child meshes.
                if node.geometry != nil {
                    return node
                }

                // Only if the hit node is a wrapper, use the nearest mesh child.
                if let child = node.childNodes.first(where: {
                    guard let childName = $0.name else { return $0.geometry != nil }
                    return $0.geometry != nil &&
                           childName != "_SelectionOutline" &&
                           childName != "_TransformGizmo" &&
                           !childName.hasPrefix("GizmoHandle_")
                }) {
                    return child
                }
            }

            return nil
        }

        private func projectRoot(for node: SCNNode) -> SCNNode {
            var current = node
            while let parent = current.parent, parent !== studio.contentRoot {
                if parent === studio.editorRoot || parent === studio.helpersRoot { break }
                current = parent
            }
            return current
        }

        private func isDescendant(_ node: SCNNode, of ancestor: SCNNode) -> Bool {
            var current: SCNNode? = node
            while let value = current {
                if value === ancestor { return true }
                current = value.parent
            }
            return false
        }

        private func selectionForNormalTouch(_ hit: SCNNode) -> SCNNode {
            if let selected = studio.selectedNode, isDescendant(hit, of: selected) { return selected }
            return projectRoot(for: hit)
        }

        // MARK: One Finger

        @objc func handleOneFingerPan(_ gesture: UIPanGestureRecognizer) {
            guard let view, let camera = view.pointOfView else { return }
            let point = gesture.location(in: view)

            // VIEW and OBJECT are explicit, sticky modes. A drag that starts on
            // top of a model must never kick the user out of VIEW. This is
            // especially important on iPad because a camera-look gesture often
            // begins over the project itself.
            if studio.viewportInteractionMode == .view {
                handleFreeLook(gesture, point: point, camera: camera)
            } else {
                handleObjectPan(gesture, point: point)
            }
        }

        private func handleFreeLook(
            _ gesture: UIPanGestureRecognizer,
            point: CGPoint,
            camera: SCNNode
        ) {
            switch gesture.state {
            case .began:
                lookStartPoint = point
                lookStartEuler = camera.eulerAngles

            case .changed:
                let translation = gesture.translation(in: view)
                gesture.setTranslation(.zero, in: view)

                let dx = Float(translation.x)
                let dy = Float(translation.y)
                let sensitivity: Float = 0.0032

                SCNTransaction.begin()
                SCNTransaction.disableActions = true

                let current = camera.eulerAngles
                let pitch = clamp(
                    current.x - dy * sensitivity,
                    -Float.pi * 0.495,
                    Float.pi * 0.495
                )
                let yaw = current.y - dx * sensitivity

                camera.eulerAngles = SCNVector3(
                    pitch,
                    yaw,
                    current.z
                )

                SCNTransaction.commit()
                studio.updateSelectionGizmoScreenScale()
                studio.statusText = "VIEW • Free Look"

            default:
                break
            }
        }

        // MARK: Two Finger Camera Pan

        @objc func handleTwoFingerPan(_ gesture: UIPanGestureRecognizer) {
            guard let view, let camera = view.pointOfView else { return }

            switch gesture.state {
            case .began:
                gesture.setTranslation(.zero, in: view)

            case .changed:
                let translation = gesture.translation(in: view)
                gesture.setTranslation(.zero, in: view)

                let dx = Float(translation.x)
                let dy = Float(translation.y)

                let right = normalized(
                    camera.presentation.convertVector(SCNVector3(1, 0, 0), to: nil)
                )
                let up = normalized(
                    camera.presentation.convertVector(SCNVector3(0, 1, 0), to: nil)
                )

                let amount: Float = 0.006

                SCNTransaction.begin()
                SCNTransaction.disableActions = true

                let current = camera.position
                camera.position = SCNVector3(
                    current.x - right.x * dx * amount + up.x * dy * amount,
                    current.y - right.y * dx * amount + up.y * dy * amount,
                    current.z - right.z * dx * amount + up.z * dy * amount
                )

                SCNTransaction.commit()
                studio.updateSelectionGizmoScreenScale()
                studio.statusText = "VIEW • Free Pan"

            default:
                break
            }
        }

        // MARK: Unlimited Free Zoom

        @objc func handlePinch(_ gesture: UIPinchGestureRecognizer) {
            guard studio.pinchZoomEnabled else { return }
            guard let view, let camera = view.pointOfView else { return }

            switch gesture.state {
            case .began:
                gesture.scale = 1.0

            case .changed:
                let delta = max(0.001, min(1000.0, Float(gesture.scale)))
                gesture.scale = 1.0

                let forward = normalized(
                    camera.presentation.convertVector(SCNVector3(0, 0, -1), to: nil)
                )

                // Incremental logarithmic dolly:
                // very smooth near 1.0, and can be repeated without a practical limit.
                let signedTravel = logf(delta) * 2.8

                SCNTransaction.begin()
                SCNTransaction.disableActions = true

                let current = camera.position
                camera.position = SCNVector3(
                    current.x + forward.x * signedTravel,
                    current.y + forward.y * signedTravel,
                    current.z + forward.z * signedTravel
                )

                camera.camera?.zNear = 0.01
                camera.camera?.zFar = 100_000

                SCNTransaction.commit()
                studio.updateSelectionGizmoScreenScale()
                studio.statusText = studio.appLanguage == .arabic ? "المنظور • تكبير سلس بلا حدود" : "VIEW • Smooth Unlimited Zoom"

            default:
                break
            }
        }

        // MARK: Object / Gizmo Manipulation

        private func worldAxisVector(
            axis: TransformAxis,
            reference: SCNNode?
        ) -> SCNVector3 {
            let unit: SCNVector3

            switch axis {
            case .x:
                unit = SCNVector3(
                    1,
                    0,
                    0
                )

            case .y:
                unit = SCNVector3(
                    0,
                    1,
                    0
                )

            case .z:
                unit = SCNVector3(
                    0,
                    0,
                    1
                )

            case .free:
                return SCNVector3Zero
            }

            guard studio.transformSpace == .local,
                  let reference else {
                return unit
            }

            return normalized(
                reference.presentation.convertVector(
                    unit,
                    to: nil
                )
            )
        }

        private func localDelta(
            worldDelta: SCNVector3,
            for node: SCNNode
        ) -> SCNVector3 {
            guard let parent = node.parent else {
                return worldDelta
            }

            return parent.presentation.convertVector(
                worldDelta,
                from: nil
            )
        }

        private func projectedDragAmount(
            axis: TransformAxis,
            reference: SCNNode?,
            dx: Float,
            dy: Float
        ) -> Float {
            guard let view,
                  let reference,
                  axis != .free else {
                return 0
            }

            let worldAxis = worldAxisVector(
                axis: axis,
                reference: reference
            )

            let origin = reference.presentation.worldPosition
            let endpoint = SCNVector3(
                origin.x + worldAxis.x,
                origin.y + worldAxis.y,
                origin.z + worldAxis.z
            )

            let p0 = view.projectPoint(origin)
            let p1 = view.projectPoint(endpoint)

            let up = view.pointOfView?.presentation.convertVector(SCNVector3(0,1,0), to: nil) ?? SCNVector3(0,1,0)
            let projectedUp = view.projectPoint(SCNVector3(origin.x+up.x, origin.y+up.y, origin.z+up.z))
            let ySign: Float = projectedUp.y > p0.y ? -1 : 1
            let sx = p1.x-p0.x
            let sy = (p1.y-p0.y)*ySign
            let length = sqrtf(
                sx * sx +
                sy * sy
            )

            guard length.isFinite,
                  length > 0.75 else {
                // If an axis points almost directly into the camera its screen
                // projection is nearly a point. Keep it controllable without
                // ever unlocking the selected 3D axis.
                return abs(dx) >= abs(dy)
                    ? dx
                    : -dy
            }

            let ux = sx / length
            let uy = sy / length

            // Dot product: only the finger movement parallel to the visible
            // arrow counts. Perpendicular dragging has essentially no effect.
            return dx * ux + dy * uy
        }

        private func handleObjectPan(_ gesture: UIPanGestureRecognizer, point: CGPoint) {
            guard let view else { return }
            switch gesture.state {
            case .began:
                guard !studio.importIsRunning else { return }
                let axis = gizmoAxis(at: point)
                if let axis {
                    activeAxis = axis
                    studio.setTransformAxis(axis, pressed: true)
                } else if let hit = selectableNode(at: point) {
                    let target = selectionForNormalTouch(hit)
                    if !studio.isNodeMultiSelected(target) { studio.select(target) }
                    activeAxis = studio.transformAxis
                } else {
                    // Empty space must never move the previously selected object.
                    manipulatedNodes.removeAll()
                    return
                }
                manipulatedNodes = studio.editingNodes.filter { !studio.isNodeLocked($0) }
                guard let reference = manipulatedNodes.last else { return }
                studio.stopPlayback()
                manipulatedNode = reference
                dragMode = studio.transformMode
                dragStates = manipulatedNodes.map {
                    DragState(node: $0, position: $0.position, orientation: $0.simdOrientation, scale: $0.scale)
                }
                studio.beginTransformHistory(manipulatedNodes)
                dragWorldAxis = worldAxisVector(axis: activeAxis, reference: reference)
                previousWorldDelta = SCNVector3Zero
                if let camera = view.pointOfView {
                    dragRight = normalized(camera.presentation.convertVector(SCNVector3(1, 0, 0), to: nil))
                    dragUp = normalized(camera.presentation.convertVector(SCNVector3(0, 1, 0), to: nil))
                    let p = camera.presentation.worldPosition
                    let q = reference.presentation.worldPosition
                    let distance = vectorLength(SCNVector3(p.x-q.x, p.y-q.y, p.z-q.z))
                    let height = Float(max(1, view.bounds.height))
                    if camera.camera?.usesOrthographicProjection == true {
                        dragUnitsPerPoint = Float(camera.camera?.orthographicScale ?? 1) * 2 / height
                    } else {
                        let fov = Float(camera.camera?.fieldOfView ?? 55) * .pi / 180
                        dragUnitsPerPoint = max(0.00001, 2 * distance * tanf(fov / 2) / height)
                    }
                }
                studio.isTransformGestureActive = true
                studio.setPressedTransformAxis(activeAxis == .free ? nil : activeAxis)
                gesture.setTranslation(.zero, in: view)

            case .changed:
                guard !dragStates.isEmpty, studio.isTransformGestureActive else { return }
                // Total displacement from gesture start preserves sub-step motion for snapping.
                let translation = gesture.translation(in: view)
                let dx = Float(translation.x), dy = Float(translation.y)
                let speed = Float(studio.manipulationSpeed) * (studio.fineMode ? 0.3 : 1)
                let snapping = studio.snapEnabled && studio.snapTarget == .increment
                func snap(_ value: Float, step: Float) -> Float {
                    snapping ? (value / max(0.0001, step)).rounded() * step : value
                }
                SCNTransaction.begin()
                SCNTransaction.disableActions = true
                switch dragMode {
                case .move:
                    let amount = dragUnitsPerPoint * speed
                    var delta: SCNVector3
                    if activeAxis == .free {
                        let x = snap(dx * amount, step: Float(studio.snapStep))
                        let y = snap(-dy * amount, step: Float(studio.snapStep))
                        delta = SCNVector3(dragRight.x*x + dragUp.x*y,
                                           dragRight.y*x + dragUp.y*y,
                                           dragRight.z*x + dragUp.z*y)
                    } else {
                        let projected = projectedDragAmount(axis: activeAxis, reference: manipulatedNode, dx: dx, dy: dy)
                        let distance = snap(projected * amount, step: Float(studio.snapStep))
                        delta = SCNVector3(dragWorldAxis.x*distance, dragWorldAxis.y*distance, dragWorldAxis.z*distance)
                    }
                    for state in dragStates {
                        let local = localDelta(worldDelta: delta, for: state.node)
                        state.node.position = SCNVector3(state.position.x+local.x, state.position.y+local.y, state.position.z+local.z)
                    }
                    studio.offsetSelectionGizmo(by: SCNVector3(delta.x-previousWorldDelta.x, delta.y-previousWorldDelta.y, delta.z-previousWorldDelta.z))
                    previousWorldDelta = delta
                case .rotate:
                    // The WOW-style ring assembly is authored so Y/blue already feels
                    // correct with the base drag sign, while X/red and Z/green need
                    // the opposite sign to keep upward dragging visually rotating in
                    // the expected direction.
                    let baseAngle = snap((dx-dy) * 0.006 * speed, step: Float(studio.rotationSnapDegrees) * .pi / 180)
                    let angleSign: Float
                    switch activeAxis {
                    case .x, .z:
                        angleSign = -1
                    case .y, .free:
                        angleSign = 1
                    }
                    let angle = baseAngle * angleSign
                    let unit: SIMD3<Float>
                    switch activeAxis {
                    case .x: unit = SIMD3(1,0,0)
                    case .y: unit = SIMD3(0,1,0)
                    case .z: unit = SIMD3(0,0,1)
                    case .free: unit = SIMD3(0,1,0)
                    }
                    for state in dragStates {
                        if activeAxis != .free && studio.transformSpace == .local {
                            state.node.simdOrientation = simd_normalize(state.orientation * simd_quatf(angle: angle, axis: unit))
                        } else {
                            let world = activeAxis == .free ? dragUp : dragWorldAxis
                            let parentQ = state.node.parent?.simdWorldOrientation ?? simd_quatf(angle: 0, axis: SIMD3<Float>(0,1,0))
                            let localAxis = simd_normalize(parentQ.inverse.act(SIMD3(world.x,world.y,world.z)))
                            state.node.simdOrientation = simd_normalize(simd_quatf(angle: angle, axis: localAxis) * state.orientation)
                        }
                    }
                    studio.refreshSelectionGizmoOrientationOnly()
                case .scale:
                    let factor = expf(min(8, max(-8, (dx-dy)*0.004*speed)))
                    func scaled(_ value: Float) -> Float {
                        let sign: Float = value < 0 ? -1 : 1
                        return sign * min(10000, max(0.001, abs(snap(value*factor, step: Float(studio.scaleSnapStep)))))
                    }
                    for state in dragStates {
                        var value = state.scale
                        if activeAxis == .free || activeAxis == .x { value.x = scaled(state.scale.x) }
                        if activeAxis == .free || activeAxis == .y { value.y = scaled(state.scale.y) }
                        if activeAxis == .free || activeAxis == .z { value.z = scaled(state.scale.z) }
                        state.node.scale = value
                    }
                }
                SCNTransaction.commit()
                let now = ProcessInfo.processInfo.systemUptime
                if now-lastTransformUIRefresh > 0.1 {
                    lastTransformUIRefresh = now
                    studio.objectWillChange.send()
                }

            case .ended, .cancelled, .failed:
                guard studio.isTransformGestureActive else { return }
                studio.isTransformGestureActive = false
                studio.setPressedTransformAxis(nil)
                if gesture.state != .ended {
                    for state in dragStates {
                        state.node.position = state.position
                        state.node.simdOrientation = state.orientation
                        state.node.scale = state.scale
                    }
                    studio.cancelTransformHistory()
                } else {
                    studio.endTransformHistory(label: "Transform")
                    if studio.snapEnabled && dragMode == .move {
                        switch studio.snapTarget {
                        case .workPoint: studio.snapSelectionToWorkPoint()
                        case .worldOrigin: studio.snapSelectionToWorldOrigin()
                        case .activeObject: studio.snapSelectionToActive()
                        case .increment: break
                        }
                    }
                    if studio.autoKeyframeEnabled { studio.addKeyframe() }
                }
                studio.refreshSelectionGizmo()
                dragStates.removeAll()
                manipulatedNodes.removeAll()
                manipulatedNode = nil
                studio.objectWillChange.send()
            default: break
            }
        }

        // MARK: Tap Selection

        @objc func handleTap(_ gesture: UITapGestureRecognizer) {
            guard let view else {
                return
            }

            let point = gesture.location(
                in: view
            )

            // Tapping an axis switches to OBJECT and chooses that axis.
            if let axis = gizmoAxis(at: point) {
                studio.setTransformAxis(axis)
                studio.viewportInteractionMode = .object
                studio.statusText = "OBJECT • Axis \(axis.rawValue.uppercased())"
                return
            }

            // Single tap stays at object/root level. A selected car keeps the
            // whole car active even when the finger lands on a wheel/body child.
            if let hit = selectableNode(at: point) {
                let node = selectionForNormalTouch(hit)
                studio.select(node)
                studio.viewportInteractionMode = .object
                studio.statusText = "OBJECT • \(node.name ?? "Object")"
                return
            }

            studio.select(nil)
            studio.viewportInteractionMode = .view
            studio.statusText = "VIEW • No Selection"
        }

        @objc func handleDoubleTap(_ gesture: UITapGestureRecognizer) {
            guard let view else { return }
            let point = gesture.location(in: view)
            guard gizmoAxis(at: point) == nil, let node = selectableNode(at: point) else { return }
            studio.select(node)
            studio.viewportInteractionMode = .object
            studio.statusText = "PART • \(node.name ?? "Part")"
        }

        @objc func handleAdditiveTap(_ gesture: UITapGestureRecognizer) {
            guard let view else { return }
            var nodes = studio.multiSelectedNodes
            for index in 0..<gesture.numberOfTouches {
                let point = gesture.location(ofTouch: index, in: view)
                guard gizmoAxis(at: point) == nil, let hit = selectableNode(at: point) else { continue }
                let node = hit
                // If an ancestor/root is already selected, replace that ancestor
                // with the exact touched part so child multi-selection can work.
                nodes.removeAll { existing in
                    var parent = node.parent
                    while let value = parent {
                        if value === existing { return true }
                        parent = value.parent
                    }
                    return false
                }
                if !nodes.contains(where: { $0 === node }) { nodes.append(node) }
            }
            guard !nodes.isEmpty else { return }
            studio.selectMultiple(nodes)
            studio.viewportInteractionMode = .object
        }

        // MARK: Math

        private func vectorLength(_ v: SCNVector3) -> Float {
            sqrtf(v.x * v.x + v.y * v.y + v.z * v.z)
        }

        private func normalized(_ v: SCNVector3) -> SCNVector3 {
            let length = max(0.000001, vectorLength(v))
            return SCNVector3(
                v.x / length,
                v.y / length,
                v.z / length
            )
        }

        private func clamp(
            _ value: Float,
            _ lower: Float,
            _ upper: Float
        ) -> Float {
            min(max(value, lower), upper)
        }
    }
}

// MARK: - Hierarchy

@MainActor
struct HierarchyPanel: View {
    @EnvironmentObject var studio: StudioStore
    @State private var query = ""
    @State private var matches: [SCNNode] = []

    private func search() {
        let text = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { matches = []; return }
        var found: [SCNNode] = []
        for root in [studio.contentRoot, studio.camerasRoot, studio.lightsRoot] {
            root.enumerateChildNodes { node, stop in
                if !node.isStudioMetadata, node.name != "_SelectionOutline", (node.name ?? "").localizedCaseInsensitiveContains(text) {
                    found.append(node)
                }
                if found.count >= 200 { stop.pointee = true }
            }
            if found.count >= 200 { break }
        }
        matches = found
    }

    var body: some View {
        VStack(spacing: 0) {
            panelHeader(studio.tr("scene"), icon: "square.stack.3d.up")
            HStack(spacing: 8) {
                Button { studio.hierarchyMultiSelectEnabled.toggle() } label: {
                    Label(studio.appLanguage == .arabic ? "تحديد متعدد" : "Multi Select", systemImage: studio.hierarchyMultiSelectEnabled ? "checkmark.circle.fill" : "checkmark.circle")
                }.buttonStyle(.bordered).tint(studio.hierarchyMultiSelectEnabled ? .accentColor : .secondary)
                if studio.hierarchyMultiSelectEnabled {
                    Button(studio.appLanguage == .arabic ? "الكل" : "All") { studio.selectMultiple(studio.contentRoot.childNodes) }
                    Button(studio.appLanguage == .arabic ? "إلغاء" : "Clear") { studio.clearMultiSelection() }
                }
            }.font(.caption).padding(.horizontal, 8).padding(.top, 6)
            TextField(studio.appLanguage == .arabic ? "بحث القطع والملفات" : "Search objects and files", text: $query)
                .textFieldStyle(.roundedBorder).padding(8)
                .onChange(of: query) { _, _ in search() }
                .onChange(of: studio.importIsRunning) { _, _ in search() }

            if studio.hierarchyDragIsActive {
                HStack(spacing: 7) {
                    Image(systemName: "arrow.up.left.and.arrow.down.right")
                    Text(studio.appLanguage == .arabic
                         ? "اسحب هنا لفصل القطعة عن المجموعة"
                         : "Drop here to detach from group")
                        .lineLimit(1)
                    Spacer(minLength: 0)
                }
                .font(.caption.bold())
                .padding(.horizontal, 10)
                .frame(minHeight: 38)
                .background(Color.accentColor.opacity(0.18), in: RoundedRectangle(cornerRadius: 9))
                .padding(.horizontal, 8)
                .onDrop(of: [UTType.plainText], isTargeted: nil) { _ in
                    studio.detachHierarchyDraggedNode()
                }
            }

            ScrollView {
                LazyVStack(alignment: .leading, spacing: 2) {
                    if query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        HierarchyGroup(title: studio.appLanguage == .arabic ? "العناصر" : "Objects", root: studio.contentRoot)
                        HierarchyGroup(title: studio.appLanguage == .arabic ? "الكاميرات" : "Cameras", root: studio.camerasRoot)
                        HierarchyGroup(title: studio.appLanguage == .arabic ? "الإضاءات" : "Lights", root: studio.lightsRoot)
                    } else {
                        ForEach(matches, id: \.self) { node in
                            HierarchyNodeRow(node: node, depth: 0)
                        }
                        if matches.isEmpty && !studio.audioAssets.contains(where: { $0.name.localizedCaseInsensitiveContains(query) }) { Text(studio.appLanguage == .arabic ? "لا توجد نتائج" : "No results").font(.caption) }
                        if matches.count >= 200 { Text(studio.appLanguage == .arabic ? "أول 200 نتيجة؛ حدّد البحث" : "First 200 results; refine your search").font(.caption2) }
                    }
                    Divider().padding(.vertical, 6)
                    ProjectAudioFiles(query: query.trimmingCharacters(in: .whitespacesAndNewlines))
                }
                .padding(8)
            }

            Divider()

            HStack {


                Button {
                    studio.groupSelectedNodes()
                } label: {
                    Image(systemName: "folder.badge.plus")
                }
                .studioTooltip(studio.appLanguage == .arabic ? "مجموعة من العناصر المحددة" : "Group selected objects")
                Button {
                    studio.ungroupSelectedNode()
                } label: {
                    Image(systemName: "folder.badge.minus")
                }
                .studioTooltip(studio.appLanguage == .arabic ? "فك المجموعة" : "Ungroup")
                Spacer()
                Button(role: .destructive) {
                    studio.deleteSelected()
                } label: {
                    Image(systemName: "trash")
                }
                .studioTooltip(studio.appLanguage == .arabic ? "حذف المحدد" : "Delete selected")
            }
            .buttonStyle(.borderless)
            .padding(10)
        }
        .background(Color(red: 0.105, green: 0.135, blue: 0.175).opacity(0.97))
    }
}

@MainActor
struct HierarchyGroup: View {
    @EnvironmentObject var studio: StudioStore
    let title: String
    let root: SCNNode
    @State private var expanded = true

    var body: some View {
        DisclosureGroup(isExpanded: $expanded) {
            ForEach(visibleChildren(root), id: \.self) { node in
                HierarchyNodeRow(node: node, depth: 0)
                    .environmentObject(studio)
            }
        } label: {
            Label(title, systemImage: "folder.fill")
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(.secondary)
        }
        .tint(.secondary)
        .onDrop(of: [UTType.plainText], isTargeted: nil) { _ in
            studio.finishHierarchyDrag(to: root)
        }
    }

    private func visibleChildren(_ node: SCNNode) -> [SCNNode] {
        node.childNodes.filter {
            $0.name != "_SelectionOutline" && $0.name != "_TransformGizmo" && !$0.isStudioMetadata
        }
    }
}

@MainActor
struct HierarchyNodeRow: View {
    @EnvironmentObject var studio: StudioStore
    let node: SCNNode
    let depth: Int
    @State private var expanded = false

    private var visibleChildren: [SCNNode] {
        node.childNodes.filter {
            $0.name != "_SelectionOutline" && $0.name != "_TransformGizmo" && !$0.isStudioMetadata
        }
    }

    private var hasChildren: Bool {
        !visibleChildren.isEmpty
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 1) {
            HStack(spacing: 5) {
                if hasChildren {
                    Button {
                        withAnimation(.easeInOut(duration: 0.15)) {
                            expanded.toggle()
                        }
                    } label: {
                        Image(systemName: expanded ? "chevron.down" : "chevron.right")
                            .font(.system(size: 9, weight: .bold))
                            .frame(width: 14, height: 24)
                    }
                    .buttonStyle(.plain)
                } else {
                    Color.clear.frame(width: 14, height: 24)
                }

                Button {
                    if studio.hierarchyMultiSelectEnabled { studio.toggleMultiSelection(node) }
                    else { studio.select(node); studio.statusText = studio.appLanguage == .arabic ? "تم تحديد • \(node.name ?? "عنصر")" : "Selected • \(node.name ?? "Object")" }
                } label: {
                    HStack(spacing: 7) {
                        Image(systemName: icon(for: node))
                            .foregroundStyle(iconColor(for: node))
                            .frame(width: 16)

                        Text(displayName(node))
                            .lineLimit(1)

                        Spacer()

                        if node.geometry != nil {
                            Text(studio.appLanguage == .arabic ? "مجسم" : "MESH")
                                .font(.system(size: 7, weight: .black))
                                .foregroundStyle(.secondary)
                        }
                    }
                    .font(.system(size: 11.5))
                    .padding(.vertical, 5)
                    .padding(.horizontal, 6)
                    .background(
                        studio.isNodeMultiSelected(node)
                        ? Color.accentColor.opacity(0.26)
                        : Color.clear,
                        in: RoundedRectangle(cornerRadius: 7)
                    )
                }
                .buttonStyle(.plain)
            }
            .padding(.leading, CGFloat(min(depth, 8)) * 12)
            .contextMenu {
                Button(studio.appLanguage == .arabic ? "تحديد متعدد" : "Multi-select") { studio.toggleMultiSelection(node) }
                Button(studio.appLanguage == .arabic ? "تركيز" : "Frame") { studio.selectAndFrame(node) }


            }
            .onDrag {
                studio.beginHierarchyDrag(node)
                return NSItemProvider(object: "3D-MOTION-HIERARCHY" as NSString)
            }
            .onDrop(of: [UTType.plainText], isTargeted: nil) { _ in
                studio.finishHierarchyDrag(to: node)
            }

            if expanded && hasChildren {
                ForEach(visibleChildren, id: \.self) { child in
                    HierarchyNodeRow(node: child, depth: depth + 1)
                        .environmentObject(studio)
                }
            }
        }
        .id(ObjectIdentifier(node))
        .onAppear { revealSelectedPath() }
        .onChange(of: studio.selectedNode) { _, _ in revealSelectedPath() }
    }

    private func revealSelectedPath() {
        guard hasChildren, let selected = studio.selectedNode else { return }
        var current: SCNNode? = selected.parent
        while let value = current {
            if value === node { expanded = true; return }
            current = value.parent
        }
    }

    private func displayName(_ node: SCNNode) -> String {
        let name = node.name?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if studio.appLanguage == .arabic {
            if name == "Ground" { return "الأرض" }
            if name == "Object" { return "عنصر" }
            if name == "Part" { return "قطعة" }
            if name == "Mesh" { return "مجسم" }
        }
        if name.isEmpty {
            return node.geometry == nil
                ? (studio.appLanguage == .arabic ? "قطعة" : "Part")
                : (studio.appLanguage == .arabic ? "مجسم" : "Mesh")
        }
        return name
    }

    private func icon(for node: SCNNode) -> String {
        if node.camera != nil { return "camera.fill" }
        if node.light != nil { return "lightbulb.fill" }
        if node.geometry != nil { return "cube.fill" }
        return "square.stack.3d.up.fill"
    }

    private func iconColor(for node: SCNNode) -> Color {
        if node.camera != nil { return .cyan }
        if node.light != nil { return .yellow }
        if node.geometry != nil { return .orange }
        return .secondary
    }
}

// MARK: - Inspector



@MainActor
struct ProjectLibraryView: View {
    @EnvironmentObject var studio: StudioStore
    @Binding var isPresented: Bool
    @State private var showFilePicker = false
    @State private var name = ""
    @State private var refresh = UUID()

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.04, green: 0.05, blue: 0.08).ignoresSafeArea()
                PerspectiveGridBackground(showGrid: true)
                    .ignoresSafeArea()
                    .opacity(0.82)
                LinearGradient(
                    colors: [Color.black.opacity(0.18), Color.clear, Color.black.opacity(0.30)],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("3D MOTION")
                                    .font(.largeTitle.bold())
                                    .foregroundStyle(
                                        LinearGradient(
                                            colors: [.cyan, .blue, .purple, .pink],
                                            startPoint: .leading,
                                            endPoint: .trailing
                                        )
                                    )
                                Text(studio.appLanguage == .arabic ? "مشاريعي" : "My Projects").foregroundStyle(.secondary)
                            }
                            Spacer()
                            HStack(spacing: 10) {
                                Button { showFilePicker = true } label: {
                                    Label(studio.appLanguage == .arabic ? "فتح مشروع سابق" : "Open Project", systemImage: "folder.open")
                                }.buttonStyle(.bordered)
                                Button { studio.newProject(); isPresented = false } label: {
                                    Label(studio.appLanguage == .arabic ? "مشروع جديد" : "New Project", systemImage: "plus")
                                }.buttonStyle(.borderedProminent)
                            }
                        }
                        let cards = studio.projectCards()
                        if cards.isEmpty {
                            ContentUnavailableView(studio.appLanguage == .arabic ? "لا توجد مشاريع محفوظة" : "No saved projects", systemImage: "cube.transparent", description: Text(studio.appLanguage == .arabic ? "أنشئ مشروعًا جديدًا أو ارجع للمحرر واحفظ المشروع الحالي." : "Create a project or return to the editor and save the current project."))
                        } else {
                            LazyVGrid(columns: [GridItem(.adaptive(minimum: 240), spacing: 14)], spacing: 14) {
                                ForEach(cards) { card in
                                    Button { if studio.openProject(card) { isPresented = false } } label: {
                                        VStack(alignment: .leading, spacing: 10) {
                                            RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.06)).frame(height: 120).overlay(Image(systemName: "cube.transparent").font(.largeTitle))
                                            Text(card.name).font(.headline).lineLimit(1)
                                            Text(card.modified.formatted(date: .abbreviated, time: .shortened)).font(.caption).foregroundStyle(.secondary)
                                        }.padding(10).background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 16))
                                    }.buttonStyle(.plain).contextMenu {
                                        Button(role: .destructive) { studio.deleteProject(card); refresh = UUID() } label: { Label(studio.appLanguage == .arabic ? "حذف" : "Delete", systemImage: "trash") }
                                    }
                                }
                            }.id(refresh)
                        }
                    }.padding(24)
                }
            }
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button(studio.appLanguage == .arabic ? "المحرر" : "Editor") { isPresented = false } } }
        }
        .fileImporter(isPresented: $showFilePicker, allowedContentTypes: [.item, .data]) { result in
            do {
                let url = try result.get()
                let scoped = url.startAccessingSecurityScopedResource()
                defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                let data = try Data(contentsOf: url)
                try studio.importPortableProject(data)
                isPresented = false
            } catch {
                studio.toast = "تعذر فتح المشروع: \(error.localizedDescription)"
            }
        }
        .preferredColorScheme(.dark)
    }
}

// Shares an actual .3dmotion file, preserving its filename in Save to Files.
private struct StudioProjectShareSheet: UIViewControllerRepresentable {
    let fileURL: URL
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
