import Foundation
import SceneKit
import SwiftUI

extension SCNNode {
    var studioIKBinding:(root:String,target:String)? {
        get {
            guard let text=childNodes.first(where:{$0.name?.hasPrefix("_5LnIK:")==true})?.name else {return nil}
            let parts=String(text.dropFirst("_5LnIK:".count)).split(separator:":")
            guard parts.count==2 else {return nil};return (String(parts[0]),String(parts[1]))
        }
        set {
            childNodes.filter {$0.name?.hasPrefix("_5LnIK:")==true}.forEach {$0.removeFromParentNode()}
            if let newValue {let marker=SCNNode();marker.name="_5LnIK:"+newValue.root+":"+newValue.target;marker.isHidden=true;addChildNode(marker)}
        }
    }
}

struct WorkshopPhysicsLink {
    var kind:String,a:String,b:String?
    var anchorA:SCNVector3,anchorB:SCNVector3,axisA:SCNVector3,axisB:SCNVector3
}

@MainActor
extension StudioStore {
    func capturePhysicsLinks() -> [WorkshopPhysicsLink] {
        var bodies:[ObjectIdentifier:String]=[:]
        for node in ProjectSceneCodec.nodes(in:scene.rootNode) {
            if let body=node.physicsBody {bodies[ObjectIdentifier(body)]=animationIdentity(node)}
        }
        func id(_ body:SCNPhysicsBody?) -> String? {body.flatMap {bodies[ObjectIdentifier($0)]}}
        return scene.physicsWorld.allBehaviors.compactMap {behavior in
            if let joint=behavior as? SCNPhysicsHingeJoint,let a=id(joint.bodyA) {
                return WorkshopPhysicsLink(kind:"hinge",a:a,b:id(joint.bodyB),anchorA:joint.anchorA,anchorB:joint.anchorB,axisA:joint.axisA,axisB:joint.axisB)
            }
            if let joint=behavior as? SCNPhysicsBallSocketJoint,let a=id(joint.bodyA) {
                return WorkshopPhysicsLink(kind:"ball",a:a,b:id(joint.bodyB),anchorA:joint.anchorA,anchorB:joint.anchorB,axisA:SCNVector3(0,1,0),axisB:SCNVector3(0,1,0))
            }
            return nil
        }
    }
    func restorePhysicsLinks(_ links:[WorkshopPhysicsLink]) {
        scene.physicsWorld.removeAllBehaviors()
        var bodies:[String:SCNPhysicsBody]=[:]
        for node in ProjectSceneCodec.nodes(in:scene.rootNode) {if let body=node.physicsBody,let id=node.studioAnimationID {bodies[id]=body}}
        for link in links {
            guard let a=bodies[link.a] else {continue};let b=link.b.flatMap {bodies[$0]}
            if link.b != nil,b==nil {continue}
            if link.kind=="hinge" {
                let joint=b.map {SCNPhysicsHingeJoint(bodyA:a,axisA:link.axisA,anchorA:link.anchorA,bodyB:$0,axisB:link.axisB,anchorB:link.anchorB)} ?? SCNPhysicsHingeJoint(body:a,axis:link.axisA,anchor:link.anchorA)
                scene.physicsWorld.addBehavior(joint)
            } else {
                let joint=b.map {SCNPhysicsBallSocketJoint(bodyA:a,anchorA:link.anchorA,bodyB:$0,anchorB:link.anchorB)} ?? SCNPhysicsBallSocketJoint(body:a,anchor:link.anchorA)
                scene.physicsWorld.addBehavior(joint)
            }
        }
    }
    func removeRigIK(in root:SCNNode) {
        pushUndoSnapshot("Remove rig IK")
        for node in ProjectSceneCodec.nodes(in:root) {node.constraints=(node.constraints ?? []).filter {!($0 is SCNIKConstraint)};node.studioIKBinding=nil;node.setValue(nil,forKey:"5lnIKTarget")}
        objectWillChange.send()
    }
}

@MainActor
struct WorkshopIKCard:View {
    @EnvironmentObject var studio:StudioStore
    @State private var rootKey=""
    @State private var endKey=""
    @State private var targetKey=""
    private var ar:Bool {studio.appLanguage == .arabic}
    var body:some View {
        if let rig=studio.selectedImportedRig ?? studio.selectedNode {
            let bones=studio.rigBoneNodes(in:rig),targets=ProjectSceneCodec.nodes(in:studio.contentRoot).filter {!$0.isStudioMetadata}
            InspectorCard(title:"IK") {
                Picker(ar ? "أصل السلسلة" : "Chain root",selection:$rootKey) {Text("—").tag("");ForEach(bones,id:\.self) {n in Text(n.name ?? "Bone").tag(String(ObjectIdentifier(n).hashValue))}}.pickerStyle(.menu)
                Picker(ar ? "نهاية السلسلة" : "Chain end",selection:$endKey) {Text("—").tag("");ForEach(bones,id:\.self) {n in Text(n.name ?? "Bone").tag(String(ObjectIdentifier(n).hashValue))}}.pickerStyle(.menu)
                Picker(ar ? "عنصر الهدف" : "Target object",selection:$targetKey) {Text("—").tag("");ForEach(Array(targets.prefix(200)),id:\.self) {n in Text(n.name ?? "Object").tag(String(ObjectIdentifier(n).hashValue))}}.pickerStyle(.menu)
                Button(ar ? "ربط IK" : "Bind IK") {
                    guard let root=bones.first(where:{String(ObjectIdentifier($0).hashValue)==rootKey}),let end=bones.first(where:{String(ObjectIdentifier($0).hashValue)==endKey}),let target=targets.first(where:{String(ObjectIdentifier($0).hashValue)==targetKey}) else {return}
                    studio.addIKConstraint(to:end,chainRoot:root,target:target)
                }.frame(minHeight:44)
                Button(ar ? "إزالة IK من الشخصية" : "Remove rig IK") {studio.removeRigIK(in:rig)}.frame(minHeight:44)
            }
        }
    }
}
