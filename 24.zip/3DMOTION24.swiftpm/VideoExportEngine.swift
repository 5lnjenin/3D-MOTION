import Foundation
import UIKit
import SceneKit
import AVFoundation
import CoreVideo

enum StudioVideoResolution: String, CaseIterable, Identifiable, Sendable {
    case p720 = "720p"
    case p1080 = "1080p"
    case p2K = "2K"
    case p4K = "4K"
    var id: String { rawValue }
    var size: CGSize {
        switch self {
        case .p720: return CGSize(width: 1280, height: 720)
        case .p1080: return CGSize(width: 1920, height: 1080)
        case .p2K: return CGSize(width: 2560, height: 1440)
        case .p4K: return CGSize(width: 3840, height: 2160)
        }
    }
}

@MainActor
extension StudioStore {
    func exportVideo(resolution: StudioVideoResolution = .p1080, exportFPS: Int = 30) {
        guard !isExporting, !importIsRunning else { return }
        guard duration > 0 else {
            toast = "مدة المشروع غير صالحة / Invalid project duration"
            return
        }

        stopPlayback()
        isExporting = true
        exportProgress = 0
        toast = "جارٍ تجهيز الفيديو / Preparing video…"

        let originalTime = currentTime
        let output = FileManager.default.temporaryDirectory
            .appendingPathComponent("5Ln-Render-\(UUID().uuidString).mp4")
        let size = resolution.size
        let fpsValue = max(1, min(144, exportFPS))
        let frameCount = max(1, Int(ceil(duration * Double(fpsValue))))

        videoExportTask?.cancel()
        videoExportTask = Task { @MainActor in
            do {
                try? FileManager.default.removeItem(at: output)
                let writer = try AVAssetWriter(outputURL: output, fileType: .mp4)
                let settings: [String: Any] = [
                    AVVideoCodecKey: AVVideoCodecType.hevc,
                    AVVideoWidthKey: Int(size.width),
                    AVVideoHeightKey: Int(size.height),
                    AVVideoCompressionPropertiesKey: [
                        AVVideoAverageBitRateKey: resolution == .p4K ? 28_000_000 : (resolution == .p2K ? 18_000_000 : (resolution == .p1080 ? 12_000_000 : 7_000_000)),
                        AVVideoMaxKeyFrameIntervalKey: fpsValue * 2
                    ]
                ]
                let input = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
                input.expectsMediaDataInRealTime = false
                let attributes: [String: Any] = [
                    kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                    kCVPixelBufferWidthKey as String: Int(size.width),
                    kCVPixelBufferHeightKey as String: Int(size.height),
                    kCVPixelBufferIOSurfacePropertiesKey as String: [:]
                ]
                let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: attributes)
                guard writer.canAdd(input) else { throw NSError(domain: "5LnVideo", code: 1, userInfo: [NSLocalizedDescriptionKey: "Video writer input unavailable"]) }
                writer.add(input)
                guard writer.startWriting() else { throw writer.error ?? NSError(domain: "5LnVideo", code: 2) }
                writer.startSession(atSourceTime: .zero)

                let renderer = SCNRenderer(device: nil, options: nil)
                renderer.scene = scene
                renderer.pointOfView = scnView?.pointOfView
                renderer.autoenablesDefaultLighting = false
                renderer.isPlaying = false

                let hiddenEditor = editorRoot.isHidden
                let hiddenHelpers = helpersRoot.isHidden
                let hiddenOutline = selectionOutline?.isHidden ?? true
                editorRoot.isHidden = true
                helpersRoot.isHidden = true
                selectionOutline?.isHidden = true
                defer {
                    editorRoot.isHidden = hiddenEditor
                    helpersRoot.isHidden = hiddenHelpers
                    selectionOutline?.isHidden = hiddenOutline
                }

                for frame in 0..<frameCount {
                    if Task.isCancelled { throw CancellationError() }
                    let t = min(duration, Double(frame) / Double(fpsValue))
                    applyTimeline(at: t)
                    currentTime = t

                    while !input.isReadyForMoreMediaData {
                        try await Task.sleep(nanoseconds: 2_000_000)
                    }

                    autoreleasepool {
                        let image = renderer.snapshot(atTime: t, with: size, antialiasingMode: .multisampling4X)
                        if let pool = adaptor.pixelBufferPool,
                           let buffer = Self.makePixelBuffer(from: applyRenderFilter(to: image), size: size, pool: pool) {
                            let pts = CMTime(value: CMTimeValue(frame), timescale: CMTimeScale(fpsValue))
                            _ = adaptor.append(buffer, withPresentationTime: pts)
                        }
                    }

                    exportProgress = Double(frame + 1) / Double(frameCount)
                    if frame % 3 == 0 { await Task.yield() }
                }

                input.markAsFinished()
                await writer.finishWriting()
                guard writer.status == .completed else {
                    throw writer.error ?? NSError(domain: "5LnVideo", code: 3, userInfo: [NSLocalizedDescriptionKey: "Video export failed"])
                }

                currentTime = originalTime
                applyTimeline(at: originalTime)
                exportedVideoURL = output
                isExporting = false
                videoExportTask = nil
                exportProgress = 1
                toast = "تم تصدير الفيديو / Video exported"
            } catch {
                currentTime = originalTime
                applyTimeline(at: originalTime)
                isExporting = false
                videoExportTask = nil
                exportProgress = 0
                toast = error is CancellationError ? "تم إلغاء التصدير / Export cancelled" : "فشل تصدير الفيديو / Export failed: \(error.localizedDescription)"
            }
        }
    }

    func cancelVideoExport() {
        guard isExporting else { return }
        videoExportTask?.cancel()
        toast = "جارٍ إلغاء التصدير / Cancelling export…"
    }

    nonisolated private static func makePixelBuffer(from image: UIImage, size: CGSize, pool: CVPixelBufferPool) -> CVPixelBuffer? {
        var pixelBuffer: CVPixelBuffer?
        guard CVPixelBufferPoolCreatePixelBuffer(nil, pool, &pixelBuffer) == kCVReturnSuccess,
              let buffer = pixelBuffer else { return nil }
        CVPixelBufferLockBaseAddress(buffer, [])
        defer { CVPixelBufferUnlockBaseAddress(buffer, []) }
        guard let context = CGContext(
            data: CVPixelBufferGetBaseAddress(buffer),
            width: Int(size.width), height: Int(size.height),
            bitsPerComponent: 8,
            bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue
        ) else { return nil }
        context.clear(CGRect(origin: .zero, size: size))
        if let cg = image.cgImage {
            context.draw(cg, in: CGRect(origin: .zero, size: size))
        }
        return buffer
    }
}
