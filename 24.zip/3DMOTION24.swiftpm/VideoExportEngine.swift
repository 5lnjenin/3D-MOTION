import Foundation
import UIKit
import SceneKit
import AVFoundation
import CoreVideo
import CoreImage

enum StudioVideoResolution: String, CaseIterable, Identifiable, Sendable {
    case p720 = "720p", p1080 = "1080p", p2K = "2K", p4K = "4K"
    var id: String { rawValue }
    var size: CGSize {
        switch self {
        case .p720: return CGSize(width: 1280, height: 720)
        case .p1080: return CGSize(width: 1920, height: 1080)
        case .p2K: return CGSize(width: 2560, height: 1440)
        case .p4K: return CGSize(width: 3840, height: 2160)
        }
    }
}

enum StudioVideoFailure: LocalizedError {
    case problem(String)
    var errorDescription: String? { if case let .problem(message) = self { return message }; return nil }
}

struct StudioVideoExportOptions: Sendable {
    static let frameRates = [24, 30, 60, 90, 120, 144]
    let resolution: StudioVideoResolution
    let fps: Int
    let duration: Double
    var frameCount: Int { max(1, Int(ceil(duration * Double(fps)))) }
    var encodedDuration: Double { Double(frameCount) / Double(fps) }
    func validate() throws {
        guard Self.frameRates.contains(fps), duration.isFinite, duration > 0,
              duration * Double(fps) < Double(Int32.max) else {
            throw StudioVideoFailure.problem("إعدادات التصدير غير صالحة / Invalid export settings")
        }
    }
    func settings(codec: AVVideoCodecType) -> [String: Any] {
        let base: Double
        switch resolution { case .p720: base = 7_000_000; case .p1080: base = 12_000_000; case .p2K: base = 18_000_000; case .p4K: base = 28_000_000 }
        return [AVVideoCodecKey: codec, AVVideoWidthKey: Int(resolution.size.width), AVVideoHeightKey: Int(resolution.size.height),
            AVVideoCompressionPropertiesKey: [AVVideoAverageBitRateKey: Int(base * sqrt(Double(fps) / 30)),
                AVVideoMaxKeyFrameIntervalKey: fps * 2, AVVideoExpectedSourceFrameRateKey: fps, AVVideoAllowFrameReorderingKey: false]]
    }
}

struct StudioVideoExportResult {
    let url: URL
    let options: StudioVideoExportOptions
    let hasAudio: Bool
    let codec: String
}

@MainActor
extension StudioStore {
    func exportVideo(resolution: StudioVideoResolution = .p1080, exportFPS: Int = 30) {
        guard videoExportTask == nil, !isExporting, !importIsRunning, !audioImportRunning else { return }
        videoExportTask = Task { @MainActor in
            do { _ = try await renderProjectVideo(resolution: resolution, exportFPS: exportFPS) }
            catch { /* renderProjectVideo supplies the failure message and cleanup. */ }
            videoExportTask = nil
        }
    }

    // This is also the test entry point: success requires a real, validated MP4.
    @discardableResult
    func renderProjectVideo(resolution: StudioVideoResolution, exportFPS: Int) async throws -> StudioVideoExportResult {
        guard !isExporting, !importIsRunning, !audioImportRunning else { throw ProjectFailure.busy }
        reconcileTimelineDuration()
        let options = StudioVideoExportOptions(resolution: resolution, fps: exportFPS, duration: duration)
        try options.validate()
        stopPlayback(); isExporting = true; exportProgress = 0; exportedVideoURL = nil
        toast = "جارٍ تجهيز الفيديو / Preparing video…"
        let originalTime = currentTime
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("MotionRender-" + UUID().uuidString, isDirectory: true)
        let output = FileManager.default.temporaryDirectory.appendingPathComponent("3DMOTION-\(resolution.rawValue)-\(exportFPS)FPS-\(UUID().uuidString).mp4")
        let editorHidden = editorRoot.isHidden, helpersHidden = helpersRoot.isHidden
        let outlineHidden = selectionOutline?.isHidden ?? true
        editorRoot.isHidden = true; helpersRoot.isHidden = true; selectionOutline?.isHidden = true
        defer {
            editorRoot.isHidden = editorHidden; helpersRoot.isHidden = helpersHidden; selectionOutline?.isHidden = outlineHidden
            currentTime = originalTime; applyTimeline(at: originalTime)
            isExporting = false
            try? FileManager.default.removeItem(at: folder)
            ciContext.clearCaches()
        }
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let rendered = folder.appendingPathComponent("picture.mp4")
            var codecName = "", failures: [String] = []
            // Retry a compatible codec at the SAME dimensions and timestamps.
            // Offline encoding is paced by the writer, never by a realtime FPS limit.
            for codec in [AVVideoCodecType.h264, .hevc] {
                try Task.checkCancellation()
                do {
                    try? FileManager.default.removeItem(at: rendered)
                    try await writeVideoFrames(to: rendered, options: options, codec: codec)
                    codecName = codec.rawValue; break
                } catch is CancellationError { throw CancellationError() }
                catch { failures.append(error.localizedDescription) }
            }
            guard !codecName.isEmpty else { throw StudioVideoFailure.problem(failures.joined(separator: " / ")) }
            exportProgress = 0.90; toast = "جارٍ تجهيز الملف النهائي / Finishing video…"
            let hasAudio = try await VideoAudioMixer.combine(video: rendered, output: output, clips: audioClips.map(\.stoppedCopy),
                masterVolume: masterAudioVolume, duration: options.encodedDuration, folder: folder)
            try Task.checkCancellation()
            try await Self.validateExportedVideo(output, options: options, requiresAudio: hasAudio)
            exportedVideoURL = output; exportProgress = 1; toast = "تم تصدير الفيديو / Video exported"
            return StudioVideoExportResult(url: output, options: options, hasAudio: hasAudio, codec: codecName)
        } catch {
            try? FileManager.default.removeItem(at: output)
            exportProgress = 0
            toast = error is CancellationError ? "تم إلغاء التصدير / Export cancelled" : "فشل تصدير الفيديو / Export failed: \(error.localizedDescription)"
            throw error
        }
    }

    private func writeVideoFrames(to output: URL, options: StudioVideoExportOptions, codec: AVVideoCodecType) async throws {
        let writer = try AVAssetWriter(outputURL: output, fileType: .mp4)
        writer.movieTimeScale = Int32(options.fps * 1_000)
        let settings = options.settings(codec: codec)
        guard writer.canApply(outputSettings: settings, forMediaType: .video) else {
            throw StudioVideoFailure.problem("تعذر تطبيق إعدادات التصدير / Export settings unavailable")
        }
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
        input.expectsMediaDataInRealTime = false
        input.mediaTimeScale = Int32(options.fps * 1_000)
        let size = options.resolution.size
        let attributes: [String: Any] = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: Int(size.width), kCVPixelBufferHeightKey as String: Int(size.height),
            kCVPixelBufferMetalCompatibilityKey as String: true, kCVPixelBufferIOSurfacePropertiesKey as String: [:]]
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: attributes)
        guard writer.canAdd(input) else { throw StudioVideoFailure.problem("تعذر تجهيز الفيديو / Video input unavailable") }
        writer.add(input)
        guard writer.startWriting() else { throw writer.error ?? StudioVideoFailure.problem("تعذر بدء التصدير / Cannot start export") }
        writer.startSession(atSourceTime: .zero)
        var finished = false
        defer { if !finished { writer.cancelWriting() } }
        guard let pool = adaptor.pixelBufferPool else { throw StudioVideoFailure.problem("تعذر تخصيص الإطارات / Pixel pool unavailable") }
        let frameRenderer = try VideoFrameRenderer(scene: scene, camera: scnView?.pointOfView ?? editorViewportCamera, size: size)
        for index in 0..<options.frameCount {
            try Task.checkCancellation()
            try await waitForVideoWriter(input, writer: writer)
            let time = Double(index) / Double(options.fps)
            applyTimeline(at: time, notifyUI: false)
            let buffer = try await videoPixelBuffer(pool: pool, writer: writer)
            try await frameRenderer.render(at: time, into: buffer)
            let encodedBuffer: CVPixelBuffer
            if renderFilterPreset != .none {
                encodedBuffer = try await videoPixelBuffer(pool: pool, writer: writer)
                ciContext.render(filteredRenderImage(CIImage(cvPixelBuffer: buffer)), to: encodedBuffer)
            } else { encodedBuffer = buffer }
            guard adaptor.append(encodedBuffer, withPresentationTime: CMTime(value: Int64(index), timescale: Int32(options.fps))) else {
                throw writer.error ?? StudioVideoFailure.problem("لم يُحفظ الإطار \(index + 1) / Frame append failed")
            }
            if index % max(1, options.fps / 10) == 0 || index == options.frameCount - 1 {
                exportProgress = 0.90 * Double(index + 1) / Double(options.frameCount)
                await Task.yield()
            }
        }
        writer.endSession(atSourceTime: CMTime(value: Int64(options.frameCount), timescale: Int32(options.fps)))
        input.markAsFinished()
        await withTaskCancellationHandler(operation: { await writer.finishWriting() }, onCancel: { writer.cancelWriting() })
        try Task.checkCancellation()
        guard writer.status == .completed else { throw writer.error ?? StudioVideoFailure.problem("تعذر إكمال الفيديو / Video completion failed") }
        finished = true
    }

    private func waitForVideoWriter(_ input: AVAssetWriterInput, writer: AVAssetWriter) async throws {
        let deadline = Date().addingTimeInterval(30)
        while !input.isReadyForMoreMediaData {
            try Task.checkCancellation()
            guard writer.status == .writing, Date() < deadline else {
                throw writer.error ?? StudioVideoFailure.problem("توقف التصدير / Video writer stalled")
            }
            try await Task.sleep(nanoseconds: 5_000_000)
        }
        guard writer.status == .writing else { throw writer.error ?? StudioVideoFailure.problem("فشل الترميز / Video encoding failed") }
    }

    private func videoPixelBuffer(pool: CVPixelBufferPool, writer: AVAssetWriter) async throws -> CVPixelBuffer {
        var buffer: CVPixelBuffer?
        let deadline = Date().addingTimeInterval(30)
        // Include filter output in the same bounded pool, rather than allocating
        // independent buffers which a busy encoder could retain without a limit.
        while buffer == nil {
            try Task.checkCancellation()
            let status = CVPixelBufferPoolCreatePixelBufferWithAuxAttributes(nil, pool,
                [kCVPixelBufferPoolAllocationThresholdKey: 5] as CFDictionary, &buffer)
            if status == kCVReturnWouldExceedAllocationThreshold {
                guard writer.status == .writing, Date() < deadline else {
                    throw writer.error ?? StudioVideoFailure.problem("توقف ترميز الإطارات / Frame encoder stalled")
                }
                try await Task.sleep(nanoseconds: 5_000_000)
            } else if status != kCVReturnSuccess {
                throw StudioVideoFailure.problem("تعذر تخصيص إطار: \(status) / Frame allocation failed")
            }
        }
        guard let buffer else { throw StudioVideoFailure.problem("إطار مفقود / Missing frame") }
        return buffer
    }

    nonisolated static func validateExportedVideo(_ url: URL, options: StudioVideoExportOptions, requiresAudio: Bool) async throws {
        let asset = AVURLAsset(url: url)
        guard let video = try await asset.loadTracks(withMediaType: .video).first else { throw StudioVideoFailure.problem("ملف دون فيديو / Missing video track") }
        let size = try await video.load(.naturalSize), rate = try await video.load(.nominalFrameRate)
        let seconds = CMTimeGetSeconds(try await asset.load(.duration))
        guard size == options.resolution.size, abs(Double(rate) - Double(options.fps)) < 0.15,
              abs(seconds - options.encodedDuration) < max(0.05, 1 / Double(options.fps)) else {
            throw StudioVideoFailure.problem("نتيجة التصدير لا تطابق الخيارات / Export mismatch: \(size.width)x\(size.height), \(rate) FPS, \(seconds)s; expected \(options.resolution.rawValue)/\(options.fps)FPS/\(options.encodedDuration)s")
        }
        if requiresAudio, try await asset.loadTracks(withMediaType: .audio).isEmpty {
            throw StudioVideoFailure.problem("الصوت مفقود من الفيديو / Exported audio is missing")
        }
    }

    func cancelVideoExport() {
        guard isExporting else { return }
        videoExportTask?.cancel()
        toast = "جارٍ إلغاء التصدير / Cancelling export…"
    }
}
