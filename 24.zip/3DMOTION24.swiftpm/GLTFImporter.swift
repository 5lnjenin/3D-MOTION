import Foundation
import UIKit
import SceneKit
import QuartzCore
import ImageIO
import simd

// MARK: - Built-in GLB / glTF Static Mesh Importer

final class GLTFImporter {
    var json: [String: Any] = [:]
    private var buffers: [Data] = []
    private var baseURL = FileManager.default.temporaryDirectory
    private var meshCache: [Int: SCNNode] = [:]
    private var materialCache: [Int: SCNMaterial] = [:]
    private var imageCache: [Int: UIImage] = [:]
    private var decodedTextureBytes = 0
    private var decodedAccessorBytes = 0
    var warnings: [String] = []

    func load(url: URL) throws -> SCNNode {
        baseURL = url.deletingLastPathComponent()

        if url.pathExtension.lowercased() == "glb" {
            try parseGLB(Data(contentsOf: url, options: [.mappedIfSafe]))
        } else {
            let data = try Data(contentsOf: url, options: [.mappedIfSafe])
            guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                throw GLTFImportError.invalidJSON
            }
            json = object
            try loadBuffers(binaryChunk: nil)
        }

        let asset = json["asset"] as? [String: Any]
        guard (asset?["version"] as? String) == "2.0" else { throw GLTFImportError.invalidJSON }
        let required = json["extensionsRequired"] as? [String] ?? []
        let supportedRequiredExtensions: Set<String> = [
            "KHR_lights_punctual",
            "KHR_materials_pbrSpecularGlossiness",
            "KHR_texture_transform"
        ]
        guard required.allSatisfy({ supportedRequiredExtensions.contains($0) }) else {
            throw GLTFImportError.unsupportedExtension
        }
        return try buildScene()
    }

    private func parseGLB(_ data: Data) throws {
        guard data.count >= 20,
              u32(data, 0) == 0x46546C67,
              u32(data, 4) == 2,
              Int(u32(data, 8)) == data.count else {
            throw GLTFImportError.invalidGLB
        }

        var offset = 12
        var jsonChunk: Data?
        var binChunk: Data?

        while offset + 8 <= data.count {
            let length = Int(u32(data, offset))
            let type = u32(data, offset + 4)
            offset += 8
            guard length >= 0,
                  offset <= data.count,
                  length <= data.count - offset else { throw GLTFImportError.invalidGLB }

            let chunk = data.subdata(in: offset..<(offset + length))
            if type == 0x4E4F534A {
                guard jsonChunk == nil, offset == 20 else { throw GLTFImportError.invalidGLB }
                jsonChunk = chunk
            }
            if type == 0x004E4942 {
                guard binChunk == nil, jsonChunk != nil else { throw GLTFImportError.invalidGLB }
                binChunk = chunk
            }
            offset += length
        }

        guard offset == data.count, let jsonChunk,
              let object = try JSONSerialization.jsonObject(with: jsonChunk) as? [String: Any] else {
            throw GLTFImportError.invalidJSON
        }

        json = object
        try loadBuffers(binaryChunk: binChunk)
    }

    private func loadBuffers(binaryChunk: Data?) throws {
        buffers.removeAll()
        let defs = json["buffers"] as? [[String: Any]] ?? []

        for (i, def) in defs.enumerated() {
            try Task.checkCancellation()
            if let uri = def["uri"] as? String {
                if uri.hasPrefix("data:") {
                    guard let comma = uri.firstIndex(of: ","),
                          let data = Data(base64Encoded: String(uri[uri.index(after: comma)...])) else {
                        throw GLTFImportError.invalidDataURI
                    }
                    buffers.append(data)
                } else {
                    let name = uri.removingPercentEncoding ?? uri
                    let candidate = baseURL.appendingPathComponent(name).standardizedFileURL
                    let basePath = baseURL.standardizedFileURL.path
                    guard candidate.path.hasPrefix(basePath + "/") || candidate.path == basePath else {
                        throw GLTFImportError.missingBuffer
                    }
                    buffers.append(try Data(contentsOf: candidate, options: [.mappedIfSafe]))
                }
            } else if i == 0, let binaryChunk {
                buffers.append(binaryChunk)
            } else {
                throw GLTFImportError.missingBuffer
            }
        }

        if defs.isEmpty, let binaryChunk { buffers = [binaryChunk] }
        var total = 0
        for (index, buffer) in buffers.enumerated() {
            guard buffer.count <= 384 * 1024 * 1024 - total else { throw GLTFImportError.resourceLimit }
            total += buffer.count
            if defs.indices.contains(index) {
                guard let declared = defs[index]["byteLength"] as? Int,
                      declared >= 0, declared <= buffer.count else { throw GLTFImportError.outOfBounds }
            }
        }
    }

    private func buildScene() throws -> SCNNode {
        let root = SCNNode()
        root.name = "glTF"

        let nodeDefs = json["nodes"] as? [[String: Any]] ?? []
        let meshDefs = json["meshes"] as? [[String: Any]] ?? []

        guard nodeDefs.count <= 20_000,
              meshDefs.count <= 10_000 else {
            throw GLTFImportError.resourceLimit
        }

        let childLists: [[Int]] = nodeDefs.map {
            ($0["children"] as? [Int]) ?? []
        }
        try validateHierarchy(childLists, nodeCount: nodeDefs.count)

        let nodes = nodeDefs.map { _ in SCNNode() }

        for i in nodeDefs.indices {
            let def = nodeDefs[i]
            let node = nodes[i]
            node.name = def["name"] as? String ?? "Node \(i + 1)"

            if let mesh = def["mesh"] as? Int, mesh >= 0, mesh < meshDefs.count {
                node.addChildNode(try buildMesh(index: mesh))
            }

            // Preserve cameras and KHR_lights_punctual nodes instead of silently
            // discarding them. They remain in the imported hierarchy and are fully
            // selectable/editable from the scene tree.
            if let cameraIndex = def["camera"] as? Int {
                node.camera = buildCamera(index: cameraIndex)
            }

            if let extensions = def["extensions"] as? [String: Any],
               let punctual = extensions["KHR_lights_punctual"] as? [String: Any],
               let lightIndex = punctual["light"] as? Int {
                node.light = buildPunctualLight(index: lightIndex)
            }

            applyTransform(def, to: node)
        }

        for i in nodeDefs.indices {
            for c in childLists[i] {
                nodes[i].addChildNode(nodes[c])
            }
        }

        let scenes = json["scenes"] as? [[String: Any]] ?? []
        let sceneIndex = (json["scene"] as? Int) ?? 0

        if sceneIndex >= 0, sceneIndex < scenes.count, let top = scenes[sceneIndex]["nodes"] as? [Int] {
            var seen = Set<Int>()
            for i in top {
                guard nodes.indices.contains(i), nodes[i].parent == nil, seen.insert(i).inserted else {
                    throw GLTFImportError.invalidHierarchy
                }
                root.addChildNode(nodes[i])
            }
        } else {
            let children = Set(nodeDefs.flatMap { ($0["children"] as? [Int]) ?? [] })
            for i in nodes.indices where !children.contains(i) { root.addChildNode(nodes[i]) }
        }

        if root.childNodes.isEmpty {
            for i in meshDefs.indices { root.addChildNode(try buildMesh(index: i)) }
        }

        try buildSkins(nodes: nodes, root: root)
        try applyTransformAnimations(to: nodes, root: root)
        return root
    }

    private func buildCamera(index: Int) -> SCNCamera? {
        let defs = json["cameras"] as? [[String: Any]] ?? []
        guard defs.indices.contains(index) else { return nil }

        let def = defs[index]
        let camera = SCNCamera()
        camera.name = def["name"] as? String

        switch def["type"] as? String {
        case "orthographic":
            guard let ortho = def["orthographic"] as? [String: Any] else {
                return camera
            }
            camera.usesOrthographicProjection = true
            if let ymag = ortho["ymag"] as? Double, ymag.isFinite, ymag > 0 {
                camera.orthographicScale = ymag * 2.0
            }
            if let near = ortho["znear"] as? Double, near.isFinite, near > 0 {
                camera.zNear = near
            }
            if let far = ortho["zfar"] as? Double, far.isFinite, far > camera.zNear {
                camera.zFar = far
            }

        default:
            if let perspective = def["perspective"] as? [String: Any] {
                if let yfov = perspective["yfov"] as? Double,
                   yfov.isFinite, yfov > 0 {
                    camera.fieldOfView = yfov * 180.0 / Double.pi
                }
                if let near = perspective["znear"] as? Double,
                   near.isFinite, near > 0 {
                    camera.zNear = near
                }
                if let far = perspective["zfar"] as? Double,
                   far.isFinite, far > camera.zNear {
                    camera.zFar = far
                }
            }
        }

        return camera
    }

    private func buildPunctualLight(index: Int) -> SCNLight? {
        guard let extensions = json["extensions"] as? [String: Any],
              let punctual = extensions["KHR_lights_punctual"] as? [String: Any],
              let lights = punctual["lights"] as? [[String: Any]],
              lights.indices.contains(index) else {
            return nil
        }

        let def = lights[index]
        let light = SCNLight()
        light.name = def["name"] as? String

        switch def["type"] as? String {
        case "directional":
            light.type = .directional
        case "spot":
            light.type = .spot
        default:
            light.type = .omni
        }

        if let rgb = def["color"] as? [Double], rgb.count >= 3 {
            light.color = UIColor(
                red: CGFloat(min(max(rgb[0], 0), 1)),
                green: CGFloat(min(max(rgb[1], 0), 1)),
                blue: CGFloat(min(max(rgb[2], 0), 1)),
                alpha: 1
            )
        }

        if let intensity = def["intensity"] as? Double,
           intensity.isFinite, intensity >= 0 {
            light.intensity = CGFloat(min(intensity, 1_000_000))
        }

        if let range = def["range"] as? Double,
           range.isFinite, range > 0 {
            light.attenuationStartDistance = 0
            light.attenuationEndDistance = range
        }

        if light.type == .spot,
           let spot = def["spot"] as? [String: Any] {
            if let inner = spot["innerConeAngle"] as? Double,
               inner.isFinite, inner >= 0 {
                light.spotInnerAngle = CGFloat(inner * 180.0 / Double.pi)
            }
            if let outer = spot["outerConeAngle"] as? Double,
               outer.isFinite, outer > 0 {
                light.spotOuterAngle = CGFloat(outer * 180.0 / Double.pi)
            }
        }

        return light
    }

    private func validateHierarchy(_ childLists: [[Int]], nodeCount: Int) throws {
        var parentCounts = Array(repeating: 0, count: nodeCount)

        for (parent, children) in childLists.enumerated() {
            for child in children {
                guard child >= 0, child < nodeCount, child != parent else {
                    throw GLTFImportError.invalidHierarchy
                }

                parentCounts[child] += 1
                guard parentCounts[child] <= 1 else {
                    throw GLTFImportError.invalidHierarchy
                }
            }
        }

        // 0 = unvisited, 1 = visiting, 2 = finished. Iterative DFS avoids
        // stack overflow on intentionally deep or malformed glTF files.
        var color = Array(repeating: UInt8(0), count: nodeCount)

        for start in 0..<nodeCount where color[start] == 0 {
            var stack: [(node: Int, nextChild: Int)] = [(start, 0)]
            color[start] = 1

            while !stack.isEmpty {
                let topIndex = stack.count - 1
                let node = stack[topIndex].node
                let nextChild = stack[topIndex].nextChild

                if nextChild >= childLists[node].count {
                    color[node] = 2
                    stack.removeLast()
                    continue
                }

                let child = childLists[node][nextChild]
                stack[topIndex].nextChild += 1

                if color[child] == 1 {
                    throw GLTFImportError.invalidHierarchy
                }

                if color[child] == 0 {
                    color[child] = 1
                    guard stack.count < 256 else { throw GLTFImportError.resourceLimit }
                    stack.append((child, 0))
                }
            }
        }
    }

    private func buildMesh(index: Int) throws -> SCNNode {
        try Task.checkCancellation()
        if let cached = meshCache[index] { return cached.clone() }
        let meshes = json["meshes"] as? [[String: Any]] ?? []
        guard index >= 0, index < meshes.count else { throw GLTFImportError.invalidMesh }

        let mesh = meshes[index]
        let root = SCNNode()
        root.name = mesh["name"] as? String ?? "Mesh \(index + 1)"

        for (pi, primitive) in ((mesh["primitives"] as? [[String: Any]]) ?? []).enumerated() {
            guard let attrs = primitive["attributes"] as? [String: Any],
                  let posIndex = attrs["POSITION"] as? Int else { throw GLTFImportError.invalidMesh }

            let pos = try readFloatAccessor(posIndex)
            guard pos.components == 3, pos.count > 0 else { throw GLTFImportError.invalidMesh }

            var sources = [
                source(pos.values, semantic: .vertex, count: pos.count, components: 3)
            ]

            if let ni = attrs["NORMAL"] as? Int {
                let n = try readFloatAccessor(ni)
                if n.components == 3 && n.count == pos.count {
                    sources.append(source(n.values, semantic: .normal, count: n.count, components: 3))
                }
            }

            let uvChannels = attrs.keys.compactMap { key -> Int? in
                guard key.hasPrefix("TEXCOORD_") else { return nil }
                return Int(key.dropFirst("TEXCOORD_".count))
            }
            if let last = uvChannels.max() {
                guard last >= 0, last < 8 else { throw GLTFImportError.resourceLimit }
                for channel in 0...last {
                    if let accessor = attrs["TEXCOORD_\(channel)"] as? Int {
                        let uv = try readFloatAccessor(accessor)
                        guard uv.components >= 2, uv.count == pos.count else { throw GLTFImportError.invalidMesh }
                        sources.append(source(firstComponents(uv.values, source: uv.components, count: 2), semantic: .texcoord, count: uv.count, components: 2))
                    } else {
                        sources.append(source([Float](repeating: 0, count: pos.count * 2), semantic: .texcoord, count: pos.count, components: 2))
                    }
                }
            }

            let mode = (primitive["mode"] as? Int) ?? 4
            let type: SCNGeometryPrimitiveType
            switch mode {
            case 0: type = .point
            case 1: type = .line
            case 4: type = .triangles
            case 5: type = .triangleStrip
            default:
                // LINE_LOOP, LINE_STRIP and TRIANGLE_FAN need explicit
                // conversion before SceneKit can represent them safely.
                throw GLTFImportError.unsupportedPrimitive
            }

            let indices: [UInt32]
            if let ii = primitive["indices"] as? Int {
                indices = try readIndices(ii)
            } else {
                indices = Array(0..<UInt32(pos.count))
            }

            guard !indices.isEmpty,
                  (mode != 4 || indices.count % 3 == 0),
                  (mode != 1 || indices.count % 2 == 0),
                  (mode != 5 || indices.count >= 3),
                  indices.allSatisfy({ Int($0) < pos.count }) else {
                throw GLTFImportError.invalidMesh
            }

            let count: Int
            switch type {
            case .point: count = indices.count
            case .line: count = indices.count / 2
            case .triangleStrip: count = max(0, indices.count - 2)
            default: count = indices.count / 3
            }

            let element = SCNGeometryElement(data: dataUInt32(indices), primitiveType: type, primitiveCount: count, bytesPerIndex: 4)
            let geometry = SCNGeometry(sources: sources, elements: [element])
            if let bounds = ImportedHierarchyProcessor.boundsForElement(element, geometry: geometry) {
                geometry.boundingBox = bounds
            }

            if let mi = primitive["material"] as? Int {
                geometry.materials = [material(mi)]
            } else {
                let m = SCNMaterial()
                m.lightingModel = .physicallyBased
                m.diffuse.contents = UIColor(white: 0.72, alpha: 1)
                m.roughness.contents = 0.45
                geometry.materials = [m]
            }

            let node = SCNNode(geometry: geometry)
            node.name = "Primitive \(pi + 1)"
            let targets = primitive["targets"] as? [[String: Any]] ?? []
            if !targets.isEmpty {
                guard targets.count <= 64 else { throw GLTFImportError.resourceLimit }
                var geometries: [SCNGeometry] = []
                for (targetIndex, target) in targets.enumerated() {
                    guard let accessor = target["POSITION"] as? Int else { throw GLTFImportError.invalidMesh }
                    let delta = try readFloatAccessor(accessor)
                    guard delta.count == pos.count && delta.components == 3 else { throw GLTFImportError.invalidMesh }
                    var positions = pos.values
                    for j in positions.indices { positions[j] += delta.values[j] }
                    var targetSources = [source(positions, semantic: .vertex, count: pos.count, components: 3)]
                    if let ni = attrs["NORMAL"] as? Int {
                        let base = try readFloatAccessor(ni)
                        if base.count == pos.count && base.components == 3 {
                            var normals = base.values
                            if let di = target["NORMAL"] as? Int {
                                let nd = try readFloatAccessor(di)
                                guard nd.count == pos.count && nd.components == 3 else { throw GLTFImportError.invalidMesh }
                                for j in normals.indices { normals[j] += nd.values[j] }
                            }
                            targetSources.append(source(normals, semantic: .normal, count: pos.count, components: 3))
                        }
                    }
                    let shape = SCNGeometry(sources: targetSources, elements: [element])
                    let names = (mesh["extras"] as? [String: Any])?["targetNames"] as? [String] ?? []
                    shape.name = targetIndex < names.count ? names[targetIndex] : "Morph \(targetIndex + 1)"
                    geometries.append(shape)
                }
                let morpher = SCNMorpher()
                morpher.calculationMode = .additive
                morpher.targets = geometries
                let weights = mesh["weights"] as? [NSNumber] ?? []
                for i in geometries.indices {
                    morpher.setWeight(CGFloat(i < weights.count ? weights[i].doubleValue : 0), forTargetAt: i)
                }
                node.morpher = morpher
            }
            root.addChildNode(node)
        }

        guard !root.childNodes.isEmpty else { throw GLTFImportError.invalidMesh }
        meshCache[index] = root
        return root.clone()
    }

    private func material(_ index: Int) -> SCNMaterial {
        if let cached = materialCache[index] { return cached }
        let result = SCNMaterial()
        result.lightingModel = .physicallyBased
        result.metalness.contents = 1.0
        result.roughness.contents = 1.0

        guard let defs = json["materials"] as? [[String: Any]], index >= 0, index < defs.count else { return result }
        let def = defs[index]
        result.name = def["name"] as? String

        if let pbr = def["pbrMetallicRoughness"] as? [String: Any] {
            if let f = pbr["baseColorFactor"] as? [Double], f.count >= 4 {
                result.diffuse.contents = UIColor(
                    red: CGFloat(min(max(f[0], 0), 1)),
                    green: CGFloat(min(max(f[1], 0), 1)),
                    blue: CGFloat(min(max(f[2], 0), 1)),
                    alpha: CGFloat(min(max(f[3], 0), 1))
                )
            }
            if let v = pbr["metallicFactor"] as? Double { result.metalness.contents = v }
            if let v = pbr["roughnessFactor"] as? Double { result.roughness.contents = v }

            if let tex = pbr["baseColorTexture"] as? [String: Any],
               let ti = tex["index"] as? Int,
               let image = imageForTexture(ti) {
                if let factor = result.diffuse.contents as? UIColor { result.multiply.contents = factor }
                result.diffuse.contents = image
                result.diffuse.wrapS = .repeat
                result.diffuse.wrapT = .repeat
                applyTextureInfo(tex, to: result.diffuse)
            }

            if let tex = pbr["metallicRoughnessTexture"] as? [String: Any],
               let ti = tex["index"] as? Int,
               let image = imageForTexture(ti) {
                result.metalness.contents = image
                result.roughness.contents = image
                result.metalness.textureComponents = .blue
                result.roughness.textureComponents = .green
                result.metalness.intensity = CGFloat((pbr["metallicFactor"] as? Double) ?? 1)
                result.roughness.intensity = CGFloat((pbr["roughnessFactor"] as? Double) ?? 1)
                applyTextureInfo(tex, to: result.metalness)
                applyTextureInfo(tex, to: result.roughness)
            }
        }

        if let extensions = def["extensions"] as? [String: Any],
           let specGloss = extensions["KHR_materials_pbrSpecularGlossiness"] as? [String: Any] {
            if let factor = specGloss["diffuseFactor"] as? [Double], factor.count >= 4 {
                result.diffuse.contents = UIColor(
                    red: CGFloat(min(max(factor[0], 0), 1)),
                    green: CGFloat(min(max(factor[1], 0), 1)),
                    blue: CGFloat(min(max(factor[2], 0), 1)),
                    alpha: CGFloat(min(max(factor[3], 0), 1))
                )
            }
            if let tex = specGloss["diffuseTexture"] as? [String: Any],
               let ti = tex["index"] as? Int,
               let image = imageForTexture(ti) {
                if let factor = result.diffuse.contents as? UIColor { result.multiply.contents = factor }
                result.diffuse.contents = image
                result.diffuse.wrapS = .repeat
                result.diffuse.wrapT = .repeat
                applyTextureInfo(tex, to: result.diffuse)
            }
            if let specularFactor = specGloss["specularFactor"] as? [Double], specularFactor.count >= 3 {
                result.specular.contents = UIColor(
                    red: CGFloat(min(max(specularFactor[0], 0), 1)),
                    green: CGFloat(min(max(specularFactor[1], 0), 1)),
                    blue: CGFloat(min(max(specularFactor[2], 0), 1)),
                    alpha: 1
                )
            }
            if let gloss = specGloss["glossinessFactor"] as? Double {
                result.roughness.contents = max(0, min(1, 1 - gloss))
            }
        }

        if let normal = def["normalTexture"] as? [String: Any],
           let ti = normal["index"] as? Int,
           let image = imageForTexture(ti) {
            result.normal.contents = image
            result.normal.intensity = CGFloat((normal["scale"] as? Double) ?? 1)
            applyTextureInfo(normal, to: result.normal)
        }

        if let occlusion = def["occlusionTexture"] as? [String: Any],
           let ti = occlusion["index"] as? Int,
           let image = imageForTexture(ti) {
            result.ambientOcclusion.contents = image
            result.ambientOcclusion.intensity = CGFloat((occlusion["strength"] as? Double) ?? 1)
            applyTextureInfo(occlusion, to: result.ambientOcclusion)
        }

        if let emissiveTexture = def["emissiveTexture"] as? [String: Any],
           let ti = emissiveTexture["index"] as? Int,
           let image = imageForTexture(ti) {
            result.emission.contents = image
            applyTextureInfo(emissiveTexture, to: result.emission)
        } else if let e = def["emissiveFactor"] as? [Double], e.count >= 3 {
            result.emission.contents = UIColor(
                red: CGFloat(min(max(e[0], 0), 1)),
                green: CGFloat(min(max(e[1], 0), 1)),
                blue: CGFloat(min(max(e[2], 0), 1)),
                alpha: 1
            )
        }

        if let alphaMode = def["alphaMode"] as? String {
            switch alphaMode {
            case "BLEND":
                result.transparencyMode = .dualLayer
                result.blendMode = .alpha
            case "MASK":
                // SceneKit on iPadOS does not expose glTF-style alpha cutoff directly.
                // Keep alpha blending enabled so masked textures still render.
                result.transparencyMode = .aOne
                result.blendMode = .alpha
            default:
                break
            }
        }

        result.isDoubleSided = (def["doubleSided"] as? Bool) ?? false
        materialCache[index] = result
        return result
    }

    private func applyTextureInfo(_ info: [String: Any], to property: SCNMaterialProperty) {
        property.mappingChannel = max(0, (info["texCoord"] as? Int) ?? 0)
        property.wrapS = .repeat; property.wrapT = .repeat
        if let index = info["index"] as? Int,
           let textures = json["textures"] as? [[String: Any]], textures.indices.contains(index),
           let samplerID = textures[index]["sampler"] as? Int,
           let samplers = json["samplers"] as? [[String: Any]], samplers.indices.contains(samplerID) {
            let sampler = samplers[samplerID]
            func wrap(_ value: Int?) -> SCNWrapMode {
                switch value { case 33071: return .clamp; case 33648: return .mirror; default: return .repeat }
            }
            property.wrapS = wrap(sampler["wrapS"] as? Int); property.wrapT = wrap(sampler["wrapT"] as? Int)
            property.magnificationFilter = (sampler["magFilter"] as? Int) == 9728 ? .nearest : .linear
            switch sampler["minFilter"] as? Int {
            case 9728: property.minificationFilter = .nearest; property.mipFilter = .none
            case 9729: property.minificationFilter = .linear; property.mipFilter = .none
            case 9984: property.minificationFilter = .nearest; property.mipFilter = .nearest
            case 9985: property.minificationFilter = .linear; property.mipFilter = .nearest
            case 9986: property.minificationFilter = .nearest; property.mipFilter = .linear
            default: property.minificationFilter = .linear; property.mipFilter = .linear
            }
        }
        if let extensions = info["extensions"] as? [String: Any],
           let transform = extensions["KHR_texture_transform"] as? [String: Any] {
            let offset = transform["offset"] as? [Double] ?? [0,0]
            let scale = transform["scale"] as? [Double] ?? [1,1]
            let rotation = (transform["rotation"] as? Double) ?? 0
            if let channel = transform["texCoord"] as? Int { property.mappingChannel = max(0, channel) }
            if offset.count == 2, scale.count == 2,
               (offset + scale + [rotation]).allSatisfy(\.isFinite) {
                var matrix = SCNMatrix4Identity
                matrix.m11 = Float(cos(rotation) * scale[0]); matrix.m12 = Float(sin(rotation) * scale[0])
                matrix.m21 = Float(-sin(rotation) * scale[1]); matrix.m22 = Float(cos(rotation) * scale[1])
                matrix.m41 = Float(offset[0]); matrix.m42 = Float(offset[1])
                property.contentsTransform = matrix
            }
        }
    }

    private func imageForTexture(_ textureIndex: Int) -> UIImage? {
        guard let textures = json["textures"] as? [[String: Any]], textures.indices.contains(textureIndex),
              let index = textures[textureIndex]["source"] as? Int,
              let images = json["images"] as? [[String: Any]], images.indices.contains(index) else { return nil }
        if let cached = imageCache[index] { return cached }
        guard decodedTextureBytes < 128 * 1024 * 1024 else {
            if !warnings.contains("بعض الخامات لم تُحمّل بسبب حد ذاكرة المعاينة.") {
                warnings.append("بعض الخامات لم تُحمّل بسبب حد ذاكرة المعاينة.")
            }
            return nil
        }
        let definition = images[index]
        var source: CGImageSource?
        let options = [kCGImageSourceShouldCache: false] as CFDictionary
        if let uri = definition["uri"] as? String {
            if uri.hasPrefix("data:"), let comma = uri.firstIndex(of: ","),
               let data = Data(base64Encoded: String(uri[uri.index(after: comma)...])) {
                source = CGImageSourceCreateWithData(data as CFData, options)
            } else {
                let candidate = baseURL.appendingPathComponent(uri.removingPercentEncoding ?? uri).standardizedFileURL
                guard candidate.path.hasPrefix(baseURL.standardizedFileURL.path + "/") else { return nil }
                source = CGImageSourceCreateWithURL(candidate as CFURL, options)
            }
        } else if let view = definition["bufferView"] as? Int, let data = try? bufferViewData(view) {
            source = CGImageSourceCreateWithData(data as CFData, options)
        }
        guard let source else {
            if !warnings.contains("بعض الصور مفقودة أو غير مدعومة؛ اختر ملفات الخامات مع الموديل.") {
                warnings.append("بعض الصور مفقودة أو غير مدعومة؛ اختر ملفات الخامات مع الموديل.")
            }
            return nil
        }
        let thumbnailOptions: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceThumbnailMaxPixelSize: 2048,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceShouldCacheImmediately: true
        ]
        guard let cg = CGImageSourceCreateThumbnailAtIndex(source, 0, thumbnailOptions as CFDictionary) else { return nil }
        decodedTextureBytes += cg.bytesPerRow * cg.height
        let image = UIImage(cgImage: cg)
        imageCache[index] = image
        return image
    }

    private func applyTransform(_ d: [String: Any], to node: SCNNode) {
        if let v = d["translation"] as? [Double],
           v.count >= 3, v.prefix(3).allSatisfy({ $0.isFinite && abs($0) <= Double(Float.greatestFiniteMagnitude) }) {
            node.position = SCNVector3(Float(v[0]), Float(v[1]), Float(v[2]))
        }
        if let v = d["rotation"] as? [Double],
           v.count >= 4, v.prefix(4).allSatisfy({ $0.isFinite && abs($0) <= Double(Float.greatestFiniteMagnitude) }) {
            node.orientation = SCNQuaternion(Float(v[0]), Float(v[1]), Float(v[2]), Float(v[3]))
        }
        if let v = d["scale"] as? [Double],
           v.count >= 3, v.prefix(3).allSatisfy({ $0.isFinite && abs($0) <= Double(Float.greatestFiniteMagnitude) }) {
            node.scale = SCNVector3(Float(v[0]), Float(v[1]), Float(v[2]))
        }
        if let v = d["matrix"] as? [Double],
           v.count >= 16, v.prefix(16).allSatisfy({ $0.isFinite && abs($0) <= Double(Float.greatestFiniteMagnitude) }) {
            var m = SCNMatrix4Identity
            m.m11 = Float(v[0]);  m.m12 = Float(v[1]);  m.m13 = Float(v[2]);  m.m14 = Float(v[3])
            m.m21 = Float(v[4]);  m.m22 = Float(v[5]);  m.m23 = Float(v[6]);  m.m24 = Float(v[7])
            m.m31 = Float(v[8]);  m.m32 = Float(v[9]);  m.m33 = Float(v[10]); m.m34 = Float(v[11])
            m.m41 = Float(v[12]); m.m42 = Float(v[13]); m.m43 = Float(v[14]); m.m44 = Float(v[15])
            node.transform = m
        }
    }

    struct AccessorLayout {
        let data: Data
        let start: Int
        let count: Int
        let components: Int
        let componentType: Int
        let bytes: Int
        let stride: Int
        let normalized: Bool
    }

    func accessorLayout(_ index: Int, indices: Bool = false) throws -> AccessorLayout {
        let accessors = json["accessors"] as? [[String: Any]] ?? []
        guard accessors.indices.contains(index) else { throw GLTFImportError.invalidAccessor }
        let a = accessors[index]
        guard a["sparse"] == nil else { throw GLTFImportError.unsupportedAccessor }
        guard let vi = a["bufferView"] as? Int, let count = a["count"] as? Int,
              let ct = a["componentType"] as? Int, let type = a["type"] as? String else {
            throw GLTFImportError.invalidAccessor
        }
        let bytes: Int
        switch ct {
        case 5120,5121: bytes = 1
        case 5122,5123: bytes = 2
        case 5125,5126: bytes = 4
        default: throw GLTFImportError.unsupportedAccessor
        }
        let components = componentCount(type)
        guard components > 0, (!type.hasPrefix("MAT") || (type == "MAT4" && ct == 5126)),
              !indices || (type == "SCALAR" && [5121,5123,5125].contains(ct)) else {
            throw GLTFImportError.unsupportedAccessor
        }
        let views = json["bufferViews"] as? [[String: Any]] ?? []
        guard views.indices.contains(vi), let bi = views[vi]["buffer"] as? Int, buffers.indices.contains(bi),
              let length = views[vi]["byteLength"] as? Int else { throw GLTFImportError.invalidBufferView }
        let data = buffers[bi]
        let offset = (views[vi]["byteOffset"] as? Int) ?? 0
        let accessorOffset = (a["byteOffset"] as? Int) ?? 0
        let width = bytes * components
        let stride = (views[vi]["byteStride"] as? Int) ?? width
        guard count > 0, count <= 8_000_000,
              offset >= 0, offset <= data.count,
              length >= 0, length <= data.count-offset,
              accessorOffset >= 0, accessorOffset <= length,
              width <= length-accessorOffset,
              stride >= width, stride <= 252, stride % bytes == 0,
              accessorOffset % bytes == 0, offset % bytes == 0,
              count-1 <= (length-accessorOffset-width)/stride else { throw GLTFImportError.outOfBounds }
        let allocation = count * components * 4
        guard allocation <= 256 * 1024 * 1024 - decodedAccessorBytes else { throw GLTFImportError.resourceLimit }
        decodedAccessorBytes += allocation
        return AccessorLayout(data: data, start: offset+accessorOffset, count: count,
                              components: components, componentType: ct, bytes: bytes, stride: stride,
                              normalized: (a["normalized"] as? Bool) ?? false)
    }

    func readFloatAccessor(_ index: Int) throws -> (values: [Float], count: Int, components: Int) {
        let a = try accessorLayout(index)
        var values: [Float] = []
        values.reserveCapacity(a.count*a.components)
        for row in 0..<a.count {
            if row % 4096 == 0 { try Task.checkCancellation() }
            for column in 0..<a.components {
                let offset = a.start+row*a.stride+column*a.bytes
                var value: Float
                switch a.componentType {
                case 5120:
                    value = Float(Int8(bitPattern: a.data[offset]))
                    if a.normalized { value = max(-1,value/127) }
                case 5121:
                    value = Float(a.data[offset]); if a.normalized { value /= 255 }
                case 5122:
                    value = Float(Int16(bitPattern: u16(a.data,offset)))
                    if a.normalized { value = max(-1,value/32767) }
                case 5123:
                    value = Float(u16(a.data,offset)); if a.normalized { value /= 65535 }
                case 5125: value = Float(u32(a.data,offset))
                default: value = Float(bitPattern: u32(a.data,offset))
                }
                guard value.isFinite else { throw GLTFImportError.invalidAccessor }
                values.append(value)
            }
        }
        return (values,a.count,a.components)
    }

    private func readIndices(_ index: Int) throws -> [UInt32] {
        let a = try accessorLayout(index, indices: true)
        var values: [UInt32] = []
        values.reserveCapacity(a.count)
        for row in 0..<a.count {
            let offset = a.start+row*a.stride
            switch a.bytes {
            case 1: values.append(UInt32(a.data[offset]))
            case 2: values.append(UInt32(u16(a.data,offset)))
            default: values.append(u32(a.data,offset))
            }
        }
        return values
    }

    private func bufferViewData(_ index: Int) throws -> Data {
        let views = json["bufferViews"] as? [[String: Any]] ?? []
        guard index >= 0, index < views.count else { throw GLTFImportError.invalidBufferView }
        let v = views[index]

        guard let bi = v["buffer"] as? Int,
              bi >= 0, bi < buffers.count,
              let length = v["byteLength"] as? Int, length >= 0 else { throw GLTFImportError.invalidBufferView }

        let offset = (v["byteOffset"] as? Int) ?? 0
        let data = buffers[bi]
        guard offset >= 0,
              length >= 0,
              offset <= data.count,
              length <= data.count - offset else { throw GLTFImportError.outOfBounds }
        return data.subdata(in: offset..<(offset + length))
    }

    private func source(_ values: [Float], semantic: SCNGeometrySource.Semantic, count: Int, components: Int) -> SCNGeometrySource {
        SCNGeometrySource(
            data: dataFloat(values),
            semantic: semantic,
            vectorCount: count,
            usesFloatComponents: true,
            componentsPerVector: components,
            bytesPerComponent: 4,
            dataOffset: 0,
            dataStride: components * 4
        )
    }

    private func firstComponents(_ values: [Float], source: Int, count: Int) -> [Float] {
        guard source > count else { return values }
        var out: [Float] = []
        var i = 0
        while i + source <= values.count {
            out.append(contentsOf: values[i..<(i + count)])
            i += source
        }
        return out
    }

    private func componentCount(_ type: String) -> Int {
        switch type {
        case "VEC2": 2
        case "VEC3": 3
        case "VEC4": 4
        case "MAT2": 4
        case "MAT3": 9
        case "MAT4": 16
        case "SCALAR": 1
        default: 0
        }
    }

    private func dataFloat(_ values: [Float]) -> Data {
        values.withUnsafeBufferPointer { p in
            guard let base = p.baseAddress else { return Data() }
            return Data(bytes: base, count: p.count * MemoryLayout<Float>.size)
        }
    }

    private func dataUInt32(_ values: [UInt32]) -> Data {
        values.withUnsafeBufferPointer { p in
            guard let base = p.baseAddress else { return Data() }
            return Data(bytes: base, count: p.count * MemoryLayout<UInt32>.size)
        }
    }

    private func u16(_ d: Data, _ o: Int) -> UInt16 {
        UInt16(d[o]) | (UInt16(d[o + 1]) << 8)
    }

    private func u32(_ d: Data, _ o: Int) -> UInt32 {
        UInt32(d[o]) |
        (UInt32(d[o + 1]) << 8) |
        (UInt32(d[o + 2]) << 16) |
        (UInt32(d[o + 3]) << 24)
    }
}

enum GLTFImportError: LocalizedError {
    case invalidGLB, invalidJSON, invalidDataURI, missingBuffer
    case invalidBufferView, invalidAccessor, unsupportedAccessor
    case invalidMesh, invalidHierarchy, unsupportedPrimitive, resourceLimit, outOfBounds
    case unsupportedExtension, animatedAsset

    var errorDescription: String? {
        switch self {
        case .unsupportedExtension: "الملف يحتاج امتداد glTF غير مدعوم. صدّر GLB غير مضغوط أو USDZ."
        case .animatedAsset: "هذا المستورد يدعم GLB ثابتًا؛ الملف يحتوي Rig/Animation/Morph. استخدم DAE أو USDZ للحفاظ على البيانات المدعومة."
        case .invalidGLB: "ملف GLB غير صالح."
        case .invalidJSON: "بيانات glTF غير صالحة."
        case .invalidDataURI: "بيانات glTF المضمنة غير صالحة."
        case .missingBuffer: "ملف .bin المطلوب غير موجود. حدده مع ملف glTF."
        case .invalidBufferView: "BufferView غير صالح داخل glTF."
        case .invalidAccessor: "Accessor غير صالح داخل glTF."
        case .unsupportedAccessor: "نوع بيانات داخل glTF غير مدعوم بعد."
        case .invalidMesh: "Mesh غير صالح داخل glTF."
        case .invalidHierarchy: "هيكل Nodes داخل glTF غير صالح أو يحتوي دورة/تكرار أبوي."
        case .unsupportedPrimitive: "نوع Primitive داخل glTF يحتاج تحويلًا غير مدعوم حاليًا."
        case .resourceLimit: "الموديل يحتوي عددًا ضخمًا جدًا من Nodes أو Meshes للاستيراد الآمن."
        case .outOfBounds: "بيانات المجسم تالفة أو خارج حدود الملف."
        }
    }
}

