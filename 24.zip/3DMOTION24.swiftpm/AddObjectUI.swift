import Foundation
import SwiftUI
import UIKit
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

@MainActor
struct TextStudioSheet: View {
    var editingSelected: Bool = false
    @EnvironmentObject var studio: StudioStore
    @Environment(\.dismiss) private var dismiss

    @State private var value = "نص جديد"
    @State private var fontName = ""
    @State private var style: StudioStore.TextMaterialStyle = .plain
    @State private var color: Color = .white
    @State private var extrusion: Double = 0.08
    @State private var chamfer: Double = 0.02
    @State private var flatness: Double = 0.12
    @State private var fontSearch = ""
    @State private var animationPreset: StudioStore.TextAnimationPreset?

    private var fonts: [String] {
        let all = studio.availableTextFonts()
        guard !fontSearch.isEmpty else { return all }
        return all.filter { $0.localizedCaseInsensitiveContains(fontSearch) }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    TextField(studio.tr("text"), text: $value, axis: .vertical)
                        .textFieldStyle(.roundedBorder)
                        .font(.title2.bold())
                        .lineLimit(2...5)

                    GroupBox(studio.tr("font")) {
                        VStack(spacing: 10) {
                            TextField(studio.appLanguage == .arabic ? "بحث عن خط" : "Search fonts", text: $fontSearch)
                                .textFieldStyle(.roundedBorder)

                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 8) {
                                    ForEach(fonts, id: \.self) { name in
                                        Button {
                                            fontName = name
                                        } label: {
                                            Text(value.isEmpty ? "Ab أب" : value)
                                                .font(Font(UIFont(name: name, size: 18) ?? .systemFont(ofSize: 18)))
                                                .lineLimit(1)
                                                .padding(.horizontal, 12)
                                                .padding(.vertical, 9)
                                                .background(fontName == name ? Color.accentColor.opacity(0.3) : Color.white.opacity(0.06),
                                                            in: RoundedRectangle(cornerRadius: 10))
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                            }
                        }
                    }

                    GroupBox(studio.tr("style")) {
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 92))], spacing: 10) {
                            ForEach(StudioStore.TextMaterialStyle.allCases) { item in
                                Button {
                                    style = item
                                } label: {
                                    VStack(spacing: 7) {
                                        Image(systemName: textStyleIcon(item))
                                            .font(.title2)
                                        Text(styleTitle(item))
                                            .font(.caption.bold())
                                    }
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 12)
                                    .background(style == item ? Color.accentColor.opacity(0.28) : Color.white.opacity(0.06),
                                                in: RoundedRectangle(cornerRadius: 12))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }

                    GroupBox(studio.tr("effects")) {
                        VStack(spacing: 14) {
                            ColorPicker(studio.tr("color"), selection: $color, supportsOpacity: true)
                            HStack {
                                Text(studio.tr("depth"))
                                Slider(value: $extrusion, in: 0...0.35)
                                Text(String(format: "%.2f", extrusion))
                                    .monospacedDigit()
                                    .frame(width: 44)
                            }
                            HStack {
                                Text(studio.tr("bevel"))
                                Slider(value: $chamfer, in: 0...0.12)
                                Text(String(format: "%.2f", chamfer))
                                    .monospacedDigit()
                                    .frame(width: 44)
                            }
                            HStack {
                                Text("Quality")
                                Slider(value: $flatness, in: 0.02...0.5)
                                Text(String(format: "%.2f", flatness))
                                    .monospacedDigit()
                                    .frame(width: 44)
                            }
                        }
                    }

                    GroupBox(studio.tr("textAnimation")) {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(StudioStore.TextAnimationPreset.allCases) { preset in
                                    Button {
                                        animationPreset = animationPreset == preset ? nil : preset
                                    } label: {
                                        Text(animationTitle(preset))
                                            .font(.caption.bold())
                                            .padding(.horizontal, 12)
                                            .padding(.vertical, 9)
                                            .background(animationPreset == preset ? Color.accentColor.opacity(0.3) : Color.white.opacity(0.06),
                                                        in: Capsule())
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                    }

                    // Live 2D preview of the chosen font/style before creating the 3D mesh.
                    Text(value.isEmpty ? "نص جديد" : value)
                        .font(Font(UIFont(name: fontName, size: 42) ?? .boldSystemFont(ofSize: 42)))
                        .foregroundStyle(color)
                        .shadow(color: style == .glow || style == .neon ? color.opacity(0.9) : .clear,
                                radius: style == .glow ? 14 : 7)
                        .frame(maxWidth: .infinity, minHeight: 100)
                        .background(Color.black.opacity(0.28), in: RoundedRectangle(cornerRadius: 14))
                }
                .padding()
            }
            .navigationTitle(studio.tr("textStudio"))
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(studio.tr("cancel")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(editingSelected ? studio.tr("editText") : studio.tr("create")) {
                        let uiColor = UIColor(color)
                        let selectedFont = fontName.isEmpty ? (studio.availableTextFonts().first ?? "HelveticaNeue-Bold") : fontName

                        if editingSelected {
                            studio.updateSelected3DText(
                                value: value,
                                fontName: selectedFont,
                                style: style,
                                color: uiColor,
                                extrusion: CGFloat(extrusion)
                            )
                            if let text = studio.selectedNode?.geometry as? SCNText {
                                text.chamferRadius = min(
                                    max(0, CGFloat(chamfer)),
                                    max(0.001, CGFloat(extrusion) * 0.8)
                                )
                                text.flatness = max(0.01, CGFloat(flatness))
                                studio.objectWillChange.send()
                            }
                        } else {
                            studio.add3DText(
                                value,
                                fontName: selectedFont,
                                style: style,
                                color: uiColor,
                                extrusion: CGFloat(extrusion),
                                chamfer: CGFloat(chamfer),
                                flatness: CGFloat(flatness)
                            )
                        }

                        if let animationPreset {
                            studio.animateSelectedText(animationPreset)
                        }
                        dismiss()
                    }
                    .disabled(
                        value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                        (editingSelected && !(studio.selectedNode?.geometry is SCNText))
                    )
                }
            }
            .onAppear {
                if editingSelected {
                    loadSelectedText()
                } else if fontName.isEmpty {
                    fontName = studio.availableTextFonts().first ?? "HelveticaNeue-Bold"
                }
            }
        }
        .environment(\.layoutDirection, studio.appLanguage.direction)
        .environment(\.locale, studio.appLanguage.locale)
    }

    private func loadSelectedText() {
        guard let node = studio.selectedNode, let text = node.geometry as? SCNText else { return }

        value = text.string as? String ?? ""
        fontName = (node.value(forKey: "studioTextFont") as? String)
            .flatMap { $0.isEmpty ? nil : $0 }
            ?? text.font?.fontName
            ?? studio.availableTextFonts().first
            ?? "HelveticaNeue-Bold"
        extrusion = Double(text.extrusionDepth)
        chamfer = Double(text.chamferRadius)
        flatness = Double(text.flatness)

        if let raw = node.value(forKey: "studioTextStyle") as? String,
           let parsed = StudioStore.TextMaterialStyle(rawValue: raw) {
            style = parsed
        }

        if let material = text.materials.first {
            if let uiColor = material.diffuse.contents as? UIColor {
                color = Color(uiColor: uiColor)
            } else if let uiColor = material.emission.contents as? UIColor {
                color = Color(uiColor: uiColor)
            }
        }
    }

    private func styleTitle(_ style: StudioStore.TextMaterialStyle) -> String {
        switch style {
        case .plain: return studio.tr("plain")
        case .metal: return studio.tr("metal")
        case .gold: return studio.tr("gold")
        case .neon: return studio.tr("neon")
        case .glass: return studio.tr("glass")
        case .matte: return studio.tr("matte")
        case .chrome: return studio.tr("chrome")
        case .glow: return studio.tr("glow")
        case .gradient: return studio.tr("gradient")
        case .outline: return studio.tr("outline")
        }
    }

    private func animationTitle(_ preset: StudioStore.TextAnimationPreset) -> String {
        switch preset {
        case .wave: return studio.tr("wave")
        case .pop: return studio.tr("pop")
        case .spin: return studio.tr("spin")
        case .float: return studio.tr("float")
        case .pulse: return studio.tr("pulse")
        }
    }

    private func textStyleIcon(_ style: StudioStore.TextMaterialStyle) -> String {
        switch style {
        case .plain: return "textformat"
        case .metal: return "circle.hexagongrid.fill"
        case .gold: return "sparkles"
        case .neon: return "bolt.fill"
        case .glass: return "drop.fill"
        case .matte: return "circle.fill"
        case .chrome: return "circle.lefthalf.filled"
        case .glow: return "sun.max.fill"
        case .gradient: return "circle.hexagongrid"
        case .outline: return "square.dashed"
        }
    }
}

struct AddObjectSheet: View {
    @EnvironmentObject var studio: StudioStore
    @Environment(\.dismiss) private var dismiss
    @State private var referencePhotoItem: PhotosPickerItem?
    @State private var showTextStudio = false
    @StateObject private var assetManager = AssetDownloadManager.shared

    let cols = [GridItem(.adaptive(minimum: 110), spacing: 12)]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text(studio.appLanguage == .arabic ? "الأشكال" : "Geometry")
                        .font(.headline)

                    LazyVGrid(columns: cols, spacing: 12) {
                        ForEach(PrimitiveKind.allCases, id: \.self) { kind in
                            addCard(kind.title, icon: kind.icon) {
                                studio.addPrimitive(kind)
                                dismiss()
                            }
                        }
                    }

                    Text(studio.appLanguage == .arabic ? "المكتبة الجاهزة" : "Built-in Asset Library")
                        .font(.headline)

                    Text(studio.appLanguage == .arabic ? "عشب" : "Grass")
                        .font(.caption.bold())
                        .foregroundStyle(.secondary)

                    LazyVGrid(columns: cols, spacing: 12) {
                        ForEach(BundledAssetKind.grass) { asset in
                            bundledAssetCard(asset) {
                                studio.addBundledModel(asset)
                                dismiss()
                            }
                        }
                    }

                    Text(studio.appLanguage == .arabic ? "أشجار" : "Trees")
                        .font(.caption.bold())
                        .foregroundStyle(.secondary)

                    LazyVGrid(columns: cols, spacing: 12) {
                        ForEach(BundledAssetKind.trees) { asset in
                            bundledAssetCard(asset) {
                                studio.addBundledModel(asset)
                                dismiss()
                            }
                        }
                    }

                    Text(studio.appLanguage == .arabic ? "نباتات وزهور" : "Plants & Flowers")
                        .font(.caption.bold())
                        .foregroundStyle(.secondary)

                    LazyVGrid(columns: cols, spacing: 12) {
                        ForEach(BundledAssetKind.plants) { asset in
                            bundledAssetCard(asset) {
                                studio.addBundledModel(asset)
                                dismiss()
                            }
                        }
                    }

                    Text(studio.appLanguage == .arabic ? "مشاهد وبيئات" : "Environments")
                        .font(.caption.bold())
                        .foregroundStyle(.secondary)

                    LazyVGrid(columns: cols, spacing: 12) {
                        ForEach(BundledAssetKind.environments) { asset in
                            bundledAssetCard(asset) {
                                studio.addBundledModel(asset)
                                dismiss()
                            }
                        }
                    }

                    Text(studio.appLanguage == .arabic ? "مؤثرات" : "FX")
                        .font(.caption.bold())
                        .foregroundStyle(.secondary)

                    LazyVGrid(columns: cols, spacing: 12) {
                        ForEach(BundledAssetKind.effects) { asset in
                            bundledAssetCard(asset) {
                                studio.addBundledModel(asset)
                                dismiss()
                            }
                        }
                    }

                    Text(studio.appLanguage == .arabic ? "أغراض" : "Props")
                        .font(.caption.bold())
                        .foregroundStyle(.secondary)

                    LazyVGrid(columns: cols, spacing: 12) {
                        ForEach(BundledAssetKind.props) { asset in
                            bundledAssetCard(asset) {
                                studio.addBundledModel(asset)
                                dismiss()
                            }
                        }
                    }

                    Text(studio.appLanguage == .arabic ? "موديلات إجرائية خفيفة" : "Lightweight Procedural Models")
                        .font(.headline)

                    Text(studio.appLanguage == .arabic ? "عشب ونباتات متحركة" : "Animated Grass & Plants")
                        .font(.caption.bold())
                        .foregroundStyle(.secondary)

                    LazyVGrid(columns: cols, spacing: 12) {
                        ForEach(ReadyModelKind.vegetation) { kind in
                            addCard(kind.title(for: studio.appLanguage), icon: kind.icon) {
                                studio.addReadyModel(kind)
                                dismiss()
                            }
                        }
                    }

                    Text(studio.appLanguage == .arabic ? "طبيعة" : "Nature")
                        .font(.caption.bold())
                        .foregroundStyle(.secondary)

                    LazyVGrid(columns: cols, spacing: 12) {
                        ForEach(ReadyModelKind.nature) { kind in
                            addCard(kind.title(for: studio.appLanguage), icon: kind.icon) {
                                studio.addReadyModel(kind)
                                dismiss()
                            }
                        }
                    }

                    Text(studio.appLanguage == .arabic ? "طرق وأرض" : "Roads & Ground")
                        .font(.caption.bold())
                        .foregroundStyle(.secondary)

                    LazyVGrid(columns: cols, spacing: 12) {
                        ForEach(ReadyModelKind.roads) { kind in
                            addCard(kind.title(for: studio.appLanguage), icon: kind.icon) {
                                studio.addReadyModel(kind)
                                dismiss()
                            }
                        }
                    }

                    Text(studio.appLanguage == .arabic ? "مباني وهياكل" : "Buildings & Structures")
                        .font(.caption.bold())
                        .foregroundStyle(.secondary)

                    LazyVGrid(columns: cols, spacing: 12) {
                        ForEach(ReadyModelKind.structures) { kind in
                            addCard(kind.title(for: studio.appLanguage), icon: kind.icon) {
                                studio.addReadyModel(kind)
                                dismiss()
                            }
                        }
                    }

                    Text(studio.appLanguage == .arabic ? "أغراض جاهزة" : "Ready Props")
                        .font(.caption.bold())
                        .foregroundStyle(.secondary)

                    LazyVGrid(columns: cols, spacing: 12) {
                        ForEach(ReadyModelKind.props) { kind in
                            addCard(kind.title(for: studio.appLanguage), icon: kind.icon) {
                                studio.addReadyModel(kind)
                                dismiss()
                            }
                        }
                    }

                    Text(studio.appLanguage == .arabic ? "المشهد" : "Scene")
                        .font(.headline)

                    LazyVGrid(columns: cols, spacing: 12) {
                        addCard(studio.tr("empty"), icon: "circle.dashed") {
                            studio.addEmpty()
                            dismiss()
                        }

                        addCard(studio.tr("camera"), icon: "camera.fill") {
                            studio.addCamera()
                            dismiss()
                        }

                        addCard(
                            studio.tr("text3d"),
                            icon: "textformat"
                        ) {
                            showTextStudio = true
                        }

                        ForEach(LightKind.allCases, id: \.self) { kind in
                            addCard(kind.title, icon: "lightbulb.fill") {
                                studio.addLight(kind)
                                dismiss()
                            }
                        }
                    }

                    Text(studio.appLanguage == .arabic ? "المرجع" : "Reference")
                        .font(.headline)

                    PhotosPicker(
                        selection:
                            $referencePhotoItem,
                        matching: .images
                    ) {
                        Label(
                            studio.tr("referenceImage"),
                            systemImage:
                                "photo.badge.plus"
                        )
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(
                            Color.white.opacity(0.06),
                            in:
                                RoundedRectangle(
                                    cornerRadius: 12
                                )
                        )
                    }
                    .buttonStyle(.plain)
                    .onChange(
                        of: referencePhotoItem
                    ) { _, newItem in
                        guard let newItem else {
                            return
                        }

                        Task { @MainActor in
                            if let data =
                                try? await newItem
                                    .loadTransferable(
                                        type: Data.self
                                    ),
                               let image =
                                UIImage(data: data) {
                                studio.addReferenceImage(
                                    image
                                )
                                dismiss()
                            }
                        }
                    }

                    Text("FX / Design")
                        .font(.headline)

                    LazyVGrid(columns: cols, spacing: 12) {
                        ForEach(ParticleKind.allCases, id: \.self) { kind in
                            addCard(kind.title, icon: kind.icon) {
                                studio.addParticle(kind)
                                dismiss()
                            }
                        }

                        addCard("Neon Trail", icon: "waveform.path") {
                            studio.addNeonTrail()
                            dismiss()
                        }
                    }
                }
                .padding()
            }
            .navigationTitle(studio.tr("add"))
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(studio.tr("done")) { dismiss() }
                }
            }
        }
        .sheet(isPresented: $showTextStudio) {
            TextStudioSheet()
                .environmentObject(studio)
                .presentationDetents([.large])
        }
    }


    private func bundledAssetCard(_ asset: BundledAssetKind, action: @escaping () -> Void) -> some View {
        let manager = assetManager
        let installed = manager.isInstalled(asset)
        let downloading = manager.isDownloading(asset)

        return VStack(spacing: 7) {
            Group {
                if let preview = asset.thumbnailImage() {
                    Image(uiImage: preview).resizable().scaledToFill()
                } else {
                    ZStack {
                        Color.black.opacity(0.20)
                        Image(systemName: "cube.transparent").font(.title2).foregroundStyle(.secondary)
                    }
                }
            }
            .frame(maxWidth: .infinity).frame(height: 82).clipped()
            .clipShape(RoundedRectangle(cornerRadius: 11))

            Text(asset.title(for: studio.appLanguage))
                .font(.caption2.bold()).lineLimit(2).multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)

            HStack(spacing: 7) {
                if installed {
                    Button {
                        action()
                    } label: {
                        Label(studio.appLanguage == .arabic ? "إضافة" : "Add", systemImage: "plus")
                    }
                    .buttonStyle(.borderedProminent).controlSize(.mini)

                    Button(role: .destructive) {
                        do { try manager.delete(asset) }
                        catch { studio.toast = error.localizedDescription }
                    } label: { Image(systemName: "trash") }
                    .buttonStyle(.bordered).controlSize(.mini)
                } else if downloading {
                    ProgressView().controlSize(.small)
                    Text(studio.appLanguage == .arabic ? "تنزيل…" : "Downloading…")
                        .font(.caption2).foregroundStyle(.secondary)
                } else {
                    Button {
                        Task {
                            do {
                                try await manager.download(asset)
                                studio.toast = studio.appLanguage == .arabic ? "اكتمل تنزيل الموديل" : "Model downloaded"
                            } catch {
                                studio.toast = studio.appLanguage == .arabic ? "فشل التنزيل: \(error.localizedDescription)" : "Download failed: \(error.localizedDescription)"
                            }
                        }
                    } label: {
                        Label(studio.appLanguage == .arabic ? "تنزيل" : "Download", systemImage: "arrow.down.circle")
                    }
                    .buttonStyle(.bordered).controlSize(.mini)
                }
            }
            .frame(height: 28)
        }
        .padding(7)
        .frame(maxWidth: .infinity)
        .frame(height: 150)
        .background(Color(red: 0.18, green: 0.18, blue: 0.20).opacity(0.95), in: RoundedRectangle(cornerRadius: 14))
        .id("\(asset.id)-\(manager.revision)")
    }

    private func addCard(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 10) {
                Image(systemName: icon)
                    .font(.title2)
                Text(title)
                    .font(.caption.bold())
            }
            .frame(maxWidth: .infinity)
            .frame(height: 82)
            .background(Color(red: 0.18, green: 0.18, blue: 0.20).opacity(0.95), in: RoundedRectangle(cornerRadius: 14))
        }
        .buttonStyle(.plain)
    }
}

