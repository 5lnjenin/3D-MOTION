import SwiftUI

@MainActor
struct TimelineEditMenu: View {
    @EnvironmentObject var studio: StudioStore
    let editAudio: (StudioAudioClip) -> Void
    private var arabic: Bool { studio.appLanguage == .arabic }

    var body: some View {
        Menu {
            if let id = studio.selectedAudioClipID, let clip = studio.audioClips.first(where: { $0.id == id }) {
                Button(arabic ? "قص وتحرير الصوت" : "Trim / edit audio", systemImage: "slider.horizontal.3") { editAudio(clip) }
                Button(arabic ? "تقسيم عند المؤشر" : "Split at playhead", systemImage: "scissors") { studio.splitAudioClip(id, at: studio.currentTime) }
                    .disabled(clip.loops || studio.currentTime <= clip.startTime + 0.001 || studio.currentTime >= clip.endTime - 0.001)
                Button(arabic ? "قص إلى الحافظة" : "Cut", systemImage: "scissors") { studio.cutAudioClip(id) }
                Button(arabic ? "نسخ" : "Copy", systemImage: "doc.on.doc") { studio.copyAudioClip(id) }
                Button(arabic ? "تكرار المقطع" : "Duplicate clip", systemImage: "plus.square.on.square") { studio.duplicateAudioClip(id) }
                Button(role: .destructive) { studio.removeAudioClip(id) } label: {
                    Label(arabic ? "حذف المقطع فقط" : "Delete clip only", systemImage: "trash")
                }
            } else if studio.selectedKeyframeID != nil {
                Button(arabic ? "قص نقطة الحركة" : "Cut keyframe", systemImage: "scissors") { studio.cutSelectedKeyframe() }
                Button(arabic ? "نسخ نقطة الحركة" : "Copy keyframe", systemImage: "doc.on.doc") { studio.copySelectedKeyframe() }
                Button(arabic ? "تكرار نقطة الحركة" : "Duplicate keyframe", systemImage: "plus.square.on.square") { studio.duplicateSelectedKeyframe() }
                Button(role: .destructive) { studio.deleteSelectedKeyframe() } label: {
                    Label(arabic ? "حذف نقطة الحركة" : "Delete keyframe", systemImage: "trash")
                }
            } else if let node = studio.selectedNode, let track = studio.selectedMotionTrackID {
                Button(arabic ? "قص مسار الحركة" : "Cut animation track", systemImage: "scissors") { studio.cutMotionTrack(track, for: node) }
                Button(arabic ? "نسخ مسار الحركة" : "Copy animation track", systemImage: "doc.on.doc") { studio.copyMotionTrack(track, for: node) }
                Button(arabic ? "تكرار المسار" : "Duplicate track", systemImage: "plus.square.on.square") { studio.duplicateMotionTrack(track, for: node) }
                Button(role: .destructive) { studio.deleteMotionTrack(track, for: node) } label: {
                    Label(arabic ? "حذف المسار" : "Delete track", systemImage: "trash")
                }
            } else {
                Text(arabic ? "حدد مقطعًا أو نقطة أو مسارًا" : "Select a clip, keyframe or track")
            }
            Divider()
            Button(arabic ? "لصق الصوت عند المؤشر" : "Paste audio at playhead", systemImage: "doc.on.clipboard") { studio.pasteAudioClip() }
                .disabled(studio.audioClipboard == nil)
            Button(arabic ? "لصق نقطة الحركة" : "Paste keyframe", systemImage: "diamond") { studio.pasteKeyframe() }
                .disabled(studio.keyframeClipboard == nil || studio.selectedNode == nil)
            Button(arabic ? "لصق مسار الحركة" : "Paste animation track", systemImage: "rectangle.stack") {
                if let node = studio.selectedNode { studio.pasteMotionTrack(to: node) }
            }.disabled(studio.animationClipboardFrames.isEmpty || studio.selectedNode == nil)
        } label: {
            Label(arabic ? "تحرير" : "Edit", systemImage: "ellipsis.circle")
        }
        .accessibilityLabel(arabic ? "أدوات المقطع أو المسار المحدد" : "Selected clip or track actions")
    }
}

@MainActor
struct AudioClipEditorSheet: View {
    @EnvironmentObject var studio: StudioStore
    @Environment(\.dismiss) private var dismiss
    let clip: StudioAudioClip
    @State private var start: Double
    @State private var trimIn: Double
    @State private var trimOut: Double
    @State private var volume: Double
    @State private var loops: Bool

    init(clip: StudioAudioClip) {
        self.clip = clip
        _start = State(initialValue: clip.startTime)
        _trimIn = State(initialValue: clip.sourceStart)
        _trimOut = State(initialValue: clip.trimmedEnd)
        _volume = State(initialValue: clip.volume)
        _loops = State(initialValue: clip.loops)
    }

    private var arabic: Bool { studio.appLanguage == .arabic }
    private var valid: Bool { start.isFinite && start >= 0 && trimIn.isFinite && trimOut.isFinite && trimIn >= 0 && trimOut <= clip.sourceDuration && trimOut - trimIn >= 0.001 }

    var body: some View {
        NavigationStack {
            Form {
                Section(arabic ? "المقطع" : "Clip") {
                    Text(clip.name)
                    numberRow(arabic ? "البداية على التراك" : "Timeline start", value: $start)
                }
                Section(arabic ? "قص الصوت" : "Trim audio") {
                    numberRow(arabic ? "بداية الجزء من الملف" : "Source in", value: $trimIn)
                    Slider(value: $trimIn, in: 0...max(0.001, clip.sourceDuration))
                    numberRow(arabic ? "نهاية الجزء من الملف" : "Source out", value: $trimOut)
                    Slider(value: $trimOut, in: 0...max(0.001, clip.sourceDuration))
                    Text(String(format: arabic ? "مدة المقطع: %.3f ثانية" : "Clip duration: %.3f seconds", max(0, trimOut - trimIn)))
                        .monospacedDigit()
                    HStack {
                        Button(arabic ? "قص البداية للمؤشر" : "Trim start to playhead") {
                            let offset = studio.currentTime - start
                            trimIn += offset; start = studio.currentTime
                        }
                        .disabled(loops || studio.currentTime <= start || studio.currentTime >= start + trimOut - trimIn)
                        Button(arabic ? "قص النهاية للمؤشر" : "Trim end to playhead") {
                            trimOut = trimIn + studio.currentTime - start
                        }
                        .disabled(loops || studio.currentTime <= start || studio.currentTime >= start + trimOut - trimIn)
                    }
                    Text(arabic ? "القص يحدد الجزء المستخدم، ويحتفظ بالملف الأصلي كاملًا." : "Trimming changes the used range and keeps the original file intact.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section(arabic ? "التشغيل" : "Playback") {
                    Slider(value: $volume, in: 0...1) {
                        Text(arabic ? "مستوى الصوت" : "Volume")
                    }
                    Text(String(format: arabic ? "مستوى الصوت: %.0f%%" : "Volume: %.0f%%", volume * 100))
                    Toggle(arabic ? "تكرار الجزء المقصوص" : "Loop trimmed range", isOn: $loops)
                }
            }
            .navigationTitle(arabic ? "تحرير الصوت" : "Edit audio")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(arabic ? "إلغاء" : "Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(arabic ? "حفظ" : "Save") {
                        if studio.editAudioClip(clip.id, startTime: start, sourceStart: trimIn, sourceEnd: trimOut, volume: volume, loops: loops) { dismiss() }
                    }.disabled(!valid)
                }
            }
        }
        .environment(\.layoutDirection, studio.appLanguage.direction)
    }

    private func numberRow(_ title: String, value: Binding<Double>) -> some View {
        HStack {
            Text(title)
            Spacer()
            TextField(title, value: value, format: .number.precision(.fractionLength(3)))
                .keyboardType(.decimalPad).multilineTextAlignment(.trailing)
                .frame(width: 110).monospacedDigit()
            Text(arabic ? "ث" : "s").foregroundStyle(.secondary)
        }
    }
}

@MainActor
struct ProjectAudioFiles: View {
    @EnvironmentObject var studio: StudioStore
    @State private var pendingDelete: StudioAudioAsset?
    @State private var expanded = true
    let query: String

    private var assets: [StudioAudioAsset] {
        studio.audioAssets.filter { query.isEmpty || $0.name.localizedCaseInsensitiveContains(query) }
    }

    var body: some View {
        DisclosureGroup(isExpanded: $expanded) {
            if assets.isEmpty {
                Text(studio.appLanguage == .arabic ? "الملفات الصوتية المستوردة تظهر هنا" : "Imported audio files appear here")
                    .font(.caption).foregroundStyle(.secondary).padding(.vertical, 8)
            }
            ForEach(assets) { asset in
                HStack(spacing: 6) {
                    Image(systemName: "waveform").foregroundStyle(.mint)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(asset.name).lineLimit(1)
                        let count = studio.audioClips.filter { $0.assetID == asset.id }.count
                        Text(String(format: studio.appLanguage == .arabic ? "%.1f ث · %d مقطع" : "%.1f s · %d clips", asset.duration, count))
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                    Menu {
                        Button {
                            studio.addAudioAssetToTimeline(asset.id)
                        } label: {
                            Label(studio.appLanguage == .arabic ? "استخدام عند المؤشر" : "Use at playhead", systemImage: "plus")
                        }
                        Button(role: .destructive) { pendingDelete = asset } label: {
                            Label(studio.appLanguage == .arabic ? "حذف الملف من المشروع" : "Delete file from project", systemImage: "trash")
                        }
                    } label: { Image(systemName: "ellipsis.circle").frame(width: 32, height: 44) }
                }
                .font(.caption).padding(.vertical, 2)
            }
        } label: {
            Label(studio.appLanguage == .arabic ? "ملفات الصوت (\(studio.audioAssets.count))" : "Audio files (\(studio.audioAssets.count))", systemImage: "folder")
                .font(.caption.bold())
        }
        .confirmationDialog(studio.appLanguage == .arabic ? "حذف الملف وجميع مقاطعه من المشروع؟" : "Delete this file and all its clips from the project?", isPresented: Binding(
            get: { pendingDelete != nil }, set: { if !$0 { pendingDelete = nil } }
        ), titleVisibility: .visible) {
            Button(studio.appLanguage == .arabic ? "حذف من المشروع" : "Delete from project", role: .destructive) {
                if let asset = pendingDelete { studio.removeAudioAsset(asset.id) }
                pendingDelete = nil
            }
            Button(studio.appLanguage == .arabic ? "إلغاء" : "Cancel", role: .cancel) { pendingDelete = nil }
        } message: {
            Text(pendingDelete?.name ?? "")
        }
    }
}

@MainActor
struct AudioTimelineRow: View {
    @EnvironmentObject var studio: StudioStore
    let clips: [StudioAudioClip]
    let width: CGFloat
    let pixelsPerSecond: CGFloat
    let edit: (StudioAudioClip) -> Void

    var body: some View {
        ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: 6).fill(Color.white.opacity(0.035)).frame(width: width, height: 36)
            ForEach(clips) { clip in
                AudioTimelineBlock(clip: clip, pixelsPerSecond: pixelsPerSecond, edit: edit)
                    .offset(x: CGFloat(clip.startTime) * pixelsPerSecond)
            }
        }.frame(width: width, height: 38)
    }
}

@MainActor
private struct AudioTimelineBlock: View {
    @EnvironmentObject var studio: StudioStore
    let clip: StudioAudioClip
    let pixelsPerSecond: CGFloat
    let edit: (StudioAudioClip) -> Void
    @State private var translation: CGFloat = 0

    var body: some View {
        let visibleDuration = clip.loops ? max(clip.trimmedDuration, studio.duration - clip.startTime) : clip.trimmedDuration
        HStack(spacing: 5) {
            Image(systemName: "waveform")
            Text(clip.name).lineLimit(1)
            if clip.loops { Image(systemName: "repeat") }
        }
        .font(.caption).padding(.horizontal, 6)
        .frame(width: max(20, CGFloat(visibleDuration) * pixelsPerSecond), height: 32, alignment: .leading)
        .background(studio.selectedAudioClipID == clip.id ? Color.mint.opacity(0.85) : Color.teal.opacity(0.65), in: RoundedRectangle(cornerRadius: 5))
        .overlay(RoundedRectangle(cornerRadius: 5).stroke(studio.selectedAudioClipID == clip.id ? Color.white : .clear, lineWidth: 1.5))
        .foregroundStyle(.white)
        .contentShape(Rectangle())
        .offset(x: translation)
        .onTapGesture(count: 2) { studio.selectAudioClip(clip.id); edit(clip) }
        .onTapGesture { studio.selectAudioClip(clip.id) }
        .gesture(DragGesture(minimumDistance: 4).onChanged { value in
            translation = max(-CGFloat(clip.startTime) * pixelsPerSecond, value.translation.width)
        }.onEnded { _ in
            let time = max(0, clip.startTime + Double(translation / pixelsPerSecond))
            translation = 0; studio.selectAudioClip(clip.id)
            studio.updateAudioClip(id: clip.id, startTime: (time * studio.fps).rounded() / studio.fps)
        })
        .accessibilityLabel("\(clip.name), \(String(format: "%.2f", clip.startTime))")
        .accessibilityAddTraits(.isButton)
        .accessibilityAction { studio.selectAudioClip(clip.id); edit(clip) }
    }
}
