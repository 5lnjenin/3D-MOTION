import Foundation

/// AVFoundation objects remain on the main actor. Cancellation may arrive from
/// any executor, so the Sendable handler captures this actor-isolated owner.
@MainActor
final class MediaExportCancellation {
    private let action: () -> Void

    init(_ action: @escaping () -> Void) { self.action = action }

    nonisolated func request() {
        Task { @MainActor in self.action() }
    }
}
