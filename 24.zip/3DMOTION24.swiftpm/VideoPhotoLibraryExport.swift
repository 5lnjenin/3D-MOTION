import Foundation
import AVFoundation
import Photos

/// Photos may classify a >60 FPS import as slow motion and retime it. The
/// original high-FPS file stays untouched; saving there is an explicit 60 FPS
/// compatibility copy, retaining dimensions, playback duration and audio.
@MainActor
enum VideoPhotoLibraryExport {
    static func compatibleCopy(of source: URL, options: StudioVideoExportOptions) async throws -> URL {
        try await StudioStore.validateExportedVideo(source, options: options, requiresAudio: false)
        guard options.fps > 60 else { return source }
        let asset = AVURLAsset(url: source)
        let output = FileManager.default.temporaryDirectory.appendingPathComponent(
            "3DMOTION-\(options.resolution.rawValue)-60FPS-Photos-\(UUID().uuidString).mp4")
        let picture = output.deletingPathExtension().appendingPathExtension("picture.mp4")
        defer { try? FileManager.default.removeItem(at: picture) }
        do {
            let hasAudio = try await asset.loadTracks(withMediaType: .audio).isEmpty == false
            let compatible = StudioVideoExportOptions(resolution: options.resolution, fps: 60,
                duration: options.encodedDuration)
            try await VideoFrameRateConverter.convert(source, to: picture, options: compatible)
            if hasAudio { try await VideoAudioMixer.mux(video: picture, audio: source, output: output) }
            else { try FileManager.default.moveItem(at: picture, to: output) }
            try await StudioStore.validateExportedVideo(output, options: compatible, requiresAudio: hasAudio)
            return output
        } catch {
            try? FileManager.default.removeItem(at: output)
            throw error
        }
    }

    static func save(_ url: URL) async throws {
        let permission = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard permission == .authorized || permission == .limited else {
            throw StudioVideoFailure.problem("اسمح بحفظ الفيديو من الإعدادات / Allow Photos access")
        }
        try await PHPhotoLibrary.shared().performChanges {
            PHAssetCreationRequest.forAsset().addResource(with: .video, fileURL: url, options: nil)
        }
    }
}

@MainActor
extension StudioStore {
    func saveExportedVideoToPhotos() {
        guard !isSavingVideoToPhotos, !isExporting,
              let original = exportedVideoURL, let options = exportedVideoOptions else { return }
        isSavingVideoToPhotos = true
        toast = appLanguage == .arabic ? "جارٍ تجهيز الفيديو للصور…" : "Preparing video for Photos…"
        Task { @MainActor in
            var prepared: URL?
            defer {
                isSavingVideoToPhotos = false
                if let prepared, prepared != original { try? FileManager.default.removeItem(at: prepared) }
            }
            do {
                let copy = try await VideoPhotoLibraryExport.compatibleCopy(of: original, options: options)
                prepared = copy
                try await VideoPhotoLibraryExport.save(copy)
                toast = appLanguage == .arabic
                    ? (options.fps > 60 ? "حُفظت نسخة 60 FPS في الصور؛ الأصلي متاح للحفظ في الملفات" : "تم حفظ الفيديو في الصور")
                    : (options.fps > 60 ? "60 FPS copy saved to Photos; save the original to Files" : "Video saved to Photos")
            } catch { toast = "تعذر الحفظ في الصور / Photos save failed: \(error.localizedDescription)" }
        }
    }
}
