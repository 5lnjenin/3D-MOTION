import Foundation
import UIKit
import SceneKit

@MainActor
extension StudioStore {
    /// The renderer keeps its live maps/lights throughout save and autosave.
    /// Clone the complete graph once so cross-object bones and constraints bind
    /// to snapshot nodes, then remove only editor objects from that snapshot.
    func makePersistenceSceneSnapshot() throws -> SCNScene {
        let originals = ProjectSceneCodec.nodes(in: scene.rootNode)
        for node in originals where node.studioAnimationID == nil { _ = animationIdentity(node) }
        let links = capturePhysicsLinks()
        guard links.count == scene.physicsWorld.allBehaviors.count else { throw ProjectFailure.unsupported("physics behavior") }
        let root = cleanDeepClone(scene.rootNode, copyGeometry: true)
        var copied: [String: SCNNode] = [:]
        for node in ProjectSceneCodec.nodes(in: root) {
            guard let id = node.studioAnimationID, copied[id] == nil else { throw ProjectFailure.invalid("duplicate node identity") }
            copied[id] = node
        }
        var materials: [ObjectIdentifier: SCNMaterial] = [:]
        for original in originals {
            guard let id = original.studioAnimationID, let node = copied[id], let geometry = node.geometry else { continue }
            geometry.materials = (original.geometry?.materials ?? []).map { material in
                let key = ObjectIdentifier(material)
                if let existing = materials[key] { return existing }
                let copy = material.copy() as! SCNMaterial
                // These caches describe a temporary display override only.
                // In rendered mode the material itself is the authored truth.
                if previousViewportShadingMode != .rendered, let model = materialLighting.object(forKey: material) {
                    copy.lightingModel = SCNMaterial.LightingModel(rawValue: model as String)
                    copy.fillMode = .fill
                }
                if previousViewportShadingMode == .lit {
                    if let value = materialSpecular.object(forKey: material) { copy.specular.intensity = CGFloat(value.doubleValue) }
                    if let value = materialShininess.object(forKey: material) { copy.shininess = CGFloat(value.doubleValue) }
                }
                if !previousBackfaceCullingEnabled, let sided = materialDoubleSided.object(forKey: material) {
                    copy.isDoubleSided = sided.boolValue
                }
                materials[key] = copy
                return copy
            }
        }
        let snapshot = SCNScene()
        snapshot.rootNode.name = scene.rootNode.name
        snapshot.rootNode.studioAnimationID = scene.rootNode.studioAnimationID
        snapshot.rootNode.transform = root.transform
        snapshot.rootNode.pivot = root.pivot
        snapshot.rootNode.opacity = root.opacity
        snapshot.rootNode.isHidden = root.isHidden
        snapshot.rootNode.categoryBitMask = root.categoryBitMask
        for child in root.childNodes where child.name != "_Editor" && child.name != "_Helpers" {
            snapshot.rootNode.addChildNode(child)
        }
        snapshot.background.contents = scene.background.contents
        snapshot.background.intensity = scene.background.intensity
        snapshot.background.contentsTransform = scene.background.contentsTransform
        snapshot.lightingEnvironment.contents = scene.lightingEnvironment.contents
        snapshot.lightingEnvironment.intensity = scene.lightingEnvironment.intensity
        snapshot.lightingEnvironment.contentsTransform = scene.lightingEnvironment.contentsTransform
        snapshot.fogStartDistance = scene.fogStartDistance
        snapshot.fogEndDistance = scene.fogEndDistance
        snapshot.fogDensityExponent = scene.fogDensityExponent
        snapshot.fogColor = scene.fogColor
        snapshot.physicsWorld.gravity = scene.physicsWorld.gravity
        snapshot.physicsWorld.speed = scene.physicsWorld.speed
        snapshot.physicsWorld.timeStep = scene.physicsWorld.timeStep
        restorePhysicsLinks(links, in: snapshot)
        return snapshot
    }
}
