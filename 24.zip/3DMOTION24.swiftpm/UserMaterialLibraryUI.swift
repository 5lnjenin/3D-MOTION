import SwiftUI
import UniformTypeIdentifiers
import SceneKit

struct MaterialSourcesGuide: View {
    @Environment(\.dismiss) private var dismiss
    let arabic: Bool
    var body: some View {
        NavigationStack {
            Form {
                Section(arabic ? "من أين أحصل على الخامات؟" : "Where can I find textures?") {
                    Text(arabic ? "نزّل خرائط الخامة إلى تطبيق الملفات، ثم أضفها من زر «استيراد من الجهاز»." : "Download texture maps to Files, then use Import from device.")
                    source("Poly Haven", url: "https://polyhaven.com/textures", description: arabic ? "خامات PBR مجانية برخصة CC0؛ اختر حزمة صور ZIP." : "Free CC0 PBR textures; choose a ZIP of image maps.")
                    source("ambientCG", url: "https://ambientcg.com/", description: arabic ? "خامات أسطح متنوعة برخصة CC0؛ ابدأ بدقة 1K أو 2K." : "A wide range of CC0 surfaces; start with 1K or 2K maps.")
                    source("cgbookcase", url: "https://www.cgbookcase.com/textures/", description: arabic ? "خرائط PBR مجانية للاستخدام الشخصي والتجاري؛ راجع صفحة الخامة قبل التنزيل." : "Free PBR maps for personal and commercial use; check the material page before downloading.")
                }
                Section(arabic ? "طريقة الاستيراد" : "How to import") {
                    Text(arabic ? "١. اختر صور PNG أو JPG، أو حزمة ZIP لخرائط الخامة، واحفظها في «الملفات»." : "1. Download PNG or JPG maps, or a ZIP texture pack, and save them in Files.")
                    Text(arabic ? "٢. افتح مكتبة الخامات ← استيراد من الجهاز، واختر الصور معًا أو مجلدها أو حزمة ZIP." : "2. Open the material library → Import from device. Select the maps together, their folder, or the ZIP.")
                    Text(arabic ? "٣. راجع اسم الخامة وتعيين الخرائط والدقة، ثم احفظها في «خاماتي» واضغط عليها لتطبيقها على المجسم المحدد." : "3. Review the name, map assignments and resolution. Save to My materials, then tap it to apply to the selected mesh.")
                }
                Section(arabic ? "اختيار الخرائط" : "Choosing maps") {
                    Text(arabic ? "Base Color / Albedo للون، Normal للتفاصيل، Roughness للخشونة، Metallic للمعدنية، وAO للظلال المحيطية. اختر Normal OpenGL؛ يمكن تحويل DirectX بقلب الأخضر في صفحة المراجعة." : "Base Color / Albedo supplies color, Normal detail, Roughness surface finish, Metallic metalness, and AO ambient occlusion. Choose OpenGL normals; DirectX maps can be converted with Flip green in the review.")
                    Text(arabic ? "يمكن استيراد صورة واحدة، أو استخراج خامات GLB/glTF. اجمع ملف glTF مع خرائطه وملفاته المرافقة داخل مجلد أو ZIP. ملفات Blender وSBSAR ليست خرائط صور جاهزة؛ صدّر خرائطها أولًا." : "Import a single image, or extract GLB/glTF materials. Keep a glTF file and its maps and supporting files together in a folder or ZIP. Blender and SBSAR files need their maps exported first.")
                    Text(arabic ? "الخامة المضافة تبقى في مكتبتك بين المشاريع، وتُضمّن داخل المشروع عند حفظه. راجع رخصة كل حزمة عند تنزيلها." : "Imported materials remain in your library across projects and are embedded in saved projects. Check each pack's license when downloading.")
                }
            }
            .navigationTitle(arabic ? "مصادر الخامات" : "Material sources")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button(arabic ? "إغلاق" : "Close") { dismiss() } } }
        }.environment(\.layoutDirection, arabic ? .rightToLeft : .leftToRight)
    }
    private func source(_ name: String, url: String, description: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(name).font(.headline)
            Text(description).font(.callout).foregroundStyle(.secondary)
            Link(arabic ? "فتح الموقع" : "Open website", destination: URL(string: url)!)
                .accessibilityLabel(name + (arabic ? "، فتح الموقع" : ", open website"))
        }.padding(.vertical, 4)
    }
}

@MainActor
struct UserMaterialLibraryPanel: View {
    @EnvironmentObject var studio: StudioStore
    @ObservedObject private var library = UserMaterialLibrary.shared
    var search: String
    var tiling: Double
    @State private var filePicker = false
    @State private var sourcesSheet = false
    @State private var session: MaterialImportSession?
    @State private var importTask: Task<Void, Never>?
    @State private var errorText = ""
    @State private var renameCard: UserMaterialCard?
    @State private var renameText = ""
    @State private var deleteCard: UserMaterialCard?
    @State private var details: UserMaterialCard?
    private var ar: Bool { studio.appLanguage == .arabic }
    private var matching: [UserMaterialCard] {
        library.cards.filter { search.isEmpty || $0.name.localizedCaseInsensitiveContains(search) || $0.source.label.localizedCaseInsensitiveContains(search) }
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(ar ? "خاماتي" : "My materials").font(.title2.bold())
                Spacer()
            }
            ViewThatFits(in: .horizontal) {
                HStack { importButton; sourcesButton }
                VStack(alignment: .leading) { importButton; sourcesButton }
            }
            Text(ar ? "تُحفظ في مكتبتك وتبقى متاحة بين المشاريع. الصور أو مجموعات PBR أو ZIP أو GLB/glTF." : "Saved in your library for reuse across projects. Images, PBR map sets, ZIP or GLB/glTF.")
                .font(.callout).foregroundStyle(.secondary)
            if importTask != nil {
                HStack {
                    ProgressView()
                    Text(ar ? "تجهيز الخامات…" : "Preparing materials…")
                        .font(.caption)
                    Button(ar ? "إلغاء" : "Cancel") { importTask?.cancel() }
                }
            }
            if library.cards.isEmpty {
                Text(ar ? "لم تُضف خاماتك بعد. اضغط استيراد خامات." : "Your library is empty. Choose Import materials.")
                    .foregroundStyle(.secondary).padding(.vertical, 8)
            }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 130))], spacing: 12) {
                ForEach(matching) { card in
                    Button { apply(card) } label: {
                        VStack(spacing: 6) {
                            if let image = library.thumbnail(card) {
                                Image(uiImage: image).resizable().scaledToFit().clipShape(RoundedRectangle(cornerRadius: 12))
                            } else { Image(systemName: "paintpalette").resizable().scaledToFit().padding(20) }
                            Text(card.name).font(.body).lineLimit(2)
                            Text(card.source.author ?? card.source.label).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                    }.buttonStyle(.plain)
                    .accessibilityLabel(card.name)
                    .contextMenu {
                        Button(ar ? "تطبيق على المجسم" : "Apply to mesh") { apply(card) }
                            .disabled(studio.selectedNode == nil || studio.isExporting || studio.importIsRunning)
                        Button(ar ? "تفاصيل المصدر" : "Source details") { details = card }
                        Button(ar ? "تغيير الاسم" : "Rename") { renameText = card.name; renameCard = card }
                        Button(ar ? "حذف من المكتبة" : "Delete from library", role: .destructive) { deleteCard = card }
                    }
                }
            }
            Divider()
        }
        .fileImporter(isPresented: $filePicker, allowedContentTypes: [.image, .zip, .folder, .data], allowsMultipleSelection: true) { result in
            switch result {
            case .success(let urls): prepareFiles(urls)
            case .failure(let error):
                if (error as NSError).code != NSUserCancelledError { errorText = error.localizedDescription }
            }
        }
        .sheet(isPresented: $sourcesSheet) { MaterialSourcesGuide(arabic: ar) }
        .sheet(item: $session) { prepared in
            UserMaterialReview(session: prepared, library: library)
                .environmentObject(studio)
        }
        .sheet(item: $details) { card in MaterialSourceDetails(card: card, arabic: ar) }
        .alert(ar ? "تعذر استيراد أو تطبيق الخامة" : "Material import or apply failed",
               isPresented: Binding(get: { !errorText.isEmpty }, set: { if !$0 { errorText = "" } })) {
            Button(ar ? "حسنًا" : "OK", role: .cancel) { errorText = "" }
        } message: { Text(errorText) }
        .alert(ar ? "اسم الخامة" : "Material name", isPresented: Binding(get: { renameCard != nil }, set: { if !$0 { renameCard = nil } })) {
            TextField(ar ? "الاسم" : "Name", text: $renameText)
            Button(ar ? "حفظ" : "Save") {
                if let card = renameCard { do { try library.rename(card, to: renameText) } catch { errorText = error.localizedDescription } }
                renameCard = nil
            }
            Button(ar ? "إلغاء" : "Cancel", role: .cancel) { renameCard = nil }
        }
        .confirmationDialog(ar ? "حذف الخامة من مكتبتك؟" : "Delete this library material?",
            isPresented: Binding(get: { deleteCard != nil }, set: { if !$0 { deleteCard = nil } }), titleVisibility: .visible) {
            Button(ar ? "حذف من المكتبة" : "Delete from library", role: .destructive) {
                if let card = deleteCard { do { try library.delete(card) } catch { errorText = error.localizedDescription } }
                deleteCard = nil
            }
        } message: { Text(ar ? "تبقى الخامة المستخدمة داخل مشاريعك محفوظة فيها." : "Materials already used in projects remain saved in those projects.") }
        .onAppear {
            do { try library.reload() } catch { errorText = error.localizedDescription }
            if !library.errorText.isEmpty { errorText = library.errorText; library.errorText = "" }
        }
        .onDisappear { importTask?.cancel() }
    }

    private var importButton: some View {
        Button { filePicker = true } label: {
            Label(ar ? "استيراد من الجهاز" : "Import from device", systemImage: "square.and.arrow.down")
        }.buttonStyle(.borderedProminent)
            .disabled(importTask != nil || studio.isExporting || studio.importIsRunning || studio.workshopIsRunning || studio.audioImportRunning)
    }
    private var sourcesButton: some View {
        Button { sourcesSheet = true } label: {
            Label(ar ? "مصادر الخامات" : "Material sources", systemImage: "books.vertical")
        }.buttonStyle(.bordered)
    }

    private func apply(_ card: UserMaterialCard) {
        do { try studio.applyUserMaterial(library.material(card), tiling: tiling) }
        catch { errorText = error.localizedDescription }
    }
    private func prepareFiles(_ urls: [URL]) {
        guard importTask == nil else { return }
        importTask = Task { @MainActor in
            defer { importTask = nil }
            let staging = Task.detached(priority: .userInitiated) { try MaterialImportFiles.prepare(urls) }
            do {
                let prepared = try await withTaskCancellationHandler(operation: { try await staging.value }, onCancel: { staging.cancel() })
                try Task.checkCancellation(); session = prepared
            } catch { if !Task.isCancelled { errorText = error.localizedDescription } }
        }
    }
}

@MainActor
struct UserMaterialReview: View {
    @EnvironmentObject var studio: StudioStore
    @Environment(\.dismiss) private var dismiss
    let session: MaterialImportSession
    @ObservedObject var library: UserMaterialLibrary
    @State private var candidates: [MaterialImportCandidate]
    @State private var quality = 2048
    @State private var task: Task<Void, Never>?
    @State private var errorText = ""
    private var ar: Bool { studio.appLanguage == .arabic }
    init(session: MaterialImportSession, library: UserMaterialLibrary) {
        self.session = session; self.library = library
        _candidates = State(initialValue: session.candidates)
    }
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker(ar ? "أقصى دقة للخرائط" : "Maximum map resolution", selection: $quality) {
                        Text("1K").tag(1024); Text("2K").tag(2048); Text("4K").tag(4096)
                    }
                    Text(ar ? "الصور الأصغر تبقى بدقتها؛ الصور الأكبر تُصغّر للحد المختار. راجع تعيين الخرائط قبل الحفظ." : "Smaller images keep their size; larger images are resized to this limit. Review map assignments before saving.")
                        .font(.callout).foregroundStyle(.secondary)
                    HStack {
                        Button(ar ? "تحديد الكل" : "Select all") { for i in candidates.indices { candidates[i].selected = true } }
                        Spacer()
                        Text("\(candidates.filter(\.selected).count) / \(candidates.count)")
                    }
                }
                ForEach($candidates) { $candidate in
                    Section {
                        Toggle(ar ? "إضافة الخامة" : "Add material", isOn: $candidate.selected)
                        TextField(ar ? "اسم الخامة" : "Material name", text: $candidate.name)
                        if case .images = candidate.kind {
                            ForEach($candidate.maps) { $map in
                                VStack(alignment: .leading) {
                                    Text(map.url.lastPathComponent).font(.caption).lineLimit(2)
                                    Picker(ar ? "نوع الخريطة" : "Map type", selection: $map.role) {
                                        ForEach(MaterialMapRole.allCases) { role in Text(role.title(ar)).tag(role) }
                                    }
                                    if map.role == .normal { Toggle(ar ? "قلب الأخضر • DirectX" : "Flip green • DirectX", isOn: $map.flipGreen) }
                                    if map.role == .roughness { Toggle(ar ? "تحويل Gloss إلى خشونة" : "Convert gloss to roughness", isOn: $map.invert) }
                                }
                            }
                        } else {
                            Text(ar ? "تُحفظ قنوات PBR وتعيينات UV الأصلية من النموذج." : "Original PBR channels and UV transforms are retained.")
                                .font(.callout).foregroundStyle(.secondary)
                        }
                    }
                }
                if !errorText.isEmpty { Section { Text(errorText).foregroundStyle(.red) } }
            }
            .disabled(task != nil)
            .navigationTitle(ar ? "مراجعة الخامات" : "Review materials")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(ar ? "إلغاء" : "Cancel") { if let task { task.cancel() } else { dismiss() } }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(ar ? "حفظ بالمكتبة" : "Save to library") { save() }
                        .disabled(task != nil || !candidates.contains(where: \.selected) || studio.isExporting || studio.importIsRunning)
                }
            }
            .overlay(alignment: .bottom) {
                if task != nil {
                    ProgressView(ar ? "حفظ خرائط الخامات…" : "Saving material maps…")
                        .padding().background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12)).padding()
                }
            }
        }
        .environment(\.layoutDirection, studio.appLanguage.direction)
        .interactiveDismissDisabled(task != nil)
        .onDisappear { task?.cancel() }
    }
    private func save() {
        guard task == nil, !studio.importIsRunning, !studio.workshopIsRunning, !studio.isExporting, !studio.audioImportRunning else { return }
        studio.importIsRunning = true
        task = Task { @MainActor in
            defer { task = nil; studio.importIsRunning = false }
            do {
                let materials = try await MaterialImportDecoder.decode(candidates, maximumDimension: quality)
                let added = try await library.add(materials, source: session.source)
                studio.toast = ar ? "أضيفت \(added.count) خامات إلى مكتبتك" : "\(added.count) materials added to your library"
                dismiss()
            } catch {
                if Task.isCancelled { dismiss() }
                else { errorText = error.localizedDescription }
            }
        }
    }
}

@MainActor
struct MaterialSourceDetails: View {
    @Environment(\.dismiss) private var dismiss
    let card: UserMaterialCard
    let arabic: Bool
    var body: some View {
        NavigationStack {
            Form {
                Section(card.name) {
                    Text(card.source.label == "Device" ? (arabic ? "مستورد من الجهاز" : "Imported from device") : card.source.label)
                    if let author = card.source.author { Text(author) }
                    if let license = card.source.license { Text(license) }
                    if let url = card.source.modelURL.flatMap(URL.init(string:)) { Link(arabic ? "فتح المصدر" : "Open source", destination: url) }
                    if let url = card.source.licenseURL.flatMap(URL.init(string:)) { Link(arabic ? "عرض الرخصة" : "View license", destination: url) }
                }
                Text(arabic ? "الخامات المستخدمة في مشروع تُحفظ داخله عند حفظ المشروع." : "Materials used in a project are embedded when the project is saved.")
            }.navigationTitle(arabic ? "تفاصيل الخامة" : "Material details")
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button(arabic ? "إغلاق" : "Close") { dismiss() } } }
        }.environment(\.layoutDirection, arabic ? .rightToLeft : .leftToRight)
    }
}
