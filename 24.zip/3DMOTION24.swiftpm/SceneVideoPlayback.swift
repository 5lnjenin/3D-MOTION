import Foundation
import SceneKit
import AVFoundation
import CoreMedia

/// AVPlayer reports seek completion through its native callback. The owner
/// serializes those events, keeps the latest request, and bounds decoder waits.
@MainActor
final class SceneVideoPlayback {
    private var players: [AVPlayer] = []
    private var revision = UUID()
    private struct Request {
        let player: AVPlayer
        let time: Double
        let hostTime: Double
        let playing: Bool
        let failure: @MainActor (String) -> Void
    }
    private var requests: [ObjectIdentifier: Request] = [:]
    private(set) var failures: [ObjectIdentifier: String] = [:]

    func synchronize(_ next: [AVPlayer], at time: Double, playing: Bool,
                     failure: @escaping @MainActor (String) -> Void) {
        revision = UUID()
        let generation = revision
        for player in players + next { player.pause(); player.currentItem?.cancelPendingSeeks() }
        players = next; requests.removeAll(); failures.removeAll()
        let hostTime = CMTimeGetSeconds(CMClockGetTime(CMClockGetHostTimeClock()))
        for player in next {
            let id = ObjectIdentifier(player)
            requests[id] = Request(player: player, time: max(0, time), hostTime: hostTime, playing: playing, failure: failure)
            // Host-clock synchronized playback requires this AVPlayer mode.
            // Local resources are prepared by the bounded seek before playback.
            player.automaticallyWaitsToMinimizeStalling = false
            player.actionAtItemEnd = .pause
            let length = CMTimeGetSeconds(player.currentItem?.duration ?? .invalid)
            let position = length.isFinite && length > 0 ? min(max(0,time), max(0,length - 0.000001)) : max(0,time)
            player.seek(to: CMTime(seconds: position, preferredTimescale: 600_000), toleranceBefore: .zero, toleranceAfter: .zero) { [weak self] complete in
                DispatchQueue.main.async {
                    self?.completed(id, generation: generation, success: complete)
                }
            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 10) { [weak self] in
            guard let self, revision == generation else { return }
            let overdue = requests
            requests.removeAll()
            for request in overdue.values {
                request.player.currentItem?.cancelPendingSeeks()
                let message = "انتهت مهلة تحميل الفيديو / Movie seek timed out"
                failures[ObjectIdentifier(request.player)] = message
                request.failure(message)
            }
        }
    }

    private func completed(_ id: ObjectIdentifier, generation: UUID, success: Bool) {
        guard revision == generation, let request = requests.removeValue(forKey: id) else { return }
        guard success else {
            let message = "تعذر الانتقال داخل الفيديو / Movie seek failed"
            failures[id] = message; request.failure(message); return
        }
        if request.playing {
            let host = CMClockGetTime(CMClockGetHostTimeClock())
            let now = request.time + CMTimeGetSeconds(host) - request.hostTime
            let length = CMTimeGetSeconds(request.player.currentItem?.duration ?? .invalid)
            if !length.isFinite || now < length {
                // Recheck at the actual call, not ten seconds earlier before a seek.
                // A movie texture consumer can change player configuration meanwhile.
                request.player.automaticallyWaitsToMinimizeStalling = false
                request.player.setRate(1, time: CMTime(seconds: now, preferredTimescale: 600_000), atHostTime: host)
            }
        }
    }

    func reset() {
        revision = UUID(); requests.removeAll(); failures.removeAll()
        for player in players { player.pause(); player.currentItem?.cancelPendingSeeks() }
        players.removeAll()
    }

    func waitForCurrentRequest() async {
        while !requests.isEmpty && !Task.isCancelled {
            try? await Task.sleep(nanoseconds: 10_000_000)
        }
    }
}

@MainActor
extension StudioStore {
    @discardableResult
    func importVideoFile(_ source: URL, autoplay: Bool = false) async throws -> SCNNode {
        try Task.checkCancellation()
        guard !isExporting, !importIsRunning, !audioImportRunning else { throw ProjectFailure.busy }
        importIsRunning = true
        importCancellationRequested = false
        defer { importIsRunning = false }
        stopPlayback()
        let folder = autosaveFolderURL.appendingPathComponent("Video", isDirectory: true)
        let destination = folder.appendingPathComponent(UUID().uuidString + "-" + source.lastPathComponent)
        let journal = videoImportJournal
        let attempt = journal.begin(filename: source.lastPathComponent)
        func progress(_ stage: VideoImportStage) {
            journal.advance(attempt, to: stage)
            statusText = stage.label(arabic: appLanguage == .arabic)
        }
        var staged = false, accepted = false
        defer { if staged && !accepted { try? FileManager.default.removeItem(at: destination) } }
        do {
            progress(.copying)
            let operation = VideoImportFile.Operation()
            let copying = Task.detached(priority: .userInitiated) { try operation.copy(source, to: destination) }
            try await withTaskCancellationHandler(operation: { try await copying.value }, onCancel: { operation.cancel(); copying.cancel() })
            staged = true
            try Task.checkCancellation()
            progress(.inspecting)
            let asset = AVURLAsset(url: destination)
            guard try await asset.load(.isPlayable) else { throw StudioVideoFailure.problem("صيغة الفيديو لا يمكن تشغيلها / Movie format cannot be played") }
            guard let track = try await asset.loadTracks(withMediaType: .video).first else {
                throw StudioVideoFailure.problem("الملف لا يحتوي فيديو / Missing video track")
            }
            let size = try await track.load(.naturalSize)
            let transform = try await track.load(.preferredTransform)
            let length = CMTimeGetSeconds(try await asset.load(.duration))
            let oriented = CGRect(origin: .zero, size: size).applying(transform).size
            guard oriented.width.isFinite, oriented.height.isFinite, oriented.width > 0, oriented.height > 0,
                  length.isFinite, length > 0 else { throw StudioVideoFailure.problem("فيديو غير صالح / Invalid video") }
            progress(.decoding)
            try await validateFirstMovieImage(asset)
            try Task.checkCancellation()
            let ratio = oriented.width / oriented.height
            let plane = SCNPlane(width: ratio >= 1 ? 4.8 : 4.8 * ratio, height: ratio >= 1 ? 4.8 / ratio : 4.8)
            let player = AVPlayer(playerItem: AVPlayerItem(asset: asset)); player.actionAtItemEnd = .pause
            player.automaticallyWaitsToMinimizeStalling = false
            progress(.preparing)
            try await waitForMoviePlayer(player)
            try Task.checkCancellation()
            let material = SCNMaterial(); material.diffuse.contents = player
            material.isDoubleSided = true; material.lightingModel = .constant; plane.materials = [material]
            let node = SCNNode(geometry: plane)
            node.name = "Video • " + source.deletingPathExtension().lastPathComponent
            node.position = SCNVector3(0, max(1.8, Float(plane.height / 2) + 0.1), 0)
            progress(.adding)
            pushUndoSnapshot("Import Video")
            contentRoot.addChildNode(node); accepted = true; select(node)
            importIsRunning = false
            progress(.starting)
            seek(to: autoplay ? 0 : currentTime)
            if autoplay { startPlayback() }
            await sceneVideoPlayback.waitForCurrentRequest()
            try Task.checkCancellation()
            if let failure = sceneVideoPlayback.failures[ObjectIdentifier(player)] {
                journal.finish(attempt, state: .failed, error: StudioVideoFailure.problem(failure))
                isVideoImportError = true
                importerMessage = (appLanguage == .arabic ? "أضيف الفيديو، لكن تعذر بدء تشغيله: " : "Video was added, but playback could not start: ") + failure
                statusText = appLanguage == .arabic ? "تعذر تشغيل الفيديو" : "Video playback failed"
                return node
            }
            journal.finish(attempt, state: .completed)
            statusText = appLanguage == .arabic ? "تمت إضافة الفيديو" : "Video added"
            toast = appLanguage == .arabic ? "تمت إضافة الفيديو للمشهد" : "Video added to scene"
            return node
        } catch is CancellationError {
            journal.finish(attempt, state: .cancelled)
            throw CancellationError()
        } catch {
            journal.finish(attempt, state: .failed, error: error)
            throw error
        }
    }

    private func validateFirstMovieImage(_ asset: AVAsset) async throws {
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 512, height: 512)
        defer { generator.cancelAllCGImageGeneration() }
        let image = try await withTaskCancellationHandler(operation: {
            try await generator.image(at: .zero).image
        }, onCancel: { generator.cancelAllCGImageGeneration() })
        guard image.width > 0, image.height > 0 else { throw StudioVideoFailure.problem("تعذر قراءة صور الفيديو / Movie images could not be decoded") }
    }

    private func waitForMoviePlayer(_ player: AVPlayer) async throws {
        let deadline = ProcessInfo.processInfo.systemUptime + 10
        while player.status == .unknown || player.currentItem?.status == .unknown {
            try Task.checkCancellation()
            guard ProcessInfo.processInfo.systemUptime < deadline else { throw StudioVideoFailure.problem("انتهت مهلة تجهيز الفيديو / Movie preparation timed out") }
            try await Task.sleep(nanoseconds: 10_000_000)
        }
        guard player.status == .readyToPlay, player.currentItem?.status == .readyToPlay else {
            throw player.currentItem?.error ?? player.error ?? StudioVideoFailure.problem("تعذر تجهيز الفيديو / Movie preparation failed")
        }
    }

    var videoImportJournal: VideoImportJournal { VideoImportJournal(folder: autosaveFolderURL) }

    func showInterruptedVideoImportIfNeeded() {
        guard let record = pendingVideoImportRecovery, importerMessage.isEmpty else { return }
        pendingVideoImportRecovery = nil; isVideoImportError = true
        importerMessage = appLanguage == .arabic
            ? "لم تكتمل إضافة الفيديو السابق: \(record.filename)\nآخر مرحلة مسجلة: \(record.stage.label(arabic: true)).\nهذه المرحلة تساعد على التشخيص، ولا تحدد سبب إغلاق التطبيق وحدها."
            : "The previous video import did not finish: \(record.filename)\nLast recorded step: \(record.stage.label(arabic: false)).\nThis helps diagnosis; it does not identify the termination reason by itself."
    }

    func sceneVideoPlayers() -> [AVPlayer] {
        var seen = Set<ObjectIdentifier>(), result: [AVPlayer] = []
        func add(_ value: Any?) {
            if let player = value as? AVPlayer, seen.insert(ObjectIdentifier(player)).inserted { result.append(player) }
        }
        for root in [contentRoot, camerasRoot, lightsRoot] {
            for node in ProjectSceneCodec.nodes(in: root) {
                for material in node.geometry?.materials ?? [] {
                    for (_, property) in ProjectSceneCodec.properties(material) { add(property.contents) }
                }
            }
        }
        for frame in keyframes {
            for material in frame.materialStates ?? [] {
                for value in [material.diffuse, material.emission, material.roughness, material.metalness] { add(value) }
            }
        }
        return result
    }

    func synchronizeVideoTimeline() {
        guard !isExporting else { return }
        sceneVideoPlayback.synchronize(sceneVideoPlayers(), at: currentTime, playing: isPlaying) { [weak self] error in
            self?.toast = "تعذر تشغيل الفيديو / Video playback failed: " + error
        }
    }
}
