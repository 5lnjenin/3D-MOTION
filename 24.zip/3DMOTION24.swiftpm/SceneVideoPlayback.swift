import Foundation
import SceneKit
import AVFoundation
import CoreMedia

/// AVPlayer reports seek completion through its native callback. The owner
/// serializes those events, keeps the latest request, and bounds decoder waits.
@MainActor
final class SceneVideoPlayback {
    private var players: [AVPlayer] = []
    private var revision = UUID()
    private struct Request {
        let player: AVPlayer
        let time: Double
        let hostTime: Double
        let playing: Bool
        let failure: @MainActor (String) -> Void
    }
    private var requests: [ObjectIdentifier: Request] = [:]

    func synchronize(_ next: [AVPlayer], at time: Double, playing: Bool,
                     failure: @escaping @MainActor (String) -> Void) {
        revision = UUID()
        let generation = revision
        for player in players + next { player.pause(); player.currentItem?.cancelPendingSeeks() }
        players = next; requests.removeAll()
        let hostTime = CMTimeGetSeconds(CMClockGetTime(CMClockGetHostTimeClock()))
        for player in next {
            let id = ObjectIdentifier(player)
            requests[id] = Request(player: player, time: max(0, time), hostTime: hostTime, playing: playing, failure: failure)
            player.actionAtItemEnd = .pause
            let length = CMTimeGetSeconds(player.currentItem?.duration ?? .invalid)
            let position = length.isFinite && length > 0 ? min(max(0,time), max(0,length - 0.000001)) : max(0,time)
            player.seek(to: CMTime(seconds: position, preferredTimescale: 600_000), toleranceBefore: .zero, toleranceAfter: .zero) { [weak self] complete in
                DispatchQueue.main.async {
                    self?.completed(id, generation: generation, success: complete)
                }
            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 10) { [weak self] in
            guard let self, revision == generation else { return }
            let overdue = requests
            requests.removeAll()
            for request in overdue.values {
                request.player.currentItem?.cancelPendingSeeks()
                request.failure("انتهت مهلة تحميل الفيديو / Movie seek timed out")
            }
        }
    }

    private func completed(_ id: ObjectIdentifier, generation: UUID, success: Bool) {
        guard revision == generation, let request = requests.removeValue(forKey: id) else { return }
        guard success else { request.failure("تعذر الانتقال داخل الفيديو / Movie seek failed"); return }
        if request.playing {
            let host = CMClockGetTime(CMClockGetHostTimeClock())
            let now = request.time + CMTimeGetSeconds(host) - request.hostTime
            let length = CMTimeGetSeconds(request.player.currentItem?.duration ?? .invalid)
            if !length.isFinite || now < length {
                request.player.setRate(1, time: CMTime(seconds: now, preferredTimescale: 600_000), atHostTime: host)
            }
        }
    }

    func reset() {
        revision = UUID(); requests.removeAll()
        for player in players { player.pause(); player.currentItem?.cancelPendingSeeks() }
        players.removeAll()
    }

    func waitForCurrentRequest() async {
        while !requests.isEmpty && !Task.isCancelled {
            try? await Task.sleep(nanoseconds: 10_000_000)
        }
    }
}

@MainActor
extension StudioStore {
    @discardableResult
    func importVideoFile(_ source: URL, autoplay: Bool = false) async throws -> SCNNode {
        try Task.checkCancellation()
        guard !isExporting, !importIsRunning, !audioImportRunning else { throw ProjectFailure.busy }
        importIsRunning = true
        defer { importIsRunning = false }
        stopPlayback()
        let access = source.startAccessingSecurityScopedResource()
        defer { if access { source.stopAccessingSecurityScopedResource() } }
        let folder = autosaveFolderURL.appendingPathComponent("Video", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let destination = folder.appendingPathComponent(UUID().uuidString + "-" + source.lastPathComponent)
        var accepted = false
        defer { if !accepted { try? FileManager.default.removeItem(at: destination) } }
        try FileManager.default.copyItem(at: source, to: destination)
        let asset = AVURLAsset(url: destination)
        guard let track = try await asset.loadTracks(withMediaType: .video).first else {
            throw StudioVideoFailure.problem("الملف لا يحتوي فيديو / Missing video track")
        }
        let size = try await track.load(.naturalSize)
        let transform = try await track.load(.preferredTransform)
        let length = CMTimeGetSeconds(try await asset.load(.duration))
        let oriented = CGRect(origin: .zero, size: size).applying(transform).size
        guard oriented.width.isFinite, oriented.height.isFinite, oriented.width > 0, oriented.height > 0,
              length.isFinite, length > 0 else { throw StudioVideoFailure.problem("فيديو غير صالح / Invalid video") }
        try Task.checkCancellation()
        let ratio = oriented.width / oriented.height
        let plane = SCNPlane(width: ratio >= 1 ? 4.8 : 4.8 * ratio, height: ratio >= 1 ? 4.8 / ratio : 4.8)
        let player = AVPlayer(playerItem: AVPlayerItem(asset: asset)); player.actionAtItemEnd = .pause
        let material = SCNMaterial(); material.diffuse.contents = player
        material.isDoubleSided = true; material.lightingModel = .constant; plane.materials = [material]
        let node = SCNNode(geometry: plane)
        node.name = "Video • " + source.deletingPathExtension().lastPathComponent
        node.position = SCNVector3(0, max(1.8, Float(plane.height / 2) + 0.1), 0)
        pushUndoSnapshot("Import Video")
        contentRoot.addChildNode(node); accepted = true; select(node)
        importIsRunning = false
        seek(to: autoplay ? 0 : currentTime)
        if autoplay { startPlayback() }
        toast = appLanguage == .arabic ? "تمت إضافة الفيديو للمشهد" : "Video added to scene"
        return node
    }

    func sceneVideoPlayers() -> [AVPlayer] {
        var seen = Set<ObjectIdentifier>(), result: [AVPlayer] = []
        func add(_ value: Any?) {
            if let player = value as? AVPlayer, seen.insert(ObjectIdentifier(player)).inserted { result.append(player) }
        }
        for root in [contentRoot, camerasRoot, lightsRoot] {
            for node in ProjectSceneCodec.nodes(in: root) {
                for material in node.geometry?.materials ?? [] {
                    for (_, property) in ProjectSceneCodec.properties(material) { add(property.contents) }
                }
            }
        }
        for frame in keyframes {
            for material in frame.materialStates ?? [] {
                for value in [material.diffuse, material.emission, material.roughness, material.metalness] { add(value) }
            }
        }
        return result
    }

    func synchronizeVideoTimeline() {
        guard !isExporting else { return }
        sceneVideoPlayback.synchronize(sceneVideoPlayers(), at: currentTime, playing: isPlaying) { [weak self] error in
            self?.toast = "تعذر تشغيل الفيديو / Video playback failed: " + error
        }
    }
}
