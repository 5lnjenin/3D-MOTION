import Foundation
import SceneKit
import AVFoundation
import CoreMedia

/// One timeline owns every movie player, including players restored from a file.
/// A newer seek cancels older requests so scrubbing cannot restart an old position.
@MainActor
final class SceneVideoPlayback {
    private(set) var task: Task<Void, Never>?
    private var players: [AVPlayer] = []
    private var revision = UUID()

    func synchronize(_ next: [AVPlayer], at time: Double, playing: Bool,
                     failure: @escaping @MainActor (String) -> Void) {
        revision = UUID()
        let request = revision
        task?.cancel()
        for player in players + next { player.pause(); player.currentItem?.cancelPendingSeeks() }
        players = next
        let clock = CMClockGetHostTimeClock()
        let requestedHostTime = CMTimeGetSeconds(CMClockGetTime(clock))
        task = Task { @MainActor [weak self] in
            for player in next {
                do {
                    guard let asset = player.currentItem?.asset else { continue }
                    let length = CMTimeGetSeconds(try await asset.load(.duration))
                    try Task.checkCancellation()
                    guard length.isFinite, length > 0 else {
                        throw StudioVideoFailure.problem("مدة الفيديو غير صالحة / Invalid video duration")
                    }
                    player.actionAtItemEnd = .pause
                    let position = min(max(0, time), max(0, length - 0.000001))
                    let complete = await player.seek(to: CMTime(seconds: position, preferredTimescale: 600_000),
                        toleranceBefore: .zero, toleranceAfter: .zero)
                    try Task.checkCancellation()
                    guard self?.revision == request else { return }
                    guard complete else { throw StudioVideoFailure.problem("تعذر الانتقال داخل الفيديو / Video seek failed") }
                    if playing {
                        // Anchor to the same clock as the timeline rather than the
                        // completion time of each individual decoder's initial seek.
                        let host = CMClockGetTime(clock)
                        let positionNow = max(0, time) + CMTimeGetSeconds(host) - requestedHostTime
                        if positionNow < length {
                            player.setRate(1, time: CMTime(seconds: positionNow, preferredTimescale: 600_000), atHostTime: host)
                        }
                    }
                } catch is CancellationError { return }
                catch {
                    guard self?.revision == request else { return }
                    failure(error.localizedDescription)
                }
            }
        }
    }

    func reset() {
        revision = UUID(); task?.cancel(); task = nil
        for player in players { player.pause(); player.currentItem?.cancelPendingSeeks() }
        players.removeAll()
    }
}

@MainActor
extension StudioStore {
    @discardableResult
    func importVideoFile(_ source: URL, autoplay: Bool = false) async throws -> SCNNode {
        try Task.checkCancellation()
        guard !isExporting, !importIsRunning, !audioImportRunning else { throw ProjectFailure.busy }
        importIsRunning = true
        defer { importIsRunning = false }
        stopPlayback()
        let access = source.startAccessingSecurityScopedResource()
        defer { if access { source.stopAccessingSecurityScopedResource() } }
        let folder = autosaveFolderURL.appendingPathComponent("Video", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let destination = folder.appendingPathComponent(UUID().uuidString + "-" + source.lastPathComponent)
        var accepted = false
        defer { if !accepted { try? FileManager.default.removeItem(at: destination) } }
        try FileManager.default.copyItem(at: source, to: destination)
        let asset = AVURLAsset(url: destination)
        guard let track = try await asset.loadTracks(withMediaType: .video).first else {
            throw StudioVideoFailure.problem("الملف لا يحتوي فيديو / Missing video track")
        }
        let size = try await track.load(.naturalSize)
        let transform = try await track.load(.preferredTransform)
        let length = CMTimeGetSeconds(try await asset.load(.duration))
        let oriented = CGRect(origin: .zero, size: size).applying(transform).size
        guard oriented.width.isFinite, oriented.height.isFinite, oriented.width > 0, oriented.height > 0,
              length.isFinite, length > 0 else { throw StudioVideoFailure.problem("فيديو غير صالح / Invalid video") }
        try Task.checkCancellation()
        let ratio = oriented.width / oriented.height
        let plane = SCNPlane(width: ratio >= 1 ? 4.8 : 4.8 * ratio, height: ratio >= 1 ? 4.8 / ratio : 4.8)
        let player = AVPlayer(playerItem: AVPlayerItem(asset: asset)); player.actionAtItemEnd = .pause
        let material = SCNMaterial(); material.diffuse.contents = player
        material.isDoubleSided = true; material.lightingModel = .constant; plane.materials = [material]
        let node = SCNNode(geometry: plane)
        node.name = "Video • " + source.deletingPathExtension().lastPathComponent
        node.position = SCNVector3(0, 1.8, 0)
        pushUndoSnapshot("Import Video")
        contentRoot.addChildNode(node); accepted = true; select(node)
        importIsRunning = false
        seek(to: autoplay ? 0 : currentTime)
        if autoplay { startPlayback() }
        toast = appLanguage == .arabic ? "تمت إضافة الفيديو للمشهد" : "Video added to scene"
        return node
    }

    func sceneVideoPlayers() -> [AVPlayer] {
        var seen = Set<ObjectIdentifier>(), result: [AVPlayer] = []
        func add(_ value: Any?) {
            if let player = value as? AVPlayer, seen.insert(ObjectIdentifier(player)).inserted { result.append(player) }
        }
        for root in [contentRoot, camerasRoot, lightsRoot] {
            for node in ProjectSceneCodec.nodes(in: root) {
                for material in node.geometry?.materials ?? [] {
                    for (_, property) in ProjectSceneCodec.properties(material) { add(property.contents) }
                }
            }
        }
        for frame in keyframes {
            for material in frame.materialStates ?? [] {
                for value in [material.diffuse, material.emission, material.roughness, material.metalness] { add(value) }
            }
        }
        return result
    }

    func synchronizeVideoTimeline() {
        guard !isExporting else { return }
        sceneVideoPlayback.synchronize(sceneVideoPlayers(), at: currentTime, playing: isPlaying) { [weak self] error in
            self?.toast = "تعذر تشغيل الفيديو / Video playback failed: " + error
        }
    }
}
