import Foundation
import SwiftUI
import UIKit
import SceneKit

struct PreparedStudioProject {
    var package: StudioPortablePackage
    var scene: SCNScene
    var metadata: StudioAutosaveMetadata
    var keyframes: [StudioKeyframe]
    var audio: [StudioAudioClip]
    var audioAssets: [StudioAudioAsset]
    var environment: UIImage?
    var editorCamera: SCNCamera?
    var runtimeFolder: URL
}

@MainActor
extension StudioStore {
    var autosaveProjectURL: URL { autosaveFolderURL.appendingPathComponent("Autosave.3dmotion") }

    func projectFolder(named name: String) -> URL {
        if name == currentProjectName, let id = currentProjectLibraryID { return projectFolder(id: id) }
        let cleaned = name.trimmingCharacters(in: .whitespacesAndNewlines)
            .components(separatedBy: CharacterSet(charactersIn: "/\\:\0")).joined(separator: "-")
        let safe = (cleaned.isEmpty || cleaned == "." || cleaned == "..") ? "Untitled Project" : cleaned
        return projectsFolderURL.appendingPathComponent(safe, isDirectory: true)
    }

    func projectMetadata() throws -> StudioAutosaveMetadata {
        var r: CGFloat=0.5, g: CGFloat=0.5, b: CGFloat=0.5, a: CGFloat=1
        UIColor(fogColor).getRed(&r, green: &g, blue: &b, alpha: &a)
        var metadata = StudioAutosaveMetadata(savedAt: Date(), duration: duration, fps: fps, currentTime: currentTime,
            gridSpacing: gridSpacing, gridHalfCount: gridHalfCount, showGrid: showGrid, showAxes: showAxes,
            showWorkPoint: showWorkPoint, ambientStrength: ambientStrength, fogEnabled: fogEnabled, fogDensity: fogDensity,
            fogR: Double(r), fogG: Double(g), fogB: Double(b), fogA: Double(a), activeCameraName: scnView?.pointOfView?.name,
            keyframes: [], environmentPreset: environmentPreset.rawValue, environmentIntensity: environmentIntensity,
            audioClips: audioClips.map { SavedAudioClip(name: $0.name, fileName: $0.url.lastPathComponent,
                startTime: $0.startTime, volume: $0.volume, loops: $0.loops) },
            renderFilterPreset: renderFilterPreset.rawValue, renderFilterIntensity: renderFilterIntensity,
            transformSpace: transformSpace.rawValue, autoKeyframeEnabled: autoKeyframeEnabled)
        if let camera = scnView?.pointOfView ?? projectOpeningCamera, camera !== editorViewportCamera {
            metadata.activeCameraID = animationIdentity(camera)
        }
        if let node = editorViewportCamera {
            metadata.editorCameraTransform = ProjectSceneCodec.matrix(node.transform)
            if let camera = node.camera {
                metadata.editorCameraArchive = try NSKeyedArchiver.archivedData(withRootObject: camera, requiringSecureCoding: true)
            }
        }
        metadata.viewportState = SavedViewportState(backgroundIndex: viewportBackgroundIndex,
            shadingMode: viewportShadingMode.rawValue, backfaceCulling: backfaceCullingEnabled,
            lightCount: viewportLightCount, keyStrength: viewportKeyStrength, fillStrength: viewportFillStrength,
            rimStrength: viewportRimStrength, specularStrength: viewportSpecularStrength, highlightSize: viewportHighlightSize)
        metadata.audioClips = audioClips.map {
            var saved = SavedAudioClip(name: $0.name, fileName: $0.url.lastPathComponent, startTime: $0.startTime, volume: $0.volume, loops: $0.loops)
            saved.id = $0.id; saved.assetID = $0.assetID; saved.trackID = $0.trackID
            saved.sourceStart = $0.sourceStart; saved.sourceEnd = $0.sourceEnd
            return saved
        }
        metadata.audioAssets = audioAssets.map { SavedAudioAsset(id: $0.id, name: $0.name, fileName: $0.url.lastPathComponent, duration: $0.duration) }
        metadata.masterAudioVolume = masterAudioVolume
        metadata.timelineMinimumDuration = timelineMinimumDuration
        metadata.projectLibraryID = currentProjectLibraryID
        metadata.animationLayers = animationLayers
        metadata.motionTrackNames = motionTrackNames
        metadata.activeMotionTracks = activeMotionTrackByNode
        metadata.loopingMotionTracks = loopingMotionTrackIDs
        return metadata
    }

    func captureProject(named name: String? = nil) throws -> StudioPortablePackage {
        guard !workshopIsRunning, !isAutosaving, !importIsRunning, !audioImportRunning, !isPlaying, !isExporting, !isTransformGestureActive else {
            throw ProjectFailure.busy
        }
        reconcileTimelineDuration()
        isAutosaving = true
        defer { isAutosaving = false }
        // Serialization may strip image providers and editor overlays. All of
        // that happens on a detached graph, never on the visible viewport.
        let snapshot = try makePersistenceSceneSnapshot()
        var audio: [String: Data] = [:]
        let audioResources = audioAssets.map { ($0.name, $0.url) } + audioClips.map { ($0.name, $0.url) }
        for (name, url) in audioResources {
            let key = url.lastPathComponent
            let data = try Data(contentsOf: url)
            guard !data.isEmpty else { throw ProjectFailure.missing(name) }
            if let previous = audio[key], previous != data { throw ProjectFailure.invalid("duplicate audio filename") }
            audio[key] = data
        }
        var environment: Data?
        if let image = customEnvironmentImage {
            guard let data = image.pngData() else { throw ProjectFailure.invalid("environment image") }
            environment = data
        } else if environmentPreset == .custom { throw ProjectFailure.missing("environment image") }
        return try ProjectSceneCodec.makePackage(scene: snapshot, name: name ?? currentProjectName,
            metadata: projectMetadata(), keyframes: keyframes, environment: environment, audio: audio)
    }

    // Detached decoding completes before a file is replaced or the workspace is
    // touched. The same decoder validates save, open, import, and export.
    func prepareProject(_ package: StudioPortablePackage) throws -> PreparedStudioProject {
        try package.validate()
        let metadata = try JSONDecoder().decode(StudioAutosaveMetadata.self, from: package.metadata)
        let scalars = [metadata.duration, metadata.fps, metadata.currentTime, metadata.gridSpacing, metadata.gridHalfCount,
            metadata.ambientStrength, metadata.fogDensity, metadata.fogR, metadata.fogG, metadata.fogB, metadata.fogA]
        guard scalars.allSatisfy(\.isFinite), metadata.duration > 0, metadata.fps > 0,
              (metadata.timelineMinimumDuration ?? 0).isFinite, (metadata.timelineMinimumDuration ?? 0) >= 0 else {
            throw ProjectFailure.invalid("animation metadata")
        }
        let folder = autosaveFolderURL.appendingPathComponent("ProjectRuntime", isDirectory: true)
            .appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        var complete = false
        defer { if !complete { try? FileManager.default.removeItem(at: folder) } }
        let restored: SCNScene
        if package.version == 2 {
            guard let decoded = try NSKeyedUnarchiver.unarchivedObject(ofClass: SCNScene.self, from: package.scene) else {
                throw ProjectFailure.invalid("scene archive")
            }
            restored = decoded
        } else {
            let file = folder.appendingPathComponent("Scene.scn")
            try package.scene.write(to: file, options: .atomic)
            restored = try SCNScene(url: file, options: [.checkConsistency: true, .flattenScene: false])
        }
        guard let content = restored.rootNode.childNode(withName: "Scene", recursively: false) else {
            throw ProjectFailure.invalid("scene root")
        }
        let resourceFolder = folder.appendingPathComponent("Resources", isDirectory: true)
        let audioFolder = folder.appendingPathComponent("Audio", isDirectory: true)
        try FileManager.default.createDirectory(at: resourceFolder, withIntermediateDirectories: true)
        try FileManager.default.createDirectory(at: audioFolder, withIntermediateDirectories: true)
        let decoder = ProjectSceneCodec.Decoder(resources: package.resources ?? [:], folder: resourceFolder)
        if package.version == 2 { try ProjectSceneCodec.bind(package, to: restored, decoder: decoder) }
        else {
            if let textures = package.textures { try ProjectSceneCodec.restoreLegacyTextures(textures, root: content) }
            let unresolved = ProjectSceneCodec.embedImportedResources(content, baseURL: folder)
            guard unresolved.isEmpty else { throw ProjectFailure.missing(unresolved.joined(separator: ", ")) }
        }
        let frames = try metadata.keyframes.map { try ProjectSceneCodec.decodeKeyframe($0, decoder: decoder) }
        let nodes = ProjectSceneCodec.nodes(in: restored.rootNode)
        for frame in frames {
            guard frame.time.isFinite,
                  [frame.position.x, frame.position.y, frame.position.z, frame.euler.x, frame.euler.y, frame.euler.z,
                   frame.scale.x, frame.scale.y, frame.scale.z].allSatisfy(\.isFinite) else {
                throw ProjectFailure.invalid("keyframe values")
            }
            guard nodes.contains(where: { frame.nodeID != nil ? $0.studioAnimationID == frame.nodeID : $0.name == frame.nodeName }) else {
                throw ProjectFailure.invalid("keyframe target " + frame.nodeName)
            }
        }
        if let active = metadata.activeCameraID {
            guard nodes.contains(where: { $0.studioAnimationID == active && $0.camera != nil }) else {
                throw ProjectFailure.invalid("active camera")
            }
        }
        for layer in metadata.animationLayers ?? [] {
            guard let node = nodes.first(where: { layer.nodeID != nil ? $0.studioAnimationID == layer.nodeID : $0.name == layer.nodeName }),
                  node.animationPlayer(forKey: layer.id) != nil else { throw ProjectFailure.invalid("animation layer " + layer.name) }
        }
        var assets: [StudioAudioAsset] = []
        var assetByFile: [String: StudioAudioAsset] = [:]
        for saved in metadata.audioAssets ?? [] {
            guard ProjectFileStore.safeComponent(saved.fileName), let data = package.audio[saved.fileName], !data.isEmpty,
                  saved.duration.isFinite, saved.duration > 0, assetByFile[saved.fileName] == nil,
                  !assets.contains(where: { $0.id == saved.id }) else { throw ProjectFailure.invalid("audio file") }
            let url = audioFolder.appendingPathComponent(saved.fileName)
            try data.write(to: url, options: .atomic)
            let actualDuration = try AudioPreviewCache.duration(of: url)
            guard abs(saved.duration - actualDuration) < 0.05 else { throw ProjectFailure.invalid("audio duration") }
            let asset = StudioAudioAsset(id: saved.id, name: saved.name, url: url, duration: actualDuration)
            assets.append(asset); assetByFile[saved.fileName] = asset
        }
        var clips: [StudioAudioClip] = []
        for saved in metadata.audioClips ?? [] {
            guard ProjectFileStore.safeComponent(saved.fileName), let data = package.audio[saved.fileName], !data.isEmpty,
                  saved.startTime.isFinite, saved.startTime >= 0, saved.volume.isFinite, (0...1).contains(saved.volume) else {
                throw ProjectFailure.invalid("audio clip")
            }
            let asset: StudioAudioAsset
            if let existing = assetByFile[saved.fileName] { asset = existing }
            else {
                guard metadata.audioAssets == nil else { throw ProjectFailure.missing("audio file " + saved.name) }
                let url = audioFolder.appendingPathComponent(saved.fileName)
                try data.write(to: url, options: .atomic)
                asset = StudioAudioAsset(name: saved.name, url: url, duration: try AudioPreviewCache.duration(of: url))
                assets.append(asset); assetByFile[saved.fileName] = asset
            }
            guard saved.assetID == nil || saved.assetID == asset.id else { throw ProjectFailure.invalid("audio file binding") }
            var clip = StudioAudioClip(name: saved.name, url: asset.url, startTime: saved.startTime, volume: saved.volume, loops: saved.loops)
            clip.id = saved.id ?? UUID(); clip.assetID = asset.id; clip.trackID = saved.trackID ?? UUID()
            clip.sourceStart = saved.sourceStart ?? 0; clip.sourceEnd = saved.sourceEnd; clip.sourceDuration = asset.duration
            guard clip.sourceStart.isFinite, (clip.sourceEnd ?? asset.duration).isFinite,
                  clip.sourceStart >= 0, clip.sourceStart < asset.duration, clip.trimmedDuration >= 0.001,
                  (clip.sourceEnd ?? asset.duration) <= asset.duration + 0.000001,
                  !clips.contains(where: { $0.id == clip.id }) else { throw ProjectFailure.invalid("audio trim range") }
            clips.append(clip)
        }
        if let volume = metadata.masterAudioVolume, !volume.isFinite || !(0...1).contains(volume) {
            throw ProjectFailure.invalid("master audio volume")
        }
        let environment = package.environment.flatMap { UIImage(data: $0) }
        if package.environment != nil && environment == nil { throw ProjectFailure.invalid("environment image") }
        if metadata.environmentPreset == SceneEnvironmentPreset.custom.rawValue && environment == nil {
            throw ProjectFailure.missing("environment image")
        }
        var camera: SCNCamera?
        if let data = metadata.editorCameraArchive {
            camera = try NSKeyedUnarchiver.unarchivedObject(ofClass: SCNCamera.self, from: data)
            guard camera != nil else { throw ProjectFailure.invalid("editor camera") }
        }
        if let matrix = metadata.editorCameraTransform { _ = try ProjectSceneCodec.matrix(matrix) }
        complete = true
        return PreparedStudioProject(package: package, scene: restored, metadata: metadata, keyframes: frames,
            audio: clips, audioAssets: assets, environment: environment, editorCamera: camera, runtimeFolder: folder)
    }

    func verifiedProjectData(_ package: StudioPortablePackage) throws -> Data {
        let data = try ProjectFileStore.encode(package)
        let prepared = try prepareProject(ProjectFileStore.decode(data))
        defer { try? FileManager.default.removeItem(at: prepared.runtimeFolder) }
        return data
    }

    @discardableResult
    func saveAutosave(showToast: Bool = false, force: Bool = false) -> Bool {
        guard !recoveryBlocksAutosave else {
            lastAutosaveText = "Recovery failed; original save preserved. Open a project or create a new one."
            return false
        }
        if !showToast && !force {
            let profile = currentSceneLoadProfile(stopAfterNodes: 5_000, stopAfterVertices: 750_000, stopAfterTextureBytes: 160 * 1024 * 1024)
            if profile.nodes >= 5_000 || profile.vertices >= 750_000 || profile.textureBytes >= 160 * 1024 * 1024 {
                lastAutosaveText = "Autosave paused • Large scene • Use Save"
                return false
            }
        }
        do {
            let data = try verifiedProjectData(captureProject())
            try ProjectFileStore.commit(data, to: autosaveProjectURL)
            lastAutosaveText = "Saved " + Date().formatted(date: .omitted, time: .shortened)
            if showToast { toast = "تم حفظ المشروع والخامات / Project and materials saved" }
            return true
        } catch {
            lastAutosaveText = "Save failed: " + error.localizedDescription
            if showToast { toast = lastAutosaveText }
            return false
        }
    }

    @discardableResult
    func saveNamedProject(_ requestedName: String? = nil, saveAs: Bool = false) -> Bool {
        let requested = requestedName?.trimmingCharacters(in: .whitespacesAndNewlines)
        let name = requested?.isEmpty == false ? requested! : currentProjectName
        let id = saveAs ? UUID().uuidString : (currentProjectLibraryID ?? UUID().uuidString)
        let folder = projectFolder(id: id)
        do {
            var package = try captureProject(named: name)
            var metadata = try JSONDecoder().decode(StudioAutosaveMetadata.self, from: package.metadata)
            metadata.projectLibraryID = id
            package.metadata = try JSONEncoder().encode(metadata); package.seal()
            let data = try verifiedProjectData(package)
            try ProjectFileStore.commit(data, to: folder.appendingPathComponent("Project.3dmotion"))
            currentProjectLibraryID = id
            currentProjectName = name
            do { try writeProjectLabel(name, in: folder) }
            catch { reportProjectError(error) }
            updateProjectPreview(in: folder)
            recoveryBlocksAutosave = false
            lastAutosaveText = "Project saved"
            // The named project is already committed. An autosave-cache failure
            // must be disclosed without misrepresenting the named save.
            do { try ProjectFileStore.commit(data, to: autosaveProjectURL) }
            catch {
                toast = "حُفظ المشروع؛ تعذر تحديث الحفظ التلقائي / Project saved; autosave update failed"
                return true
            }
            toast = "تم حفظ المشروع والخامات / Project and materials saved"
            return true
        } catch {
            let message = "تعذر حفظ المشروع / Save failed: " + error.localizedDescription
            toast = message
            projectErrorDetails = message
            lastAutosaveText = message
            return false
        }
    }

    func exportPortableProject() throws -> Data {
        stopPlayback()
        return try verifiedProjectData(captureProject())
    }

    func exportProjectFile() -> URL? {
        do {
            let data = try exportPortableProject()
            let folder = FileManager.default.temporaryDirectory.appendingPathComponent("3DMotionExports", isDirectory: true)
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let url = folder.appendingPathComponent("3D_MOTION_" + UUID().uuidString).appendingPathExtension("3dmotion")
            try data.write(to: url, options: .atomic)
            guard try Data(contentsOf: url) == data else { throw ProjectFailure.write }
            toast = "تم تصدير المشروع والخامات / Project and materials exported"
            return url
        } catch { toast = "تعذر تصدير المشروع / Export failed: " + error.localizedDescription; return nil }
    }

    func importPortableProject(_ data: Data) throws {
        guard !workshopIsRunning, !isExporting, !importIsRunning, !audioImportRunning, !isAutosaving, !isTransformGestureActive else { throw ProjectFailure.busy }
        var package = try ProjectFileStore.decode(data)
        var prepared = try prepareProject(package)
        do {
            if package.version == 1 {
                // Migrate the detached legacy graph, including its actual images,
                // rather than saving any currently open project's sidecar files.
                package = try ProjectSceneCodec.makePackage(scene: prepared.scene, name: package.name,
                    metadata: prepared.metadata, keyframes: prepared.keyframes, environment: package.environment, audio: package.audio)
                let replacement = try prepareProject(package)
                try? FileManager.default.removeItem(at: prepared.runtimeFolder)
                prepared = replacement
            }
            let id = UUID().uuidString, folder = projectFolder(id: id)
            prepared.metadata.projectLibraryID = id
            package.metadata = try JSONEncoder().encode(prepared.metadata); package.seal()
            let encoded = try ProjectFileStore.encode(package)
            try ProjectFileStore.commit(encoded, to: folder.appendingPathComponent("Project.3dmotion"))
            try writeProjectLabel(package.name, in: folder)
            applyPreparedProject(prepared)
            currentProjectLibraryID = id
            do { try ProjectFileStore.commit(encoded, to: autosaveProjectURL) }
            catch { toast = "فُتح المشروع؛ تعذر تحديث الحفظ التلقائي / Project opened; autosave update failed"; return }
            toast = "تم فتح المشروع / Project opened"
        } catch {
            try? FileManager.default.removeItem(at: prepared.runtimeFolder)
            throw error
        }
    }

    func openProjectDocument(at url: URL) throws {
        guard url.isFileURL, url.pathExtension.lowercased() == "3dmotion" else {
            throw ProjectFailure.invalid("project file type")
        }
        guard !isExporting else { throw ProjectFailure.busy }
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        try importPortableProject(Data(contentsOf: url))
    }

    func readProject(at url: URL) throws -> PreparedStudioProject {
        do { return try prepareProject(ProjectFileStore.decode(Data(contentsOf: url))) }
        catch {
            // A previously verified complete document can be recovered without
            // overwriting either file. A later explicit save repairs the primary.
            let backup = ProjectFileStore.previous(url)
            guard FileManager.default.fileExists(atPath: backup.path) else { throw error }
            let prepared = try prepareProject(ProjectFileStore.decode(Data(contentsOf: backup)))
            toast = "تمت استعادة النسخة السابقة السليمة / Recovered previous complete save"
            return prepared
        }
    }

    private func optionalLegacyData(_ url: URL) throws -> Data? {
        guard FileManager.default.fileExists(atPath: url.path) else { return nil }
        return try Data(contentsOf: url)
    }

    func legacyProject(in folder: URL, autosave: Bool = false, name: String) throws -> PreparedStudioProject {
        let meta = try Data(contentsOf: folder.appendingPathComponent(autosave ? "Autosave.json" : "Project.json"))
        let metadata = try JSONDecoder().decode(StudioAutosaveMetadata.self, from: meta)
        var audio: [String: Data] = [:]
        for clip in metadata.audioClips ?? [] {
            guard ProjectFileStore.safeComponent(clip.fileName) else { throw ProjectFailure.invalid("legacy audio path") }
            audio[clip.fileName] = try Data(contentsOf: audioFolderURL.appendingPathComponent(clip.fileName))
        }
        let package = StudioPortablePackage(version: 1, name: name,
            scene: try Data(contentsOf: folder.appendingPathComponent(autosave ? "Autosave.scn" : "Project.scn")), metadata: meta,
            environment: try optionalLegacyData(folder.appendingPathComponent("Environment.jpg")), audio: audio,
            textures: try optionalLegacyData(folder.appendingPathComponent("MaterialTextures.json")))
        return try prepareProject(package)
    }

    @discardableResult
    func openProject(_ card: ProjectCard) -> Bool {
        guard !workshopIsRunning, !isExporting, !importIsRunning, !isAutosaving, !audioImportRunning, !isTransformGestureActive else { toast = ProjectFailure.busy.localizedDescription; return false }
        if card.id == "autosave://last" { return restoreAutosaveIfAvailable() }
        do {
            guard ProjectFileStore.safeComponent(card.id) else { throw ProjectFailure.invalid("project folder") }
            let folder = projectsFolderURL.appendingPathComponent(card.id, isDirectory: true)
            let url = folder.appendingPathComponent("Project.3dmotion")
            let prepared = FileManager.default.fileExists(atPath: url.path)
                ? try readProject(at: url) : try legacyProject(in: folder, name: card.name)
            applyPreparedProject(prepared)
            currentProjectLibraryID = card.id
            return true
        } catch { reportProjectError(error); return false }
    }

    @discardableResult
    func restoreAutosaveIfAvailable() -> Bool {
        do {
            let prepared: PreparedStudioProject
            if FileManager.default.fileExists(atPath: autosaveProjectURL.path) { prepared = try readProject(at: autosaveProjectURL) }
            else if FileManager.default.fileExists(atPath: autosaveSceneURL.path) {
                prepared = try legacyProject(in: autosaveFolderURL, autosave: true, name: "Recovered Project")
            } else { return false }
            applyPreparedProject(prepared)
            lastAutosaveText = "Restored complete project"
            return true
        } catch {
            recoveryBlocksAutosave = true
            lastAutosaveText = "Recovery failed: " + error.localizedDescription
            return false
        }
    }

    func clearProjectTransientState() {
        videoImportTask?.cancel(); videoImportTask = nil
        stopPlayback(); select(nil); clearMultiSelection()
        sceneVideoPlayback.reset()
        undoStack.removeAll(); redoStack.removeAll(); audioUndoStack.removeAll(); audioRedoStack.removeAll()
        transformUndoStack.removeAll(); transformRedoStack.removeAll()
        materialUndoStack.removeAll(); materialRedoStack.removeAll()
        deleteUndoStack.removeAll(); deleteRedoStack.removeAll()
        pendingTransformHistory.removeAll(); originalMaterialStates.removeAll()
        timelineChannels = nil; undoCount = 0; redoCount = 0
        selectedKeyframeID = nil; selectedMotionTrackID = nil; selectedAudioClipID = nil
        audioClipboard = nil; keyframeClipboard = nil; animationClipboardFrames.removeAll()
        audioImportGeneration = UUID()
        materialLighting.removeAllObjects(); materialDoubleSided.removeAllObjects()
        materialSpecular.removeAllObjects(); materialShininess.removeAllObjects()
        previousViewportShadingMode = .rendered; previousBackfaceCullingEnabled = true
        cameraBeforePreview = nil; projectOpeningCamera = nil; isUsingSelectedCamera = false
    }

    func applyPreparedProject(_ project: PreparedStudioProject) {
        hasActiveProject = true
        currentProjectLibraryID = nil
        recoveryBlocksAutosave = false
        clearProjectTransientState()
        func transfer(_ name: String, to destination: SCNNode) {
            destination.childNodes.forEach { $0.removeFromParentNode() }
            if let source = project.scene.rootNode.childNode(withName: name, recursively: false) {
                destination.transform = source.transform; destination.pivot = source.pivot
                destination.opacity = source.opacity; destination.isHidden = source.isHidden
                for child in source.childNodes { destination.addChildNode(child) }
                source.removeFromParentNode()
            }
            destination.removeFromParentNode()
            project.scene.rootNode.addChildNode(destination)
        }
        transfer("Scene", to: contentRoot); transfer("Cameras", to: camerasRoot); transfer("Lights", to: lightsRoot)
        editorRoot.removeFromParentNode(); helpersRoot.removeFromParentNode()
        project.scene.rootNode.addChildNode(editorRoot); project.scene.rootNode.addChildNode(helpersRoot)
        scene = project.scene
        removeStaleSelectionOverlays()
        let oldRuntime = activeProjectRuntimeFolder
        activeProjectRuntimeFolder = project.runtimeFolder
        if let oldRuntime, oldRuntime != project.runtimeFolder { try? FileManager.default.removeItem(at: oldRuntime) }
        currentProjectName = project.package.name
        let m = project.metadata
        if let id = m.projectLibraryID, ProjectFileStore.safeComponent(id),
           FileManager.default.fileExists(atPath: projectFolder(id: id).appendingPathComponent("Project.3dmotion").path) {
            currentProjectLibraryID = id
        }
        timelineMinimumDuration = m.timelineMinimumDuration ?? 0; fps = m.fps; currentTime = m.currentTime
        gridSpacing = m.gridSpacing; gridHalfCount = m.gridHalfCount
        showGrid = m.showGrid; showAxes = m.showAxes; showWorkPoint = m.showWorkPoint
        ambientStrength = m.ambientStrength; fogEnabled = m.fogEnabled; fogDensity = m.fogDensity
        fogColor = Color(red: m.fogR, green: m.fogG, blue: m.fogB, opacity: m.fogA)
        keyframes = project.keyframes; audioClips = project.audio; audioAssets = project.audioAssets
        masterAudioVolume = m.masterAudioVolume ?? 1
        reconcileTimelineDuration()
        currentTime = min(currentTime, duration)
        animationLayers = m.animationLayers ?? []
        motionTrackNames = m.motionTrackNames ?? [:]; activeMotionTrackByNode = m.activeMotionTracks ?? [:]
        loopingMotionTrackIDs = m.loopingMotionTracks ?? []
        environmentPreset = m.environmentPreset.flatMap(SceneEnvironmentPreset.init(rawValue:)) ?? .none
        environmentIntensity = m.environmentIntensity ?? 1
        customEnvironmentImage = project.environment
        renderFilterPreset = m.renderFilterPreset.flatMap(RenderFilterPreset.init(rawValue:)) ?? .none
        renderFilterIntensity = m.renderFilterIntensity ?? 1
        if let raw = m.transformSpace, let space = TransformSpace(rawValue: raw) { transformSpace = space }
        autoKeyframeEnabled = m.autoKeyframeEnabled ?? false
        if let v = m.viewportState {
            viewportBackgroundIndex = v.backgroundIndex; viewportShadingMode = ViewportShadingMode(rawValue: v.shadingMode) ?? .rendered
            backfaceCullingEnabled = v.backfaceCulling; viewportLightCount = v.lightCount
            viewportKeyStrength = v.keyStrength; viewportFillStrength = v.fillStrength; viewportRimStrength = v.rimStrength
            viewportSpecularStrength = v.specularStrength; viewportHighlightSize = v.highlightSize
        }
        if let camera = project.editorCamera { editorViewportCamera?.camera = camera }
        if let matrix = m.editorCameraTransform, let transform = try? ProjectSceneCodec.matrix(matrix) {
            editorViewportCamera?.transform = transform
        }
        // Do not run the legacy "repair cube" routine or a material preset on
        // restoration. Authored maps/colors are already decoded and bound.
        for node in ProjectSceneCodec.nodes(in: contentRoot) {
            for material in node.geometry?.materials ?? [] {
                materialLighting.setObject(material.lightingModel.rawValue as NSString, forKey: material)
                materialDoubleSided.setObject(NSNumber(value: material.isDoubleSided), forKey: material)
            }
        }
        rebuildHelpers(); applySceneEnvironment()
        applyViewportSettings(updateMaterials: false, updateProjectLights: false)
        let nodes = ProjectSceneCodec.nodes(in: scene.rootNode)
        let namedCamera = m.activeCameraName.flatMap { name in
            name == editorViewportCamera?.name ? editorViewportCamera : nodes.first { $0.name == name && $0.camera != nil }
        }
        let camera = m.activeCameraID.flatMap { id in nodes.first { $0.studioAnimationID == id && $0.camera != nil } }
            ?? namedCamera ?? editorViewportCamera
        projectOpeningCamera = camera
        scnView?.scene = scene; scnView?.pointOfView = camera
        isUsingSelectedCamera = camera != nil && camera !== editorViewportCamera
        for layer in animationLayers {
            let node = nodes.first { layer.nodeID != nil ? $0.studioAnimationID == layer.nodeID : $0.name == layer.nodeName }
            if let player = node?.animationPlayer(forKey: layer.id) {
                player.speed = layer.speed; player.blendFactor = layer.weight
                if layer.isPaused { player.paused = true } else { player.play() }
            }
        }
        statusText = "تم فتح المشروع والخامات / Project and materials restored"
        synchronizeVideoTimeline()
    }
}
