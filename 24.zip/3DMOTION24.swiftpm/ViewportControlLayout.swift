import CoreGraphics

// Coordinates are physical viewport coordinates; never mirror them for RTL.
struct ViewportControlLayout {
    let tools: CGRect
    let joystick: CGRect

    init(size: CGSize, joystickSize: CGFloat, joystickOffset: CGPoint, scaleTools: Bool) {
        let railWidth: CGFloat = scaleTools ? 128 : 52
        let extent = min(max(44, joystickSize), max(44, size.width - railWidth - 36), max(44, size.height - 156))
        let x = min(max(12, 24 + joystickOffset.x), max(12, size.width - extent - 12))
        let y = min(max(12, size.height - 20 - extent + joystickOffset.y), max(12, size.height - extent - 12))
        var joy = CGRect(x: x, y: y, width: extent, height: extent)
        let top: CGFloat = min(102, max(12, size.height - 116))
        let preferred: CGFloat = scaleTools ? 334 : 282
        var height = min(preferred, max(44, joy.minY - top - 12))
        let rail = CGRect(x: 10, y: top, width: railWidth, height: height)
        if rail.intersects(joy.insetBy(dx: -8, dy: -8)) {
            // Short windows keep all controls reachable: the rail scrolls and
            // the joystick moves beside it, rather than drawing over buttons.
            joy.origin.x = min(max(rail.maxX + 12, joy.minX), max(12, size.width - extent - 12))
            if rail.intersects(joy.insetBy(dx: -8, dy: -8)) {
                joy.origin.y = min(size.height - extent - 12, top + 56)
                height = max(36, joy.minY - top - 12)
            }
        }
        tools = CGRect(x: 10, y: top, width: railWidth, height: height)
        joystick = joy
    }
}
