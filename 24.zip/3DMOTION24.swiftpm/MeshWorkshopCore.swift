import Foundation

// Independent, bounded triangle operations. No Blender binary or source is used.
enum MeshWorkshopError: LocalizedError {
    case invalid, limit, unsupported, empty
    var errorDescription: String? {
        switch self {
        case .invalid: return "بيانات هندسة غير صالحة / Invalid mesh data"
        case .limit: return "تجاوز العملية حد الهندسة الآمن / Mesh operation exceeds the safe budget"
        case .unsupported: return "هذه الأداة تحتاج مجسمًا مثلثًا ثابتًا / This tool requires a static triangle mesh"
        case .empty: return "النتيجة فارغة؛ لم يتغير المجسم / Empty result; the object was preserved"
        }
    }
}

struct WorkshopMesh: Sendable {
    typealias V = SIMD3<Double>
    struct Vertex: Sendable {
        var p: V
        var n: V = V(0, 1, 0)
        var uv: SIMD2<Double> = .zero
        static func interpolate(_ a: Vertex, _ b: Vertex, _ t: Double) -> Vertex {
            Vertex(p: a.p + (b.p - a.p) * t, n: unit(a.n + (b.n - a.n) * t), uv: a.uv + (b.uv - a.uv) * t)
        }
    }
    struct Face: Sendable { var a: Int; var b: Int; var c: Int; var material: Int = 0; var indices: [Int] { [a,b,c] } }
    var vertices: [Vertex]
    var faces: [Face]
    static let maximumFaces = 100_000
    static let maximumVertices = 300_000
    static func dot(_ a: V, _ b: V) -> Double { a.x*b.x + a.y*b.y + a.z*b.z }
    static func cross(_ a: V, _ b: V) -> V { V(a.y*b.z-a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x) }
    static func length(_ a: V) -> Double { sqrt(dot(a,a)) }
    static func unit(_ a: V) -> V { let l = length(a); return l > 1e-12 ? a/l : .zero }
    var bounds: (V,V) {
        var lo = V(repeating: .infinity), hi = V(repeating: -.infinity)
        for v in vertices { for axis in 0..<3 { lo[axis] = min(lo[axis],v.p[axis]); hi[axis] = max(hi[axis],v.p[axis]) } }
        return (lo,hi)
    }
    func checked() throws -> WorkshopMesh {
        guard !faces.isEmpty, !vertices.isEmpty else { throw MeshWorkshopError.empty }
        guard faces.count <= Self.maximumFaces, vertices.count <= Self.maximumVertices else { throw MeshWorkshopError.limit }
        guard vertices.allSatisfy({ v in (0..<3).allSatisfy { v.p[$0].isFinite && v.n[$0].isFinite } && v.uv.x.isFinite && v.uv.y.isFinite }),
              faces.allSatisfy({ $0.material >= 0 && $0.indices.allSatisfy(vertices.indices.contains) }) else { throw MeshWorkshopError.invalid }
        return self
    }
    func faceNormal(_ f: Face) -> V { Self.unit(Self.cross(vertices[f.b].p-vertices[f.a].p, vertices[f.c].p-vertices[f.a].p)) }
    func normals(smooth: Bool) -> WorkshopMesh {
        var result = self
        if !smooth {
            result.vertices = []; result.faces = []
            for f in faces {
                let base = result.vertices.count, n = faceNormal(f)
                for i in f.indices { var v = vertices[i]; v.n = n; result.vertices.append(v) }
                result.faces.append(Face(a:base,b:base+1,c:base+2,material:f.material))
            }
        } else {
            // Welded positions share their area-weighted normal, including UV seams.
            var sums: [String:V] = [:]
            for f in faces {
                let n = Self.cross(vertices[f.b].p-vertices[f.a].p, vertices[f.c].p-vertices[f.a].p)
                for i in f.indices { sums[positionKey(vertices[i].p), default:.zero] += n }
            }
            for i in result.vertices.indices { result.vertices[i].n = Self.unit(sums[positionKey(vertices[i].p)] ?? .zero) }
        }
        return result
    }
    private func positionKey(_ p: V) -> String { "\(p.x),\(p.y),\(p.z)" }
    func subdivided() throws -> WorkshopMesh {
        guard faces.count <= Self.maximumFaces/4 else { throw MeshWorkshopError.limit }
        var result = self, midpoints: [String:Int] = [:]
        result.faces = []
        func midpoint(_ a: Int, _ b: Int) -> Int {
            let key = "\(min(a,b)):\(max(a,b))"
            if let i = midpoints[key] { return i }
            let i = result.vertices.count
            result.vertices.append(Vertex.interpolate(vertices[a],vertices[b],0.5)); midpoints[key] = i
            return i
        }
        for f in faces {
            let ab = midpoint(f.a,f.b), bc = midpoint(f.b,f.c), ca = midpoint(f.c,f.a)
            result.faces += [Face(a:f.a,b:ab,c:ca,material:f.material), Face(a:ab,b:f.b,c:bc,material:f.material),
                             Face(a:ca,b:bc,c:f.c,material:f.material), Face(a:ab,b:bc,c:ca,material:f.material)]
        }
        return try result.checked()
    }
    func mirrored(axis: Int) throws -> WorkshopMesh {
        guard (0..<3).contains(axis) else { throw MeshWorkshopError.invalid }
        var result = self
        for i in result.vertices.indices { result.vertices[i].p[axis] *= -1; result.vertices[i].n[axis] *= -1 }
        for i in result.faces.indices {let b=result.faces[i].b;result.faces[i].b=result.faces[i].c;result.faces[i].c=b}
        return try result.checked()
    }
    // Region extrusion recognizes coincident seam vertices for boundary edges.
    func extruded(selected: Set<Int>, distance: Double) throws -> WorkshopMesh {
        guard distance.isFinite, abs(distance) > 1e-9, !selected.isEmpty, selected.allSatisfy(faces.indices.contains) else { throw MeshWorkshopError.invalid }
        let welded = try welded(tolerance: 1e-9, preserveUV: false)
        // Welding may remove degenerate faces; keep face indices stable for selection.
        guard welded.faces.count == faces.count else { throw MeshWorkshopError.invalid }
        var result = self, offsets: [String:V] = [:], counts: [String:Int] = [:]
        for i in selected.sorted() {
            let f = faces[i], n = faceNormal(f)
            for index in f.indices { let key = positionKey(vertices[index].p); offsets[key,default:.zero] += n; counts[key,default:0] += 1 }
        }
        var top: [Int:Int] = [:]
        for i in Set(selected.flatMap { faces[$0].indices }).sorted() {
            var v = vertices[i]; v.p += Self.unit(offsets[positionKey(v.p)] ?? .zero) * distance
            top[i] = result.vertices.count; result.vertices.append(v)
        }
        var edges: [String:(Int,Int,Int,Int)] = [:]
        for i in selected.sorted() {
            let f = faces[i], w = welded.faces[i]
            for e in 0..<3 {
                let a=f.indices[e], b=f.indices[(e+1)%3], wa=w.indices[e], wb=w.indices[(e+1)%3]
                let key="\(min(wa,wb)):\(max(wa,wb))"
                if let old=edges[key] { edges[key]=(old.0,old.1,old.2+1,old.3) } else { edges[key]=(a,b,1,f.material) }
            }
            result.faces[i] = Face(a:top[f.a]!,b:top[f.b]!,c:top[f.c]!,material:f.material)
        }
        for key in edges.keys.sorted() {
            let (a,b,count,mat)=edges[key]!
            if count == 1 { result.faces += [Face(a:a,b:b,c:top[b]!,material:mat),Face(a:a,b:top[b]!,c:top[a]!,material:mat)] }
            if count > 2 { throw MeshWorkshopError.unsupported }
        }
        return try result.normals(smooth:false).checked()
    }
    func inset(selected: Set<Int>, fraction: Double) throws -> WorkshopMesh {
        guard fraction.isFinite, fraction > 0, fraction < 1, !selected.isEmpty, selected.allSatisfy(faces.indices.contains) else { throw MeshWorkshopError.invalid }
        var result=self; result.faces=[]
        for (i,f) in faces.enumerated() {
            if !selected.contains(i) { result.faces.append(f); continue }
            let center=(vertices[f.a].p+vertices[f.b].p+vertices[f.c].p)/3, base=result.vertices.count
            for index in f.indices { var v=vertices[index]; v.p += (center-v.p)*fraction; result.vertices.append(v) }
            result.faces.append(Face(a:base,b:base+1,c:base+2,material:f.material))
            for e in 0..<3 {
                let a=f.indices[e], b=f.indices[(e+1)%3], ta=base+e, tb=base+(e+1)%3
                result.faces += [Face(a:a,b:b,c:tb,material:f.material),Face(a:a,b:tb,c:ta,material:f.material)]
            }
        }
        return try result.checked()
    }
    func solidified(thickness: Double) throws -> WorkshopMesh {
        guard thickness.isFinite, abs(thickness)>1e-9 else { throw MeshWorkshopError.invalid }
        var result=self.normals(smooth:true), base=result.vertices.count
        let outer=result.vertices
        for var v in outer { v.p -= v.n*thickness; v.n *= -1; result.vertices.append(v) }
        for f in faces { result.faces.append(Face(a:f.a+base,b:f.c+base,c:f.b+base,material:f.material)) }
        let welded=try welded(tolerance:1e-9,preserveUV:false)
        guard welded.faces.count == faces.count else { throw MeshWorkshopError.invalid }
        var edges:[String:(Int,Int,Int,Int)]=[:]
        for (i,f) in faces.enumerated() {
            let w=welded.faces[i]
            for e in 0..<3 {
                let wa=w.indices[e], wb=w.indices[(e+1)%3], key="\(min(wa,wb)):\(max(wa,wb))"
                if let old=edges[key] { edges[key]=(old.0,old.1,old.2+1,old.3) }
                else { edges[key]=(f.indices[e],f.indices[(e+1)%3],1,f.material) }
            }
        }
        for key in edges.keys.sorted() {
            let (a,b,count,mat)=edges[key]!
            if count>2 { throw MeshWorkshopError.unsupported }
            if count==1 { result.faces += [Face(a:b,b:a,c:a+base,material:mat),Face(a:b,b:a+base,c:b+base,material:mat)] }
        }
        return try result.checked()
    }
    func welded(tolerance: Double, preserveUV: Bool = true) throws -> WorkshopMesh {
        guard tolerance.isFinite, tolerance>0 else { throw MeshWorkshopError.invalid }
        var cells:[String:[Int]]=[:], output:[Vertex]=[], remap:[Int]=[]
        for v in vertices {
            let scaled=v.p/tolerance
            guard (0..<3).allSatisfy({ scaled[$0].isFinite && abs(scaled[$0]) < Double(Int64.max/4) }) else { throw MeshWorkshopError.invalid }
            let q=(0..<3).map { Int64(floor(scaled[$0])) }
            var found:Int?
            search: for x in -1...1 { for y in -1...1 { for z in -1...1 {
                let key="\(q[0]+Int64(x)):\(q[1]+Int64(y)):\(q[2]+Int64(z))"
                for i in cells[key] ?? [] where Self.length(output[i].p-v.p)<=tolerance && (!preserveUV || output[i].uv==v.uv) { found=i; break search }
            } } }
            if let i=found { remap.append(i) }
            else { let i=output.count; output.append(v); remap.append(i); cells["\(q[0]):\(q[1]):\(q[2])",default:[]].append(i) }
        }
        let mapped=faces.compactMap { f -> Face? in
            let a=remap[f.a],b=remap[f.b],c=remap[f.c]
            return a != b && b != c && a != c ? Face(a:a,b:b,c:c,material:f.material) : nil
        }
        return try WorkshopMesh(vertices:output,faces:mapped).checked()
    }
    func smoothed(iterations: Int, strength: Double) throws -> WorkshopMesh {
        guard (1...20).contains(iterations), strength.isFinite, (0...1).contains(strength) else { throw MeshWorkshopError.invalid }
        var mesh=try welded(tolerance:1e-9,preserveUV:false), neighbors=Array(repeating:Set<Int>(),count:0)
        neighbors=Array(repeating:Set<Int>(),count:mesh.vertices.count)
        for f in mesh.faces { for a in f.indices { for b in f.indices where a != b { neighbors[a].insert(b) } } }
        for _ in 0..<iterations {
            let original=mesh.vertices
            for i in original.indices where !neighbors[i].isEmpty {
                let average=neighbors[i].sorted().reduce(V.zero) { $0+original[$1].p } / Double(neighbors[i].count)
                mesh.vertices[i].p += (average-original[i].p)*strength
            }
        }
        // Keep original UV seams and vertex ordering; only replace positions.
        var result=self
        let weldedOriginal=try welded(tolerance:1e-9,preserveUV:false)
        var byPosition:[String:V]=[:]
        for i in weldedOriginal.vertices.indices { byPosition[positionKey(weldedOriginal.vertices[i].p)]=mesh.vertices[i].p }
        for i in result.vertices.indices { result.vertices[i].p=byPosition[positionKey(vertices[i].p)] ?? vertices[i].p }
        return try result.normals(smooth:true).checked()
    }
    enum Deform: String, CaseIterable { case twist, bend, taper }
    func deformed(_ kind: Deform, axis: Int, amount: Double) throws -> WorkshopMesh {
        guard (0..<3).contains(axis), amount.isFinite, abs(amount)<=Double.pi*4 else { throw MeshWorkshopError.invalid }
        let (lo,hi)=bounds, span=hi[axis]-lo[axis]
        guard span>1e-9 else { throw MeshWorkshopError.invalid }
        let a=(axis+1)%3,b=(axis+2)%3, center=(lo+hi)/2
        var result=self
        for i in result.vertices.indices {
            var p=vertices[i].p-center; let t=p[axis]/span
            switch kind {
            case .twist: let angle=t*amount,x=p[a],y=p[b]; p[a]=cos(angle)*x-sin(angle)*y; p[b]=sin(angle)*x+cos(angle)*y
            case .taper: let factor=max(0.01,1+t*amount); p[a]*=factor; p[b]*=factor
            case .bend:
                if abs(amount)>1e-9 {
                    let radius=span/amount,angle=p[axis]/radius,x=p[a]
                    p[a]=(radius+x)*cos(angle)-radius; p[axis]=(radius+x)*sin(angle)
                }
            }
            result.vertices[i].p=p+center
        }
        return try result.normals(smooth:true).checked()
    }
    enum UV: String, CaseIterable { case box, planar, cylindrical, spherical }
    func mappedUV(_ mapping: UV, axis: Int, tiling: Double) throws -> WorkshopMesh {
        guard (0..<3).contains(axis),tiling.isFinite,tiling>0,tiling<=100 else { throw MeshWorkshopError.invalid }
        let (lo,hi)=bounds, center=(lo+hi)/2, size=hi-lo
        var result=normals(smooth:false)
        for (i,f) in result.faces.enumerated() {
            let n=result.faceNormal(f)
            let dominant=(0..<3).max { abs(n[$0])<abs(n[$1]) } ?? axis
            let projection=mapping == .box ? dominant : axis, a=(projection+1)%3,b=(projection+2)%3
            for index in result.faces[i].indices {
                let p=result.vertices[index].p, d=p-center
                var uv=SIMD2((p[a]-lo[a])/max(size[a],1e-9),(p[b]-lo[b])/max(size[b],1e-9))
                if mapping == .cylindrical { uv=SIMD2(atan2(d[b],d[a])/(2 * .pi)+0.5,(p[axis]-lo[axis])/max(size[axis],1e-9)) }
                if mapping == .spherical { uv=SIMD2(atan2(d[b],d[a])/(2 * .pi)+0.5,acos(max(-1,min(1,d[axis]/max(Self.length(d),1e-9)))) / .pi) }
                result.vertices[index].uv=uv*tiling
            }
            if mapping == .cylindrical || mapping == .spherical {
                let ids=result.faces[i].indices, values=ids.map { result.vertices[$0].uv.x }
                if (values.max() ?? 0)-(values.min() ?? 0)>tiling/2 { for index in ids where result.vertices[index].uv.x<tiling/2 { result.vertices[index].uv.x += tiling } }
            }
        }
        return try result.checked()
    }
    func sculpted(center: V, radius: Double, strength: Double) throws -> WorkshopMesh {
        guard radius.isFinite,radius>0,strength.isFinite, (0..<3).allSatisfy({center[$0].isFinite}) else { throw MeshWorkshopError.invalid }
        var result=normals(smooth:true)
        for i in result.vertices.indices {
            let distance=Self.length(result.vertices[i].p-center)/radius
            if distance<1 { let weight=(1-distance*distance); result.vertices[i].p += result.vertices[i].n*(strength*weight*weight) }
        }
        return try result.normals(smooth:true).checked()
    }
}
