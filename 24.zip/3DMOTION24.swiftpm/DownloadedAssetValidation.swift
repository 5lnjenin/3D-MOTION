import Foundation

enum DownloadedAssetValidation {
    /// Inspect a GLB container before replacing a cache entry. Bounded reads
    /// reject HTML error pages and truncated/mismatched downloads.
    static func validate(_ url: URL, expectedBytes: Int64? = nil) throws {
        let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
        guard size >= 20, expectedBytes.map({ $0 < 0 || $0 == Int64(size) }) != false else { throw CocoaError(.fileReadCorruptFile) }
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        func read(_ count: Int) throws -> Data {
            guard let bytes = try handle.read(upToCount: count), bytes.count == count else { throw CocoaError(.fileReadCorruptFile) }
            return bytes
        }
        func integer(_ bytes: Data, at offset: Int) -> UInt32 {
            (0..<4).reduce(0) { $0 | UInt32(bytes[offset + $1]) << ($1 * 8) }
        }
        let header = try read(12)
        guard header.prefix(4) == Data("glTF".utf8), integer(header, at: 4) == 2,
              UInt64(integer(header, at: 8)) == UInt64(size) else { throw CocoaError(.fileReadCorruptFile) }
        var offset = 12, first = true
        while offset < size {
            let chunk = try read(8), length = Int(integer(chunk, at: 0)), type = integer(chunk, at: 4)
            guard length > 0, length % 4 == 0, length <= size - offset - 8 else { throw CocoaError(.fileReadCorruptFile) }
            if first {
                guard type == 0x4E4F534A, length <= 128 * 1024 * 1024,
                      let json = try JSONSerialization.jsonObject(with: read(length)) as? [String: Any],
                      let asset = json["asset"] as? [String: Any], asset["version"] as? String == "2.0" else { throw CocoaError(.fileReadCorruptFile) }
                first = false
            } else { try handle.seek(toOffset: UInt64(offset + 8 + length)) }
            offset += 8 + length
        }
        guard offset == size, !first else { throw CocoaError(.fileReadCorruptFile) }
    }
}
