import Foundation

/// The same authored clock is used by the preview, offline pictures and audio.
struct VideoClipTiming: Codable, Equatable, Sendable {
    var start = 0.0
    var sourceIn = 0.0
    var sourceOut: Double? = nil
    var speed = 1.0
    var loops = false
    var volume = 1.0
    var muted = false

    func validate() throws {
        guard [start, sourceIn, speed, volume].allSatisfy(\.isFinite), start >= 0, sourceIn >= 0,
              (0.1...4).contains(speed), (0...1).contains(volume),
              sourceOut.map({ $0.isFinite && $0 > sourceIn }) != false else { throw CocoaError(.coderInvalidValue) }
    }

    func endOfSource(_ duration: Double) -> Double { min(sourceOut ?? duration, duration) }
    func cycleDuration(_ duration: Double) -> Double { max(0, endOfSource(duration) - sourceIn) / speed }
    func timelineEnd(_ duration: Double) -> Double { start + cycleDuration(duration) }

    func sourceTime(at time: Double, duration: Double) -> Double {
        let end = endOfSource(duration), length = max(0, end - sourceIn)
        let elapsed = max(0, time - start) * speed
        var offset = loops && length > 0 ? elapsed.truncatingRemainder(dividingBy: length) : elapsed
        if loops && abs(offset - length) < 0.000000001 { offset = 0 }
        return max(0, min(max(0, duration - 0.000001), min(sourceIn + offset, max(sourceIn, end - 0.000001))))
    }

    func isActive(at time: Double, duration: Double) -> Bool {
        time >= start && cycleDuration(duration) > 0 && (loops || time < timelineEnd(duration))
    }

    struct AudioSegment: Equatable, Sendable {
        let sourceStart: Double
        let sourceDuration: Double
        let timelineStart: Double
        let timelineDuration: Double
    }

    /// Intersect with the actual audio track range; retain its offset (some
    /// movies have a delayed or shorter audio stream). Speed scales both clocks.
    func audioSegments(sourceDuration: Double, audioStart: Double, audioEnd: Double,
                       timelineDuration: Double, windowStart: Double = 0, windowEnd: Double? = nil) throws -> [AudioSegment] {
        try validate()
        guard [sourceDuration, audioStart, audioEnd, timelineDuration, windowStart].allSatisfy(\.isFinite),
              windowEnd?.isFinite != false, sourceDuration > 0, timelineDuration > 0 else { throw CocoaError(.coderInvalidValue) }
        let period = cycleDuration(sourceDuration)
        let upper = min(timelineDuration, windowEnd ?? timelineDuration)
        guard period > 0, start < upper else { return [] }
        let first = max(sourceIn, audioStart), last = min(endOfSource(sourceDuration), audioEnd)
        guard last > first else { return [] }
        var result: [AudioSegment] = []
        var cycle = start
        if loops && windowStart > start { cycle += floor((windowStart - start) / period) * period }
        repeat {
            let begin = max(windowStart, cycle + (first - sourceIn) / speed)
            let end = min(upper, cycle + (last - sourceIn) / speed)
            if end - begin > 0.000000001 {
                result.append(AudioSegment(sourceStart: sourceIn + (begin - cycle) * speed,
                    sourceDuration: (end - begin) * speed, timelineStart: begin, timelineDuration: end - begin))
            }
            guard result.count < 100_000 else { throw CocoaError(.coderInvalidValue) }
            let next = cycle + period
            guard next > cycle else { throw CocoaError(.coderInvalidValue) }
            cycle = next
        } while loops && cycle < upper
        return result
    }
}
