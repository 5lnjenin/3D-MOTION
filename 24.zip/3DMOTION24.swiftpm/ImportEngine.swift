import Foundation
import SwiftUI
import UIKit
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

@MainActor
extension StudioStore {
// MARK: Import


    func extractDeepPartsFromSelection() {
        guard let node = selectedNode, !importIsRunning, !isTransformGestureActive else {
            toast = "حدد مجسمًا وانتظر اكتمال العملية الحالية / Select an object first"
            return
        }
        var hasRig = node.skinner != nil || node.morpher != nil
        node.enumerateChildNodes { child, stop in
            if child.skinner != nil || child.morpher != nil { hasRig = true; stop.pointee = true }
        }
        guard !hasRig else {
            toast = "تم إبقاء الشخصية مترابطة لحماية Rig / Rigged meshes cannot be separated"
            return
        }
        stopPlayback()
        let before = partCount(in: node)
        let box = ImportedNodeBox(cleanDeepClone(node, copyGeometry: false))
        importIsRunning = true
        importCancellationRequested = false
        statusText = appLanguage == .arabic ? "استخراج القطع…" : "Separating parts…"
        Task { @MainActor in
            await Task.detached(priority: .userInitiated) {
                ImportedHierarchyProcessor.separateImportedMaterialParts(in: box.node, deep: true)
            }.value
            defer { importIsRunning = false }
            guard !importCancellationRequested, node.parent != nil else {
                statusText = appLanguage == .arabic ? "تم إلغاء استخراج القطع" : "Separation cancelled"
                return
            }
            let after = partCount(in: box.node)
            guard after > before else {
                statusText = appLanguage == .arabic ? "لا توجد قطع إضافية قابلة للفصل" : "No additional parts"
                toast = statusText
                return
            }
            pushUndoSnapshot("Separate parts")
            node.geometry = box.node.geometry
            node.childNodes.forEach { $0.removeFromParentNode() }
            for child in box.node.childNodes { node.addChildNode(child) }
            importNodeItems.removeAll(keepingCapacity: true)
            appendImportInventory(root: contentRoot, sourceFile: "Scene")
            select(node)
            statusText = appLanguage == .arabic ? "تم استخراج \(after-before) قطعة" : "Separated \(after-before) parts"
            toast = statusText
        }
    }

    func partCount(in root: SCNNode) -> Int {
        var count = root.geometry == nil ? 0 : 1
        root.enumerateChildNodes { node, _ in
            if node.geometry != nil && node.name != "_SelectionOutline" {
                count += 1
            }
        }
        return count
    }

    func unhideImportedTree(_ root: SCNNode) {
        root.isHidden = false
        root.opacity = 1
        root.enumerateChildNodes { node, _ in
            node.isHidden = false
            if node.opacity <= 0.001 {
                node.opacity = 1
            }
        }
    }

    func revealAndFrameSelected() {
        guard let selectedNode else {
            toast = "حدد عنصرًا من القائمة أولًا"
            return
        }
        unhideImportedTree(selectedNode)
        frameNode(selectedNode)
    }

    func placeImportedProjectInFrontOfView(_ node: SCNNode) {
        selectionOutline?.removeFromParentNode()
        selectionOutline = nil
        selectionGizmo?.removeFromParentNode()
        selectionGizmo = nil

        node.isHidden = false

        // Normalize imported project size first.
        if autoFitImports, let before = worldBounds(of: node) {
            let sx = max(0.0001, before.max.x - before.min.x)
            let sy = max(0.0001, before.max.y - before.min.y)
            let sz = max(0.0001, before.max.z - before.min.z)
            let maxSide = max(sx, max(sy, sz))

            if maxSide.isFinite && maxSide > 0.0001 {
                let targetSize: Float = 4.2
                let factor = targetSize / maxSide
                node.scale = SCNVector3(
                    node.scale.x * factor,
                    node.scale.y * factor,
                    node.scale.z * factor
                )
            }
        }

        guard let view = scnView,
              let camera = view.pointOfView else {
            prepareForWorkspace(node, normalizeSize: false)
            return
        }

        // Compute the project's current world-space center after scaling.
        guard let bounds = worldBounds(of: node) else {
            prepareForWorkspace(node, normalizeSize: false)
            return
        }

        let currentCenter = SCNVector3(
            (bounds.min.x + bounds.max.x) * 0.5,
            (bounds.min.y + bounds.max.y) * 0.5,
            (bounds.min.z + bounds.max.z) * 0.5
        )

        let sx = max(0.05, bounds.max.x - bounds.min.x)
        let sy = max(0.05, bounds.max.y - bounds.min.y)
        let sz = max(0.05, bounds.max.z - bounds.min.z)
        let maxSide = max(sx, max(sy, sz))

        // SceneKit cameras look down their local -Z axis.
        var forward = camera.presentation.convertVector(
            SCNVector3(0, 0, -1),
            to: nil
        )
        let length = sqrtf(
            forward.x * forward.x +
            forward.y * forward.y +
            forward.z * forward.z
        )

        if length > 0.00001 {
            forward = SCNVector3(
                forward.x / length,
                forward.y / length,
                forward.z / length
            )
        } else {
            forward = SCNVector3(0, 0, -1)
        }

        let cameraPosition = camera.presentation.worldPosition

        // Keep the model comfortably away from the current viewpoint.
        // Larger projects are placed proportionally farther away.
        let distance = max(6.0, maxSide * 2.4)

        let targetCenter = SCNVector3(
            cameraPosition.x + forward.x * distance,
            cameraPosition.y + forward.y * distance,
            cameraPosition.z + forward.z * distance
        )

        let offset = SCNVector3(
            targetCenter.x - currentCenter.x,
            targetCenter.y - currentCenter.y,
            targetCenter.z - currentCenter.z
        )

        node.position = SCNVector3(
            node.position.x + offset.x,
            node.position.y + offset.y,
            node.position.z + offset.z
        )

        // Keep camera position and zoom untouched; only point it at the project.
        if let placed = worldBounds(of: node) {
            let placedCenter = SCNVector3(
                (placed.min.x + placed.max.x) * 0.5,
                (placed.min.y + placed.max.y) * 0.5,
                (placed.min.z + placed.max.z) * 0.5
            )
            camera.studioLook(at: placedCenter)
            statusText = appLanguage == .arabic ? "تم وضع المشروع أمام المنظور" : "Project placed in front"
        }
    }

    func resetImportMonitor(
        with urls: [URL]
    ) {
        importFileItems = urls.map {
            ImportFileItem(
                name: $0.lastPathComponent,
                fileType: $0.pathExtension.uppercased(),
                status: "Queued",
                detail: "بانتظار الاستيراد"
            )
        }

        importNodeItems.removeAll()
        importLoadedModels = 0
        importErrorCount = 0
        importIsRunning = true

        // Never auto-present a second sheet from the fileImporter completion.
        // On iPadOS this can race the document picker dismissal and terminate
        // the presentation stack. Import progress stays in the main UI state;
        // the monitor may still be opened explicitly by the user if desired.
        isImportMonitorPresented = false
    }

    func updateImportFile(
        named fileName: String,
        status: String,
        detail: String
    ) {
        if let index = importFileItems.firstIndex(
            where: { $0.name == fileName }
        ) {
            importFileItems[index].status = status
            importFileItems[index].detail = detail
            return
        }

        let stem = URL(
            fileURLWithPath: fileName
        )
        .deletingPathExtension()
        .lastPathComponent

        if let index = importFileItems.firstIndex(
            where: {
                URL(fileURLWithPath: $0.name)
                    .deletingPathExtension()
                    .lastPathComponent == stem
            }
        ) {
            importFileItems[index].status = status
            importFileItems[index].detail = detail
        }
    }

    func appendImportInventory(
        root: SCNNode,
        sourceFile: String
    ) {
        var stack: [(node: SCNNode, depth: Int)] = [(root, 0)]
        var visited = Set<ObjectIdentifier>()
        var appended = 0
        var inventory: [ImportNodeItem] = []
        let maximumInventoryNodes = 5_000

        while let current = stack.popLast() {
            let id = ObjectIdentifier(current.node)
            guard visited.insert(id).inserted else { continue }

            let rawName = current.node.name?
                .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""

            if !current.node.isStudioMetadata && rawName != "_TransformGizmo" && rawName != "_SelectionOutline" {
                inventory.append(
                    ImportNodeItem(
                        node: current.node,
                        name: rawName.isEmpty
                            ? (current.node.geometry == nil ? "Node" : "Mesh")
                            : rawName,
                        sourceFile: sourceFile,
                        depth: current.depth,
                        isMesh: current.node.geometry != nil
                    )
                )
                appended += 1
            }

            guard appended < maximumInventoryNodes else { break }

            for child in current.node.childNodes.reversed() {
                stack.append((child, current.depth + 1))
            }
        }
        importNodeItems.append(contentsOf: inventory)
    }

    func importFiles(_ urls: [URL]) {
        guard !isExporting, !urls.isEmpty, !importIsRunning else {
            return
        }

        stopPlayback()
        importCancellationRequested = false
        resetImportMonitor(with: urls)
        statusText = appLanguage == .arabic ? "تجهيز الاستيراد…" : "Preparing import…"

        // The picker can hand us security-scoped URLs backed by iCloud or another
        // provider. Copying and decoding those files on the main actor can freeze
        // the app long enough for iPadOS to kill it. Stage and decode completely
        // off the UI thread, then attach only the finished SceneKit node on MainActor.
        let selectedURLs = urls

        Task { @MainActor in
            do {
                let staged = try await Task.detached(priority: .userInitiated) {
                    try ImportFileStager.stage(selectedURLs)
                }.value

                for resource in staged where helperImportExtensions.contains(
                    resource.pathExtension.lowercased()
                ) {
                    updateImportFile(
                        named: resource.lastPathComponent,
                        status: "Resource",
                        detail: "ملف مساعد / Texture / BIN"
                    )
                }

                var loaded = 0
                var failures: [String] = []
                var notices: [String] = []

                for url in staged where !helperImportExtensions.contains(
                    url.pathExtension.lowercased()
                ) {
                    if importCancellationRequested { break }
                    await Task.yield()
                    updateImportFile(
                        named: url.lastPathComponent,
                        status: "Loading",
                        detail: "يتم فتح المشروع…"
                    )

                    do {
                        let importedBox = try await Task.detached(priority: .userInitiated) {
                            let box = try AssetNodeLoader.load(url: url)
                            try Task.checkCancellation()
                            ImportedHierarchyProcessor.prepareImportedHierarchy(
                                box.node, assetName: url.deletingPathExtension().lastPathComponent
                            )
                            return box
                        }.value

                        let node = importedBox.node
                        notices.append(contentsOf: importedBox.warnings)
                        guard !importCancellationRequested else { break }
                        // Preserve authored visibility, opacity, rig and node transforms.
                        node.isHidden = false
                        renewAnimationIdentity(node)
                        let workspaceNode = workspaceWrappedImportedAsset(node)
                        contentRoot.addChildNode(workspaceNode)

                        // Normalize file units to a comfortable editor size when Auto Fit is on,
                        // then place the complete hierarchy at the project origin/work plane.
                        // This fixes models exported in centimeters/millimeters appearing microscopic.
                        prepareForWorkspace(workspaceNode, normalizeSize: true)
                        select(workspaceNode)
                        frameNode(workspaceNode)

                        appendImportInventory(
                            root: node,
                            sourceFile: url.lastPathComponent
                        )

                        let parts = partCount(in: node)

                        updateImportFile(
                            named: url.lastPathComponent,
                            status: "Loaded",
                            detail: "\(parts) Mesh"
                        )

                        importLoadedModels += 1
                        loaded += 1
                    } catch {
                        let message = error.localizedDescription

                        failures.append(
                            "\(url.lastPathComponent): \(message)"
                        )
                        importErrorCount += 1

                        updateImportFile(
                            named: url.lastPathComponent,
                            status: "Error",
                            detail: message
                        )
                    }
                }

                importIsRunning = false
                refreshAdaptivePerformanceMode()
                refreshParticlePerformanceBudget()

                if importCancellationRequested {
                    for index in importFileItems.indices where
                        importFileItems[index].status == "Loading" || importFileItems[index].status == "Queued" {
                        importFileItems[index].status = "Cancelled"
                    }
                    statusText = appLanguage == .arabic ? "توقف الاستيراد • تم الاحتفاظ بـ \(loaded)" : "Import stopped • kept \(loaded)"
                } else if loaded > 0 {
                    statusText = appLanguage == .arabic ? "تم استيراد \(loaded) عنصر" : "Imported \(loaded)"
                    toast = "تم الاستيراد بنجاح / Import complete"
                } else {
                    statusText = appLanguage == .arabic ? "لم يتم استيراد أي عنصر" : "Nothing imported"
                }

                if !failures.isEmpty {
                    importerMessage = """
                    تم استيراد \(loaded) عنصر.
                    تعذر فتح:
                    \(failures.prefix(6).joined(separator: "\n"))
                    """
                } else if loaded == 0 && !importCancellationRequested {
                    importerMessage = "لم يتم العثور على ملف موديل قابل للفتح."
                }

                if !notices.isEmpty {
                    importerMessage += "\n" + Array(Set(notices)).sorted().joined(separator: "\n")
                }
                // Do not deep-clone and serialize the whole imported scene here.
                // That doubled peak memory in the old path and could be the final
                // push that caused iPadOS to terminate the app. The regular
                // autosave timer will persist the scene after memory settles.
            } catch {
                importIsRunning = false
                importErrorCount += 1
                importerMessage = error.localizedDescription
                statusText = appLanguage == .arabic ? "فشل الاستيراد" : "Import failed"
            }
        }
    }
}
