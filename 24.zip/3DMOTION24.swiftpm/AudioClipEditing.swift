import Foundation
import AVFoundation

struct AudioHistoryState {
    var assets: [StudioAudioAsset]
    var clips: [StudioAudioClip]
    var masterVolume: Double
    var duration: Double
    var timelineMinimumDuration: Double
    var selectedID: UUID?
}

struct AudioHistoryCommand {
    var label: String
    var timestamp = Date().timeIntervalSince1970
    var before: AudioHistoryState
    var after: AudioHistoryState
}

struct AudioClipboardItem {
    var clip: StudioAudioClip
    var asset: StudioAudioAsset
}

// Preview files contain only the authored source range. The original stays
// intact, and AVAudioPlayer can loop this range accurately without UI timers.
enum AudioPreviewCache {
    static func duration(of url: URL) throws -> Double {
        let file = try AVAudioFile(forReading: url)
        let duration = Double(file.length) / file.processingFormat.sampleRate
        guard duration.isFinite, duration > 0 else { throw ProjectFailure.invalid("audio duration") }
        return duration
    }

    static func render(_ clip: StudioAudioClip, folder: URL) throws -> URL {
        guard clip.sourceStart > 0 || clip.trimmedEnd < clip.sourceDuration - 0.000001 else { return clip.url }
        let key = ProjectIntegrity.hash(Data("\(clip.url.path)|\(clip.sourceStart)|\(clip.trimmedEnd)".utf8))
        let target = folder.appendingPathComponent(key + ".caf")
        if FileManager.default.fileExists(atPath: target.path) { return target }
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let pending = folder.appendingPathComponent(UUID().uuidString + ".caf")
        defer { try? FileManager.default.removeItem(at: pending) }
        do {
            let source = try AVAudioFile(forReading: clip.url)
            let rate = source.processingFormat.sampleRate
            let first = max(0, min(source.length, AVAudioFramePosition((clip.sourceStart * rate).rounded())))
            let last = max(first, min(source.length, AVAudioFramePosition((clip.trimmedEnd * rate).rounded())))
            guard last > first else { throw ProjectFailure.invalid("audio trim range") }
            source.framePosition = first
            let output = try AVAudioFile(forWriting: pending, settings: source.processingFormat.settings)
            guard let buffer = AVAudioPCMBuffer(pcmFormat: source.processingFormat, frameCapacity: 16_384) else {
                throw ProjectFailure.invalid("audio buffer")
            }
            var remaining = last - first
            while remaining > 0 {
                try Task.checkCancellation()
                try source.read(into: buffer, frameCount: AVAudioFrameCount(min(remaining, 16_384)))
                guard buffer.frameLength > 0 else { throw ProjectFailure.invalid("audio data") }
                try output.write(from: buffer)
                remaining -= AVAudioFramePosition(buffer.frameLength)
            }
        } // Closing the file finalizes its header before it is used for playback.
        if !FileManager.default.fileExists(atPath: target.path) {
            try FileManager.default.moveItem(at: pending, to: target)
        }
        return target
    }
}

@MainActor
extension StudioStore {
    var historyUndoCount: Int { undoStack.count + transformUndoStack.count + materialUndoStack.count + deleteUndoStack.count + audioUndoStack.count }
    var historyRedoCount: Int { redoStack.count + transformRedoStack.count + materialRedoStack.count + deleteRedoStack.count + audioRedoStack.count }

    var audioHistoryState: AudioHistoryState {
        AudioHistoryState(assets: audioAssets, clips: audioClips.map(\.stoppedCopy), masterVolume: masterAudioVolume,
                          duration: duration, timelineMinimumDuration: timelineMinimumDuration, selectedID: selectedAudioClipID)
    }

    func restoreAudioHistory(_ state: AudioHistoryState) {
        stopAudioTimeline()
        audioAssets = state.assets; audioClips = state.clips.map(\.stoppedCopy)
        masterAudioVolume = state.masterVolume; timelineMinimumDuration = state.timelineMinimumDuration
        reconcileTimelineDuration()
        selectedAudioClipID = state.selectedID
        if isPlaying { playAudioTimeline() }
    }

    func recordAudioEdit(_ label: String, _ change: () -> Void) {
        let before = audioHistoryState
        stopAudioTimeline()
        change()
        reconcileTimelineDuration()
        currentTime = min(currentTime, duration)
        audioUndoStack.append(AudioHistoryCommand(label: label, before: before, after: audioHistoryState))
        if audioUndoStack.count > 100 { audioUndoStack.removeFirst(audioUndoStack.count - 100) }
        audioRedoStack.removeAll(); redoStack.removeAll(); transformRedoStack.removeAll()
        materialRedoStack.removeAll(); deleteRedoStack.removeAll()
        undoCount = historyUndoCount; redoCount = 0
        if isPlaying { playAudioTimeline() }
    }

    func selectAudioClip(_ id: UUID) {
        guard audioClips.contains(where: { $0.id == id }) else { return }
        selectedAudioClipID = id; selectedKeyframeID = nil; selectedMotionTrackID = nil
        activeInspector = .audio
    }

    func addAudioAssetToTimeline(_ id: UUID) {
        guard let asset = audioAssets.first(where: { $0.id == id }) else { return }
        recordAudioEdit("Add Audio Clip") {
            var clip = StudioAudioClip(name: asset.name, url: asset.url, startTime: currentTime)
            clip.assetID = asset.id; clip.sourceDuration = asset.duration
            audioClips.append(clip); selectAudioClip(clip.id)
        }
    }

    func copyAudioClip(_ id: UUID) {
        guard let clip = audioClips.first(where: { $0.id == id }),
              let asset = audioAssets.first(where: { $0.id == clip.assetID }) else { return }
        audioClipboard = AudioClipboardItem(clip: clip.stoppedCopy, asset: asset)
        toast = appLanguage == .arabic ? "تم نسخ المقطع" : "Audio clip copied"
    }

    func cutAudioClip(_ id: UUID) {
        guard audioClips.contains(where: { $0.id == id }) else { return }
        copyAudioClip(id); removeAudioClip(id)
    }

    func pasteAudioClip() {
        guard let item = audioClipboard else { return }
        recordAudioEdit("Paste Audio Clip") {
            if !audioAssets.contains(where: { $0.id == item.asset.id }) { audioAssets.append(item.asset) }
            var clip = item.clip.stoppedCopy
            clip.id = UUID(); clip.trackID = UUID(); clip.startTime = currentTime
            audioClips.append(clip); selectAudioClip(clip.id)
        }
    }

    func duplicateAudioClip(_ id: UUID) {
        guard let original = audioClips.first(where: { $0.id == id }) else { return }
        recordAudioEdit("Duplicate Audio Clip") {
            var copy = original.stoppedCopy
            copy.id = UUID(); copy.startTime = original.endTime
            if copy.loops { copy.trackID = UUID() }
            audioClips.append(copy); selectAudioClip(copy.id)
        }
    }

    @discardableResult
    func editAudioClip(_ id: UUID, startTime: Double, sourceStart: Double, sourceEnd: Double, volume: Double, loops: Bool) -> Bool {
        guard let index = audioClips.firstIndex(where: { $0.id == id }),
              [startTime, sourceStart, sourceEnd, volume].allSatisfy(\.isFinite), startTime >= 0,
              sourceStart >= 0, sourceEnd <= audioClips[index].sourceDuration + 0.000001,
              sourceEnd - sourceStart >= 0.001 else {
            toast = appLanguage == .arabic ? "حدد بداية ونهاية صحيحتين للمقطع" : "Choose a valid audio range"
            return false
        }
        recordAudioEdit("Edit Audio Clip") {
            audioClips[index].startTime = startTime; audioClips[index].sourceStart = sourceStart
            audioClips[index].sourceEnd = min(sourceEnd, audioClips[index].sourceDuration)
            audioClips[index].volume = max(0, min(1, volume)); audioClips[index].loops = loops
        }
        return true
    }

    @discardableResult
    func splitAudioClip(_ id: UUID, at time: Double) -> Bool {
        guard let index = audioClips.firstIndex(where: { $0.id == id }) else { return false }
        let clip = audioClips[index]
        guard !clip.loops, time.isFinite, time > clip.startTime + 0.001, time < clip.endTime - 0.001 else {
            toast = appLanguage == .arabic ? "ضع المؤشر داخل المقطع، وأوقف التكرار قبل تقسيمه" : "Place the playhead inside a non-looping clip"
            return false
        }
        recordAudioEdit("Split Audio Clip") {
            let sourceCut = clip.sourceStart + time - clip.startTime
            audioClips[index].sourceEnd = sourceCut
            var right = clip.stoppedCopy; right.id = UUID(); right.startTime = time; right.sourceStart = sourceCut
            audioClips.append(right); selectAudioClip(right.id)
        }
        return true
    }

    func removeAudioAsset(_ id: UUID) {
        guard audioAssets.contains(where: { $0.id == id }) else { return }
        recordAudioEdit("Delete Audio File") {
            let ids = Set(audioClips.filter { $0.assetID == id }.map(\.id))
            audioClips.removeAll { $0.assetID == id }; audioAssets.removeAll { $0.id == id }
            if let selected = selectedAudioClipID, ids.contains(selected) { selectedAudioClipID = nil }
        }
        if audioClipboard?.asset.id == id { audioClipboard = nil }
        // Cache bytes remain available to Undo. Deleted assets are omitted from
        // subsequent portable documents; user-owned source files are untouched.
    }

    func setMasterAudioVolume(_ value: Double) {
        guard value.isFinite, value != masterAudioVolume else { return }
        recordAudioEdit("Master Volume") { masterAudioVolume = max(0, min(1, value)) }
    }
}
