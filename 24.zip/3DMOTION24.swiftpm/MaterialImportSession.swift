import Foundation
import UIKit
import SceneKit
import ImageIO

final class MaterialImportSession: @unchecked Sendable, Identifiable {
    let id = UUID()
    let directory: URL
    let candidates: [MaterialImportCandidate]
    let source: MaterialSourceCredit
    init(directory: URL, candidates: [MaterialImportCandidate], source: MaterialSourceCredit) {
        self.directory = directory; self.candidates = candidates; self.source = source
    }
    deinit { try? FileManager.default.removeItem(at: directory) }
}

enum MaterialImportFiles {
    static let maximumFileBytes = 128 * 1024 * 1024
    static let maximumBatchBytes = 256 * 1024 * 1024
    static let imageExtensions: Set<String> = ["png", "jpg", "jpeg", "heic", "heif", "webp", "tif", "tiff", "bmp", "tga", "gif"]

    static func prepare(_ urls: [URL], source: MaterialSourceCredit = .init(label: "Device")) throws -> MaterialImportSession {
        guard !urls.isEmpty, urls.count <= 1000 else { throw MaterialImportFailure.noMaterials }
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("5LnMaterialImport-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        var accepted = false
        defer { if !accepted { try? FileManager.default.removeItem(at: root) } }
        var bytes = 0, files = 0, archives: [URL] = []
        var common = urls[0].deletingLastPathComponent().standardizedFileURL.pathComponents
        for url in urls.dropFirst() {
            while !url.deletingLastPathComponent().standardizedFileURL.pathComponents.starts(with: common), !common.isEmpty { common.removeLast() }
        }
        func copy(_ original: URL) throws {
            try Task.checkCancellation()
            let values = try original.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
            guard values.isSymbolicLink != true, values.isRegularFile == true else { throw MaterialImportFailure.invalid("نوع ملف غير مدعوم / Unsupported file type") }
            let count = values.fileSize ?? 0
            guard count >= 0, count <= maximumFileBytes else { throw MaterialImportFailure.tooLarge }
            files += 1; bytes += count
            guard files <= 1000, bytes <= maximumBatchBytes else { throw MaterialImportFailure.tooLarge }
            let relative = original.standardizedFileURL.pathComponents.dropFirst(common.count).joined(separator: "/")
            let target = root.appendingPathComponent(relative).standardizedFileURL
            guard target.path.hasPrefix(root.path + "/"), !FileManager.default.fileExists(atPath: target.path) else {
                throw MaterialImportFailure.invalid("تكرار في أسماء الملفات / Duplicate file path")
            }
            try FileManager.default.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
            try FileManager.default.copyItem(at: original, to: target)
            let actual = try target.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
            guard actual == count else { throw MaterialImportFailure.invalid("تغير الملف أثناء النسخ / Source changed during copying") }
            if target.pathExtension.lowercased() == "zip" { archives.append(target) }
        }
        for url in urls {
            let access = url.startAccessingSecurityScopedResource()
            defer { if access { url.stopAccessingSecurityScopedResource() } }
            let values = try url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard values.isSymbolicLink != true else { throw MaterialImportFailure.invalid("الرابط الرمزي غير مدعوم / Symbolic links are unsupported") }
            if values.isDirectory == true {
                guard let iterator = FileManager.default.enumerator(at: url, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey], options: [.skipsHiddenFiles]) else { throw MaterialImportFailure.noMaterials }
                for case let child as URL in iterator {
                    let attributes = try child.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
                    guard attributes.isSymbolicLink != true else { throw MaterialImportFailure.invalid("رابط رمزي داخل الحزمة / Symbolic link in package") }
                    if attributes.isDirectory != true { try copy(child) }
                }
            } else { try copy(url) }
        }
        for archive in archives {
            let destination = archive.deletingPathExtension().appendingPathExtension("unpacked")
            guard !FileManager.default.fileExists(atPath: destination.path) else { throw MaterialImportFailure.invalid("مسار استخراج مكرر / Duplicate unpack path") }
            let extracted = try SafeZIPExtractor.extract(archive, to: destination, maximumBytes: Int64(maximumBatchBytes - bytes))
            for file in extracted {
                bytes += try file.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                files += 1
                guard files <= 2000, bytes <= maximumBatchBytes else { throw MaterialImportFailure.tooLarge }
            }
        }
        try Task.checkCancellation()
        guard let iterator = FileManager.default.enumerator(at: root, includingPropertiesForKeys: [.isRegularFileKey], options: [.skipsHiddenFiles]) else { throw MaterialImportFailure.noMaterials }
        let allFiles = iterator.compactMap { $0 as? URL }.filter {
            !$0.pathComponents.contains("__MACOSX") && (try? $0.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) == true
        }.sorted { $0.path < $1.path }
        var candidates: [MaterialImportCandidate] = [], referenced = Set<String>()
        for file in allFiles where ["gltf", "glb"].contains(file.pathExtension.lowercased()) {
            let document = try jsonDocument(file)
            guard (document["asset"] as? [String: Any])?["version"] as? String == "2.0" else { throw MaterialImportFailure.invalid("glTF 2.0 required") }
            let definitions = document["materials"] as? [[String: Any]] ?? []
            guard definitions.count <= 256 else { throw MaterialImportFailure.tooLarge }
            for (index, definition) in definitions.enumerated() {
                let name = (definition["name"] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? file.deletingPathExtension().lastPathComponent + " \(index + 1)"
                candidates.append(.init(name: name, file: file, kind: .gltf(index), selected: definitions.count <= 8))
            }
            for image in document["images"] as? [[String: Any]] ?? [] {
                if let uri = image["uri"] as? String, !uri.hasPrefix("data:") {
                    referenced.insert(file.deletingLastPathComponent().appendingPathComponent(uri.removingPercentEncoding ?? uri).standardizedFileURL.path)
                }
            }
        }
        var groups: [String: Int] = [:]
        for file in allFiles where imageExtensions.contains(file.pathExtension.lowercased()) && !referenced.contains(file.standardizedFileURL.path) {
            let classified = MaterialImportNames.classify(file)
            let key = file.deletingLastPathComponent().path + "/" + classified.name.lowercased()
            let map = MaterialMapInput(url: file, role: classified.role, flipGreen: classified.flipGreen, invert: classified.invert)
            if let index = groups[key] { candidates[index].maps.append(map) }
            else {
                let name = classified.name == root.lastPathComponent ? urls[0].deletingPathExtension().lastPathComponent : classified.name
                groups[key] = candidates.count
                candidates.append(.init(name: name, file: file, kind: .images, maps: [map]))
            }
        }
        guard !candidates.isEmpty, candidates.count <= 256 else { throw MaterialImportFailure.noMaterials }
        if candidates.count > 8 { for index in candidates.indices { candidates[index].selected = false } }
        accepted = true
        return MaterialImportSession(directory: root, candidates: candidates, source: source)
    }

    private static func jsonDocument(_ file: URL) throws -> [String: Any] {
        let data = try Data(contentsOf: file, options: [.mappedIfSafe])
        guard data.count <= maximumFileBytes else { throw MaterialImportFailure.tooLarge }
        let json: Data
        if file.pathExtension.lowercased() == "glb" {
            guard data.count >= 20 else { throw MaterialImportFailure.invalid("Invalid GLB") }
            func u32(_ offset: Int) -> UInt32 {
                data.withUnsafeBytes { UInt32(littleEndian: $0.loadUnaligned(fromByteOffset: offset, as: UInt32.self)) }
            }
            let length = Int(u32(12))
            guard u32(0) == 0x46546C67, u32(4) == 2, Int(u32(8)) == data.count,
                  u32(16) == 0x4E4F534A, length <= data.count - 20 else { throw MaterialImportFailure.invalid("Invalid GLB") }
            json = data.subdata(in: 20..<(20 + length))
        } else { json = data }
        guard let object = try JSONSerialization.jsonObject(with: json) as? [String: Any] else { throw MaterialImportFailure.invalid("Invalid glTF JSON") }
        return object
    }
}

@MainActor
enum MaterialImportDecoder {
    static func decode(_ candidates: [MaterialImportCandidate], maximumDimension: Int) async throws -> [(String, SCNMaterial)] {
        let selected = candidates.filter(\.selected)
        guard !selected.isEmpty, selected.count <= 64, [1024, 2048, 4096].contains(maximumDimension) else { throw MaterialImportFailure.noMaterials }
        var result: [(String, SCNMaterial)] = []
        var imageCache: [String: UIImage] = [:], decodedBytes = 0
        var gltfFiles: [URL: [Int]] = [:], gltfMaterials: [URL: [Int: SCNMaterial]] = [:]
        for candidate in selected {
            if case .gltf(let index) = candidate.kind { gltfFiles[candidate.file, default: []].append(index) }
        }
        for (file, indices) in gltfFiles {
            try Task.checkCancellation()
            let importer = GLTFImporter(); importer.maximumTextureDimension = maximumDimension
            importer.maximumDecodedTextureBytes = 128 * 1024 * 1024 - decodedBytes
            let imported = try importer.loadMaterialSet(url: file, indices: indices)
            var unique = Set<ObjectIdentifier>()
            for material in imported.values {
                for (_, property) in ProjectSceneCodec.properties(material) {
                    if let image = property.contents as? UIImage, unique.insert(ObjectIdentifier(image)).inserted, let cg = image.cgImage {
                        decodedBytes += cg.bytesPerRow * cg.height
                    }
                }
            }
            guard decodedBytes <= 128 * 1024 * 1024 else { throw MaterialImportFailure.tooLarge }
            gltfMaterials[file] = imported
            await Task.yield()
        }
        for candidate in selected {
            try Task.checkCancellation()
            switch candidate.kind {
            case .gltf(let index):
                guard let material = gltfMaterials[candidate.file]?[index] else { throw MaterialImportFailure.damaged }
                material.name = candidate.name
                result.append((candidate.name, material))
            case .images:
                try MaterialImportNames.validate(candidate.maps)
                let material = SCNMaterial(); material.name = candidate.name; material.lightingModel = .physicallyBased
                material.roughness.contents = 0.5; material.metalness.contents = 0
                for map in candidate.maps where map.role != .ignore {
                    try Task.checkCancellation()
                    let flip = map.role == .normal && map.flipGreen, invert = map.role == .roughness && map.invert
                    let key = map.url.path + "|\(flip)|\(invert)"
                    let image: UIImage
                    if let cached = imageCache[key] { image = cached }
                    else {
                        guard let source = CGImageSourceCreateWithURL(map.url as CFURL, [kCGImageSourceShouldCache: false] as CFDictionary),
                              let cg = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                                kCGImageSourceCreateThumbnailFromImageAlways: true, kCGImageSourceCreateThumbnailWithTransform: true,
                                kCGImageSourceShouldCacheImmediately: true, kCGImageSourceThumbnailMaxPixelSize: maximumDimension
                              ] as CFDictionary) else { throw MaterialImportFailure.invalid(map.url.lastPathComponent + " • Unreadable image") }
                        decodedBytes += cg.bytesPerRow * cg.height
                        guard decodedBytes <= 128 * 1024 * 1024 else { throw MaterialImportFailure.tooLarge }
                        image = try adjusted(cg, flipGreen: flip, invert: invert)
                        imageCache[key] = image
                    }
                    for name in map.role.channels {
                        guard let property = ProjectSceneCodec.properties(material).first(where: { $0.0 == name })?.1 else { throw MaterialImportFailure.damaged }
                        property.contents = image; property.wrapS = .repeat; property.wrapT = .repeat
                        if map.role == .orm || map.role == .metallicRoughness {
                            property.textureComponents = name == "metalness" ? .blue : (name == "roughness" ? .green : .red)
                        }
                    }
                    if map.role == .opacity { material.transparencyMode = .rgbZero; material.blendMode = .alpha }
                    await Task.yield()
                }
                result.append((candidate.name, material))
            }
        }
        // Bound the total decoded image footprint across glTF files and maps.
        var seen = Set<ObjectIdentifier>(), bytes = 0
        for (_, material) in result {
            for (_, property) in ProjectSceneCodec.properties(material) {
                if let image = property.contents as? UIImage, seen.insert(ObjectIdentifier(image)).inserted, let cg = image.cgImage {
                    bytes += cg.bytesPerRow * cg.height
                }
            }
        }
        guard bytes <= 128 * 1024 * 1024 else { throw MaterialImportFailure.tooLarge }
        return result
    }

    private static func adjusted(_ image: CGImage, flipGreen: Bool, invert: Bool) throws -> UIImage {
        guard flipGreen || invert else { return UIImage(cgImage: image) }
        var rgba = [UInt8](repeating: 0, count: image.width * image.height * 4)
        let adjusted: CGImage? = rgba.withUnsafeMutableBytes { bytes in
            guard let context = CGContext(data: bytes.baseAddress, width: image.width, height: image.height, bitsPerComponent: 8,
                bytesPerRow: image.width * 4, space: CGColorSpaceCreateDeviceRGB(),
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue) else { return nil }
            context.draw(image, in: CGRect(x: 0, y: 0, width: image.width, height: image.height))
            for index in stride(from: 0, to: bytes.count, by: 4) {
                let pixel = bytes.bindMemory(to: UInt8.self)
                if flipGreen { pixel[index + 1] = pixel[index + 3] - min(pixel[index + 1], pixel[index + 3]) }
                if invert { for channel in 0..<3 { pixel[index + channel] = pixel[index + 3] - min(pixel[index + channel], pixel[index + 3]) } }
            }
            return context.makeImage()
        }
        guard let adjusted else { throw MaterialImportFailure.damaged }
        return UIImage(cgImage: adjusted)
    }
}
