import Foundation
import UIKit
import SceneKit
import CoreImage
import SpriteKit
import AVFoundation
import ImageIO

enum ProjectSceneCodec {
    static func properties(_ material: SCNMaterial) -> [(String, SCNMaterialProperty)] {
        [("diffuse", material.diffuse), ("normal", material.normal),
         ("specular", material.specular), ("emission", material.emission),
         ("transparent", material.transparent), ("reflective", material.reflective),
         ("roughness", material.roughness), ("metalness", material.metalness),
         ("ambient", material.ambient), ("multiply", material.multiply),
         ("displacement", material.displacement), ("ambientOcclusion", material.ambientOcclusion),
         ("selfIllumination", material.selfIllumination)]
    }

    static func matrix(_ m: SCNMatrix4) -> [Float] {
        [m.m11,m.m12,m.m13,m.m14,m.m21,m.m22,m.m23,m.m24,
         m.m31,m.m32,m.m33,m.m34,m.m41,m.m42,m.m43,m.m44]
    }

    static func matrix(_ a: [Float]) throws -> SCNMatrix4 {
        guard a.count == 16, a.allSatisfy(\.isFinite) else { throw ProjectFailure.invalid("matrix") }
        var m = SCNMatrix4Identity
        m.m11=a[0]; m.m12=a[1]; m.m13=a[2]; m.m14=a[3]
        m.m21=a[4]; m.m22=a[5]; m.m23=a[6]; m.m24=a[7]
        m.m31=a[8]; m.m32=a[9]; m.m33=a[10]; m.m34=a[11]
        m.m41=a[12]; m.m42=a[13]; m.m43=a[14]; m.m44=a[15]
        return m
    }

    static func nodes(in root: SCNNode) -> [SCNNode] {
        var result: [SCNNode] = []
        var stack = [root]
        while let node = stack.popLast() {
            if node.isStudioMetadata { continue }
            result.append(node)
            stack.append(contentsOf: node.childNodes.reversed())
        }
        return result
    }

    static func elementSignatures(_ geometry: SCNGeometry) -> [String] {
        geometry.elements.map {
            "\($0.primitiveType.rawValue):\($0.primitiveCount):\($0.bytesPerIndex):" + ProjectIntegrity.hash($0.data)
        }
    }

    static func texcoordSignatures(_ geometry: SCNGeometry) -> [String] {
        geometry.sources(for: .texcoord).map {
            "\($0.vectorCount):\($0.componentsPerVector):\($0.bytesPerComponent):\($0.dataOffset):\($0.dataStride):" + ProjectIntegrity.hash($0.data)
        }
    }

    private static func resource(_ data: Data, kind: String, ext: String,
                                 into resources: inout [String: ProjectResource]) -> ProjectValue {
        let id = ProjectIntegrity.hash(data)
        resources[id] = ProjectResource(kind: kind, fileExtension: ext, data: data)
        return ProjectValue(kind: kind, resourceID: id)
    }

    private static func imageData(_ image: UIImage) throws -> Data {
        var normalized = image
        if image.imageOrientation != .up {
            let format = UIGraphicsImageRendererFormat()
            format.scale = image.scale
            normalized = UIGraphicsImageRenderer(size: image.size, format: format).image { _ in
                image.draw(in: CGRect(origin: .zero, size: image.size))
            }
        }
        guard let data = normalized.pngData(), !data.isEmpty else { throw ProjectFailure.invalid("image encoding") }
        return data
    }

    static func image(at value: Any, baseURL: URL? = nil) throws -> UIImage {
        let url: URL
        if let supplied = value as? URL {
            guard supplied.isFileURL else { throw ProjectFailure.unsupported("remote texture URL") }
            url = supplied
        } else if let path = value as? String {
            if let supplied = URL(string: path), supplied.isFileURL { url = supplied }
            else if path.hasPrefix("/") { url = URL(fileURLWithPath: path) }
            else if let baseURL { url = baseURL.appendingPathComponent(path.removingPercentEncoding ?? path) }
            else if let bundled = UIImage(named: path) { return bundled }
            else { throw ProjectFailure.missing(path) }
        } else { throw ProjectFailure.unsupported(String(describing: type(of: value))) }
        guard let image = UIImage(contentsOfFile: url.path) else { throw ProjectFailure.missing(url.lastPathComponent) }
        return image
    }

    static func encodeValue(_ value: Any?, resources: inout [String: ProjectResource], baseURL: URL? = nil) throws -> ProjectValue {
        guard let value else { return ProjectValue(kind: "empty") }
        if let color = value as? UIColor {
            var r: CGFloat=0, g: CGFloat=0, b: CGFloat=0, a: CGFloat=0
            guard color.getRed(&r, green: &g, blue: &b, alpha: &a) else { throw ProjectFailure.unsupported("pattern color") }
            return ProjectValue(kind: "color", rgba: [Double(r),Double(g),Double(b),Double(a)])
        }
        if let number = value as? NSNumber {
            guard number.doubleValue.isFinite else { throw ProjectFailure.invalid("material number") }
            return ProjectValue(kind: "number", number: number.doubleValue)
        }
        if let image = value as? UIImage {
            return resource(try imageData(image), kind: "image", ext: "png", into: &resources)
        }
        if let data = value as? Data, let image = UIImage(data: data) {
            return resource(try imageData(image), kind: "image", ext: "png", into: &resources)
        }
        if let image = value as? CIImage {
            guard !image.extent.isInfinite, !image.extent.isEmpty,
                  let cg = CIContext().createCGImage(image, from: image.extent) else { throw ProjectFailure.invalid("CIImage") }
            return resource(try imageData(UIImage(cgImage: cg)), kind: "image", ext: "png", into: &resources)
        }
        if let texture = value as? SKTexture {
            return resource(try imageData(UIImage(cgImage: texture.cgImage())), kind: "image", ext: "png", into: &resources)
        }
        if let faces = value as? [Any] {
            guard faces.count == 6 else { throw ProjectFailure.invalid("cube faces") }
            var encoded: [ProjectValue] = []
            for face in faces { encoded.append(try encodeValue(face, resources: &resources, baseURL: baseURL)) }
            return ProjectValue(kind: "cube", faces: encoded)
        }
        if value is URL || value is String {
            return resource(try imageData(image(at: value, baseURL: baseURL)), kind: "image", ext: "png", into: &resources)
        }
        if let player = value as? AVPlayer {
            guard let asset = player.currentItem?.asset as? AVURLAsset, asset.url.isFileURL else {
                throw ProjectFailure.unsupported("non-local video material")
            }
            let data = try Data(contentsOf: asset.url)
            guard !data.isEmpty else { throw ProjectFailure.missing("video") }
            return resource(data, kind: "video", ext: asset.url.pathExtension.isEmpty ? "mov" : asset.url.pathExtension, into: &resources)
        }
        if let sprite = value as? SKScene {
            let data = try NSKeyedArchiver.archivedData(withRootObject: sprite, requiringSecureCoding: true)
            return resource(data, kind: "archive", ext: "sks", into: &resources)
        }
        // CoreFoundation image/color types are checked by type ID before casting.
        if CFGetTypeID(value as CFTypeRef) == CGImage.typeID {
            return resource(try imageData(UIImage(cgImage: value as! CGImage)), kind: "image", ext: "png", into: &resources)
        }
        if CFGetTypeID(value as CFTypeRef) == CGColor.typeID {
            return try encodeValue(UIColor(cgColor: value as! CGColor), resources: &resources, baseURL: baseURL)
        }
        throw ProjectFailure.unsupported(String(describing: type(of: value)))
    }

    final class Decoder {
        let resources: [String: ProjectResource]
        let folder: URL
        private var cache: [String: Any] = [:]
        init(resources: [String: ProjectResource], folder: URL) { self.resources = resources; self.folder = folder }

        func value(_ record: ProjectValue) throws -> Any? {
            try record.validate(resources: resources)
            switch record.kind {
            case "empty": return nil
            case "color":
                let a = record.rgba!
                return UIColor(red: CGFloat(a[0]), green: CGFloat(a[1]), blue: CGFloat(a[2]), alpha: CGFloat(a[3]))
            case "number": return NSNumber(value: record.number!)
            case "cube": return try record.faces!.map { try value($0)! }
            default:
                let id = record.resourceID!
                if let cached = cache[id] { return cached }
                let resource = resources[id]!
                let restored: Any
                if record.kind == "image" {
                    guard let image = UIImage(data: resource.data), image.cgImage != nil else {
                        throw ProjectFailure.invalid("undecodable image")
                    }
                    restored = image
                } else if record.kind == "video" {
                    let file = folder.appendingPathComponent(id).appendingPathExtension(resource.fileExtension)
                    try resource.data.write(to: file, options: .atomic)
                    restored = AVPlayer(url: file)
                } else {
                    guard let sprite = try NSKeyedUnarchiver.unarchivedObject(ofClass: SKScene.self, from: resource.data) else {
                        throw ProjectFailure.invalid("SpriteKit scene")
                    }
                    restored = sprite
                }
                cache[id] = restored
                return restored
            }
        }

        func material(_ record: ProjectMaterialRecord) throws -> SCNMaterial {
            guard let material = try NSKeyedUnarchiver.unarchivedObject(ofClass: SCNMaterial.self, from: record.archive) else {
                throw ProjectFailure.invalid("material archive")
            }
            let properties = ProjectSceneCodec.properties(material)
            guard Set(record.properties.keys) == Set(properties.map(\.0)) else { throw ProjectFailure.invalid("material channels") }
            for (name, property) in properties {
                let saved = record.properties[name]!
                guard let wrapS = SCNWrapMode(rawValue: saved.wrapS), let wrapT = SCNWrapMode(rawValue: saved.wrapT),
                      let min = SCNFilterMode(rawValue: saved.minification), let mag = SCNFilterMode(rawValue: saved.magnification),
                      let mip = SCNFilterMode(rawValue: saved.mip) else { throw ProjectFailure.invalid("sampling enum") }
                property.contents = try value(saved.value)
                property.intensity = CGFloat(saved.intensity)
                property.contentsTransform = try ProjectSceneCodec.matrix(saved.transform)
                property.mappingChannel = saved.mappingChannel
                property.wrapS = wrapS; property.wrapT = wrapT
                property.minificationFilter = min; property.magnificationFilter = mag; property.mipFilter = mip
                property.textureComponents = SCNColorMask(rawValue: saved.components)
                property.maxAnisotropy = CGFloat(saved.maxAnisotropy)
            }
            return material
        }
    }

    static func captureMaterial(_ material: SCNMaterial, resources: inout [String: ProjectResource]) throws -> ProjectMaterialRecord {
        var records: [String: ProjectPropertyRecord] = [:]
        for (name, property) in properties(material) {
            let value = try encodeValue(property.contents, resources: &resources)
            records[name] = ProjectPropertyRecord(value: value, intensity: Double(property.intensity),
                transform: matrix(property.contentsTransform), mappingChannel: property.mappingChannel,
                wrapS: property.wrapS.rawValue, wrapT: property.wrapT.rawValue,
                minification: property.minificationFilter.rawValue, magnification: property.magnificationFilter.rawValue,
                mip: property.mipFilter.rawValue, components: property.textureComponents.rawValue,
                maxAnisotropy: Double(property.maxAnisotropy))
        }
        let originals = properties(material).map { ($0.1, $0.1.contents) }
        for (property, _) in originals { property.contents = nil }
        defer { for (property, value) in originals { property.contents = value } }
        // Preserve ALL SceneKit material settings, shader modifiers, etc. Map
        // values are restored explicitly so archiver image omissions cannot win.
        let archive = try NSKeyedArchiver.archivedData(withRootObject: material, requiringSecureCoding: true)
        return ProjectMaterialRecord(archive: archive, properties: records)
    }

    static func encodeKeyframe(_ key: StudioKeyframe, resources: inout [String: ProjectResource]) throws -> SavedKeyframe {
        var saved = SavedKeyframe(key)
        if let states = key.materialStates {
            var results: [SavedMaterialKeyframeState] = []
            for state in states {
                var result = SavedMaterialKeyframeState(state)
                result.values = [:]
                for (name, value) in [("diffuse", state.diffuse), ("metalness", state.metalness),
                                      ("roughness", state.roughness), ("emission", state.emission)] {
                    // Legacy v1 omitted textures. Missing values must leave the
                    // restored geometry's map intact, rather than clear it.
                    if state.preservesMissingContents && value == nil { continue }
                    result.values?[name] = try encodeValue(value, resources: &resources)
                }
                results.append(result)
            }
            saved.materialStates = results
        }
        return saved
    }

    static func decodeKeyframe(_ saved: SavedKeyframe, decoder: Decoder) throws -> StudioKeyframe {
        var key = saved.studioKeyframe
        if let states = saved.materialStates {
            key.materialStates = try states.map { savedState in
                var state = savedState.materialState
                if let values = savedState.values {
                    state.preservesMissingContents = values.count != 4
                    if let v = values["diffuse"] { state.diffuse = try decoder.value(v) }
                    if let v = values["metalness"] { state.metalness = try decoder.value(v) }
                    if let v = values["roughness"] { state.roughness = try decoder.value(v) }
                    if let v = values["emission"] { state.emission = try decoder.value(v) }
                }
                return state
            }
        }
        return key
    }

    static func makePackage(scene: SCNScene, name: String, metadata: StudioAutosaveMetadata,
                            keyframes: [StudioKeyframe], environment: Data?, audio: [String: Data]) throws -> StudioPortablePackage {
        let allNodes = nodes(in: scene.rootNode)
        var nodeIDs = Set<String>()
        for node in allNodes {
            if node.studioAnimationID == nil { node.studioAnimationID = UUID().uuidString }
            guard nodeIDs.insert(node.studioAnimationID!).inserted else { throw ProjectFailure.invalid("duplicate node identity") }
        }
        var resources: [String: ProjectResource] = [:]
        var records: [String: ProjectMaterialRecord] = [:]
        var materialIDs: [ObjectIdentifier: String] = [:]
        var bindings: [ProjectGeometryBinding] = []
        var particles: [ProjectParticleBinding] = []
        var animations: [ProjectAnimationBinding] = []
        let hierarchy = allNodes.map { node in
            ProjectNodeRecord(id: node.studioAnimationID!, parentID: node.parent?.studioAnimationID, name: node.name,
                transform: matrix(node.transform), pivot: matrix(node.pivot), opacity: Double(node.opacity), isHidden: node.isHidden)
        }
        var cleared: [(SCNMaterialProperty, Any?)] = []
        var particleImages: [(SCNParticleSystem, Any?)] = []
        for node in allNodes {
            for key in node.animationKeys {
                guard let player = node.animationPlayer(forKey: key) else { throw ProjectFailure.invalid("animation player") }
                let archive = try NSKeyedArchiver.archivedData(withRootObject: player, requiringSecureCoding: true)
                animations.append(ProjectAnimationBinding(nodeID: node.studioAnimationID!, key: key, archive: archive))
            }
            if let geometry = node.geometry {
                var ids: [String] = []
                for material in geometry.materials {
                    let identity = ObjectIdentifier(material)
                    if let id = materialIDs[identity] { ids.append(id); continue }
                    let id = UUID().uuidString
                    records[id] = try captureMaterial(material, resources: &resources)
                    materialIDs[identity] = id
                    ids.append(id)
                    for (_, property) in properties(material) { cleared.append((property, property.contents)) }
                }
                bindings.append(ProjectGeometryBinding(nodeID: node.studioAnimationID!, materialIDs: ids,
                    elementSignatures: elementSignatures(geometry), texcoordSignatures: texcoordSignatures(geometry)))
            }
            for (index, system) in (node.particleSystems ?? []).enumerated() {
                particles.append(ProjectParticleBinding(nodeID: node.studioAnimationID!, index: index,
                    value: try encodeValue(system.particleImage, resources: &resources)))
                particleImages.append((system, system.particleImage))
            }
        }
        var metadata = metadata
        metadata.keyframes = try keyframes.map { try encodeKeyframe($0, resources: &resources) }
        let meta = try JSONEncoder().encode(metadata)
        // Contents are owned by the resource table. No path or UIKit image is
        // entrusted to .scn's image serialization. Restore live values on all exits.
        for (property, _) in cleared { property.contents = nil }
        for (particle, _) in particleImages { particle.particleImage = nil }
        let background = scene.background.contents
        let lighting = scene.lightingEnvironment.contents
        scene.background.contents = nil; scene.lightingEnvironment.contents = nil
        defer {
            for (property, contents) in cleared { property.contents = contents }
            for (particle, contents) in particleImages { particle.particleImage = contents }
            scene.background.contents = background; scene.lightingEnvironment.contents = lighting
        }
        // A keyed SceneKit archive preserves the exact node/geometry graph,
        // including skinners, morphers, UV source order and persistent identities.
        // Images are deliberately carried by our independent resource table.
        let data = try NSKeyedArchiver.archivedData(withRootObject: scene, requiringSecureCoding: true)
        var package = StudioPortablePackage(version: 2, name: name, scene: data, metadata: meta,
            environment: environment, audio: audio, textures: nil,
            resources: resources, materials: records, bindings: bindings, particles: particles,
            animations: animations, hierarchy: hierarchy)
        package.sceneEncoding = "scenekit-keyed-archive"
        package.seal()
        try package.validate()
        return package
    }

    static func bind(_ package: StudioPortablePackage, to scene: SCNScene, decoder: Decoder) throws {
        var byID: [String: SCNNode] = [:]
        for node in nodes(in: scene.rootNode) {
            guard let id = node.studioAnimationID else { continue }
            guard byID[id] == nil else { throw ProjectFailure.invalid("duplicate node identity") }
            byID[id] = node
        }
        var materials: [String: SCNMaterial] = [:]
        if let hierarchy = package.hierarchy {
            guard Set(hierarchy.map(\.id)) == Set(byID.keys) else { throw ProjectFailure.invalid("incomplete hierarchy") }
            for record in hierarchy {
                guard let node = byID[record.id], node.parent?.studioAnimationID == record.parentID,
                      node.name == record.name else { throw ProjectFailure.invalid("hierarchy association") }
                // Explicit local transforms avoid an exporter baking animation
                // presentation values or normalizing an authored group's pivot.
                node.transform = try matrix(record.transform); node.pivot = try matrix(record.pivot)
                node.opacity = CGFloat(record.opacity); node.isHidden = record.isHidden
            }
        }
        for (id, record) in package.materials ?? [:] { materials[id] = try decoder.material(record) }
        var bound = Set<String>()
        for binding in package.bindings ?? [] {
            guard let node = byID[binding.nodeID], let geometry = node.geometry,
                  elementSignatures(geometry) == binding.elementSignatures,
                  texcoordSignatures(geometry) == binding.texcoordSignatures else {
                throw ProjectFailure.invalid("geometry/UV binding " + binding.nodeID)
            }
            geometry.materials = try binding.materialIDs.map {
                guard let material = materials[$0] else { throw ProjectFailure.invalid("material slot") }
                return material
            }
            bound.insert(binding.nodeID)
        }
        let actual = Set(nodes(in: scene.rootNode).filter { $0.geometry != nil }.compactMap(\.studioAnimationID))
        guard actual == bound,
              nodes(in: scene.rootNode).filter({ $0.geometry != nil }).count == bound.count else {
            throw ProjectFailure.invalid("unbound geometry")
        }
        var particleSlots = Set<String>()
        for binding in package.particles ?? [] {
            guard let node = byID[binding.nodeID], let systems = node.particleSystems,
                  systems.indices.contains(binding.index),
                  particleSlots.insert(binding.nodeID + ":" + String(binding.index)).inserted else {
                throw ProjectFailure.invalid("particle binding")
            }
            systems[binding.index].particleImage = try decoder.value(binding.value)
        }
        guard particleSlots.count == nodes(in: scene.rootNode).reduce(0, { $0 + ($1.particleSystems?.count ?? 0) }) else {
            throw ProjectFailure.invalid("unbound particle image")
        }
        for binding in package.animations ?? [] {
            guard let node = byID[binding.nodeID],
                  let player = try NSKeyedUnarchiver.unarchivedObject(ofClass: SCNAnimationPlayer.self, from: binding.archive) else {
                throw ProjectFailure.invalid("animation player archive")
            }
            node.addAnimationPlayer(player, forKey: binding.key)
        }
    }

    static func restoreLegacyTextures(_ data: Data, root: SCNNode) throws {
        let saved = try JSONDecoder().decode([String: Data].self, from: data)
        var restored = Set<String>()
        func walk(_ node: SCNNode, _ path: String) throws {
            if let geometry = node.geometry {
                for (slot, material) in geometry.materials.enumerated() {
                    for (channel, entry) in properties(material).prefix(12).enumerated() {
                        let key = "\(path):\(slot):\(channel)"
                        if let data = saved[key] {
                            guard let image = UIImage(data: data) else { throw ProjectFailure.invalid("legacy image") }
                            entry.1.contents = image
                            restored.insert(key)
                        }
                    }
                }
            }
            for (i, child) in node.childNodes.enumerated() { try walk(child, "\(path).\(i)") }
        }
        // Build 23 indexed the exact hierarchy while the selection outline was
        // detached. Apply BEFORE removing any legacy helper/identity children.
        try walk(root, "root")
        guard restored == Set(saved.keys) else { throw ProjectFailure.invalid("legacy material binding") }
    }

    // Resolve paths while their import session/provider context still exists.
    // Failed resolutions remain explicit and block a later successful save.
    static func embedImportedResources(_ root: SCNNode, baseURL: URL) -> [String] {
        var warnings: [String] = []
        var cached: [String: UIImage] = [:]
        for node in nodes(in: root) {
            for material in node.geometry?.materials ?? [] {
                for (_, property) in properties(material) {
                    guard let contents = property.contents, contents is URL || contents is String else { continue }
                    let key = String(describing: contents)
                    do {
                        if let image = cached[key] { property.contents = image }
                        else {
                            let image = try image(at: contents, baseURL: baseURL)
                            cached[key] = image; property.contents = image
                        }
                    } catch { warnings.append(error.localizedDescription) }
                }
            }
        }
        return Array(Set(warnings)).sorted()
    }
}
