import Foundation
import SceneKit

@MainActor
extension StudioStore {
    func deleteSelectedKeyframe() {
        guard let id = selectedKeyframeID, keyframes.contains(where: { $0.id == id }) else { return }
        pushUndoSnapshot("Delete Keyframe")
        keyframes.removeAll { $0.id == id }; selectedKeyframeID = nil
    }

    func copySelectedKeyframe() {
        guard let id = selectedKeyframeID, let key = keyframes.first(where: { $0.id == id }) else { return }
        keyframeClipboard = key
        toast = appLanguage == .arabic ? "تم نسخ نقطة الحركة" : "Keyframe copied"
    }

    func cutSelectedKeyframe() {
        guard let id = selectedKeyframeID else { return }
        copySelectedKeyframe()
        pushUndoSnapshot("Cut Keyframe")
        keyframes.removeAll { $0.id == id }; selectedKeyframeID = nil
    }

    func pasteKeyframe() {
        guard let source = keyframeClipboard, let node = selectedNode else { return }
        let track = activeMotionTrackID(for: node)
        pushUndoSnapshot("Paste Keyframe")
        let copy = StudioKeyframe(nodeID: animationIdentity(node), nodeName: node.name ?? source.nodeName,
            time: currentTime, position: source.position, euler: source.euler, scale: source.scale,
            cameraFOV: source.cameraFOV, cameraExposure: source.cameraExposure, cameraBloom: source.cameraBloom,
            lightIntensity: source.lightIntensity, lightColor: source.lightColor, trackID: track,
            interpolation: source.interpolation, materialStates: source.materialStates)
        keyframes.removeAll { $0.nodeID == copy.nodeID && $0.trackID == track && abs($0.time - currentTime) < 0.0005 }
        keyframes.append(copy); keyframes.sort { $0.time < $1.time }
        selectedAudioClipID = nil; selectedKeyframeID = copy.id; selectedMotionTrackID = track
        applyTimeline(at: currentTime)
    }

    func cutMotionTrack(_ id: String, for node: SCNNode) {
        let nodeID = animationIdentity(node)
        guard keyframes.contains(where: { ($0.nodeID == nodeID || ($0.nodeID == nil && $0.nodeName == node.name)) && $0.trackID == id }) else { return }
        copyMotionTrack(id, for: node)
        deleteMotionTrack(id, for: node)
    }
}
