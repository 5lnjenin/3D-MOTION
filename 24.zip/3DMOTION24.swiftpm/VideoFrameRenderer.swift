import Foundation
import SceneKit
import CoreVideo
import Metal
import CoreImage

@MainActor
final class VideoFrameRenderer {
    let renderer: SCNRenderer
    let queue: MTLCommandQueue
    let depth: MTLTexture
    let size: CGSize
    var cache: CVMetalTextureCache

    init(scene: SCNScene, camera: SCNNode?, size: CGSize) throws {
        guard let device = MTLCreateSystemDefaultDevice(), let queue = device.makeCommandQueue() else {
            throw StudioVideoFailure.problem("تعذر تجهيز الرسم / Rendering unavailable")
        }
        self.queue = queue; self.size = size
        renderer = SCNRenderer(device: device, options: nil)
        renderer.scene = scene; renderer.pointOfView = camera
        renderer.autoenablesDefaultLighting = false; renderer.isPlaying = false
        let descriptor = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .depth32Float_stencil8,
            width: Int(size.width), height: Int(size.height), mipmapped: false)
        descriptor.usage = .renderTarget; descriptor.storageMode = .private
        guard let depth = device.makeTexture(descriptor: descriptor) else {
            throw StudioVideoFailure.problem("تعذر تجهيز عمق الصورة / Depth buffer unavailable")
        }
        self.depth = depth
        var textureCache: CVMetalTextureCache?
        guard CVMetalTextureCacheCreate(nil, nil, device, nil, &textureCache) == kCVReturnSuccess,
              let textureCache else { throw StudioVideoFailure.problem("تعذر تجهيز الصورة / Frame buffer unavailable") }
        cache = textureCache
    }

    func render(at time: Double, into buffer: CVPixelBuffer) async throws {
        var wrapped: CVMetalTexture?
        guard CVMetalTextureCacheCreateTextureFromImage(nil, cache, buffer, nil, .bgra8Unorm,
            Int(size.width), Int(size.height), 0, &wrapped) == kCVReturnSuccess,
            let wrapped, let texture = CVMetalTextureGetTexture(wrapped),
            let command = queue.makeCommandBuffer() else {
            throw StudioVideoFailure.problem("تعذر رسم الإطار / Frame rendering failed")
        }
        let pass = MTLRenderPassDescriptor()
        pass.colorAttachments[0].texture = texture
        pass.colorAttachments[0].loadAction = .clear; pass.colorAttachments[0].storeAction = .store
        pass.colorAttachments[0].clearColor = MTLClearColorMake(0, 0, 0, 1)
        pass.depthAttachment.texture = depth; pass.depthAttachment.loadAction = .clear
        pass.depthAttachment.clearDepth = 1; pass.depthAttachment.storeAction = .dontCare
        pass.stencilAttachment.texture = depth; pass.stencilAttachment.loadAction = .clear
        pass.stencilAttachment.storeAction = .dontCare
        renderer.render(atTime: time, viewport: CGRect(origin: .zero, size: size), commandBuffer: command, passDescriptor: pass)
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            command.addCompletedHandler { _ in continuation.resume() }
            command.commit()
        }
        // Keep the IOSurface texture alive until the command completed.
        withExtendedLifetime(wrapped) {}
        guard command.status == .completed else {
            throw command.error ?? StudioVideoFailure.problem("فشل رسم الإطار / Frame rendering failed")
        }
        try Task.checkCancellation()
        CVMetalTextureCacheFlush(cache, 0)
    }
}
