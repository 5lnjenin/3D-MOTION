import Foundation
import SwiftUI
import UniformTypeIdentifiers

extension UTType {
    static let studioProject = UTType(exportedAs: "app.5ln.studio.project", conformingTo: .data)
}

struct StudioPortableDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.studioProject, .json] }
    static var writableContentTypes: [UTType] { [.studioProject] }
    var data: Data
    init(data: Data) { self.data = data }
    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents else {
            throw CocoaError(.fileReadCorruptFile)
        }
        self.data = data
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}
