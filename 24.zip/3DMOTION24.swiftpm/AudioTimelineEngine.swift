import Foundation
import SwiftUI
import UIKit
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

@MainActor
extension StudioStore {
// MARK: - Audio Engine

    func importAudioFiles(_ urls: [URL]) {
        guard !urls.isEmpty, !audioImportRunning else { return }
        let folder = audioFolderURL
        let start = currentTime
        let generation = audioImportGeneration
        audioImportRunning = true
        toast = appLanguage == .arabic ? "جارٍ استيراد الصوت…" : "Importing audio…"
        Task { @MainActor in
            defer { audioImportRunning = false }
            do {
                let resources = try await Task.detached(priority: .userInitiated) {
                    let staged = try ImportFileStager.stage(urls)
                    var copied: [(URL, Double)] = []
                    do {
                        for file in staged {
                            let duration = try AudioPreviewCache.duration(of: file)
                            let target = folder.appendingPathComponent(UUID().uuidString + "-" + file.lastPathComponent)
                            try FileManager.default.moveItem(at: file, to: target)
                            copied.append((target, duration))
                        }
                        return copied
                    } catch {
                        for (target, _) in copied { try? FileManager.default.removeItem(at: target) }
                        throw error
                    }
                }.value
                guard generation == audioImportGeneration else {
                    for (url, _) in resources { try? FileManager.default.removeItem(at: url) }
                    return
                }
                recordAudioEdit("Import Audio") {
                    for (index, resource) in resources.enumerated() {
                        let name = urls.indices.contains(index) ? urls[index].deletingPathExtension().lastPathComponent : resource.0.lastPathComponent
                        let asset = StudioAudioAsset(name: name, url: resource.0, duration: resource.1)
                        var clip = StudioAudioClip(name: name, url: asset.url, startTime: start)
                        clip.assetID = asset.id; clip.sourceDuration = asset.duration
                        audioAssets.append(asset); audioClips.append(clip)
                        duration = max(duration, clip.endTime); selectAudioClip(clip.id)
                    }
                }
                toast = appLanguage == .arabic ? "تم استيراد \(resources.count) ملف صوت" : "Imported \(resources.count) audio files"
            } catch {
                toast = (appLanguage == .arabic ? "تعذر استيراد الصوت: " : "Audio import failed: ") + error.localizedDescription
            }
        }
    }

    func playAudioTimeline() {
        stopAudioTimeline()
        let clips = audioClips.map(\.stoppedCopy)
        let folder = autosaveFolderURL.appendingPathComponent("AudioPreview", isDirectory: true)
        audioPreparationTask = Task { @MainActor [weak self] in
            guard let self else { return }
            for clip in clips {
                if Task.isCancelled { return }
                do {
                    let preparation = Task.detached(priority: .userInitiated) {
                        try AudioPreviewCache.render(clip, folder: folder)
                    }
                    let rendered = try await withTaskCancellationHandler(operation: { try await preparation.value }, onCancel: { preparation.cancel() })
                    try Task.checkCancellation()
                    guard let index = self.audioClips.firstIndex(where: { $0.id == clip.id }) else { continue }
                    let player = try AVAudioPlayer(contentsOf: rendered)
                    player.volume = Float(max(0, min(1, clip.volume * self.masterAudioVolume)))
                    player.numberOfLoops = clip.loops ? -1 : 0
                    player.prepareToPlay()
                    let relative = self.currentTime - clip.startTime
                    guard player.duration > 0, relative < 0 || clip.loops || relative < player.duration else { continue }
                    if relative >= 0 {
                        player.currentTime = clip.loops ? relative.truncatingRemainder(dividingBy: player.duration) : relative
                        player.play()
                    } else {
                        player.play(atTime: player.deviceCurrentTime - relative)
                    }
                    self.audioClips[index].player = player
                    self.audioPlaybackActive = true
                } catch is CancellationError { return }
                catch {
                    self.toast = (self.appLanguage == .arabic ? "تعذر تشغيل المقطع: " : "Audio playback failed: ") + clip.name
                }
            }
        }
    }

    func stopAudioTimeline() {
        audioPreparationTask?.cancel(); audioPreparationTask = nil
        for index in audioClips.indices {
            audioClips[index].player?.stop(); audioClips[index].player = nil
        }
        audioPlaybackActive = false
    }

    func removeAudioClip(_ id: UUID) {
        guard audioClips.contains(where: { $0.id == id }) else { return }
        recordAudioEdit("Delete Audio Clip") {
            audioClips.removeAll { $0.id == id }
            if selectedAudioClipID == id { selectedAudioClipID = nil }
        }
    }

    func updateAudioClip(id: UUID, startTime: Double? = nil, volume: Double? = nil, loops: Bool? = nil) {
        guard let clip = audioClips.first(where: { $0.id == id }) else { return }
        _ = editAudioClip(id, startTime: max(0, startTime ?? clip.startTime), sourceStart: clip.sourceStart,
                          sourceEnd: clip.trimmedEnd, volume: volume ?? clip.volume, loops: loops ?? clip.loops)
    }

    // MARK: Keyframes / Timeline

    func animationIdentity(_ node: SCNNode) -> String {
        if let id = node.studioAnimationID { return id }
        let id = UUID().uuidString
        node.studioAnimationID = id
        return id
    }

    func renewAnimationIdentity(_ root: SCNNode) {
        var nodes = [root]
        root.enumerateChildNodes { node, _ in
            if !node.isStudioMetadata { nodes.append(node) }
        }
        for node in nodes { node.studioAnimationID = nil }
    }

    func activeMotionTrackID(for node: SCNNode) -> String {
        let nodeID = animationIdentity(node)
        if let existing = activeMotionTrackByNode[nodeID] { return existing }
        if let existing = keyframes.first(where: { $0.nodeID == nodeID })?.trackID {
            activeMotionTrackByNode[nodeID] = existing
            return existing
        }
        let id = UUID().uuidString
        activeMotionTrackByNode[nodeID] = id
        motionTrackNames[id] = "Animation 1"
        return id
    }

    @discardableResult
    func addMotionTrack(for node: SCNNode? = nil) -> String? {
        guard let node = node ?? selectedNode else { return nil }
        pushUndoSnapshot("Add Animation Track")
        let nodeID = animationIdentity(node)
        let existing = Set(keyframes.filter { $0.nodeID == nodeID }.compactMap(\.trackID))
        let id = UUID().uuidString
        activeMotionTrackByNode[nodeID] = id
        motionTrackNames[id] = "Animation \(existing.count + 1)"
        objectWillChange.send()
        return id
    }

    func selectMotionTrack(_ id: String, for node: SCNNode) {
        activeMotionTrackByNode[animationIdentity(node)] = id
        selectedMotionTrackID = id
        selectedAudioClipID = nil; selectedKeyframeID = nil
        objectWillChange.send()
    }

    func renameMotionTrack(_ id: String, to newName: String) {
        let clean = newName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        guard motionTrackNames[id] != clean else { return }
        pushUndoSnapshot("Rename Animation Track")
        motionTrackNames[id] = clean
        objectWillChange.send()
    }

    func deleteMotionTrack(_ id: String, for node: SCNNode) {
        pushUndoSnapshot("Delete Animation Track")
        let nodeID = animationIdentity(node)
        keyframes.removeAll { key in
            let sameNode = key.nodeID == nodeID || (key.nodeID == nil && key.nodeName == node.name)
            return sameNode && key.trackID == id
        }
        motionTrackNames[id] = nil
        loopingMotionTrackIDs.remove(id)
        if activeMotionTrackByNode[nodeID] == id { activeMotionTrackByNode[nodeID] = nil }
        if selectedMotionTrackID == id { selectedMotionTrackID = nil }
        selectedKeyframeID = nil
        objectWillChange.send()
    }

    func motionTrackIDs(for node: SCNNode) -> [String] {
        let nodeID = animationIdentity(node)
        var ids = Array(Set(keyframes.filter { $0.nodeID == nodeID }.compactMap(\.trackID)))
        if let active = activeMotionTrackByNode[nodeID], !ids.contains(active) { ids.append(active) }
        if ids.isEmpty { ids = [activeMotionTrackID(for: node)] }
        return ids.sorted { (motionTrackNames[$0] ?? $0) < (motionTrackNames[$1] ?? $1) }
    }

    var hasKeyframeAtCurrentTime: Bool {
        guard let node = selectedNode else { return false }
        let id = animationIdentity(node)
        let track = activeMotionTrackID(for: node)
        return keyframes.contains {
            ($0.nodeID == id || ($0.nodeID == nil && $0.nodeName == node.name)) &&
            ($0.trackID == track || ($0.trackID == nil && motionTrackIDs(for: node).count == 1)) &&
            abs($0.time - currentTime) < 0.08
        }
    }

    func toggleCurrentKeyframe() {
        if hasKeyframeAtCurrentTime {
            removeCurrentKeyframe()
        } else {
            addKeyframe()
        }
    }

    func addKeyframe() {
        guard let n = selectedNode else {
            toast = "حدد عنصر أولًا / Select an object first"
            return
        }

        pushUndoSnapshot("Add Keyframe")
        if currentTime >= duration - 0.10 { duration += 30 }
        let track = activeMotionTrackID(for: n)

        let key = StudioKeyframe(
            nodeID: animationIdentity(n),
            nodeName: n.name ?? "Object",
            time: currentTime,
            position: n.position,
            euler: n.eulerAngles,
            scale: n.scale,
            cameraFOV: n.camera.map { Double($0.fieldOfView) },
            cameraExposure: n.camera.map { Double($0.exposureOffset) },
            cameraBloom: n.camera.map { Double($0.bloomIntensity) },
            lightIntensity: n.light.map { Double($0.intensity) },
            lightColor: n.light?.color as? UIColor,
            trackID: track,
            interpolation: keyframeInterpolation,
            materialStates: n.geometry.map { $0.materials.map(MaterialKeyframeState.init) }
        )
        keyframes.removeAll { $0.nodeID == key.nodeID && $0.trackID == track && abs($0.time-key.time) < 0.001 }
        keyframes.append(key)
        keyframes.sort { $0.time < $1.time }
        selectedKeyframeID = key.id
        toast = n.camera != nil
            ? "تم حفظ لقطة الكاميرا عند \(String(format: "%.2f", currentTime))s"
            : "تمت إضافة Keyframe عند \(String(format: "%.2f", currentTime))s"
    }

    func duplicateMotionTrack(_ id: String, for node: SCNNode) {
        pushUndoSnapshot("Duplicate Animation Track")
        let nodeID = animationIdentity(node)
        let source = keyframes.filter { ($0.nodeID == nodeID || ($0.nodeID == nil && $0.nodeName == node.name)) && $0.trackID == id }
        guard !source.isEmpty else { return }
        let newID = UUID().uuidString
        motionTrackNames[newID] = (motionTrackNames[id] ?? "Animation") + " Copy"
        for key in source { keyframes.append(clonedKeyframe(key, node: node, trackID: newID)) }
        activeMotionTrackByNode[nodeID] = newID
        selectedMotionTrackID = newID
        keyframes.sort { $0.time < $1.time }
    }


    private func clonedKeyframe(_ source: StudioKeyframe, node: SCNNode, trackID: String, time: Double? = nil) -> StudioKeyframe {
        StudioKeyframe(
            nodeID: animationIdentity(node),
            nodeName: node.name ?? source.nodeName,
            time: time ?? source.time,
            position: source.position,
            euler: source.euler,
            scale: source.scale,
            cameraFOV: source.cameraFOV,
            cameraExposure: source.cameraExposure,
            cameraBloom: source.cameraBloom,
            lightIntensity: source.lightIntensity,
            lightColor: source.lightColor,
            trackID: trackID,
            interpolation: source.interpolation,
            materialStates: source.materialStates
        )
    }

    func copyMotionTrack(_ id: String, for node: SCNNode) {
        let nodeID = animationIdentity(node)
        let source = keyframes
            .filter { ($0.nodeID == nodeID || ($0.nodeID == nil && $0.nodeName == node.name)) && $0.trackID == id }
            .sorted { $0.time < $1.time }
        guard !source.isEmpty else {
            toast = appLanguage == .arabic ? "لا توجد حركة لنسخها" : "No animation to copy"
            return
        }
        animationClipboardFrames = source
        animationClipboardName = motionTrackNames[id] ?? "Animation"
        toast = appLanguage == .arabic ? "تم نسخ الحركة كاملة" : "Animation copied"
    }

    func pasteMotionTrack(to node: SCNNode) {
        guard !animationClipboardFrames.isEmpty else {
            toast = appLanguage == .arabic ? "انسخ حركة أولًا" : "Copy an animation first"
            return
        }
        pushUndoSnapshot("Paste Animation")
        let nodeID = animationIdentity(node)
        let newID = UUID().uuidString
        let existingCount = motionTrackIDs(for: node).count
        motionTrackNames[newID] = animationClipboardName + (existingCount > 0 ? " Copy" : "")
        let pasted = animationClipboardFrames.map { clonedKeyframe($0, node: node, trackID: newID) }
        keyframes.append(contentsOf: pasted)
        keyframes.sort { $0.time < $1.time }
        activeMotionTrackByNode[nodeID] = newID
        selectedMotionTrackID = newID
        selectedKeyframeID = pasted.first?.id
        toast = appLanguage == .arabic ? "تم لصق الحركة على العنصر" : "Animation pasted"
        objectWillChange.send()
    }

    func duplicateSelectedKeyframe() {
        guard let selectedID = selectedKeyframeID,
              let source = keyframes.first(where: { $0.id == selectedID }),
              let node = selectedNode else {
            toast = appLanguage == .arabic ? "حدد Keyframe أولًا" : "Select a keyframe first"
            return
        }
        let track = source.trackID ?? activeMotionTrackID(for: node)
        var targetTime = currentTime
        if abs(targetTime - source.time) < 0.0005 {
            targetTime = min(duration, source.time + 1.0 / max(1.0, fps))
        }
        if targetTime >= duration - 0.001 { duration += 30 }
        pushUndoSnapshot("Duplicate Keyframe")
        let copy = clonedKeyframe(source, node: node, trackID: track, time: targetTime)
        keyframes.removeAll {
            ($0.nodeID == copy.nodeID || ($0.nodeID == nil && $0.nodeName == copy.nodeName)) &&
            $0.trackID == track && abs($0.time - targetTime) < 0.0005
        }
        keyframes.append(copy)
        keyframes.sort { $0.time < $1.time }
        selectedKeyframeID = copy.id
        currentTime = targetTime
        applyTimeline(at: targetTime)
        toast = appLanguage == .arabic ? "تم تكرار الـKeyframe" : "Keyframe duplicated"
    }

    func setMotionTrackLoop(_ enabled: Bool, trackID: String) {
        if enabled { loopingMotionTrackIDs.insert(trackID) }
        else { loopingMotionTrackIDs.remove(trackID) }
        timelineChannels = nil
        objectWillChange.send()
    }

    func isMotionTrackLooping(_ trackID: String) -> Bool {
        loopingMotionTrackIDs.contains(trackID)
    }

    func setSelectedKeyframeInterpolation(_ value: StudioInterpolation) {
        keyframeInterpolation = value
        guard let id = selectedKeyframeID, let index = keyframes.firstIndex(where: { $0.id == id }) else { return }
        pushUndoSnapshot("Keyframe Interpolation")
        keyframes[index].interpolation = value
    }

    func moveSelectedKeyframe(to time: Double) {
        guard let id = selectedKeyframeID, let index = keyframes.firstIndex(where: { $0.id == id }) else { return }
        pushUndoSnapshotThrottled(label: "Move Keyframe", key: "move-keyframe-\(id.uuidString)")
        keyframes[index].time = max(0, min(duration, time))
        currentTime = keyframes[index].time
        keyframes.sort { $0.time < $1.time }
        applyTimeline(at: currentTime)
    }

    func selectKeyframe(_ key: StudioKeyframe) {
        selectedAudioClipID = nil
        selectedKeyframeID = key.id
        keyframeInterpolation = key.interpolation
        if let id = key.nodeID {
            var target: SCNNode?
            scene.rootNode.enumerateChildNodes { node, stop in
                if node.studioAnimationID == id { target = node; stop.pointee = true }
            }
            if let target {
                select(target)
                // A camera key is a saved shot: selecting it must immediately
                // restore the exact first frame of that shot.
                key.apply(to: target)
                if target.camera != nil, isUsingSelectedCamera { scnView?.pointOfView = target }
            }
        }
        seek(to: key.time)
        objectWillChange.send()
    }

    func updateKeyframeFromEditor(id: UUID, time: Double, position: SCNVector3, euler: SCNVector3, scale: SCNVector3, interpolation: StudioInterpolation) {
        guard let index = keyframes.firstIndex(where: { $0.id == id }) else { return }
        pushUndoSnapshot("Edit Keyframe")
        keyframes[index].time = max(0, min(duration, time))
        keyframes[index].position = position
        keyframes[index].euler = euler
        keyframes[index].scale = scale
        keyframes[index].interpolation = interpolation
        keyframeInterpolation = interpolation
        selectedKeyframeID = id
        currentTime = keyframes[index].time
        keyframes.sort { $0.time < $1.time }
        timelineChannels = nil
        applyTimeline(at: currentTime)
        toast = appLanguage == .arabic ? "تم حفظ تعديلات الـKeyframe" : "Keyframe changes saved"
        objectWillChange.send()
    }

    func trimSegmentStart(for keyframeID: UUID, to requestedTime: Double) {
        guard let current = keyframes.first(where: { $0.id == keyframeID }) else { return }
        let same = keyframes.filter {
            $0.id != keyframeID && $0.trackID == current.trackID &&
            ($0.nodeID == current.nodeID || ($0.nodeID == nil && $0.nodeName == current.nodeName)) && $0.time < current.time
        }
        guard let previous = same.max(by: { $0.time < $1.time }), let index = keyframes.firstIndex(where: { $0.id == previous.id }) else { return }
        let maxStart = max(previous.time, current.time - 1.0 / max(1.0, fps))
        keyframes[index].time = max(previous.time, min(maxStart, requestedTime))
        keyframes.sort { $0.time < $1.time }
        timelineChannels = nil
        objectWillChange.send()
    }

    func removeCurrentKeyframe() {
        guard let node = selectedNode else { return }
        let id = animationIdentity(node)
        pushUndoSnapshot("Remove Keyframe")
        let track = activeMotionTrackID(for: node)
        keyframes.removeAll {
            ($0.nodeID == id || ($0.nodeID == nil && $0.nodeName == node.name)) &&
            ($0.trackID == track || ($0.trackID == nil && motionTrackIDs(for: node).count == 1)) &&
            abs($0.time-currentTime) < 0.08
        }
        selectedKeyframeID = nil
    }

    func seek(to time: Double) {
        guard time.isFinite else { return }
        if !isPlaying, time > duration { duration = ceil(time / 30.0) * 30.0 }
        currentTime = max(0, min(duration, time))
        if isPlaying {
            playbackStartClock = ProcessInfo.processInfo.systemUptime
            playbackStartTime = currentTime
            playAudioTimeline()
        }
        applyTimeline(at: currentTime)
        refreshSelectionGizmo()
    }

    func togglePlayback() {
        isPlaying ? stopPlayback() : startPlayback()
    }

    func startPlayback() {
        guard !isPlaying, !importIsRunning, !isTransformGestureActive,
              duration.isFinite, duration > 0, fps.isFinite else { return }
        isPlaying = true
        if currentTime >= duration { currentTime = 0 }
        playAudioTimeline()

        playbackStartClock = ProcessInfo.processInfo.systemUptime
        playbackStartTime = currentTime
        let interval = 1.0 / min(60, max(1, fps))
        playbackTimer?.invalidate()
        playbackTimer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.isPlaying else { return }
                let next = self.playbackStartTime + ProcessInfo.processInfo.systemUptime - self.playbackStartClock
                if next >= self.duration {
                    self.currentTime = self.duration
                    self.applyTimeline(at: self.currentTime)
                    self.stopPlayback()
                } else {
                    self.currentTime = next
                    self.applyTimeline(at: self.currentTime)
                }
            }
        }
    }

    func stopPlayback() {
        isPlaying = false
        playbackTimer?.invalidate()
        playbackTimer = nil
        stopAudioTimeline()
    }

    func applyTimeline(at time: Double) {
        if timelineChannels == nil {
            let groups = Dictionary(grouping: keyframes) { ($0.nodeID ?? "legacy:" + $0.nodeName) + "|" + ($0.trackID ?? "default") }
            var nodesByID: [String: SCNNode] = [:]
            scene.rootNode.enumerateChildNodes { node, _ in
                if let id = node.studioAnimationID { nodesByID[id] = node }
            }
            timelineChannels = groups.values.compactMap { frames in
                guard let first = frames.first else { return nil }
                let target = first.nodeID.flatMap { nodesByID[$0] } ??
                    (first.nodeID == nil ? scene.rootNode.childNode(withName: first.nodeName, recursively: true) : nil)
                guard let node = target else { return nil }
                return (node: node, frames: frames.sorted { $0.time < $1.time })
            }
        }
        SCNTransaction.begin()
        SCNTransaction.disableActions = true
        defer { SCNTransaction.commit() }
        for channel in timelineChannels ?? [] {
            let n = channel.node
            let sorted = channel.frames
            guard let first = sorted.first, let last = sorted.last, n.parent != nil else { continue }

            var channelTime = time
            if let trackID = first.trackID,
               loopingMotionTrackIDs.contains(trackID),
               last.time > first.time,
               time >= first.time {
                let span = last.time - first.time
                channelTime = first.time + (time - first.time).truncatingRemainder(dividingBy: span)
            }

            if let exact = sorted.first(where: { abs($0.time - channelTime) < 0.0005 }) {
                exact.apply(to: n)
                continue
            }

            let before = sorted.last(where: { $0.time <= channelTime }) ?? first
            let after = sorted.first(where: { $0.time >= channelTime }) ?? last

            if abs(after.time - before.time) < 0.0001 {
                before.apply(to: n)
            } else {
                let rawT = Float(max(0, min(1, (channelTime - before.time) / (after.time - before.time))))
                let t: Float
                switch before.interpolation {
                case .linear: t = rawT
                case .smooth: t = rawT * rawT * (3 - 2 * rawT)
                case .easeIn: t = rawT * rawT
                case .easeOut: t = 1 - (1 - rawT) * (1 - rawT)
                case .hold: t = 0
                }
                n.position = lerp(before.position, after.position, t)
                n.eulerAngles = lerpAngles(before.euler, after.euler, t)
                n.scale = lerp(before.scale, after.scale, t)
                if let camera = n.camera {
                    let a = before.cameraFOV ?? Double(camera.fieldOfView)
                    let b = after.cameraFOV ?? a
                    camera.fieldOfView = CGFloat(a + (b - a) * Double(t))
                    let ea = before.cameraExposure ?? Double(camera.exposureOffset)
                    let eb = after.cameraExposure ?? ea
                    camera.exposureOffset = CGFloat(ea + (eb - ea) * Double(t))
                    let ba = before.cameraBloom ?? Double(camera.bloomIntensity)
                    let bb = after.cameraBloom ?? ba
                    camera.bloomIntensity = CGFloat(ba + (bb - ba) * Double(t))
                }
                if let light = n.light {
                    let ia = before.lightIntensity ?? Double(light.intensity)
                    let ib = after.lightIntensity ?? ia
                    light.intensity = CGFloat(ia + (ib - ia) * Double(t))
                    if let ca = before.lightColor, let cb = after.lightColor {
                        var ar:CGFloat=0,ag:CGFloat=0,ab:CGFloat=0,aa:CGFloat=0, br:CGFloat=0,bg:CGFloat=0,bb:CGFloat=0,ba:CGFloat=0
                        if ca.getRed(&ar, green:&ag, blue:&ab, alpha:&aa), cb.getRed(&br, green:&bg, blue:&bb, alpha:&ba) {
                            let q=CGFloat(t); light.color = UIColor(red:ar+(br-ar)*q, green:ag+(bg-ag)*q, blue:ab+(bb-ab)*q, alpha:aa+(ba-aa)*q)
                        }
                    }
                }
                applyInterpolatedMaterials(from: before, to: after, t: t, node: n)
            }
        }
        objectWillChange.send()
    }

    private func applyInterpolatedMaterials(from a: StudioKeyframe, to b: StudioKeyframe, t: Float, node: SCNNode) {
        guard let geometry = node.geometry, let aa = a.materialStates, let bb = b.materialStates else { return }
        for i in 0..<min(geometry.materials.count, aa.count, bb.count) {
            let m = geometry.materials[i], x = aa[i], y = bb[i]
            func number(_ value: Any?) -> CGFloat? {
                if let n = value as? NSNumber { return CGFloat(truncating: n) }
                if let n = value as? CGFloat { return n }
                if let n = value as? Double { return CGFloat(n) }
                if let n = value as? Float { return CGFloat(n) }
                return nil
            }
            func mixColor(_ lhs: Any?, _ rhs: Any?) -> UIColor? {
                guard let l = lhs as? UIColor, let r = rhs as? UIColor else { return nil }
                var lr: CGFloat=0, lg: CGFloat=0, lb: CGFloat=0, la: CGFloat=0
                var rr: CGFloat=0, rg: CGFloat=0, rb: CGFloat=0, ra: CGFloat=0
                guard l.getRed(&lr, green:&lg, blue:&lb, alpha:&la), r.getRed(&rr, green:&rg, blue:&rb, alpha:&ra) else { return nil }
                let q=CGFloat(t)
                return UIColor(red:lr+(rr-lr)*q, green:lg+(rg-lg)*q, blue:lb+(rb-lb)*q, alpha:la+(ra-la)*q)
            }
            let diffuse = mixColor(x.diffuse,y.diffuse) ?? (t < 0.5 ? x.diffuse : y.diffuse)
            let emission = mixColor(x.emission,y.emission) ?? (t < 0.5 ? x.emission : y.emission)
            if diffuse != nil || !(t < 0.5 ? x.preservesMissingContents : y.preservesMissingContents) { m.diffuse.contents = diffuse }
            if emission != nil || !(t < 0.5 ? x.preservesMissingContents : y.preservesMissingContents) { m.emission.contents = emission }
            if let l=number(x.metalness), let r=number(y.metalness) { m.metalness.contents = l+(r-l)*CGFloat(t) } else {
                let state = t < 0.5 ? x : y
                if state.metalness != nil || !state.preservesMissingContents { m.metalness.contents = state.metalness }
            }
            if let l=number(x.roughness), let r=number(y.roughness) { m.roughness.contents = l+(r-l)*CGFloat(t) } else {
                let state = t < 0.5 ? x : y
                if state.roughness != nil || !state.preservesMissingContents { m.roughness.contents = state.roughness }
            }
            m.emission.intensity = x.emissionIntensity + (y.emissionIntensity-x.emissionIntensity)*CGFloat(t)
            m.transparency = x.transparency + (y.transparency-x.transparency)*CGFloat(t)
        }
    }

    func lerp(_ a: SCNVector3, _ b: SCNVector3, _ t: Float) -> SCNVector3 {
        SCNVector3(a.x + (b.x-a.x)*t, a.y + (b.y-a.y)*t, a.z + (b.z-a.z)*t)
    }

    func lerpAngles(_ a: SCNVector3, _ b: SCNVector3, _ t: Float) -> SCNVector3 {
        func one(_ x: Float, _ y: Float) -> Float {
            var d = fmodf(y - x, Float.pi * 2)
            if d > Float.pi { d -= Float.pi * 2 }
            if d < -Float.pi { d += Float.pi * 2 }
            return x + d * t
        }
        return SCNVector3(one(a.x,b.x), one(a.y,b.y), one(a.z,b.z))
    }
}
