import Foundation

enum ProductInterfaceText {
    static func message(_ text: String, arabic: Bool) -> String {
        let replacements = [
            "SceneKitErrorDomain": arabic ? "خطأ في المشهد" : "Scene error",
            "SceneKit": arabic ? "المشهد" : "Scene",
            "Model I/O": arabic ? "قارئ الملفات" : "File reader",
            "ModelIO": arabic ? "قارئ الملفات" : "File reader",
            "AVFoundation": arabic ? "الوسائط" : "Media",
            "CoreImage": arabic ? "معالجة الصورة" : "Image processing",
            "Core Image": arabic ? "معالجة الصورة" : "Image processing",
            "CryptoKit": arabic ? "التحقق من الملف" : "File verification",
            "MetalPerformanceShaders": arabic ? "معالجة الصورة" : "Image processing",
            "MetalFX": arabic ? "معالجة الصورة" : "Image processing"
        ]
        var result = text
        for key in replacements.keys.sorted(by: { $0.count > $1.count }) {
            result = result.replacingOccurrences(of: key, with: replacements[key]!, options: .caseInsensitive)
        }
        return result
    }
}
