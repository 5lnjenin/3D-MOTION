import Foundation
import SwiftUI
import UIKit
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

@MainActor
extension StudioStore {
// MARK: - Layered animation playback
    struct AnimationLayerInfo: Identifiable, Hashable, Codable {
        let id: String
        var name: String
        var nodeName: String
        var weight: CGFloat
        var speed: CGFloat
        var isLooping: Bool
        var isAdditive: Bool
        var isPaused: Bool
        var nodeID: String? = nil
    }

    // Multiple animation players can coexist on the same node. Each layer gets
    // its own key so adding a new motion never replaces the previous one.
    @discardableResult
    func addAnimationLayer(
        _ animation: CAAnimation,
        to node: SCNNode,
        name: String? = nil,
        weight: CGFloat = 1.0,
        speed: CGFloat = 1.0,
        repeatForever: Bool = false,
        additive: Bool = false
    ) -> String {
        let key = "5ln.layer.\(UUID().uuidString)"
        let copy = animation.copy() as! CAAnimation
        copy.repeatCount = repeatForever ? .greatestFiniteMagnitude : copy.repeatCount
        copy.isRemovedOnCompletion = false
        copy.fillMode = .forwards

        let sceneAnimation = SCNAnimation(caAnimation: copy)
        let player = SCNAnimationPlayer(animation: sceneAnimation)
        player.speed = speed
        player.blendFactor = max(0, min(1, weight))

        // Additive layers are most useful for small offsets (bounce, recoil,
        // wheel spin, secondary motion) over a base walk/drive animation.
        if additive {
            copy.setValue(true, forKey: "additive")
        }

        node.addAnimationPlayer(player, forKey: key)
        player.play()
        animationLayers.append(
            AnimationLayerInfo(
                id: key,
                name: name?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false ? name! : "Motion \(animationLayers.count + 1)",
                nodeName: node.name ?? "Object",
                weight: max(0, min(1, weight)),
                speed: speed,
                isLooping: repeatForever,
                isAdditive: additive,
                isPaused: false,
                nodeID: animationIdentity(node)
            )
        )
        statusText = appLanguage == .arabic ? "تشغيل طبقة الحركة" : "Animation layer playing"
        return key
    }

    func setAnimationLayerWeight(
        _ weight: CGFloat,
        key: String,
        on node: SCNNode
    ) {
        guard let player = node.animationPlayer(forKey: key) else { return }
        player.blendFactor = max(0, min(1, weight))
        if let index = animationLayers.firstIndex(where: { $0.id == key }) {
            animationLayers[index].weight = max(0, min(1, weight))
        }
    }

    func setAnimationLayerSpeed(
        _ speed: CGFloat,
        key: String,
        on node: SCNNode
    ) {
        guard let player = node.animationPlayer(forKey: key) else { return }
        player.speed = speed
        if let index = animationLayers.firstIndex(where: { $0.id == key }) {
            animationLayers[index].speed = speed
        }
    }

    func pauseAnimationLayer(_ key: String, on node: SCNNode) {
        node.animationPlayer(forKey: key)?.paused = true
        if let index = animationLayers.firstIndex(where: { $0.id == key }) {
            animationLayers[index].isPaused = true
        }
    }

    func resumeAnimationLayer(_ key: String, on node: SCNNode) {
        if let player = node.animationPlayer(forKey: key) {
            player.paused = false
            player.play()
        }
        if let index = animationLayers.firstIndex(where: { $0.id == key }) {
            animationLayers[index].isPaused = false
        }
    }

    func removeAnimationLayer(_ key: String, from node: SCNNode) {
        node.removeAnimation(forKey: key, blendOutDuration: 0.15)
        animationLayers.removeAll { $0.id == key }
    }

    func stopAllAnimationLayers(on node: SCNNode, recursive: Bool = false) {
        var removedKeys = Set<String>()
        func stop(_ target: SCNNode) {
            for key in target.animationKeys where key.hasPrefix("5ln.layer.") {
                removedKeys.insert(key)
                target.removeAnimation(forKey: key, blendOutDuration: 0.15)
            }
            if recursive {
                target.childNodes.forEach(stop)
            }
        }
        stop(node)
        if !removedKeys.isEmpty {
            animationLayers.removeAll { removedKeys.contains($0.id) }
        }
    }

    func activeAnimationLayerKeys(on node: SCNNode) -> [String] {
        node.animationKeys.filter { $0.hasPrefix("5ln.layer.") }
    }

    func renameAnimationLayer(_ key: String, to newName: String) {
        let clean = newName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty,
              let index = animationLayers.firstIndex(where: { $0.id == key }) else { return }
        animationLayers[index].name = clean
    }

    func moveAnimationLayer(from source: IndexSet, to destination: Int) {
        animationLayers.move(fromOffsets: source, toOffset: destination)
    }

    func clearAnimationLayerRegistry() {
        animationLayers.removeAll()
    }


    @discardableResult
    func addAnimationLayer(
        _ animation: CAAnimation,
        to nodes: [SCNNode],
        weight: CGFloat = 1.0,
        speed: CGFloat = 1.0,
        repeatForever: Bool = false,
        additive: Bool = false
    ) -> [String] {
        nodes.map {
            addAnimationLayer(
                animation,
                to: $0,
                weight: weight,
                speed: speed,
                repeatForever: repeatForever,
                additive: additive
            )
        }
    }



    func clampedGizmoScale(_ raw: Float) -> Float {
        // Prevent an imported object's extreme bounds/pivot from producing
        // screen-filling handles. Gizmo remains readable but never gigantic.
        min(max(raw, 0.35), 2.4)
    }


    func placeImportedWorkspaceAtOrigin(_ workspace: SCNNode) {
        SCNTransaction.begin()
        SCNTransaction.disableActions = true

        // First neutralize the editor wrapper. The imported hierarchy itself keeps
        // its authored rotations/scales/materials; only this wrapper is positioned.
        workspace.position = SCNVector3Zero

        func moveVisibleBoundsToWorkPoint() {
            guard let bounds = worldBounds(of: workspace) else { return }
            let centerX = (bounds.min.x + bounds.max.x) * 0.5
            let centerZ = (bounds.min.z + bounds.max.z) * 0.5
            let floorY = bounds.min.y
            let deltaWorld = SCNVector3(
                workPoint.x - centerX,
                workPoint.y - floorY,
                workPoint.z - centerZ
            )

            // Convert a world-space correction into the wrapper parent's local
            // space. This stays correct even if contentRoot gets a transform later.
            let deltaLocal = workspace.parent?.convertVector(deltaWorld, from: nil) ?? deltaWorld
            workspace.position = SCNVector3(
                workspace.position.x + deltaLocal.x,
                workspace.position.y + deltaLocal.y,
                workspace.position.z + deltaLocal.z
            )
        }

        moveVisibleBoundsToWorkPoint()
        // A second residual correction handles unusual pivots / scaled FBX roots.
        moveVisibleBoundsToWorkPoint()

        SCNTransaction.commit()
        statusText = appLanguage == .arabic ? "تم وضع الموديل في مركز المشروع" : "Imported at project center"
    }

    func workspaceWrappedImportedAsset(_ imported: SCNNode) -> SCNNode {
        let container = SCNNode()
        container.name = imported.name.map { "\($0) • Workspace" } ?? "Imported • Workspace"

        // Preserve every child/material/animation exactly as imported. The
        // wrapper becomes the editor-facing transform instead of destructive
        // edits to the asset hierarchy.
        imported.removeFromParentNode()
        container.addChildNode(imported)

        // Exporters often put a huge translation on the file root. Preserve
        // orientation/scale, but move that root translation into a centered
        // workspace representation.
        imported.position = SCNVector3Zero

        let b = imported.boundingBox
        let minV = b.min
        let maxV = b.max
        guard minV.x.isFinite, minV.y.isFinite, minV.z.isFinite,
              maxV.x.isFinite, maxV.y.isFinite, maxV.z.isFinite else {
            return container
        }

        let center = SCNVector3(
            (minV.x + maxV.x) * 0.5,
            (minV.y + maxV.y) * 0.5,
            (minV.z + maxV.z) * 0.5
        )
        let sx = maxV.x - minV.x
        let sy = maxV.y - minV.y
        let sz = maxV.z - minV.z
        let longest = max(sx, max(sy, sz))

        // Center using the imported node's pivot, keeping children untouched.
        imported.pivot = SCNMatrix4MakeTranslation(center.x, center.y, center.z)

        // Normalize only extreme file units. Ordinary assets remain authored size.
        if longest.isFinite, longest > 0.000_001, (longest > 100 || longest < 0.02) {
            let factor: Float = 6.0 / longest
            imported.scale = SCNVector3(
                imported.scale.x * factor,
                imported.scale.y * factor,
                imported.scale.z * factor
            )
        }

        // Final X/Y/Z placement is calculated from the complete hierarchy
        // after the wrapper is attached to contentRoot.
        container.position = SCNVector3Zero
        return container
    }
}
