import Foundation
import SceneKit
import SwiftUI
import simd

extension SCNNode {
    var importedGLTFTarget:String? {
        get {childNodes.first {$0.name?.hasPrefix("_5LnGLTFTarget:")==true}?.name.map {String($0.dropFirst("_5LnGLTFTarget:".count))}}
        set {
            childNodes.filter {$0.name?.hasPrefix("_5LnGLTFTarget:")==true}.forEach {$0.removeFromParentNode()}
            if let newValue {let marker=SCNNode();marker.name="_5LnGLTFTarget:"+newValue;marker.isHidden=true;addChildNode(marker)}
        }
    }
    func importedLibrary() throws -> ImportedAnimationLibrary? {
        guard let text=childNodes.first(where: {$0.name?.hasPrefix("_5LnGLTFState:")==true})?.name else {return nil}
        guard text.utf8.count<=64*1024*1024,let data=Data(base64Encoded:String(text.dropFirst("_5LnGLTFState:".count))) else {throw MeshWorkshopError.invalid}
        let library=try PropertyListDecoder().decode(ImportedAnimationLibrary.self,from:data);try library.validate();return library
    }
    func setImportedLibrary(_ library:ImportedAnimationLibrary) throws {
        try library.validate();let encoder=PropertyListEncoder();encoder.outputFormat = .binary
        let data=try encoder.encode(library);guard data.count<=48*1024*1024 else {throw MeshWorkshopError.limit}
        let marker=SCNNode();marker.name="_5LnGLTFState:"+data.base64EncodedString();marker.isHidden=true
        childNodes.filter {$0.name?.hasPrefix("_5LnGLTFState:")==true}.forEach {$0.removeFromParentNode()};addChildNode(marker)
    }
}

@MainActor
final class ImportedRigRuntime {
    let root:SCNNode,library:ImportedAnimationLibrary,targets:[String:SCNNode]
    init(root:SCNNode,library:ImportedAnimationLibrary) throws {
        self.root=root;self.library=library
        var targets:[String:SCNNode]=[:]
        for node in ProjectSceneCodec.nodes(in:root) {
            if let id=node.importedGLTFTarget {guard targets[id]==nil else {throw MeshWorkshopError.invalid};targets[id]=node}
        }
        guard library.rest.allSatisfy({targets[$0.target] != nil}) else {throw MeshWorkshopError.invalid};self.targets=targets
    }
    func apply(at time:Double) {
        for rest in library.rest {
            guard let node=targets[rest.target] else {continue}
            node.simdPosition = .init(Float(rest.translation[0]),Float(rest.translation[1]),Float(rest.translation[2]))
            node.simdOrientation=simd_quatf(ix:Float(rest.rotation[0]),iy:Float(rest.rotation[1]),iz:Float(rest.rotation[2]),r:Float(rest.rotation[3]))
            node.simdScale = .init(Float(rest.scale[0]),Float(rest.scale[1]),Float(rest.scale[2]))
            if let morpher=node.morpher {for i in 0..<min(rest.weights.count,morpher.targets.count) {morpher.setWeight(CGFloat(rest.weights[i]),forTargetAt:i)}}
        }
        guard let clip=library.selected,let clipTime=library.clipTime(time) else {return}
        for channel in library.clips[clip].channels {
            guard let node=targets[channel.target] else {continue};let sample=channel.sample(clipTime)
            guard sample.count==channel.components,sample.allSatisfy({$0.isFinite && abs($0)<=Double(Float.greatestFiniteMagnitude)}) else {continue}
            switch channel.path {
            case "translation":node.simdPosition = .init(Float(sample[0]),Float(sample[1]),Float(sample[2]))
            case "scale":node.simdScale = .init(Float(sample[0]),Float(sample[1]),Float(sample[2]))
            case "rotation":node.simdOrientation=simd_quatf(ix:Float(sample[0]),iy:Float(sample[1]),iz:Float(sample[2]),r:Float(sample[3]))
            case "weights":if let morpher=node.morpher {for i in 0..<min(sample.count,morpher.targets.count) {morpher.setWeight(CGFloat(sample[i]),forTargetAt:i)}}
            default:break
            }
        }
    }
}

@MainActor
extension StudioStore {
    var selectedImportedRig:SCNNode? {
        var node=selectedNode
        while let current=node {
            if current.childNodes.contains(where: {$0.name?.hasPrefix("_5LnGLTFState:")==true}) {return current}
            node=current.parent
        }
        if let selectedNode {return ProjectSceneCodec.nodes(in:selectedNode).first {$0.childNodes.contains(where: {$0.name?.hasPrefix("_5LnGLTFState:")==true})}}
        return nil
    }
    func applyImportedAnimations(at time:Double) {
        if importedRigCache==nil {
            importedRigCache=ProjectSceneCodec.nodes(in:contentRoot).compactMap {node in
                guard let library=try? node.importedLibrary() else {return nil};return try? ImportedRigRuntime(root:node,library:library)
            }
        }
        for runtime in importedRigCache ?? [] where runtime.root.parent != nil {runtime.apply(at:time)}
    }
    func editImportedClip(_ change:(inout ImportedAnimationLibrary)->Void) {
        guard !isExporting,!workshopIsRunning,let root=selectedImportedRig else {return}
        do {
            guard var library=try root.importedLibrary() else {return};change(&library);try library.validate()
            // Encode before recording history or removing the existing marker.
            let encoder=PropertyListEncoder();encoder.outputFormat = .binary;_=try encoder.encode(library)
            pushUndoSnapshot("Imported animation clip");try root.setImportedLibrary(library)
            importedRigCache=nil;reconcileTimelineDuration();applyTimeline(at:currentTime);objectWillChange.send()
        } catch {reportProjectError(error)}
    }
}

@MainActor
struct ImportedAnimationInspector:View {
    @EnvironmentObject var studio:StudioStore
    private var ar:Bool {studio.appLanguage == .arabic}
    var body:some View {
        if let rig=studio.selectedImportedRig,let library=try? rig.importedLibrary() {
            InspectorCard(title:ar ? "مقاطع الحركة المستوردة" : "Imported animation clips") {
                Picker(ar ? "المقطع" : "Clip",selection:Binding(get:{library.selected ?? -1},set:{value in studio.editImportedClip {$0.selected=value<0 ? nil : value}})) {
                    Text(ar ? "وضع السكون" : "Rest pose").tag(-1)
                    ForEach(library.clips.indices,id:\.self) {i in Text(library.clips[i].name).tag(i)}
                }.pickerStyle(.menu)
                Toggle(ar ? "تكرار" : "Loop",isOn:Binding(get:{library.loops},set:{value in studio.editImportedClip {$0.loops=value}}))
                HStack {
                    Text(ar ? "السرعة" : "Speed")
                    TextField("Speed",value:Binding(get:{library.speed},set:{value in studio.editImportedClip {$0.speed=value}}),format:.number).textFieldStyle(.roundedBorder)
                }
                HStack {
                    Text(ar ? "البداية" : "Start")
                    TextField("Start",value:Binding(get:{library.start},set:{value in studio.editImportedClip {$0.start=value}}),format:.number).textFieldStyle(.roundedBorder)
                }
                Button(library.pausedAt==nil ? (ar ? "تجميد المقطع" : "Freeze clip") : (ar ? "استئناف المقطع" : "Resume clip")) {
                    studio.editImportedClip {$0.pausedAt=$0.pausedAt==nil ? studio.currentTime : nil}
                }.frame(minHeight:44)
            }
        } else {
            Text(ar ? "حدد شخصية أو مجسمًا مستوردًا يحتوي مقاطع حركة." : "Select an imported model with animation clips.").font(.callout).foregroundStyle(.secondary)
        }
    }
}
