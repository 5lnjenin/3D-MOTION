import Foundation
import SwiftUI
import UIKit
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

// 3D MOTION — build 24.
// A versioned .3dmotion container owns SceneKit graph, material channels,
// texture bytes, animation/keyframes, environment, audio and integrity data.
// PortableCoreTests ran on Linux; SceneKit/iPad validation requires Apple SDKs.
// References: https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html
// https://developer.apple.com/documentation/scenekit

enum StudioResourceFiles {
    static func candidates(name: String, fileExtension: String) -> [URL] {
        var bundles: [Bundle] = [Bundle.main]
        #if SWIFT_PACKAGE
        bundles.insert(Bundle.module, at: 0)
        #endif
        var result: [URL] = []
        let filename = name + "." + fileExtension
        for bundle in bundles {
            let urls: [URL?] = [
                bundle.url(forResource: name, withExtension: fileExtension),
                bundle.url(forResource: name, withExtension: fileExtension, subdirectory: "Resources"),
                bundle.resourceURL?.appendingPathComponent(filename),
                bundle.resourceURL?.appendingPathComponent("Resources/" + filename)
            ]
            result.append(contentsOf: urls.compactMap { $0 })
        }
        return result
    }
}

enum StudioLanguage: String, CaseIterable, Codable, Identifiable {
    case arabic
    case english

    var id: String { rawValue }
    var title: String { self == .arabic ? "العربية" : "English" }
    var locale: Locale { Locale(identifier: self == .arabic ? "ar" : "en") }
    var direction: LayoutDirection { self == .arabic ? .rightToLeft : .leftToRight }
}

enum StudioL10n {
    static func text(_ key: String, _ language: StudioLanguage) -> String {
        let ar: [String: String] = [
            "scene":"المشهد", "tools":"الأدوات", "add":"إضافة", "import":"استيراد",
            "move":"تحريك", "rotate":"تدوير", "scale":"حجم", "material":"الخامة",
            "object":"العنصر", "animate":"الحركة", "more":"المزيد", "transform":"التحويل",
            "geometry":"الأشكال", "camera":"كاميرا", "empty":"عنصر فارغ",
            "text3d":"نص ثلاثي الأبعاد", "reference":"مرجع", "referenceImage":"صورة مرجعية",
            "settings":"الإعدادات", "language":"اللغة", "arabic":"العربية", "english":"الإنجليزية",
            "undo":"تراجع", "redo":"تقدم", "save":"حفظ", "playback":"التشغيل",
            "position":"الموقع", "rotation":"الدوران", "opacity":"الشفافية",
            "color":"اللون", "lighting":"الإضاءة", "environment":"البيئة",
            "search":"بحث القطع", "done":"تم", "cancel":"إلغاء", "delete":"حذف",
            "textStudio":"استوديو النص", "text":"النص", "font":"الخط", "style":"النمط",
            "depth":"السماكة", "size":"الحجم", "alignment":"المحاذاة",
            "create":"إنشاء النص", "editText":"تعديل النص", "effects":"المؤثرات",
            "metal":"معدني", "gold":"ذهبي", "neon":"نيون", "glass":"زجاج",
            "matte":"مطفي", "chrome":"كروم", "glow":"متوهج", "outline":"حدود",
            "shadow":"ظل", "plain":"عادي", "gradient":"تدرج", "curve":"منحني", "spacing":"تباعد", "bevel":"حواف", "duplicate":"نسخ", "textAnimation":"حركة النص", "wave":"موجة", "pop":"ظهور", "spin":"دوران", "float":"طفو", "pulse":"نبض", "advanced":"أدوات متقدمة", "scanScene":"فحص المشهد", "rigging":"العظام والتحريك", "materialsAdvanced":"الخامات المتقدمة", "cinematic":"الكاميرا السينمائية"
        ]
        let en: [String: String] = [
            "scene":"Scene", "tools":"Tools", "add":"Add", "import":"Import",
            "move":"Move", "rotate":"Rotate", "scale":"Scale", "material":"Material",
            "object":"Object", "animate":"Animate", "more":"More", "transform":"Transform",
            "geometry":"Geometry", "camera":"Camera", "empty":"Empty",
            "text3d":"3D Text", "reference":"Reference", "referenceImage":"Reference Image",
            "settings":"Settings", "language":"Language", "arabic":"Arabic", "english":"English",
            "undo":"Undo", "redo":"Redo", "save":"Save", "playback":"Playback",
            "position":"Position", "rotation":"Rotation", "opacity":"Opacity",
            "color":"Color", "lighting":"Lighting", "environment":"Environment",
            "search":"Search parts", "done":"Done", "cancel":"Cancel", "delete":"Delete",
            "textStudio":"Text Studio", "text":"Text", "font":"Font", "style":"Style",
            "depth":"Depth", "size":"Size", "alignment":"Alignment",
            "create":"Create Text", "editText":"Edit Text", "effects":"Effects",
            "metal":"Metal", "gold":"Gold", "neon":"Neon", "glass":"Glass",
            "matte":"Matte", "chrome":"Chrome", "glow":"Glow", "outline":"Outline",
            "shadow":"Shadow", "plain":"Plain", "gradient":"Gradient", "curve":"Curve", "spacing":"Spacing", "bevel":"Bevel", "duplicate":"Duplicate", "textAnimation":"Text Animation", "wave":"Wave", "pop":"Pop", "spin":"Spin", "float":"Float", "pulse":"Pulse", "advanced":"Advanced Tools", "scanScene":"Scan Scene", "rigging":"Rigging & Bones", "materialsAdvanced":"Advanced Materials", "cinematic":"Cinematic Camera"
        ]
        return (language == .arabic ? ar : en)[key] ?? key
    }
}

import UIKit
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

@main
@MainActor
struct FiveLn3DStudioApp: App {
    @StateObject private var studio = StudioStore()
    @State private var showLaunchSplash = true
    @State private var incomingProjectURL: URL?

    var body: some Scene {
        WindowGroup {
            Group {
                if showLaunchSplash {
                    LaunchSplashView(isPresented: $showLaunchSplash)
                        .transition(.opacity)
                } else {
                    StudioRootView(incomingProjectURL: $incomingProjectURL)
                        .environmentObject(studio)
                        .preferredColorScheme(.dark)
                        .transition(.opacity)
                }
            }
            .preferredColorScheme(.dark)
            .onOpenURL { url in
                incomingProjectURL = url
                showLaunchSplash = false
            }
        }
    }
}


struct ImportFileItem: Identifiable {
    let id = UUID()
    let name: String
    let fileType: String
    var status: String
    var detail: String
}

struct ImportNodeItem: Identifiable {
    let id = UUID()
    let node: SCNNode
    let name: String
    let sourceFile: String
    let depth: Int
    let isMesh: Bool
}

struct SavedMaterialKeyframeState: Codable {
    var values: [String: ProjectValue]? = nil
    var diffuseRGBA: [Double]?
    var metalness: Double?
    var roughness: Double?
    var emissionRGBA: [Double]?
    var emissionIntensity: Double
    var transparency: Double

    init(_ state: MaterialKeyframeState) {
        func rgba(_ value: Any?) -> [Double]? {
            guard let c = value as? UIColor else { return nil }
            var r:CGFloat=0,g:CGFloat=0,b:CGFloat=0,a:CGFloat=0
            guard c.getRed(&r, green:&g, blue:&b, alpha:&a) else { return nil }
            return [Double(r),Double(g),Double(b),Double(a)]
        }
        func number(_ value: Any?) -> Double? {
            if let n = value as? NSNumber { return n.doubleValue }
            return nil
        }
        diffuseRGBA = rgba(state.diffuse)
        metalness = number(state.metalness)
        roughness = number(state.roughness)
        emissionRGBA = rgba(state.emission)
        emissionIntensity = Double(state.emissionIntensity)
        transparency = Double(state.transparency)
    }

    var materialState: MaterialKeyframeState {
        func color(_ a: [Double]?) -> UIColor? {
            guard let a, a.count == 4 else { return nil }
            return UIColor(red:a[0], green:a[1], blue:a[2], alpha:a[3])
        }
        var state = MaterialKeyframeState(SCNMaterial())
        state.preservesMissingContents = true
        state.diffuse = color(diffuseRGBA)
        state.metalness = metalness.map(NSNumber.init(value:))
        state.roughness = roughness.map(NSNumber.init(value:))
        state.emission = color(emissionRGBA)
        state.emissionIntensity = CGFloat(emissionIntensity)
        state.transparency = CGFloat(transparency)
        return state
    }
}

struct SavedKeyframe: Codable {
    var nodeID: String?
    var nodeName: String
    var time: Double
    var px: Float
    var py: Float
    var pz: Float
    var rx: Float
    var ry: Float
    var rz: Float
    var sx: Float
    var sy: Float
    var sz: Float
    var cameraFOV: Double?
    var cameraExposure: Double?
    var cameraBloom: Double?
    var lightIntensity: Double?
    var lightRGBA: [Double]?
    var trackID: String?
    var interpolation: StudioInterpolation?
    var materialStates: [SavedMaterialKeyframeState]?

    init(_ key: StudioKeyframe) {
        nodeID = key.nodeID
        nodeName = key.nodeName
        time = key.time
        px = key.position.x
        py = key.position.y
        pz = key.position.z
        rx = key.euler.x
        ry = key.euler.y
        rz = key.euler.z
        sx = key.scale.x
        sy = key.scale.y
        sz = key.scale.z
        cameraFOV = key.cameraFOV
        cameraExposure = key.cameraExposure
        cameraBloom = key.cameraBloom
        lightIntensity = key.lightIntensity
        if let c = key.lightColor {
            var r:CGFloat=0,g:CGFloat=0,b:CGFloat=0,a:CGFloat=0
            lightRGBA = c.getRed(&r, green:&g, blue:&b, alpha:&a) ? [Double(r),Double(g),Double(b),Double(a)] : nil
        } else { lightRGBA = nil }
        trackID = key.trackID
        interpolation = key.interpolation
        materialStates = key.materialStates?.map(SavedMaterialKeyframeState.init)
    }

    var studioKeyframe: StudioKeyframe {
        StudioKeyframe(
            nodeID: nodeID,
            nodeName: nodeName,
            time: time,
            position: SCNVector3(px, py, pz),
            euler: SCNVector3(rx, ry, rz),
            scale: SCNVector3(sx, sy, sz),
            cameraFOV: cameraFOV,
            cameraExposure: cameraExposure,
            cameraBloom: cameraBloom,
            lightIntensity: lightIntensity,
            lightColor: lightRGBA.flatMap { a in a.count == 4 ? UIColor(red:a[0], green:a[1], blue:a[2], alpha:a[3]) : nil },
            trackID: trackID,
            interpolation: interpolation ?? .smooth,
            materialStates: materialStates?.map(\.materialState)
        )
    }
}

struct StudioAutosaveMetadata: Codable {
    var savedAt: Date
    var duration: Double
    var fps: Double
    var currentTime: Double
    var gridSpacing: Double
    var gridHalfCount: Double
    var showGrid: Bool
    var showAxes: Bool
    var showWorkPoint: Bool
    var ambientStrength: Double
    var fogEnabled: Bool
    var fogDensity: Double
    var fogR: Double
    var fogG: Double
    var fogB: Double
    var fogA: Double
    var activeCameraName: String?
    var keyframes: [SavedKeyframe]
    var environmentPreset: String?
    var environmentIntensity: Double?
    var audioClips: [SavedAudioClip]?
    var renderFilterPreset: String?
    var renderFilterIntensity: Double?
    var transformSpace: String?
    var autoKeyframeEnabled: Bool?
    var activeCameraID: String? = nil
    var editorCameraTransform: [Float]? = nil
    var editorCameraArchive: Data? = nil
    var viewportState: SavedViewportState? = nil
    var animationLayers: [StudioStore.AnimationLayerInfo]? = nil
    var motionTrackNames: [String: String]? = nil
    var activeMotionTracks: [String: String]? = nil
    var loopingMotionTracks: Set<String>? = nil
    var audioAssets: [SavedAudioAsset]? = nil
    var masterAudioVolume: Double? = nil
}

struct SavedViewportState: Codable {
    var backgroundIndex: Int
    var shadingMode: String
    var backfaceCulling: Bool
    var lightCount: Int
    var keyStrength: Double
    var fillStrength: Double
    var rimStrength: Double
    var specularStrength: Double
    var highlightSize: Double
}


struct SavedAudioClip: Codable {
    var name: String
    var fileName: String
    var startTime: Double
    var volume: Double
    var loops: Bool
    var id: UUID? = nil
    var assetID: UUID? = nil
    var trackID: UUID? = nil
    var sourceStart: Double? = nil
    var sourceEnd: Double? = nil
}

struct StudioAudioClip: Identifiable {
    var id = UUID()
    var name: String
    var url: URL
    var startTime: Double = 0
    var volume: Double = 1
    var loops: Bool = false
    var player: AVAudioPlayer?
    var assetID: UUID? = nil
    var trackID = UUID()
    var sourceStart: Double = 0
    var sourceEnd: Double? = nil
    var sourceDuration: Double = 0

    var trimmedEnd: Double { min(sourceDuration, sourceEnd ?? sourceDuration) }
    var trimmedDuration: Double { max(0, trimmedEnd - sourceStart) }
    var endTime: Double { startTime + trimmedDuration }
    var stoppedCopy: StudioAudioClip { var copy = self; copy.player = nil; return copy }
}

struct SavedAudioAsset: Codable {
    var id: UUID
    var name: String
    var fileName: String
    var duration: Double
}

struct StudioAudioAsset: Identifiable {
    var id = UUID()
    var name: String
    var url: URL
    var duration: Double
}

enum SnapTarget: String, CaseIterable, Sendable {
    case increment
    case workPoint
    case worldOrigin
    case activeObject

    var title: String {
        switch self {
        case .increment: return "Increment"
        case .workPoint: return "Work Point"
        case .worldOrigin: return "World Origin"
        case .activeObject: return "Active Object"
        }
    }
}

enum TransformSpace: String, CaseIterable, Sendable {
    case world
    case local

    var title: String {
        switch self {
        case .world: return "World"
        case .local: return "Local"
        }
    }
}

enum MotionPreset: String, CaseIterable, Sendable {
    case spinY
    case wheelX
    case bounce
    case sway
    case pulse
    case forward

    var title: String {
        switch self {
        case .spinY: return "Spin Y"
        case .wheelX: return "Wheel Spin"
        case .bounce: return "Bounce"
        case .sway: return "Sway"
        case .pulse: return "Pulse"
        case .forward: return "Forward"
        }
    }

    var icon: String {
        switch self {
        case .spinY: return "rotate.3d"
        case .wheelX: return "circle.circle"
        case .bounce: return "arrow.up.and.down"
        case .sway: return "arrow.left.and.right"
        case .pulse: return "waveform.path.ecg"
        case .forward: return "arrow.forward"
        }
    }
}

enum RenderFilterPreset: String, CaseIterable, Sendable {
    case none
    case cinematic
    case vivid
    case warm
    case cool
    case mono
    case noir

    var title: String {
        rawValue.capitalized
    }
}

enum CameraViewPreset: String, CaseIterable, Sendable {
    case perspective
    case front
    case back
    case left
    case right
    case top
    case bottom

    var title: String {
        rawValue.capitalized
    }
}

// MARK: - Core Store



// MARK: - Global pointer tooltip support

struct StudioTooltipAnchor {
    let title: String
    let anchor: Anchor<CGRect>
}

struct StudioTooltipPreferenceKey: PreferenceKey {
    static var defaultValue: [StudioTooltipAnchor] = []

    static func reduce(value: inout [StudioTooltipAnchor], nextValue: () -> [StudioTooltipAnchor]) {
        value.append(contentsOf: nextValue())
    }
}

private struct StudioTooltipModifier: ViewModifier {
    let title: String
    @State private var isHovering = false

    func body(content: Content) -> some View {
        content
            // Keep the native system help as a fallback, while also publishing
            // the hovered control's bounds so StudioRootView can draw one
            // unclipped tooltip above SceneKit and every toolbar/panel.
            .help(title)
            .onHover { hovering in
                isHovering = hovering
            }
            .anchorPreference(
                key: StudioTooltipPreferenceKey.self,
                value: .bounds
            ) { anchor in
                isHovering ? [StudioTooltipAnchor(title: title, anchor: anchor)] : []
            }
    }
}

extension View {
    func studioTooltip(_ title: String) -> some View {
        modifier(StudioTooltipModifier(title: title))
    }
}
