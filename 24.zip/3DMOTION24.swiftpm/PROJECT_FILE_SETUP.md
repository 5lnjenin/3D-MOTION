# 3D MOTION 24 project documents

`.3dmotion` is a self-contained version-2 JSON container with the `3D-MOTION`
format identifier. It stores a secure SceneKit graph archive, explicit material
channel values and sampling settings, stable node-to-material bindings, embedded
resource bytes, hierarchy/transforms, native animation players, keyframes,
camera/viewport metadata, environment and audio. SHA256 checks protect the
payloads and resource identities. The graph is decoded and material bindings
validated before a save replaces a complete existing document.

Named projects and autosave use this same document format. Export Project and
Save to Files also use it. Import/Open decode in isolation before replacing the
workspace. A `.previous` sibling retains a complete previous save. Legacy v1
exports and old local Project.scn/Project.json/MaterialTextures.json are readable;
missing resources that never entered an old file cannot be reconstructed.

The separate SceneKit `.scn` export remains for interoperability. It is a scene
export, not the portable editable project document, and does not include the
full project resource manifest or timeline/audio metadata.

The delivered ZIP includes a complete `.swiftpm` app project for Swift
Playgrounds. See `REPORT_AR.md` for findings and actual validation outcomes and
`TESTING.md` for the remaining Apple checks.

`ProjectFileIcon.png` is retained. The Files document icon/type registration must
be added to the final installed app's Info.plist for a standalone distribution;
`ProjectFileTypes.plist` is a reference template, not an automatically applied
registration. Do not put an Info.plist in Resources. Swift Playgrounds file
pickers can open the `.3dmotion` file without that optional system registration.
