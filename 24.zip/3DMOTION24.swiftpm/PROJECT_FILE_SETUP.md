# 3D MOTION 24 project documents

`.3dmotion` is a self-contained version-2 JSON container with the `3D-MOTION`
format identifier. It stores a secure SceneKit graph archive, explicit material
channel values and sampling settings, stable node-to-material bindings, embedded
resource bytes, hierarchy/transforms, native animation players, keyframes,
camera/viewport metadata, environment and audio. SHA256 checks protect the
payloads and resource identities. The graph is decoded and material bindings
validated before a save replaces a complete existing document.

Named projects and autosave use this same document format. Export Project and
Save to Files also use it. Import/Open decode in isolation before replacing the
workspace. A `.previous` sibling retains a complete previous save. Legacy v1
exports and old local Project.scn/Project.json/MaterialTextures.json are readable;
missing resources that never entered an old file cannot be reconstructed.

The separate SceneKit `.scn` export remains for interoperability. It is a scene
export, not the portable editable project document, and does not include the
full project resource manifest or timeline/audio metadata.

The delivered ZIP includes a complete `.swiftpm` app project for Swift
Playgrounds. See `REPORT_AR.md` for findings and actual validation outcomes and
`TESTING.md` for the remaining Apple checks.

`ProjectFileIcon.png` is retained. The native app generator in
`Tests/create_apple_project.py` now merges `ProjectFileTypes.plist` into the
installed app's Info.plist and copies the original PNG into its resources. This
registers `app.5ln.studio.project` and `.3dmotion`, including its document icon.
The GitHub `build-ipa.yml` workflow generates a real arm64 device app with the
production bundle identifier and packages it as an unsigned IPA for local
SideStore signing. `SIDESTORE.md` explains download and installation.

The app handles incoming file URLs, asks whether to save the current project,
reads security-scoped documents and validates before replacing the workspace.
Actual Apple tests verified registration, the PNG, moved-file opening and
invalid-file rejection; the device build verified registration inside the IPA.
Physical Files icon rendering, cold-launch UI handling and SideStore signing
still require device checks. The Swift Playgrounds manifest does not merge this
plist into the Playgrounds host app; the registration applies to the native IPA.
Do not put an Info.plist in Resources. Playgrounds file pickers still support
opening `.3dmotion` documents through the existing project import commands.
