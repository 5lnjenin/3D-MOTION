import Foundation
import AVFoundation
import CoreVideo

/// Read/decode the original once and select frames on an explicit 60 FPS grid.
/// Generic export presets can reject >60 FPS assets before conversion begins.
@MainActor
enum VideoFrameRateConverter {
    static func convert(_ source: URL, to output: URL, options: StudioVideoExportOptions) async throws {
        var failures: [String] = []
        for codec in [AVVideoCodecType.h264, .hevc] {
            try Task.checkCancellation()
            do {
                try? FileManager.default.removeItem(at: output)
                try await write(source, to: output, options: options, codec: codec)
                return
            } catch is CancellationError { throw CancellationError() }
            catch { failures.append(error.localizedDescription) }
        }
        throw StudioVideoFailure.problem(failures.joined(separator: " / "))
    }

    private static func write(_ source: URL, to output: URL, options: StudioVideoExportOptions, codec: AVVideoCodecType) async throws {
        let asset = AVURLAsset(url: source)
        guard let track = try await asset.loadTracks(withMediaType: .video).first else {
            throw StudioVideoFailure.problem("ملف دون فيديو / Missing video track")
        }
        let reader = try AVAssetReader(asset: asset)
        let decoded = AVAssetReaderTrackOutput(track: track, outputSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA])
        decoded.alwaysCopiesSampleData = false
        guard reader.canAdd(decoded) else { throw StudioVideoFailure.problem("تعذر قراءة الفيديو / Video decoding unavailable") }
        reader.add(decoded)
        let writer = try AVAssetWriter(outputURL: output, fileType: .mp4)
        writer.movieTimeScale = Int32(options.fps * 1_000)
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: options.settings(codec: codec))
        input.expectsMediaDataInRealTime = false; input.mediaTimeScale = writer.movieTimeScale
        input.transform = try await track.load(.preferredTransform)
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: Int(options.resolution.size.width),
            kCVPixelBufferHeightKey as String: Int(options.resolution.size.height)])
        guard writer.canAdd(input) else { throw StudioVideoFailure.problem("تعذر تجهيز نسخة الصور / Photos writer unavailable") }
        writer.add(input)
        guard writer.startWriting(), reader.startReading() else {
            throw writer.error ?? reader.error ?? StudioVideoFailure.problem("تعذر بدء نسخة الصور / Cannot start Photos copy")
        }
        writer.startSession(atSourceTime: .zero)
        var finished = false
        defer { reader.cancelReading(); if !finished { writer.cancelWriting() } }
        var current: CMSampleBuffer?, next = decoded.copyNextSampleBuffer()
        for index in 0..<options.frameCount {
            try Task.checkCancellation()
            let time = Double(index) / Double(options.fps)
            while let sample = next, CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sample)) <= time + 0.000001 {
                current = sample; next = decoded.copyNextSampleBuffer()
            }
            guard let sample = current, let image = CMSampleBufferGetImageBuffer(sample) else {
                throw reader.error ?? StudioVideoFailure.problem("إطار مفقود في نسخة الصور / Missing Photos frame")
            }
            let deadline = Date().addingTimeInterval(30)
            while !input.isReadyForMoreMediaData {
                try Task.checkCancellation()
                guard writer.status == .writing, Date() < deadline else {
                    throw writer.error ?? StudioVideoFailure.problem("توقف حفظ نسخة الصور / Photos writer stalled")
                }
                try await Task.sleep(nanoseconds: 5_000_000)
            }
            guard writer.status == .writing,
                  adaptor.append(image, withPresentationTime: CMTime(value: Int64(index), timescale: Int32(options.fps))) else {
                throw writer.error ?? StudioVideoFailure.problem("تعذر كتابة إطار نسخة الصور / Photos frame append failed")
            }
            if index % 30 == 0 { await Task.yield() }
        }
        guard reader.status != .failed else { throw reader.error ?? StudioVideoFailure.problem("تعذر إكمال قراءة الفيديو / Video decoding failed") }
        writer.endSession(atSourceTime: CMTime(value: Int64(options.frameCount), timescale: Int32(options.fps)))
        input.markAsFinished()
        let cancellation = MediaExportCancellation { writer.cancelWriting() }
        await withTaskCancellationHandler(operation: { await writer.finishWriting() }, onCancel: { cancellation.request() })
        try Task.checkCancellation()
        guard writer.status == .completed else { throw writer.error ?? StudioVideoFailure.problem("تعذر إكمال نسخة الصور / Photos copy failed") }
        finished = true
    }
}
