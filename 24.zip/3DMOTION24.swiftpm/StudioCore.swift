import Foundation
import SwiftUI
import UIKit
import SceneKit
import SceneKit.ModelIO
import ModelIO
import UniformTypeIdentifiers
import AVFoundation
import Photos
import PhotosUI
import CoreImage
import ImageIO
import simd

@MainActor
final class StudioStore: ObservableObject {
    @Published var scene = SCNScene()
    @Published var selectedNode: SCNNode?
    @Published var selectedName: String = "لا يوجد"
    @Published var isUsingSelectedCamera = false
    var cameraBeforePreview: SCNNode?
    @Published var isImporterPresented = false
    @Published var importerMessage = ""
    @Published var showGrid = true
    @Published var showAxes = true
    @Published var showViewportStatistics = false
    @Published var backfaceCullingEnabled = true
    @Published var viewportShadingMode: ViewportShadingMode = .rendered
    @Published var viewportLightCount: Int = 3
    @Published var viewportKeyStrength: Double = 0.85
    @Published var viewportFillStrength: Double = 0.35
    @Published var viewportRimStrength: Double = 0.12
    @Published var viewportSpecularStrength: Double = 0.10
    @Published var viewportHighlightSize: Double = 24
    @Published var gridSpacing: Double = 1.0
    @Published var gridHalfCount: Double = 100
    @Published var isPlaying = false
    @Published var currentTime: Double = 0
    @Published var duration: Double = 60
    @Published var fps: Double = 30
    @Published var viewportInteractionMode: ViewportInteractionMode = .view
    @Published var boxSelectionEnabled = false
    @Published var hierarchyMultiSelectEnabled = false
    @Published var inputResetGeneration: Int = 0
    @Published var currentProjectName: String = "Untitled Project"
    @Published var viewportBackgroundIndex: Int = 0

    // On-screen navigation controls
    @Published var controlJoystickSize: Double = UserDefaults.standard.object(forKey: "5LnControlJoystickSize") as? Double ?? 104 { didSet { UserDefaults.standard.set(controlJoystickSize, forKey: "5LnControlJoystickSize") } }
    @Published var controlButtonSize: Double = UserDefaults.standard.object(forKey: "5LnControlButtonSize") as? Double ?? 46 { didSet { UserDefaults.standard.set(controlButtonSize, forKey: "5LnControlButtonSize") } }
    @Published var controlOpacity: Double = UserDefaults.standard.object(forKey: "5LnControlOpacity") as? Double ?? 0.72 { didSet { UserDefaults.standard.set(controlOpacity, forKey: "5LnControlOpacity") } }
    @Published var controlMoveSpeed: Double = UserDefaults.standard.object(forKey: "5LnControlMoveSpeed") as? Double ?? 1.0 { didSet { UserDefaults.standard.set(controlMoveSpeed, forKey: "5LnControlMoveSpeed") } }
    @Published var controlEditLayout = false
    @Published var joystickOffsetX: Double = UserDefaults.standard.object(forKey: "5LnJoystickOffsetX") as? Double ?? 0 { didSet { UserDefaults.standard.set(joystickOffsetX, forKey: "5LnJoystickOffsetX") } }
    @Published var joystickOffsetY: Double = UserDefaults.standard.object(forKey: "5LnJoystickOffsetY") as? Double ?? 0 { didSet { UserDefaults.standard.set(joystickOffsetY, forKey: "5LnJoystickOffsetY") } }
    @Published var verticalOffsetX: Double = UserDefaults.standard.object(forKey: "5LnVerticalOffsetX") as? Double ?? 0 { didSet { UserDefaults.standard.set(verticalOffsetX, forKey: "5LnVerticalOffsetX") } }
    @Published var verticalOffsetY: Double = UserDefaults.standard.object(forKey: "5LnVerticalOffsetY") as? Double ?? 0 { didSet { UserDefaults.standard.set(verticalOffsetY, forKey: "5LnVerticalOffsetY") } }
    @Published var upOffsetX: Double = UserDefaults.standard.object(forKey: "5LnUpOffsetX") as? Double ?? 0 { didSet { UserDefaults.standard.set(upOffsetX, forKey: "5LnUpOffsetX") } }
    @Published var upOffsetY: Double = UserDefaults.standard.object(forKey: "5LnUpOffsetY") as? Double ?? 0 { didSet { UserDefaults.standard.set(upOffsetY, forKey: "5LnUpOffsetY") } }
    @Published var downOffsetX: Double = UserDefaults.standard.object(forKey: "5LnDownOffsetX") as? Double ?? 0 { didSet { UserDefaults.standard.set(downOffsetX, forKey: "5LnDownOffsetX") } }
    @Published var downOffsetY: Double = UserDefaults.standard.object(forKey: "5LnDownOffsetY") as? Double ?? 0 { didSet { UserDefaults.standard.set(downOffsetY, forKey: "5LnDownOffsetY") } }
    @Published var zoomOffsetX: Double = UserDefaults.standard.object(forKey: "5LnZoomOffsetX") as? Double ?? 0 { didSet { UserDefaults.standard.set(zoomOffsetX, forKey: "5LnZoomOffsetX") } }
    @Published var zoomOffsetY: Double = UserDefaults.standard.object(forKey: "5LnZoomOffsetY") as? Double ?? 0 { didSet { UserDefaults.standard.set(zoomOffsetY, forKey: "5LnZoomOffsetY") } }
    @Published var zoomControlScale: Double = UserDefaults.standard.object(forKey: "5LnZoomControlScale") as? Double ?? 1.0 { didSet { UserDefaults.standard.set(zoomControlScale, forKey: "5LnZoomControlScale") } }
    @Published var pinchZoomEnabled: Bool = UserDefaults.standard.object(forKey: "5LnPinchZoomEnabled") as? Bool ?? true { didSet { UserDefaults.standard.set(pinchZoomEnabled, forKey: "5LnPinchZoomEnabled") } }
    @Published var transformMode: TransformMode = .move
    @Published var transformAxis: TransformAxis = .free
    @Published var pressedTransformAxis: TransformAxis? = nil
    @Published var transformSpace: TransformSpace = .world
    @Published var manipulationSpeed: Double = 0.55
    @Published var fineMode = false
    @Published var snapEnabled = false
    @Published var snapTarget: SnapTarget = .increment
    @Published var autoKeyframeEnabled = false
    @Published var snapStep: Double = 0.25
    @Published var rotationSnapDegrees: Double = 5
    @Published var scaleSnapStep: Double = 0.10
    @Published var autoFocusNewObjects = false
    @Published var autoFitImports = true
    @Published var autoFocusPartSelection = false
    @Published var showWorkPoint = true
    @Published var isolateSelection = false
    @Published var activeInspector: InspectorSection = .transform
    @Published var keyframes: [StudioKeyframe] = [] {
        didSet { timelineChannels = nil }
    }
    @Published var selectedKeyframeID: UUID? = nil
    @Published var keyframeInterpolation: StudioInterpolation = .smooth
    @Published var activeMotionTrackByNode: [String: String] = [:]
    @Published var motionTrackNames: [String: String] = [:]
    @Published var selectedMotionTrackID: String? = nil
    @Published var loopingMotionTrackIDs: Set<String> = []
    var animationClipboardFrames: [StudioKeyframe] = []
    var animationClipboardName: String = "Animation"
    var timelineChannels: [(node: SCNNode, frames: [StudioKeyframe])]?
    @Published var statusText = "جاهز"
    @Published var backgroundStrength: Double = 0.08
    @Published var ambientStrength: Double = 450
    @Published var fogEnabled = false
    @Published var fogDensity: Double = 0.25
    @Published var fogColor = Color.gray

    // Scene / Environment
    @Published var environmentPreset: SceneEnvironmentPreset = .none
    @Published var environmentIntensity: Double = 1.0
    @Published var customEnvironmentImage: UIImage?

    @Published var isExporting = false
    var videoExportTask: Task<Void, Never>?
    @Published var exportProgress: Double = 0
    @Published var exportedVideoURL: URL?
    @Published var toast: String?

    // Language / اللغة
    @Published var appLanguage: StudioLanguage = .arabic {
        didSet {
            UserDefaults.standard.set(appLanguage.rawValue, forKey: "5LnStudioLanguage")
            if selectedNode == nil && multiSelectedNodes.isEmpty {
                selectedName = appLanguage == .arabic ? "لا يوجد" : "None"
                if statusText == "جاهز" || statusText == "Ready" {
                    statusText = appLanguage == .arabic ? "جاهز" : "Ready"
                }
            }
        }
    }

    nonisolated func tr(_ key: String) -> String {
        let raw = UserDefaults.standard.string(forKey: "5LnStudioLanguage")
        let language = raw.flatMap(StudioLanguage.init(rawValue:)) ?? .arabic
        return StudioL10n.text(key, language)
    }


    // MARK: - 3D Engine Capability Registry
    enum EngineCapability: String, CaseIterable, Identifiable {
        case sceneRendering, pbrMaterials, modelImport, gltfImport
        case skeletalAnimation, morphTargets, inverseKinematics
        case animationLayers, physics, constraints, particles
        case postProcessing, spatialAudio, imageProcessing
        case photoExport, videoPipeline, text3D, boneEditing, ragdoll, animationCurves, textureChannels, cinematicCamera

        var id: String { rawValue }
    }

    struct SceneFeatureReport {
        var nodes = 0
        var geometries = 0
        var lights = 0
        var cameras = 0
        var particleSystems = 0
        var physicsBodies = 0
        var skinners = 0
        var morphers = 0
        var audioPlayers = 0
        var animations = 0
    }

    func availableEngineCapabilities() -> Set<EngineCapability> {
        [
            .sceneRendering, .pbrMaterials, .modelImport, .gltfImport,
            .skeletalAnimation, .morphTargets, .inverseKinematics,
            .animationLayers, .physics, .constraints, .particles,
            .postProcessing, .spatialAudio, .imageProcessing,
            .photoExport, .videoPipeline, .text3D, .boneEditing, .ragdoll, .animationCurves, .textureChannels, .cinematicCamera
        ]
    }

    func scanSceneFeatures() -> SceneFeatureReport {
        var report = SceneFeatureReport()
        scene.rootNode.enumerateChildNodes { node, _ in
            report.nodes += 1
            if node.geometry != nil { report.geometries += 1 }
            if node.light != nil { report.lights += 1 }
            if node.camera != nil { report.cameras += 1 }
            report.particleSystems += node.particleSystems?.count ?? 0
            if node.physicsBody != nil { report.physicsBodies += 1 }
            if node.skinner != nil { report.skinners += 1 }
            if node.morpher != nil { report.morphers += 1 }
            report.audioPlayers += node.audioPlayers.count
            report.animations += node.animationKeys.count
        }
        return report
    }

    func addLookAtConstraint(target: SCNNode, to node: SCNNode) {
        pushUndoSnapshot("Look At Constraint")
        let constraint = SCNLookAtConstraint(target: target)
        constraint.isGimbalLockEnabled = true
        node.constraints = (node.constraints ?? []) + [constraint]
        objectWillChange.send()
    }

    func addBillboardConstraint(to node: SCNNode) {
        pushUndoSnapshot("Billboard Constraint")
        let constraint = SCNBillboardConstraint()
        constraint.freeAxes = [.X, .Y]
        node.constraints = (node.constraints ?? []) + [constraint]
        objectWillChange.send()
    }

    func addDistanceConstraint(target: SCNNode, to node: SCNNode, minimum: CGFloat = 0, maximum: CGFloat = 10) {
        pushUndoSnapshot("Distance Constraint")
        let constraint = SCNDistanceConstraint(target: target)
        constraint.minimumDistance = minimum
        constraint.maximumDistance = maximum
        node.constraints = (node.constraints ?? []) + [constraint]
        objectWillChange.send()
    }

    func clearConstraints(on node: SCNNode) {
        pushUndoSnapshot("Clear Constraints")
        node.constraints = nil
        objectWillChange.send()
    }

    func setMorphWeight(_ weight: CGFloat, targetIndex: Int, on node: SCNNode) {
        guard let morpher = node.morpher,
              targetIndex >= 0,
              targetIndex < morpher.targets.count else { return }
        morpher.setWeight(weight, forTargetAt: targetIndex)
        objectWillChange.send()
    }

    func setPhysicsMode(_ mode: SCNPhysicsBodyType?, on node: SCNNode) {
        pushUndoSnapshot("Physics")
        guard let mode else {
            node.physicsBody = nil
            objectWillChange.send()
            return
        }
        let shape = SCNPhysicsShape(node: node, options: [
            SCNPhysicsShape.Option.keepAsCompound: true
        ])
        node.physicsBody = SCNPhysicsBody(type: mode, shape: shape)
        objectWillChange.send()
    }

    func addHingeJoint(
        nodeA: SCNNode,
        nodeB: SCNNode?,
        axis: SCNVector3 = SCNVector3(0, 1, 0),
        anchor: SCNVector3 = SCNVector3Zero
    ) {
        pushUndoSnapshot("Hinge Joint")
        let joint: SCNPhysicsHingeJoint
        if let bodyB = nodeB?.physicsBody, let bodyA = nodeA.physicsBody {
            joint = SCNPhysicsHingeJoint(
                bodyA: bodyA, axisA: axis, anchorA: anchor,
                bodyB: bodyB, axisB: axis, anchorB: anchor
            )
        } else if let bodyA = nodeA.physicsBody {
            joint = SCNPhysicsHingeJoint(body: bodyA, axis: axis, anchor: anchor)
        } else {
            toast = appLanguage == .arabic ? "فعّل الفيزياء للعنصر أولًا" : "Enable physics on the object first"
            return
        }
        scene.physicsWorld.addBehavior(joint)
    }



    // MARK: - Modeling / UV / Material Editing
    func duplicateSelectedNode() {
        guard let source = selectedNode else { return }
        pushUndoSnapshot("Duplicate")
        let copy = cleanDeepClone(source, copyGeometry: true)
        copy.name = nextName((source.name ?? "Object") + " Copy")
        copy.position.x += 0.35
        source.parent?.addChildNode(copy)
        select(copy)
        objectWillChange.send()
    }

    func centerPivotOnSelected() {
        guard let node = selectedNode else { return }
        pushUndoSnapshot("Center Pivot")
        let (minV, maxV) = node.boundingBox
        let center = SCNVector3(
            (minV.x + maxV.x) * 0.5,
            (minV.y + maxV.y) * 0.5,
            (minV.z + maxV.z) * 0.5
        )
        node.pivot = SCNMatrix4MakeTranslation(center.x, center.y, center.z)
        objectWillChange.send()
    }

    func resetSelectedTransform() {
        guard let node = selectedNode else { return }
        pushUndoSnapshot("Reset Transform")
        node.position = SCNVector3Zero
        node.eulerAngles = SCNVector3Zero
        node.scale = SCNVector3(1, 1, 1)
        objectWillChange.send()
    }

    func flipSelectedNormals() {
        guard let node = selectedNode else { return }
        pushUndoSnapshot("Flip Normals")
        node.enumerateChildNodes { child, _ in
            child.geometry?.materials.forEach { $0.isDoubleSided.toggle() }
        }
        node.geometry?.materials.forEach { $0.isDoubleSided.toggle() }
        objectWillChange.send()
    }

    func setSelectedSubdivision(_ level: Int) {
        guard let node = selectedNode else { return }
        pushUndoSnapshot("Subdivision")
        func apply(_ n: SCNNode) {
            n.geometry?.subdivisionLevel = max(0, min(5, level))
        }
        apply(node)
        node.enumerateChildNodes { child, _ in apply(child) }
        objectWillChange.send()
    }

    func setSelectedTessellationFactor(_ factor: CGFloat) {
        guard let node = selectedNode else { return }
        pushUndoSnapshot("Tessellation")
        func apply(_ n: SCNNode) {
            guard let geometry = n.geometry else { return }
            if geometry.tessellator == nil { geometry.tessellator = SCNGeometryTessellator() }
            geometry.tessellator?.tessellationFactorScale = max(1, min(16, factor))
        }
        apply(node)
        node.enumerateChildNodes { child, _ in apply(child) }
        objectWillChange.send()
    }

    func setUVTransform(
        scaleU: CGFloat,
        scaleV: CGFloat,
        offsetU: CGFloat,
        offsetV: CGFloat,
        rotation: CGFloat
    ) {
        guard let node = selectedNode else { return }
        pushUndoSnapshot("UV Transform")
        let transform =
            SCNMatrix4Mult(
                SCNMatrix4MakeTranslation(Float(offsetU), Float(offsetV), 0),
                SCNMatrix4Mult(
                    SCNMatrix4MakeRotation(Float(rotation), 0, 0, 1),
                    SCNMatrix4MakeScale(Float(scaleU), Float(scaleV), 1)
                )
            )
        func apply(_ n: SCNNode) {
            for material in n.geometry?.materials ?? [] {
                material.diffuse.contentsTransform = transform
                material.diffuse.wrapS = .repeat
                material.diffuse.wrapT = .repeat
                material.normal.contentsTransform = transform
                material.roughness.contentsTransform = transform
                material.metalness.contentsTransform = transform
                material.ambientOcclusion.contentsTransform = transform
            }
        }
        apply(node)
        node.enumerateChildNodes { child, _ in apply(child) }
        objectWillChange.send()
    }

    func applyPBRToSelected(
        color: UIColor,
        metalness: CGFloat,
        roughness: CGFloat,
        opacity: CGFloat
    ) {
        guard let node = selectedNode else { return }
        pushUndoSnapshot("PBR Material")
        func apply(_ n: SCNNode) {
            guard let geometry = n.geometry else { return }
            if geometry.materials.isEmpty { geometry.materials = [SCNMaterial()] }
            for material in geometry.materials {
                material.lightingModel = .physicallyBased
                material.diffuse.contents = color
                material.metalness.contents = metalness
                material.roughness.contents = roughness
                material.transparency = opacity
            }
        }
        apply(node)
        node.enumerateChildNodes { child, _ in apply(child) }
        objectWillChange.send()
    }

    // MARK: - Advanced Rig / Animation Tools
    struct BoneInfo: Identifiable, Hashable {
        let id: String
        let name: String
        let depth: Int
    }

    func bones(in root: SCNNode) -> [BoneInfo] {
        var output: [BoneInfo] = []
        func walk(_ node: SCNNode, depth: Int) {
            if node.skinner != nil || node.name?.localizedCaseInsensitiveContains("bone") == true ||
                node.name?.localizedCaseInsensitiveContains("joint") == true {
                output.append(BoneInfo(
                    id: "\(ObjectIdentifier(node).hashValue)",
                    name: node.name ?? "Bone",
                    depth: depth
                ))
            }
            node.childNodes.forEach { walk($0, depth: depth + 1) }
        }
        walk(root, depth: 0)
        return output
    }

    func addIKConstraint(
        to chainEnd: SCNNode,
        chainRoot: SCNNode,
        target: SCNNode,
        maxIterations: Int = 64
    ) {
        pushUndoSnapshot("IK")
        let ik = SCNIKConstraint(chainRootNode: chainRoot)
        // SceneKit exposes the rotation limit per joint, not as a writable property.
        ik.setMaxAllowedRotationAngle(CGFloat.pi, forJoint: chainRoot)
        chainEnd.constraints = (chainEnd.constraints ?? []) + [ik]
        ik.targetPosition = target.presentation.worldPosition
        chainEnd.setValue(target, forKey: "5lnIKTarget")
        chainEnd.setValue(maxIterations, forKey: "5lnIKIterations")
        objectWillChange.send()
    }

    func updateIKTargets() {
        contentRoot.enumerateChildNodes { node, _ in
            guard let target = node.value(forKey: "5lnIKTarget") as? SCNNode else { return }
            for constraint in node.constraints ?? [] {
                if let ik = constraint as? SCNIKConstraint {
                    ik.targetPosition = target.presentation.worldPosition
                }
            }
        }
    }

    func removeIK(from node: SCNNode) {
        pushUndoSnapshot("Remove IK")
        node.constraints = (node.constraints ?? []).filter { !($0 is SCNIKConstraint) }
        node.setValue(nil, forKey: "5lnIKTarget")
        objectWillChange.send()
    }

    func setBoneTransform(
        _ bone: SCNNode,
        position: SCNVector3? = nil,
        eulerAngles: SCNVector3? = nil,
        scale: SCNVector3? = nil
    ) {
        pushUndoSnapshot("Bone Transform")
        if let position { bone.position = position }
        if let eulerAngles { bone.eulerAngles = eulerAngles }
        if let scale { bone.scale = scale }
        objectWillChange.send()
    }

    // MARK: - Animation Curve Utilities
    enum CurveInterpolation: String, CaseIterable, Identifiable {
        case linear, easeIn, easeOut, easeInOut
        var id: String { rawValue }
    }

    func animateTransform(
        node: SCNNode,
        keyPath: String,
        from: Any?,
        to: Any,
        duration: TimeInterval,
        interpolation: CurveInterpolation = .easeInOut,
        loop: Bool = false
    ) {
        pushUndoSnapshot("Animation Curve")
        let a = CABasicAnimation(keyPath: keyPath)
        a.fromValue = from
        a.toValue = to
        a.duration = max(0.01, duration)
        a.repeatCount = loop ? .greatestFiniteMagnitude : 0
        a.isRemovedOnCompletion = false
        a.fillMode = .forwards
        switch interpolation {
        case .linear: a.timingFunction = CAMediaTimingFunction(name: .linear)
        case .easeIn: a.timingFunction = CAMediaTimingFunction(name: .easeIn)
        case .easeOut: a.timingFunction = CAMediaTimingFunction(name: .easeOut)
        case .easeInOut: a.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        }
        node.addAnimation(a, forKey: "5ln.curve.\(UUID().uuidString)")
    }

    // MARK: - Ragdoll / Physics Utilities
    func makeRagdoll(root: SCNNode) {
        pushUndoSnapshot("Ragdoll")
        var previousBodyNode: SCNNode?
        root.enumerateChildNodes { node, _ in
            let boneLike =
                node.name?.localizedCaseInsensitiveContains("bone") == true ||
                node.name?.localizedCaseInsensitiveContains("joint") == true
            guard boneLike else { return }

            if node.physicsBody == nil {
                let shape = SCNPhysicsShape(
                    geometry: SCNCapsule(capRadius: 0.06, height: 0.25),
                    options: nil
                )
                node.physicsBody = SCNPhysicsBody(type: .dynamic, shape: shape)
                node.physicsBody?.mass = 0.25
            }

            if let previous = previousBodyNode,
               let a = previous.physicsBody,
               let b = node.physicsBody {
                let joint = SCNPhysicsBallSocketJoint(
                    bodyA: a,
                    anchorA: SCNVector3Zero,
                    bodyB: b,
                    anchorB: SCNVector3Zero
                )
                scene.physicsWorld.addBehavior(joint)
            }
            previousBodyNode = node
        }
        objectWillChange.send()
    }

    // MARK: - Material / Texture Utilities
    func makePBRMaterial(
        baseColor: UIColor,
        metalness: CGFloat,
        roughness: CGFloat,
        emission: UIColor? = nil,
        opacity: CGFloat = 1
    ) -> SCNMaterial {
        let m = SCNMaterial()
        m.lightingModel = .physicallyBased
        m.diffuse.contents = baseColor
        m.metalness.contents = max(0, min(1, metalness))
        m.roughness.contents = max(0, min(1, roughness))
        m.transparency = max(0, min(1, opacity))
        m.blendMode = .alpha
        m.isDoubleSided = true
        if let emission {
            m.emission.contents = emission
            m.emission.intensity = 1
        }
        return m
    }

    func applyTexture(
        _ image: UIImage,
        channel: String,
        to node: SCNNode
    ) {
        pushUndoSnapshot("Texture")
        node.enumerateChildNodes { child, _ in
            guard let material = child.geometry?.firstMaterial else { return }
            switch channel {
            case "normal": material.normal.contents = image
            case "roughness": material.roughness.contents = image
            case "metalness": material.metalness.contents = image
            case "emission": material.emission.contents = image
            case "ao": material.ambientOcclusion.contents = image
            default: material.diffuse.contents = image
            }
        }
        if let material = node.geometry?.firstMaterial {
            switch channel {
            case "normal": material.normal.contents = image
            case "roughness": material.roughness.contents = image
            case "metalness": material.metalness.contents = image
            case "emission": material.emission.contents = image
            case "ao": material.ambientOcclusion.contents = image
            default: material.diffuse.contents = image
            }
        }
        objectWillChange.send()
    }


    func findNode(named name: String) -> SCNNode? {
        var result: SCNNode?
        scene.rootNode.enumerateChildNodes { node, stop in
            if node.name == name {
                result = node
                stop.pointee = true
            }
        }
        return result
    }

    func candidateRigNodes() -> [SCNNode] {
        var nodes: [SCNNode] = []
        contentRoot.enumerateChildNodes { node, stop in
            let n = (node.name ?? "").lowercased()
            if node.skinner != nil || n.contains("bone") || n.contains("joint") || n.contains("armature") {
                nodes.append(node)
            }
            if nodes.count >= 300 { stop.pointee = true }
        }
        return nodes
    }

    func morphTargetNames(for node: SCNNode) -> [String] {
        guard let morpher = node.morpher else { return [] }
        return morpher.targets.enumerated().map { index, target in
            target.name ?? "Morph \(index + 1)"
        }
    }

    func addSpringConstraint(to node: SCNNode) {
        pushUndoSnapshot("Spring")
        let spring = SCNDistanceConstraint(target: nil)
        spring.minimumDistance = 0
        spring.maximumDistance = 0.35
        node.constraints = (node.constraints ?? []) + [spring]
        objectWillChange.send()
    }

    // MARK: - Camera / Render Utilities
    func configureCinematicCamera(
        _ node: SCNNode,
        focalLength: CGFloat = 50,
        aperture: CGFloat = 5.6,
        focusDistance: CGFloat = 5
    ) {
        guard let camera = node.camera else { return }
        camera.focalLength = focalLength
        camera.fStop = aperture
        camera.focusDistance = focusDistance
        camera.wantsDepthOfField = true
        objectWillChange.send()
    }

    func snapshotViewport() -> UIImage? {
        scnView?.snapshot()
    }

    // Undo / Autosave
    @Published var undoCount = 0
    @Published var lastAutosaveText = "Autosave: waiting"
    @Published var isAutosaving = false

    // Import Monitor / Multi Select
    @Published var isImportMonitorPresented = false
    @Published var isVideoImporterPresented = false
    @Published var isAudioImporterPresented = false
    @Published var audioImportRunning = false
    let materialDoubleSided = NSMapTable<SCNMaterial, NSNumber>(keyOptions: .weakMemory, valueOptions: .strongMemory)
    let materialLighting = NSMapTable<SCNMaterial, NSString>(keyOptions: .weakMemory, valueOptions: .strongMemory)
    @Published var importIsRunning = false
    @Published var importCancellationRequested = false
    @Published var performanceMode = false
    var playbackStartClock: TimeInterval = 0
    var playbackStartTime: Double = 0

    func cancelImport() {
        guard importIsRunning else { return }
        importCancellationRequested = true
        statusText = appLanguage == .arabic ? "إيقاف بعد الملف الحالي…" : "Stopping after current file…"
    }

    func handleMemoryPressure() {
        undoStack.removeAll()
        redoStack.removeAll()
        transformUndoStack.removeAll()
        transformRedoStack.removeAll()
        materialUndoStack.removeAll()
        deleteUndoStack.removeAll()
        materialRedoStack.removeAll()
        deleteRedoStack.removeAll()
        timelineChannels = nil
        undoCount = 0
        redoCount = 0
        performanceMode = true
        refreshParticlePerformanceBudget()
        ciContext.clearCaches()
        stopPlayback()
        toast = "تم تخفيف المعاينة لتحرير الذاكرة / Preview reduced to free memory"
    }

    func refreshAdaptivePerformanceMode() {
        let profile = currentSceneLoadProfile(
            stopAfterNodes: 6_000,
            stopAfterVertices: 1_500_000,
            stopAfterTextureBytes: 224 * 1024 * 1024
        )
        // Keep ordinary projects at 60 fps. Only large scenes fall back to the
        // efficient 30 fps viewport; the user can still override the toggle.
        let shouldUseEfficientPreview =
            profile.nodes >= 2_500 ||
            profile.vertices >= 650_000 ||
            profile.textureBytes >= 128 * 1024 * 1024

        let canReturnToSmoothPreview =
            profile.nodes < 1_800 &&
            profile.vertices < 450_000 &&
            profile.textureBytes < 96 * 1024 * 1024

        if shouldUseEfficientPreview {
            performanceMode = true
        } else if canReturnToSmoothPreview {
            performanceMode = false
        }
    }

    func refreshParticlePerformanceBudget() {
        scene.rootNode.enumerateChildNodes { node, _ in
            guard let particle = node.particleSystems?.first else { return }
            let lowered = (node.name ?? "").lowercased()
            guard lowered.contains("rain") || lowered.contains("snow") || lowered.contains("particle") else { return }
            if performanceMode {
                particle.birthRate = min(particle.birthRate, 160)
            } else if lowered.contains("rain") {
                particle.birthRate = min(max(particle.birthRate, 180), 260)
            }
        }
    }
    @Published var importFileItems: [ImportFileItem] = []
    @Published var importNodeItems: [ImportNodeItem] = []
    @Published var importLoadedModels = 0
    @Published var importErrorCount = 0
    @Published var multiSelectedNodes: [SCNNode] = []

    // Audio / Media
    @Published var audioClips: [StudioAudioClip] = []
    @Published var masterAudioVolume: Double = 1.0
    @Published var audioPlaybackActive = false

    // Render Filter
    @Published var renderFilterPreset: RenderFilterPreset = .none
    @Published var renderFilterIntensity: Double = 1.0

    // Camera engine
    @Published var cameraFOV: Double = 55
    @Published var cameraExposure: Double = 0
    @Published var cameraBloom: Double = 0
    @Published var cameraBloomThreshold: Double = 1
    @Published var cameraBloomRadius: Double = 8
    @Published var cameraDOF = false
    @Published var cameraFocusDistance: Double = 5
    @Published var cameraFStop: Double = 5.6
    @Published var cameraVignette: Double = 0
    @Published var cameraChromatic: Double = 0
    @Published var cameraHDR = true

    // Shared stored state for split engine files
    @Published var animationLayers: [AnimationLayerInfo] = []

    let helperImportExtensions: Set<String> = [
        "bin", "mtl", "png", "jpg", "jpeg", "webp", "bmp",
        "tga", "gif", "tif", "tiff", "hdr", "exr", "ktx", "ktx2"
    ]

    var recoveryBlocksAutosave = false
    var projectOpeningCamera: SCNNode?
    var activeProjectRuntimeFolder: URL?
    weak var scnView: SCNView?
    var playbackTimer: Timer?
    var autosaveTimer: Timer?
    weak var selectionOutline: SCNNode?
    weak var selectionGizmo: SCNNode?

    // Prevent autosave from serializing while the scene graph is being mutated
    // by an active gizmo drag.
    var isTransformGestureActive = false

    struct UndoSnapshot {
        let label: String
        let timestamp: TimeInterval
        let content: SCNNode
        let cameras: SCNNode
        let lights: SCNNode
        let keyframes: [StudioKeyframe]
        let duration: Double
        let fps: Double
        let currentTime: Double
        let gridSpacing: Double
        let gridHalfCount: Double
        let showGrid: Bool
        let showAxes: Bool
        let showWorkPoint: Bool
        let ambientStrength: Double
        let fogEnabled: Bool
        let fogDensity: Double
        let activeCameraName: String?
        let environmentPreset: SceneEnvironmentPreset
        let environmentIntensity: Double
        let customEnvironmentImage: UIImage?
    }

    var undoStack: [UndoSnapshot] = []
    var redoStack: [UndoSnapshot] = []
    struct TransformHistoryState {
        let node: SCNNode
        let position: SCNVector3
        let orientation: simd_quatf
        let scale: SCNVector3
    }
    struct TransformHistoryCommand {
        let label: String
        let before: [TransformHistoryState]
        let after: [TransformHistoryState]
        let timestamp: TimeInterval = Date().timeIntervalSince1970
    }

    struct MaterialHistoryState {
        let material: SCNMaterial
        let diffuse: Any?
        let diffuseIntensity: CGFloat
        let multiply: Any?
        let transparent: Any?
        let metalness: Any?
        let roughness: Any?
        let emission: Any?
        let emissionIntensity: CGFloat
        let transparency: CGFloat
        let blendMode: SCNBlendMode
        let transparencyMode: SCNTransparencyMode
        let writesToDepthBuffer: Bool
        let readsFromDepthBuffer: Bool
        let isDoubleSided: Bool
        let cullMode: SCNCullMode
    }
    struct MaterialHistoryCommand {
        let label: String
        let key: String
        let before: [MaterialHistoryState]
        var after: [MaterialHistoryState]
        var timestamp: TimeInterval
    }
    var transformUndoStack: [TransformHistoryCommand] = []
    var transformRedoStack: [TransformHistoryCommand] = []
    var materialUndoStack: [MaterialHistoryCommand] = []
    var materialRedoStack: [MaterialHistoryCommand] = []

    // Deletion history is kept separately from full-scene snapshots. Restoring the
    // actual deleted subtree is both more reliable and cheaper than rebuilding the
    // complete SceneKit scene graph.
    struct DeletedNodeRecord {
        let parent: SCNNode
        let siblingIndex: Int
        let snapshot: SCNNode
    }
    final class DeleteHistoryCommand {
        let label: String
        let timestamp: TimeInterval
        let records: [DeletedNodeRecord]
        var restoredNodes: [SCNNode] = []
        init(label: String, records: [DeletedNodeRecord], timestamp: TimeInterval = Date().timeIntervalSince1970) {
            self.label = label
            self.records = records
            self.timestamp = timestamp
        }
    }
    var deleteUndoStack: [DeleteHistoryCommand] = []
    var deleteRedoStack: [DeleteHistoryCommand] = []
    // First-seen material state is the true imported/original material. Reset always returns here.
    var originalMaterialStates: [ObjectIdentifier: MaterialHistoryState] = [:]
    @Published var redoCount = 0

    // Internal hierarchy drag state. The NSItemProvider only starts the drag;
    // the real SCNNode stays in memory so reparenting keeps geometry/materials intact.
    var hierarchyDraggedNode: SCNNode?
    @Published var hierarchyDragIsActive = false

    var lastUndoSnapshotTime: TimeInterval = 0
    var lastUndoKey = ""

    let editorRoot = SCNNode()
    let contentRoot = SCNNode()
    let helpersRoot = SCNNode()
    let editorOnlyCategoryBit = 1 << 30
    let camerasRoot = SCNNode()
    let lightsRoot = SCNNode()

    let lockedCategoryBit = 1 << 29
    let ciContext = CIContext()

    let projectStorageOverride: URL?

    init(projectStorageURL: URL? = nil, restoreSavedProject: Bool = true, startTimer: Bool = true) {
        projectStorageOverride = projectStorageURL
        if let raw = UserDefaults.standard.string(forKey: "5LnStudioLanguage"),
           let saved = StudioLanguage(rawValue: raw) {
            appLanguage = saved
        }
        configureScene()
        // Recover the last committed complete document before any timer can
        // overwrite it with the starter scene on a fresh application launch.
        if restoreSavedProject { restoreAutosaveIfAvailable() }
        if startTimer { startAutosaveTimer() }
    }


    // MARK: - Project workspace

    struct ProjectCard: Identifiable, Hashable {
        let id: String
        let name: String
        let modified: Date
        let size: Int64
    }

    var projectsFolderURL: URL {
        let url = autosaveFolderURL.appendingPathComponent("Projects", isDirectory: true)
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }

    func projectCards() -> [ProjectCard] {
        let fm = FileManager.default
        let dirs = (try? fm.contentsOfDirectory(at: projectsFolderURL, includingPropertiesForKeys: [.contentModificationDateKey, .fileSizeKey], options: [.skipsHiddenFiles])) ?? []
        var cards = dirs.filter { $0.hasDirectoryPath }.compactMap { url in
            let current = url.appendingPathComponent("Project.3dmotion")
            let legacy = url.appendingPathComponent("Project.scn")
            let scene = fm.fileExists(atPath: current.path) ? current : legacy
            guard fm.fileExists(atPath: scene.path) else { return nil }
            let values = try? scene.resourceValues(forKeys: [.contentModificationDateKey, .fileSizeKey])
            return ProjectCard(id: url.lastPathComponent, name: url.lastPathComponent.removingPercentEncoding ?? url.lastPathComponent, modified: values?.contentModificationDate ?? .distantPast, size: Int64(values?.fileSize ?? 0))
        }.sorted { $0.modified > $1.modified }
        if fm.fileExists(atPath: autosaveProjectURL.path) {
            let values = try? autosaveProjectURL.resourceValues(forKeys: [.contentModificationDateKey, .fileSizeKey])
            cards.append(ProjectCard(id: "autosave://last", name: appLanguage == .arabic ? "آخر حفظ تلقائي" : "Last autosave",
                modified: values?.contentModificationDate ?? .distantPast, size: Int64(values?.fileSize ?? 0)))
        }
        return cards.sorted { $0.modified > $1.modified }
    }

    func newProject(named name: String = "Untitled Project") {
        recoveryBlocksAutosave = false
        stopPlayback(); select(nil); clearMultiSelection()
        contentRoot.childNodes.forEach { $0.removeFromParentNode() }
        camerasRoot.childNodes.forEach { $0.removeFromParentNode() }
        lightsRoot.childNodes.forEach { $0.removeFromParentNode() }
        clearProjectTransientState()
        keyframes.removeAll(); audioClips.removeAll(); animationLayers.removeAll()
        motionTrackNames.removeAll(); activeMotionTrackByNode.removeAll(); loopingMotionTrackIDs.removeAll()
        customEnvironmentImage = nil; environmentPreset = .none
        environmentIntensity = 1; applySceneEnvironment()
        currentTime = 0; duration = 60; currentProjectName = name
        addStarterObject(); rebuildHelpers()
        // A new project must open at the authored editor overview, not auto-frame the
        // starter cube. frameSelected() zoomed the viewport tightly around the cube.
        rebuildEditorViewportRig()
        resetEditorViewportCameraToOverview()
        // Project creation happens while the project library cover is still visible.
        // Re-assert the editor POV on the next run-loop after the cover starts dismissing
        // so a stale/removed SceneKit camera can never leave the workspace blank.
        DispatchQueue.main.async { [weak self] in
            self?.resetEditorViewportCameraToOverview()
        }
        saveAutosave(showToast: false)
    }

    func deleteProject(_ card: ProjectCard) {
        if card.id == "autosave://last" {
            try? FileManager.default.removeItem(at: autosaveProjectURL)
            try? FileManager.default.removeItem(at: ProjectFileStore.previous(autosaveProjectURL))
            return
        }
        try? FileManager.default.removeItem(at: projectsFolderURL.appendingPathComponent(card.id, isDirectory: true))
    }

    func resetFog() {
        fogEnabled = false
        fogDensity = 0.25
        fogColor = .gray
        applySceneSettings()
        toast = appLanguage == .arabic ? "تمت إعادة إعدادات الضباب" : "Fog settings reset"
    }

    func setViewportBackground(_ index: Int) {
        viewportBackgroundIndex = max(0, min(5, index))
        if environmentPreset == .none {
            let colors: [UIColor] = [.init(white: 0.12, alpha: 1), .black, .init(white: 0.22, alpha: 1), .init(white: 0.55, alpha: 1), .init(white: 0.92, alpha: 1), .init(red: 0.035, green: 0.07, blue: 0.13, alpha: 1)]
            scene.background.contents = colors[viewportBackgroundIndex]
        }
        objectWillChange.send()
    }

    func importVideoFiles(_ urls: [URL]) {
        guard let source = urls.first else { return }
        let access = source.startAccessingSecurityScopedResource(); defer { if access { source.stopAccessingSecurityScopedResource() } }
        let folder = autosaveFolderURL.appendingPathComponent("Video", isDirectory: true); try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let dst = folder.appendingPathComponent(UUID().uuidString + "-" + source.lastPathComponent)
        do { try? FileManager.default.removeItem(at: dst); try FileManager.default.copyItem(at: source, to: dst) } catch { toast = error.localizedDescription; return }
        let player = AVPlayer(url: dst); player.actionAtItemEnd = .pause
        let plane = SCNPlane(width: 4.8, height: 2.7); let mat = SCNMaterial(); mat.diffuse.contents = player; mat.isDoubleSided = true; mat.lightingModel = .constant; plane.materials = [mat]
        let node = SCNNode(geometry: plane); node.name = "Video • " + source.deletingPathExtension().lastPathComponent; node.position = SCNVector3(0, 1.8, 0); contentRoot.addChildNode(node); select(node); player.play()
        toast = appLanguage == .arabic ? "تمت إضافة الفيديو للمشهد" : "Video added to scene"
    }

    // MARK: - Undo / Autosave

    var autosaveFolderURL: URL {
        if let override = projectStorageOverride {
            try? FileManager.default.createDirectory(at: override, withIntermediateDirectories: true)
            return override
        }
        let base = FileManager.default.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        ).first ?? FileManager.default.temporaryDirectory

        let folder = base.appendingPathComponent(
            "5Ln3DStudio",
            isDirectory: true
        )

        try? FileManager.default.createDirectory(
            at: folder,
            withIntermediateDirectories: true
        )

        return folder
    }

    var autosaveSceneURL: URL {
        autosaveFolderURL.appendingPathComponent("Autosave.scn")
    }

    var autosaveMetadataURL: URL {
        autosaveFolderURL.appendingPathComponent("Autosave.json")
    }

    var autosaveEnvironmentURL: URL {
        autosaveFolderURL.appendingPathComponent("Environment.jpg")
    }

    var audioFolderURL: URL {
        let url = autosaveFolderURL.appendingPathComponent(
            "Audio",
            isDirectory: true
        )

        try? FileManager.default.createDirectory(
            at: url,
            withIntermediateDirectories: true
        )

        return url
    }

    func cleanDeepClone(
        _ source: SCNNode,
        copyGeometry: Bool = true
    ) -> SCNNode {
        let clone = source.clone()
        func copyComponents(_ node: SCNNode) {
            if let camera = node.camera { node.camera = camera.copy() as? SCNCamera }
            if let light = node.light { node.light = light.copy() as? SCNLight }
            let particles = node.particleSystems ?? []
            node.removeAllParticleSystems()
            for particle in particles {
                if let copy = particle.copy() as? SCNParticleSystem { node.addParticleSystem(copy) }
            }
        }
        copyComponents(clone)
        clone.enumerateChildNodes { node, _ in copyComponents(node) }

        if copyGeometry {
            func copyGeometryStateRecursively(_ node: SCNNode) {
                if let geometry = node.geometry,
                   let geometryCopy = geometry.copy() as? SCNGeometry {
                    geometryCopy.materials = geometry.materials.compactMap {
                        $0.copy() as? SCNMaterial
                    }
                    node.geometry = geometryCopy
                }
                for child in node.childNodes {
                    copyGeometryStateRecursively(child)
                }
            }
            copyGeometryStateRecursively(clone)
        }

        var editorNodes: [SCNNode] = []
        clone.enumerateChildNodes { node, _ in
            let name = node.name ?? ""
            if name == "_SelectionOutline" ||
               name == "_TransformGizmo" ||
               name.hasPrefix("GizmoHandle_") {
                editorNodes.append(node)
            }
        }
        editorNodes.forEach { $0.removeFromParentNode() }

        return clone
    }

    struct SceneLoadProfile {
        var nodes = 0
        var vertices = 0
        var materialSlots = 0
        var textureBytes = 0
    }

    func currentSceneLoadProfile(
        stopAfterNodes: Int = 20_000,
        stopAfterVertices: Int = 3_000_000,
        stopAfterTextureBytes: Int = 512 * 1024 * 1024
    ) -> SceneLoadProfile {
        var profile = SceneLoadProfile()
        var seenImages = Set<ObjectIdentifier>()
        var seenSources = Set<ObjectIdentifier>()

        contentRoot.enumerateChildNodes { node, stop in
            profile.nodes += 1

            if let geometry = node.geometry {
                if let source = geometry.sources(for: .vertex).first,
                   seenSources.insert(ObjectIdentifier(source)).inserted {
                    profile.vertices += source.vectorCount
                }

                for material in geometry.materials {
                    profile.materialSlots += 1

                    let properties: [SCNMaterialProperty] = [
                        material.diffuse,
                        material.normal,
                        material.emission,
                        material.roughness,
                        material.metalness,
                        material.ambientOcclusion
                    ]

                    for property in properties {
                        // SCNMaterialProperty.contents is Any?. Avoid conditional casts
                        // directly to CoreFoundation CGImage under Swift 6 because the
                        // compiler diagnoses that cast as always succeeding. UIImage is
                        // the normal iOS texture container and is sufficient for the
                        // memory-pressure estimate used by this profile.
                        if let image = property.contents as? UIImage,
                           seenImages.insert(ObjectIdentifier(image)).inserted,
                           let cg = image.cgImage {
                            profile.textureBytes += cg.width * cg.height * 4
                        }
                    }
                }
            }

            if profile.nodes >= stopAfterNodes ||
               profile.vertices >= stopAfterVertices ||
               profile.textureBytes >= stopAfterTextureBytes {
                stop.pointee = true
            }
        }

        return profile
    }

    func currentUndoSnapshot(
        label: String,
        copyGeometry: Bool,
        timestamp: TimeInterval = Date().timeIntervalSince1970
    ) -> UndoSnapshot {
        UndoSnapshot(
            label: label,
            timestamp: timestamp,
            content: cleanDeepClone(
                contentRoot,
                copyGeometry: copyGeometry
            ),
            cameras: cleanDeepClone(
                camerasRoot,
                copyGeometry: false
            ),
            lights: cleanDeepClone(
                lightsRoot,
                copyGeometry: false
            ),
            keyframes: keyframes,
            duration: duration,
            fps: fps,
            currentTime: currentTime,
            gridSpacing: gridSpacing,
            gridHalfCount: gridHalfCount,
            showGrid: showGrid,
            showAxes: showAxes,
            showWorkPoint: showWorkPoint,
            ambientStrength: ambientStrength,
            fogEnabled: fogEnabled,
            fogDensity: fogDensity,
            activeCameraName: scnView?.pointOfView?.name,
            environmentPreset: environmentPreset,
            environmentIntensity: environmentIntensity,
            customEnvironmentImage: customEnvironmentImage
        )
    }

    func pushUndoSnapshot(_ label: String) {
        let profile = currentSceneLoadProfile(
            stopAfterNodes: 6_000,
            stopAfterVertices: 1_000_000,
            stopAfterTextureBytes: 192 * 1024 * 1024
        )

        // Full geometry/material duplication is one of the largest memory spikes
        // in a 3D editor. For imported projects, keep an undo snapshot of the
        // node hierarchy and transforms while sharing heavy geometry/textures.
        // Deletion undo must preserve the exact visual object state.
        // Always deep-copy geometry/materials for delete snapshots so Undo restores
        // the same mesh, materials, textures and visibility instead of a shared shell.
        let isDeleteSnapshot = label.hasPrefix("Delete")
        let canCopyGeometry =
            isDeleteSnapshot ||
            (profile.nodes < 1_500 &&
             profile.vertices < 250_000 &&
             profile.textureBytes < 96 * 1024 * 1024)

        // Extremely large hierarchies are not safe to duplicate at all.
        guard profile.nodes < 6_000 else {
            return
        }

        undoStack.append(
            currentUndoSnapshot(
                label: label,
                copyGeometry: canCopyGeometry
            )
        )

        redoStack.removeAll()
        transformRedoStack.removeAll()
        materialRedoStack.removeAll()
        deleteRedoStack.removeAll()
        redoCount = 0

        // Imported scenes can still hold large node trees even when geometry is
        // shared, so keep fewer snapshots when the scene is heavy.
        let maximumUndoCount =
            (profile.vertices >= 250_000 ||
             profile.textureBytes >= 96 * 1024 * 1024 ||
             profile.nodes >= 1_500)
            ? 3
            : 10

        if undoStack.count > maximumUndoCount {
            undoStack.removeFirst(
                undoStack.count - maximumUndoCount
            )
        }

        undoCount = undoStack.count + transformUndoStack.count + materialUndoStack.count
        lastUndoSnapshotTime = Date().timeIntervalSince1970
        lastUndoKey = label
    }

    func pushUndoSnapshotIfReasonable(_ label: String) {
        // pushUndoSnapshot performs the memory-safety decision centrally so
        // every tool gets the same protection.
        pushUndoSnapshot(label)
    }

    func pushUndoSnapshotThrottled(
        label: String,
        key: String,
        minimumInterval: TimeInterval = 0.7
    ) {
        let now = Date().timeIntervalSince1970

        if lastUndoKey == key,
           now - lastUndoSnapshotTime < minimumInterval {
            return
        }

        pushUndoSnapshot(label)
        lastUndoKey = key
        lastUndoSnapshotTime = now
    }

    func restoreHistorySnapshot(_ snapshot: UndoSnapshot) {
        selectionOutline?.removeFromParentNode()
        selectionGizmo?.removeFromParentNode()
        selectionOutline = nil
        selectionGizmo = nil
        multiSelectedNodes.removeAll()

        restoreChildren(of: contentRoot, from: snapshot.content)
        restoreChildren(of: camerasRoot, from: snapshot.cameras)
        restoreChildren(of: lightsRoot, from: snapshot.lights)

        keyframes = snapshot.keyframes
        duration = snapshot.duration
        fps = snapshot.fps
        currentTime = snapshot.currentTime
        gridSpacing = snapshot.gridSpacing
        gridHalfCount = snapshot.gridHalfCount
        showGrid = snapshot.showGrid
        showAxes = snapshot.showAxes
        showWorkPoint = snapshot.showWorkPoint
        ambientStrength = snapshot.ambientStrength
        fogEnabled = snapshot.fogEnabled
        fogDensity = snapshot.fogDensity
        environmentPreset = snapshot.environmentPreset
        environmentIntensity = snapshot.environmentIntensity
        customEnvironmentImage = snapshot.customEnvironmentImage

        rebuildHelpers()
        applySceneSettings()
        applySceneEnvironment()

        if let name = snapshot.activeCameraName,
           name == editorViewportCamera?.name,
           let editorViewportCamera {
            scnView?.pointOfView = editorViewportCamera
        } else if let name = snapshot.activeCameraName,
                  let camera = camerasRoot.childNode(withName: name, recursively: true),
                  camera.camera != nil {
            scnView?.pointOfView = camera
        } else if let camera = camerasRoot.childNodes.first(where: { $0.camera != nil }) {
            scnView?.pointOfView = camera
        } else if let editorViewportCamera {
            scnView?.pointOfView = editorViewportCamera
        }

        select(nil)
        viewportInteractionMode = .view
        objectWillChange.send()
    }

    var pendingTransformHistory: [TransformHistoryState] = []

    func beginTransformHistory(_ nodes: [SCNNode]) {
        pendingTransformHistory = nodes.map {
            TransformHistoryState(
                node: $0,
                position: $0.position,
                orientation: $0.simdOrientation,
                scale: $0.scale
            )
        }
    }

    func cancelTransformHistory() {
        pendingTransformHistory.removeAll()
    }

    func endTransformHistory(label: String = "Transform") {
        guard !pendingTransformHistory.isEmpty else { return }

        var after: [TransformHistoryState] = []
        after.reserveCapacity(pendingTransformHistory.count)
        for state in pendingTransformHistory {
            after.append(
                TransformHistoryState(
                    node: state.node,
                    position: state.node.position,
                    orientation: state.node.simdOrientation,
                    scale: state.node.scale
                )
            )
        }

        let command = TransformHistoryCommand(
            label: label,
            before: pendingTransformHistory,
            after: after
        )
        transformUndoStack.append(command)
        if transformUndoStack.count > 40 {
            transformUndoStack.removeFirst(transformUndoStack.count - 40)
        }

        pendingTransformHistory.removeAll()
        transformRedoStack.removeAll()
        materialRedoStack.removeAll()
        deleteRedoStack.removeAll()
        redoStack.removeAll()
        undoCount = undoStack.count + transformUndoStack.count + materialUndoStack.count
        redoCount = 0
    }

    func applyTransformStates(_ states: [TransformHistoryState]) {
        SCNTransaction.begin()
        SCNTransaction.disableActions = true
        for state in states {
            state.node.position = state.position
            state.node.simdOrientation = state.orientation
            state.node.scale = state.scale
        }
        SCNTransaction.commit()
        refreshSelectionGizmo()
        objectWillChange.send()
    }

    func captureMaterialHistory(_ materials: [SCNMaterial]) -> [MaterialHistoryState] {
        materials.map { material in
            MaterialHistoryState(
                material: material,
                diffuse: material.diffuse.contents,
                diffuseIntensity: material.diffuse.intensity,
                multiply: material.multiply.contents,
                transparent: material.transparent.contents,
                metalness: material.metalness.contents,
                roughness: material.roughness.contents,
                emission: material.emission.contents,
                emissionIntensity: material.emission.intensity,
                transparency: material.transparency,
                blendMode: material.blendMode,
                transparencyMode: material.transparencyMode,
                writesToDepthBuffer: material.writesToDepthBuffer,
                readsFromDepthBuffer: material.readsFromDepthBuffer,
                isDoubleSided: material.isDoubleSided,
                cullMode: material.cullMode
            )
        }
    }

    func applyMaterialHistory(_ states: [MaterialHistoryState]) {
        SCNTransaction.begin()
        SCNTransaction.animationDuration = 0
        for state in states {
            state.material.diffuse.contents = state.diffuse
            state.material.diffuse.intensity = state.diffuseIntensity
            state.material.multiply.contents = state.multiply
            state.material.transparent.contents = state.transparent
            state.material.metalness.contents = state.metalness
            state.material.roughness.contents = state.roughness
            state.material.emission.contents = state.emission
            state.material.emission.intensity = state.emissionIntensity
            state.material.transparency = state.transparency
            state.material.blendMode = state.blendMode
            state.material.transparencyMode = state.transparencyMode
            state.material.writesToDepthBuffer = state.writesToDepthBuffer
            state.material.readsFromDepthBuffer = state.readsFromDepthBuffer
            state.material.isDoubleSided = state.isDoubleSided
            state.material.cullMode = state.cullMode
        }
        SCNTransaction.commit()
        objectWillChange.send()
    }

    func rememberOriginalMaterials(_ materials: [SCNMaterial]) {
        for state in captureMaterialHistory(materials) {
            let key = ObjectIdentifier(state.material)
            if originalMaterialStates[key] == nil { originalMaterialStates[key] = state }
        }
    }

    func resetMaterialsToOriginal(_ materials: [SCNMaterial]) {
        guard !materials.isEmpty else { return }
        rememberOriginalMaterials(materials)
        let states = materials.compactMap { originalMaterialStates[ObjectIdentifier($0)] }
        recordMaterialEdit(label: "Restore Original Material", key: "material-original", materials: materials) {
            applyMaterialHistory(states)
        }
        toast = appLanguage == .arabic ? "تمت استعادة الخامة الأصلية" : "Original material restored"
    }

    func recordMaterialEdit(label: String, key: String, materials: [SCNMaterial], change: () -> Void) {
        guard !materials.isEmpty else { return }
        rememberOriginalMaterials(materials)
        let before = captureMaterialHistory(materials)
        change()
        let after = captureMaterialHistory(materials)
        let now = Date().timeIntervalSince1970

        if var last = materialUndoStack.last,
           last.key == key,
           now - last.timestamp < 0.7 {
            last.after = after
            last.timestamp = now
            materialUndoStack[materialUndoStack.count - 1] = last
        } else {
            materialUndoStack.append(MaterialHistoryCommand(label: label, key: key, before: before, after: after, timestamp: now))
            if materialUndoStack.count > 80 { materialUndoStack.removeFirst(materialUndoStack.count - 80) }
        }
        materialRedoStack.removeAll()
        deleteRedoStack.removeAll()
        undoCount = undoStack.count + transformUndoStack.count + materialUndoStack.count
        redoCount = redoStack.count + transformRedoStack.count + materialRedoStack.count
    }

    func undoLast() {
        let sceneTime = undoStack.last?.timestamp ?? -.infinity
        let transformTime = transformUndoStack.last?.timestamp ?? -.infinity
        let materialTime = materialUndoStack.last?.timestamp ?? -.infinity
        let deleteTime = deleteUndoStack.last?.timestamp ?? -.infinity

        if deleteTime >= sceneTime, deleteTime >= transformTime, deleteTime >= materialTime,
           let command = deleteUndoStack.popLast() {
            var restored: [SCNNode] = []
            for record in command.records {
                let node = cleanDeepClone(record.snapshot, copyGeometry: true)
                record.parent.insertChildNode(node, at: min(record.siblingIndex, record.parent.childNodes.count))
                restored.append(node)
            }
            command.restoredNodes = restored
            deleteRedoStack.append(command)
            if restored.count == 1 { select(restored[0]) } else { selectMultiple(restored) }
            objectWillChange.send()
            undoCount = undoStack.count + transformUndoStack.count + materialUndoStack.count + deleteUndoStack.count
            redoCount = redoStack.count + transformRedoStack.count + materialRedoStack.count + deleteRedoStack.count
            statusText = "Undo • \(command.label)"
            toast = appLanguage == .arabic ? "تم التراجع واستعادة العنصر" : "Deleted object restored"
            return
        }

        if sceneTime >= transformTime, sceneTime >= materialTime, let snapshot = undoStack.popLast() {
            // Capture the scene exactly as it is now so Redo can restore the deletion,
            // grouping or hierarchy change that is being undone. Keep the original
            // operation timestamp so a single-step Undo/Redo behaves predictably.
            let redoSnapshot = currentUndoSnapshot(
                label: snapshot.label,
                copyGeometry: false,
                timestamp: snapshot.timestamp
            )
            redoStack.append(redoSnapshot)
            restoreHistorySnapshot(snapshot)
            undoCount = undoStack.count + transformUndoStack.count + materialUndoStack.count
            redoCount = redoStack.count + transformRedoStack.count + materialRedoStack.count
            statusText = "Undo • \(snapshot.label)"
            toast = appLanguage == .arabic ? "تم التراجع واستعادة العنصر" : "Undo complete"
            return
        }

        if materialTime >= transformTime, let command = materialUndoStack.popLast() {
            applyMaterialHistory(command.before)
            materialRedoStack.append(command)
            undoCount = undoStack.count + transformUndoStack.count + materialUndoStack.count
            redoCount = redoStack.count + transformRedoStack.count + materialRedoStack.count
            statusText = "Undo • \(command.label)"
            toast = appLanguage == .arabic ? "تم التراجع عن تعديل الخامة" : "Material change undone"
            return
        }

        guard let command = transformUndoStack.popLast() else {
            toast = appLanguage == .arabic ? "لا يوجد تعديل للتراجع عنه" : "Nothing to undo"
            undoCount = undoStack.count + transformUndoStack.count + materialUndoStack.count
            redoCount = redoStack.count + transformRedoStack.count + materialRedoStack.count
            return
        }
        applyTransformStates(command.before)
        transformRedoStack.append(command)
        undoCount = undoStack.count + transformUndoStack.count + materialUndoStack.count
        redoCount = redoStack.count + transformRedoStack.count + materialRedoStack.count
        statusText = "Undo • \(command.label)"
        toast = appLanguage == .arabic ? "تم التراجع عن آخر تعديل" : "Undo complete"
    }

    func redoLast() {
        let sceneTime = redoStack.last?.timestamp ?? -.infinity
        let transformTime = transformRedoStack.last?.timestamp ?? -.infinity
        let materialTime = materialRedoStack.last?.timestamp ?? -.infinity
        let deleteTime = deleteRedoStack.last?.timestamp ?? -.infinity

        if deleteTime >= sceneTime, deleteTime >= transformTime, deleteTime >= materialTime,
           let command = deleteRedoStack.popLast() {
            for node in command.restoredNodes { node.removeFromParentNode() }
            command.restoredNodes.removeAll()
            deleteUndoStack.append(command)
            select(nil)
            objectWillChange.send()
            undoCount = undoStack.count + transformUndoStack.count + materialUndoStack.count + deleteUndoStack.count
            redoCount = redoStack.count + transformRedoStack.count + materialRedoStack.count + deleteRedoStack.count
            statusText = "Redo • \(command.label)"
            toast = appLanguage == .arabic ? "تمت إعادة الحذف" : "Deletion redone"
            return
        }

        if sceneTime >= transformTime, sceneTime >= materialTime, let snapshot = redoStack.popLast() {
            let undoSnapshot = currentUndoSnapshot(
                label: snapshot.label,
                copyGeometry: false,
                timestamp: snapshot.timestamp
            )
            undoStack.append(undoSnapshot)
            restoreHistorySnapshot(snapshot)
            undoCount = undoStack.count + transformUndoStack.count + materialUndoStack.count
            redoCount = redoStack.count + transformRedoStack.count + materialRedoStack.count
            statusText = "Redo • \(snapshot.label)"
            toast = appLanguage == .arabic ? "تمت إعادة العملية" : "Redo complete"
            return
        }

        if materialTime >= transformTime, let command = materialRedoStack.popLast() {
            applyMaterialHistory(command.after)
            materialUndoStack.append(command)
            undoCount = undoStack.count + transformUndoStack.count + materialUndoStack.count
            redoCount = redoStack.count + transformRedoStack.count + materialRedoStack.count
            statusText = "Redo • \(command.label)"
            toast = appLanguage == .arabic ? "تمت إعادة تعديل الخامة" : "Material change redone"
            return
        }

        guard let command = transformRedoStack.popLast() else {
            toast = appLanguage == .arabic ? "لا يوجد تعديل لإعادته" : "Nothing to redo"
            undoCount = undoStack.count + transformUndoStack.count + materialUndoStack.count
            redoCount = redoStack.count + transformRedoStack.count + materialRedoStack.count
            return
        }
        applyTransformStates(command.after)
        transformUndoStack.append(command)
        undoCount = undoStack.count + transformUndoStack.count + materialUndoStack.count
        redoCount = redoStack.count + transformRedoStack.count + materialRedoStack.count
        statusText = "Redo • \(command.label)"
        toast = appLanguage == .arabic ? "تمت إعادة آخر تعديل" : "Redo complete"
    }

    func startAutosaveTimer() {
        autosaveTimer?.invalidate()
        autosaveTimer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { [weak self] _ in
            Task { @MainActor in
                guard let self, !self.importIsRunning, !self.isPlaying else { return }
                self.saveAutosave(showToast: false)
            }
        }
    }

    func restoreChildren(of destination: SCNNode, from source: SCNNode) {
        destination.childNodes.forEach { $0.removeFromParentNode() }
        // Undo must restore the complete visual state, not just the node tree.
        // Deep-copy geometry + materials so restored objects never share a mutable
        // material instance with a deleted/edited object (the old cause of white restores).
        for child in source.childNodes {
            destination.addChildNode(cleanDeepClone(child, copyGeometry: true))
        }
    }

    func configureScene() {
        scene.rootNode.addChildNode(contentRoot)
        scene.rootNode.addChildNode(editorRoot)
        scene.rootNode.addChildNode(helpersRoot)
        scene.rootNode.addChildNode(camerasRoot)
        scene.rootNode.addChildNode(lightsRoot)

        contentRoot.name = "Scene"
        editorRoot.name = "_Editor"
        helpersRoot.name = "_Helpers"
        camerasRoot.name = "Cameras"
        lightsRoot.name = "Lights"

        scene.background.contents = UIColor(white: 0.12, alpha: 1)

        // Scene cameras and lights are user-created objects. The viewport uses its
        // own editor camera/light rig and they must not appear in the project tree.
        // Keeping this rig inside editorRoot also means it is automatically excluded
        // from project export/autosave scene content.
        rebuildEditorViewportRig()
        rebuildHelpers()
        addStarterObject()
        applyViewportSettings()
        applySceneEnvironment()
    }

    /// Private editor-only camera + neutral light rig. The user's project tree stays
    /// completely free of cameras/lights until they explicitly add them, while PBR
    /// imports still retain visible colors/materials in the viewport.
    func rebuildEditorViewportRig() {
        let names: Set<String> = [
            "_ViewportCamera",
            "_ViewportKeyLight",
            "_ViewportFillLight",
            "_ViewportRimLight",
            "_ViewportAmbientLight"
        ]

        editorRoot.childNodes
            .filter { names.contains($0.name ?? "") }
            .forEach { $0.removeFromParentNode() }

        let cameraNode = SCNNode()
        cameraNode.name = "_ViewportCamera"
        let camera = SCNCamera()
        camera.fieldOfView = 50
        camera.zNear = 0.01
        camera.zFar = 100_000
        camera.wantsHDR = true
        camera.bloomIntensity = 0
        camera.wantsDepthOfField = false
        // The editor viewport must render editor-only overlays (selection box,
        // transform helpers, camera/light markers). Export/project cameras keep
        // excluding editorOnlyCategoryBit, but the viewport camera must include it.
        camera.categoryBitMask = Int.max
        cameraNode.camera = camera
        cameraNode.position = SCNVector3(15.5, 10.0, 20.5)
        cameraNode.studioLook(at: SCNVector3(0, 0.65, 0))
        editorRoot.addChildNode(cameraNode)

        let keyNode = SCNNode()
        keyNode.name = "_ViewportKeyLight"
        let key = SCNLight()
        key.type = .directional
        key.intensity = CGFloat(max(0.15, viewportKeyStrength) * 1050)
        key.color = UIColor(white: 1.0, alpha: 1)
        key.castsShadow = false
        key.categoryBitMask = Int.max ^ editorOnlyCategoryBit
        keyNode.light = key
        keyNode.eulerAngles = SCNVector3(-0.82, 0.72, 0)
        editorRoot.addChildNode(keyNode)

        let fillNode = SCNNode()
        fillNode.name = "_ViewportFillLight"
        let fill = SCNLight()
        fill.type = .omni
        fill.intensity = CGFloat(max(0.08, viewportFillStrength) * 850)
        fill.color = UIColor(white: 0.82, alpha: 1)
        fill.castsShadow = false
        fill.categoryBitMask = Int.max ^ editorOnlyCategoryBit
        fillNode.light = fill
        fillNode.position = SCNVector3(-4.5, 3.6, 5.0)
        editorRoot.addChildNode(fillNode)

        let rimNode = SCNNode()
        rimNode.name = "_ViewportRimLight"
        let rim = SCNLight()
        rim.type = .directional
        rim.intensity = CGFloat(max(0.05, viewportRimStrength) * 700)
        rim.color = UIColor(white: 0.75, alpha: 1)
        rim.castsShadow = false
        rim.categoryBitMask = Int.max ^ editorOnlyCategoryBit
        rimNode.light = rim
        rimNode.eulerAngles = SCNVector3(-0.45, -2.15, 0)
        editorRoot.addChildNode(rimNode)

        let ambientNode = SCNNode()
        ambientNode.name = "_ViewportAmbientLight"
        let ambient = SCNLight()
        ambient.type = .ambient
        ambient.intensity = CGFloat(max(180, min(520, ambientStrength)))
        ambient.color = UIColor(white: 0.56, alpha: 1)
        ambient.categoryBitMask = Int.max ^ editorOnlyCategoryBit
        ambientNode.light = ambient
        editorRoot.addChildNode(ambientNode)
    }

    var editorViewportCamera: SCNNode? {
        editorRoot.childNode(withName: "_ViewportCamera", recursively: false)
    }

    func addDefaultCamera() {
        let cameraNode = SCNNode()
        cameraNode.name = "Camera 1"
        cameraNode.camera = SCNCamera()
        cameraNode.camera?.fieldOfView = 55
        cameraNode.camera?.zNear = 0.01
        cameraNode.camera?.zFar = 100_000
        cameraNode.camera?.wantsHDR = true
        cameraNode.camera?.bloomIntensity = 0
        cameraNode.camera?.wantsDepthOfField = false
        cameraNode.camera?.categoryBitMask = Int.max ^ editorOnlyCategoryBit
        cameraNode.position = SCNVector3(0, 2.6, 7.5)
        cameraNode.eulerAngles = SCNVector3(-0.22, 0, 0)
        camerasRoot.addChildNode(cameraNode)
        installEditorMarker(for: cameraNode)
    }

    func addDefaultLights() {
        let key = SCNNode()
        key.name = "Key Light"
        key.light = SCNLight()
        key.light?.type = .directional
        key.light?.intensity = 1200
        key.light?.castsShadow = true
        key.light?.shadowRadius = 6
        key.light?.shadowSampleCount = 8
        key.eulerAngles = SCNVector3(-0.9, 0.75, 0)
        lightsRoot.addChildNode(key)

        let fill = SCNNode()
        fill.name = "Fill Light"
        fill.light = SCNLight()
        fill.light?.type = .omni
        fill.light?.intensity = 700
        fill.light?.color = UIColor(white: 0.75, alpha: 1)
        fill.position = SCNVector3(-3, 2.5, 4)
        lightsRoot.addChildNode(fill)

        let rim = SCNNode()
        rim.name = "Rim Light"
        rim.light = SCNLight()
        rim.light?.type = .directional
        rim.light?.intensity = CGFloat(viewportRimStrength * 1400)
        rim.light?.color = UIColor(white: 0.90, alpha: 1)
        rim.eulerAngles = SCNVector3(-0.55, -2.2, 0)
        lightsRoot.addChildNode(rim)

        let ambient = SCNNode()
        ambient.name = "Ambient"
        ambient.light = SCNLight()
        ambient.light?.type = .ambient
        ambient.light?.intensity = CGFloat(ambientStrength)
        ambient.light?.color = UIColor(white: 0.45, alpha: 1)
        lightsRoot.addChildNode(ambient)

        [key, fill, rim, ambient].forEach { installEditorMarker(for: $0) }
    }

    func addStarterObject() {
        // The starter floor is intentionally large and double-sided so the workspace
        // never opens as an empty flat background when the editor camera is above or
        // temporarily crosses below the ground plane. The grid is rendered just above it.
        let floor = SCNNode(geometry: SCNPlane(width: 200, height: 200))
        floor.name = "Ground"
        floor.eulerAngles.x = -.pi / 2
        floor.geometry?.firstMaterial?.diffuse.contents = UIColor(white: 0.16, alpha: 1)
        floor.geometry?.firstMaterial?.roughness.contents = 0.94
        floor.geometry?.firstMaterial?.metalness.contents = 0.02
        floor.geometry?.firstMaterial?.isDoubleSided = true
        floor.castsShadow = false
        floor.physicsBody = SCNPhysicsBody(type: .static, shape: nil)
        contentRoot.addChildNode(floor)

        let cube = SCNNode(geometry: SCNBox(width: 1.4, height: 1.4, length: 1.4, chamferRadius: 0.08))
        cube.name = "Cube"
        cube.position = SCNVector3(0, 0.72, 0)
        cube.geometry?.firstMaterial?.diffuse.contents = UIColor(red: 0.19, green: 0.42, blue: 0.98, alpha: 1)
        cube.geometry?.firstMaterial?.metalness.contents = 0.25
        cube.geometry?.firstMaterial?.roughness.contents = 0.28
        contentRoot.addChildNode(cube)

        select(cube)
    }

    func repairLegacyStarterCubeMaterialIfNeeded() {
        let migrationKey = "FiveLn3DStudio.LegacyStarterCubeMaterial.v32"
        guard !UserDefaults.standard.bool(forKey: migrationKey) else { return }
        defer { UserDefaults.standard.set(true, forKey: migrationKey) }

        let projectNodes = contentRoot.childNodes.filter { node in
            let name = node.name ?? ""
            return !name.hasPrefix("_")
        }

        // Only migrate the untouched starter scene. Never recolor a real project.
        guard projectNodes.count <= 2,
              let cube = projectNodes.first(where: { $0.name == "Cube" }),
              cube.geometry is SCNBox,
              let material = cube.geometry?.firstMaterial else {
            return
        }

        var shouldRepair = false
        if let color = material.diffuse.contents as? UIColor {
            var r: CGFloat = 0
            var g: CGFloat = 0
            var b: CGFloat = 0
            var a: CGFloat = 0

            if color.getRed(&r, green: &g, blue: &b, alpha: &a) {
                let largest = max(r, max(g, b))
                let smallest = min(r, min(g, b))
                shouldRepair = largest - smallest < 0.10
            }
        } else {
            shouldRepair = true
        }

        guard shouldRepair else { return }

        material.diffuse.contents = UIColor(
            red: 0.19,
            green: 0.42,
            blue: 0.98,
            alpha: 1
        )
        material.metalness.contents = 0.25
        material.roughness.contents = 0.28
    }

    struct ViewportStatistics {
        var objects: Int = 0
        var vertices: Int = 0
        var edges: Int = 0
        var faces: Int = 0
        var triangles: Int = 0
        var textures: Int = 0
    }

    func viewportStatistics() -> ViewportStatistics {
        var stats = ViewportStatistics()

        contentRoot.enumerateChildNodes { node, _ in
            guard let geometry = node.geometry,
                  node.name != "_SelectionOutline",
                  node.name != "_SelectionOutline" && node.name != "_TransformGizmo" && !node.isStudioMetadata else { return }

            stats.objects += 1

            if let source = geometry.sources(for: .vertex).first {
                stats.vertices += source.vectorCount
            }

            for element in geometry.elements {
                switch element.primitiveType {
                case .triangles:
                    stats.triangles += element.primitiveCount
                    stats.faces += element.primitiveCount
                    stats.edges += element.primitiveCount * 3
                case .triangleStrip:
                    let t = max(0, element.primitiveCount)
                    stats.triangles += t
                    stats.faces += t
                    stats.edges += t * 3
                case .line:
                    stats.edges += element.primitiveCount
                case .point:
                    break
                case .polygon:
                    stats.faces += element.primitiveCount
                @unknown default:
                    break
                }
            }

            for material in geometry.materials {
                let props: [SCNMaterialProperty] = [
                    material.diffuse,
                    material.normal,
                    material.emission,
                    material.roughness,
                    material.metalness,
                    material.ambientOcclusion
                ]
                stats.textures += props.filter { $0.contents != nil }.count
            }
        }

        return stats
    }

    func applyViewportSettings(updateMaterials: Bool = true, updateProjectLights: Bool = true) {
        // Editor-only lighting keeps imported PBR/base-color materials readable
        // even when the project intentionally contains zero user lights.
        if editorViewportCamera == nil {
            rebuildEditorViewportRig()
        }
        if let key = editorRoot.childNode(withName: "_ViewportKeyLight", recursively: false) {
            key.light?.intensity = CGFloat(max(0.15, viewportKeyStrength) * 1050)
            key.isHidden = viewportLightCount < 1
        }
        if let fill = editorRoot.childNode(withName: "_ViewportFillLight", recursively: false) {
            fill.light?.intensity = CGFloat(max(0.08, viewportFillStrength) * 850)
            fill.isHidden = viewportLightCount < 2
        }
        if let rim = editorRoot.childNode(withName: "_ViewportRimLight", recursively: false) {
            rim.light?.intensity = CGFloat(max(0.05, viewportRimStrength) * 700)
            rim.isHidden = viewportLightCount < 3
        }
        if let ambient = editorRoot.childNode(withName: "_ViewportAmbientLight", recursively: false) {
            ambient.light?.intensity = CGFloat(max(180, min(520, ambientStrength)))
        }

        if updateProjectLights {
        if let key = lightsRoot.childNode(withName: "Key Light", recursively: false) {
            key.light?.intensity = CGFloat(viewportKeyStrength * 1400)
            key.isHidden = viewportLightCount < 1
        }

        if let fill = lightsRoot.childNode(withName: "Fill Light", recursively: false) {
            fill.light?.intensity = CGFloat(viewportFillStrength * 1400)
            fill.isHidden = viewportLightCount < 2
        }

        if let rim = lightsRoot.childNode(withName: "Rim Light", recursively: false) {
            rim.light?.intensity = CGFloat(viewportRimStrength * 1400)
            rim.isHidden = viewportLightCount < 3
        }

        if let ambient = lightsRoot.childNode(withName: "Ambient", recursively: false) {
            ambient.light?.intensity = CGFloat(ambientStrength)
        }

        }

        if updateMaterials {
        contentRoot.enumerateChildNodes { node, _ in
            guard let geometry = node.geometry else { return }

            for material in geometry.materials {
                if materialDoubleSided.object(forKey: material) == nil {
                    materialDoubleSided.setObject(NSNumber(value: material.isDoubleSided), forKey: material)
                    materialLighting.setObject(material.lightingModel.rawValue as NSString, forKey: material)
                }
                material.isDoubleSided = (materialDoubleSided.object(forKey: material)?.boolValue ?? false) || !backfaceCullingEnabled
                material.specular.intensity = CGFloat(viewportSpecularStrength)
                material.shininess = CGFloat(max(0.1, min(1.0, viewportHighlightSize / 128.0)))

                switch viewportShadingMode {
                case .wireframe:
                    material.fillMode = .lines
                    material.lightingModel = .constant

                case .solid:
                    material.fillMode = .fill
                    material.lightingModel = .constant

                case .lit:
                    material.fillMode = .fill
                    material.lightingModel = .blinn

                case .rendered:
                    material.fillMode = .fill
                    if let model = materialLighting.object(forKey: material) {
                        material.lightingModel = SCNMaterial.LightingModel(rawValue: model as String)
                    }
                }
            }
        }

        }

        if let view = scnView {
            view.showsStatistics = false
            view.antialiasingMode = viewportShadingMode == .wireframe
                ? .none
                : .multisampling2X
        }

        // SCNView renders SceneKit mutations directly. Avoid an extra global
        // SwiftUI invalidation here; it was especially expensive with large hierarchies.
    }

    func resetViewportSettings() {
        pushUndoSnapshot("Reset Viewport")
        showGrid = true
        showAxes = true
        showViewportStatistics = false
        backfaceCullingEnabled = true
        viewportShadingMode = .rendered
        viewportLightCount = 3
        ambientStrength = 450
        viewportKeyStrength = 0.85
        viewportFillStrength = 0.35
        viewportRimStrength = 0.12
        viewportSpecularStrength = 0.10
        viewportHighlightSize = 24
        gridSpacing = 1.0
        gridHalfCount = 100
        rebuildHelpers()
        applyViewportSettings()
        toast = "Viewport Reset"
    }

    func rebuildHelpers() {
        helpersRoot.childNodes.forEach { $0.removeFromParentNode() }

        guard showGrid || showAxes || showWorkPoint else { return }

        if showGrid {
            let extent = gridHalfCount.isFinite ? Int(min(500, max(2, gridHalfCount.rounded()))) : 100
            let spacing = Float(max(0.02, gridSpacing))
            let source = SCNGeometrySource(vertices: buildGridVertices(extent: extent, spacing: spacing))
            let indices = Array(0..<Int(source.vectorCount)).map { UInt32($0) }
            let data = indices.withUnsafeBytes { Data($0) }
            let element = SCNGeometryElement(data: data, primitiveType: .line, primitiveCount: indices.count / 2, bytesPerIndex: MemoryLayout<UInt32>.size)
            let geometry = SCNGeometry(sources: [source], elements: [element])
            geometry.firstMaterial?.diffuse.contents = UIColor(white: 0.23, alpha: 0.65)
            geometry.firstMaterial?.lightingModel = .constant
            let grid = SCNNode(geometry: geometry)
            grid.name = "_Grid"
            grid.position.y = 0.002
            helpersRoot.addChildNode(grid)
        }

        if showAxes {
            helpersRoot.addChildNode(axisNode(from: SCNVector3(0, 0, 0), to: SCNVector3(2.2, 0, 0), color: .systemRed, name: "_X"))
            helpersRoot.addChildNode(axisNode(from: SCNVector3(0, 0, 0), to: SCNVector3(0, 2.2, 0), color: .systemGreen, name: "_Y"))
            helpersRoot.addChildNode(axisNode(from: SCNVector3(0, 0, 0), to: SCNVector3(0, 0, 2.2), color: .systemBlue, name: "_Z"))
        }

        if showWorkPoint {
            let ring = SCNTorus(ringRadius: 0.19, pipeRadius: 0.015)
            let material = SCNMaterial()
            material.diffuse.contents = UIColor.systemOrange
            material.emission.contents = UIColor.systemOrange
            material.lightingModel = .constant
            ring.materials = [material]

            let marker = SCNNode(geometry: ring)
            marker.name = "_WorkPoint"
            marker.eulerAngles.x = .pi / 2
            marker.position = SCNVector3(0, 0.018, 0)
            marker.renderingOrder = 998
            helpersRoot.addChildNode(marker)
        }
    }

    func buildGridVertices(extent: Int, spacing: Float) -> [SCNVector3] {
        var v: [SCNVector3] = []
        for i in -extent...extent {
            let p = Float(i) * spacing
            let e = Float(extent) * spacing
            v.append(SCNVector3(-e, 0, p))
            v.append(SCNVector3(e, 0, p))
            v.append(SCNVector3(p, 0, -e))
            v.append(SCNVector3(p, 0, e))
        }
        return v
    }

    func axisNode(from: SCNVector3, to: SCNVector3, color: UIColor, name: String) -> SCNNode {
        let source = SCNGeometrySource(vertices: [from, to])
        let idx: [UInt32] = [0, 1]
        let data = idx.withUnsafeBytes { Data($0) }
        let el = SCNGeometryElement(data: data, primitiveType: .line, primitiveCount: 1, bytesPerIndex: 4)
        let geo = SCNGeometry(sources: [source], elements: [el])
        geo.firstMaterial?.diffuse.contents = color
        geo.firstMaterial?.lightingModel = .constant
        let n = SCNNode(geometry: geo)
        n.name = name
        return n
    }

    func select(_ node: SCNNode?, preserveMultiSelection: Bool = false) {
        timelineChannels = nil
        selectionOutline?.removeFromParentNode()
        selectionOutline = nil
        selectionGizmo?.removeFromParentNode()
        selectionGizmo = nil

        var target = node
        if target?.name == "_SelectionOutline" { target = target?.parent }

        selectedNode = target
        if target == nil {
            pressedTransformAxis = nil
        }

        if !preserveMultiSelection {
            if let target {
                multiSelectedNodes = [target]
            } else {
                multiSelectedNodes.removeAll()
            }
        }

        if multiSelectedNodes.count > 1 {
            selectedName = appLanguage == .arabic ? "\(multiSelectedNodes.count) عناصر محددة" : "\(multiSelectedNodes.count) selected"
        } else {
            selectedName = target?.name ?? (appLanguage == .arabic ? "لا يوجد" : "None")
        }

        if let target {
            if target.light != nil {
                activeInspector = .light
            } else if target.camera != nil {
                activeInspector = .camera
            } else if target.particleSystems?.isEmpty == false {
                activeInspector = .fx
            }
        }

        guard let target else { return }

        // Restore the original editor selection used by the older stable builds:
        // a thin wireframe box attached to the selected node itself. Because it is
        // a child of the selected node it follows move/rotate/scale automatically.
        let bounds = recursiveLocalBounds(of: target) ??
            (min: SCNVector3(-0.18, -0.18, -0.18), max: SCNVector3(0.18, 0.18, 0.18))

        let w = max(0.02, bounds.max.x - bounds.min.x)
        let h = max(0.02, bounds.max.y - bounds.min.y)
        let l = max(0.02, bounds.max.z - bounds.min.z)

        let outlineGeometry = SCNBox(
            width: CGFloat(w * 1.025),
            height: CGFloat(h * 1.025),
            length: CGFloat(l * 1.025),
            chamferRadius: 0
        )

        let outlineMaterial = SCNMaterial()
        outlineMaterial.diffuse.contents = UIColor.systemOrange
        outlineMaterial.emission.contents = UIColor.systemOrange
        outlineMaterial.lightingModel = .constant
        outlineMaterial.fillMode = .lines
        outlineMaterial.writesToDepthBuffer = false
        outlineMaterial.readsFromDepthBuffer = true
        outlineGeometry.materials = [outlineMaterial]

        let outline = SCNNode(geometry: outlineGeometry)
        outline.name = "_SelectionOutline"
        outline.castsShadow = false
        outline.renderingOrder = 999
        outline.position = SCNVector3(
            (bounds.min.x + bounds.max.x) * 0.5,
            (bounds.min.y + bounds.max.y) * 0.5,
            (bounds.min.z + bounds.max.z) * 0.5
        )
        target.addChildNode(outline)
        selectionOutline = outline

        let worldCenter: SCNVector3
        let worldSize: Float
        let boundsNodes = multiSelectedNodes.count > 1 ? multiSelectedNodes : [target]

        if let wb = combinedGizmoWorldBounds(of: boundsNodes) {
            worldCenter = SCNVector3(
                (wb.min.x + wb.max.x) * 0.5,
                (wb.min.y + wb.max.y) * 0.5,
                (wb.min.z + wb.max.z) * 0.5
            )
            let sx = wb.max.x - wb.min.x
            let sy = wb.max.y - wb.min.y
            let sz = wb.max.z - wb.min.z
            worldSize = max(sx, max(sy, sz))
        } else {
            worldCenter = target.worldPosition
            worldSize = max(w, max(h, l))
        }

        let gizmo = makeTransformGizmo(
            length: max(0.52, min(1.65, worldSize * 0.32))
        )
        gizmo.position = worldCenter
        editorRoot.addChildNode(gizmo)
        selectionGizmo = gizmo

        if transformSpace == .local {
            gizmo.worldOrientation = target.worldOrientation
        }

        updateSelectionGizmoScreenScale()
        refreshGizmoAxisHighlight()
    }

    func isNodeMultiSelected(_ node: SCNNode) -> Bool {
        multiSelectedNodes.contains { $0 === node }
    }

    var editingNodes: [SCNNode] {
        let source = multiSelectedNodes.isEmpty
            ? (selectedNode.map { [$0] } ?? [])
            : multiSelectedNodes

        return source.filter { node in
            !source.contains { other in
                guard other !== node else { return false }

                var parent = node.parent
                while let p = parent {
                    if p === other {
                        return true
                    }
                    parent = p.parent
                }

                return false
            }
        }
    }

    func selectMultiple(_ nodes: [SCNNode]) {
        var seen = Set<ObjectIdentifier>()

        let unique = nodes.filter {
            let id = ObjectIdentifier($0)

            if seen.contains(id) {
                return false
            }

            seen.insert(id)
            return true
        }

        multiSelectedNodes = unique

        guard let primary = unique.last else {
            select(nil)
            return
        }

        select(
            primary,
            preserveMultiSelection: true
        )

        selectedName = unique.count > 1
            ? (appLanguage == .arabic ? "\(unique.count) عناصر محددة" : "\(unique.count) selected")
            : (primary.name ?? (appLanguage == .arabic ? "عنصر" : "Object"))

        statusText = unique.count > 1
            ? (appLanguage == .arabic ? "تحديد متعدد • \(unique.count) قطع" : "Multi Select • \(unique.count) parts")
            : (appLanguage == .arabic ? "تم تحديد • \(primary.name ?? "قطعة")" : "Selected • \(primary.name ?? "Part")")
    }

    func toggleMultiSelection(_ node: SCNNode) {
        if let index = multiSelectedNodes.firstIndex(
            where: { $0 === node }
        ) {
            multiSelectedNodes.remove(at: index)
        } else {
            multiSelectedNodes.append(node)
        }

        selectMultiple(multiSelectedNodes)
    }

    func clearMultiSelection() {
        select(nil)
    }

    func selectAllImportedMeshes() {
        let nodes = importNodeItems
            .filter { $0.isMesh }
            .map { $0.node }

        selectMultiple(nodes)
    }

    func exitSelectedCameraViewIfNeeded() {
        guard isUsingSelectedCamera else { return }
        if let previous = cameraBeforePreview { scnView?.pointOfView = previous }
        cameraBeforePreview = nil
        isUsingSelectedCamera = false
        updateSelectionGizmoScreenScale()
    }

    func cancelContinuousViewportInput() {
        inputResetGeneration &+= 1
        pressedTransformAxis = nil
        cancelTransformHistory()
        scnView?.gestureRecognizers?.forEach { recognizer in
            if recognizer.state == .began || recognizer.state == .changed {
                recognizer.isEnabled = false
                recognizer.isEnabled = true
            }
        }
    }

    func moveViewportCamera(
        strafe: Float,
        forward: Float,
        vertical: Float,
        frameScale: Float = 1
    ) {
        guard let camera = scnView?.pointOfView else { return }

        // Use the model transform rather than the presentation tree. Presentation
        // can lag one rendered frame while looking around and made walking feel
        // slightly rubbery/jittery when joystick + camera rotation were combined.
        let forwardVector = camera.convertVector(SCNVector3(0, 0, -1), to: nil)
        let rightVector = camera.convertVector(SCNVector3(1, 0, 0), to: nil)
        let f = normalizedVector(forwardVector)
        let r = normalizedVector(rightVector)

        // Walking stays level; vertical movement is controlled by the dedicated buttons.
        var flatF = SCNVector3(f.x, 0, f.z)
        let flatLengthSquared = flatF.x * flatF.x + flatF.z * flatF.z
        let flatLength = sqrt(flatLengthSquared)
        if flatLength > 0.0001 {
            flatF.x /= flatLength
            flatF.z /= flatLength
        }

        let speed: Float = (fineMode ? 0.035 : 0.10) * Float(controlMoveSpeed) * max(0.25, min(frameScale, 3.0))
        let strafeX = r.x * strafe
        let forwardX = flatF.x * forward
        let strafeZ = r.z * strafe
        let forwardZ = flatF.z * forward
        let deltaX = (strafeX + forwardX) * speed
        let deltaY = vertical * speed
        let deltaZ = (strafeZ + forwardZ) * speed
        let oldPosition = camera.position
        SCNTransaction.begin()
        SCNTransaction.disableActions = true
        camera.position = SCNVector3(oldPosition.x + deltaX,
                                     oldPosition.y + deltaY,
                                     oldPosition.z + deltaZ)
        SCNTransaction.commit()
        updateSelectionGizmoScreenScale()
    }

    func zoomViewportCamera(_ amount: Float) {
        guard let camera = scnView?.pointOfView else { return }
        let direction = normalizedVector(camera.convertVector(SCNVector3(0, 0, -1), to: nil))
        let travel = amount * Float(max(0.25, controlMoveSpeed))
        camera.position = SCNVector3(camera.position.x + direction.x * travel,
                                     camera.position.y + direction.y * travel,
                                     camera.position.z + direction.z * travel)
        camera.camera?.zNear = 0.01
        camera.camera?.zFar = 100_000
        updateSelectionGizmoScreenScale()
    }

    func resetControlLayout() {
        controlJoystickSize = 104
        controlButtonSize = 46
        controlOpacity = 0.72
        controlMoveSpeed = 1.0
        joystickOffsetX = 0
        joystickOffsetY = 0
        verticalOffsetX = 0
        verticalOffsetY = 0
        upOffsetX = 0
        upOffsetY = 0
        downOffsetX = 0
        downOffsetY = 0
        zoomOffsetX = 0
        zoomOffsetY = 0
        zoomControlScale = 1.0
        pinchZoomEnabled = true
    }

    private func normalizedVector(_ vector: SCNVector3) -> SCNVector3 {
        let lengthSquared = vector.x * vector.x + vector.y * vector.y + vector.z * vector.z
        let length = sqrt(lengthSquared)
        guard length > 0.000001 else { return SCNVector3Zero }
        return SCNVector3(vector.x / length, vector.y / length, vector.z / length)
    }

    func selectNodes(inViewportRect rect: CGRect) {
        guard let view = scnView else { return }
        let normalizedRect = CGRect(
            x: min(rect.minX, rect.maxX), y: min(rect.minY, rect.maxY),
            width: abs(rect.width), height: abs(rect.height)
        )
        guard normalizedRect.width > 5, normalizedRect.height > 5 else { return }

        var matches: [SCNNode] = []
        var seen = Set<ObjectIdentifier>()
        contentRoot.enumerateChildNodes { node, _ in
            guard node.geometry != nil, !node.isHidden, !self.isNodeLocked(node) else { return }
            let name = node.name ?? ""
            guard name != "Ground", !name.hasPrefix("_") else { return }
            let projected = view.projectPoint(node.presentation.worldPosition)
            guard projected.z >= 0, projected.z <= 1 else { return }

            // SCNView.projectPoint uses a bottom-left Y origin while the SwiftUI
            // drag overlay uses a top-left Y origin. Convert once here so the box
            // selects the objects under the rectangle the user actually drew.
            // X is intentionally left untouched: dragging left -> right stays
            // left -> right in every app language (RTL must not mirror selection).
            let pt = CGPoint(
                x: CGFloat(projected.x),
                y: view.bounds.height - CGFloat(projected.y)
            )
            if normalizedRect.contains(pt) {
                // Prefer the imported/model wrapper when available so dense assets do not
                // create hundreds of duplicate child selections.
                var target = node
                var cursor = node.parent
                while let parent = cursor, parent !== self.contentRoot {
                    if parent.parent === self.contentRoot { target = parent; break }
                    cursor = parent.parent
                }
                let id = ObjectIdentifier(target)
                if !seen.contains(id) { seen.insert(id); matches.append(target) }
            }
        }
        selectMultiple(matches)
        statusText = matches.isEmpty ? "Box Select • لا يوجد عناصر" : "Box Select • \(matches.count) selected"
    }

    /// World bounds used specifically by the editor gizmo.
    /// Uses the model transforms (not `presentation`) so the center is correct
    /// immediately after selection, import, undo/redo, and direct numeric edits.
    func gizmoWorldBounds(of root: SCNNode) -> (min: SCNVector3, max: SCNVector3)? {
        var found = false
        var minV = SCNVector3(
            Float.greatestFiniteMagnitude,
            Float.greatestFiniteMagnitude,
            Float.greatestFiniteMagnitude
        )
        var maxV = SCNVector3(
            -Float.greatestFiniteMagnitude,
            -Float.greatestFiniteMagnitude,
            -Float.greatestFiniteMagnitude
        )

        for node in editableDescendants(of: root)
        where node.geometry != nil && node.name != "_SelectionOutline" && !node.isHidden {
            let bounds = node.boundingBox
            for corner in boxCorners(min: bounds.min, max: bounds.max) {
                let point = node.convertPosition(corner, to: nil)
                guard point.x.isFinite, point.y.isFinite, point.z.isFinite else { continue }
                minV.x = min(minV.x, point.x)
                minV.y = min(minV.y, point.y)
                minV.z = min(minV.z, point.z)
                maxV.x = max(maxV.x, point.x)
                maxV.y = max(maxV.y, point.y)
                maxV.z = max(maxV.z, point.z)
                found = true
            }
        }

        return found ? (minV, maxV) : nil
    }

    func combinedGizmoWorldBounds(
        of nodes: [SCNNode]
    ) -> (min: SCNVector3, max: SCNVector3)? {
        var found = false
        var minV = SCNVector3(
            Float.greatestFiniteMagnitude,
            Float.greatestFiniteMagnitude,
            Float.greatestFiniteMagnitude
        )
        var maxV = SCNVector3(
            -Float.greatestFiniteMagnitude,
            -Float.greatestFiniteMagnitude,
            -Float.greatestFiniteMagnitude
        )

        for node in nodes {
            guard let bounds = gizmoWorldBounds(of: node) else { continue }
            minV.x = min(minV.x, bounds.min.x)
            minV.y = min(minV.y, bounds.min.y)
            minV.z = min(minV.z, bounds.min.z)
            maxV.x = max(maxV.x, bounds.max.x)
            maxV.y = max(maxV.y, bounds.max.y)
            maxV.z = max(maxV.z, bounds.max.z)
            found = true
        }

        return found ? (minV, maxV) : nil
    }

    func combinedWorldBounds(
        of nodes: [SCNNode]
    ) -> (min: SCNVector3, max: SCNVector3)? {
        var found = false

        var minV = SCNVector3(
            Float.greatestFiniteMagnitude,
            Float.greatestFiniteMagnitude,
            Float.greatestFiniteMagnitude
        )

        var maxV = SCNVector3(
            -Float.greatestFiniteMagnitude,
            -Float.greatestFiniteMagnitude,
            -Float.greatestFiniteMagnitude
        )

        for node in nodes {
            guard let bounds = worldBounds(of: node) else {
                continue
            }

            minV.x = min(minV.x, bounds.min.x)
            minV.y = min(minV.y, bounds.min.y)
            minV.z = min(minV.z, bounds.min.z)

            maxV.x = max(maxV.x, bounds.max.x)
            maxV.y = max(maxV.y, bounds.max.y)
            maxV.z = max(maxV.z, bounds.max.z)

            found = true
        }

        return found ? (minV, maxV) : nil
    }

    func makeTransformGizmo(
        length: Float
    ) -> SCNNode {
        let root = SCNNode()
        root.name = "_TransformGizmo"
        root.renderingOrder = 1000
        // Remember the authored gizmo length so we can keep the handles
        // comfortably sized on-screen as the editor camera moves.
        root.setValue(NSNumber(value: length), forKey: "5lnGizmoBaseLength")

        switch transformMode {
        case .move:
            root.addChildNode(
                makeMoveAxisGizmo(
                    axis: .x,
                    length: length,
                    color: axisGizmoColor(for: .x),
                    label: "X"
                )
            )

            root.addChildNode(
                makeMoveAxisGizmo(
                    axis: .y,
                    length: length,
                    color: axisGizmoColor(for: .y),
                    label: "Y"
                )
            )

            root.addChildNode(
                makeMoveAxisGizmo(
                    axis: .z,
                    length: length,
                    color: axisGizmoColor(for: .z),
                    label: "Z"
                )
            )

        case .rotate:
            // WOW-style rotation gizmo: three thick 90-degree arcs. The arcs
            // are authored in one octant, then mirrored at runtime toward the
            // camera so the rounded triangular cage remains readable from every
            // viewing direction instead of disappearing behind the object.
            // WOW color mapping: X red, Y blue, Z green.
            root.addChildNode(
                makeRotateRing(
                    axis: .x,
                    radius: length * 0.80,
                    color: rotationGizmoColor(for: .x),
                    label: "X"
                )
            )

            root.addChildNode(
                makeRotateRing(
                    axis: .y,
                    radius: length * 0.80,
                    color: rotationGizmoColor(for: .y),
                    label: "Y"
                )
            )

            root.addChildNode(
                makeRotateRing(
                    axis: .z,
                    radius: length * 0.80,
                    color: rotationGizmoColor(for: .z),
                    label: "Z"
                )
            )

        case .scale:
            root.addChildNode(
                makeScaleAxisGizmo(
                    axis: .x,
                    length: length,
                    color: axisGizmoColor(for: .x),
                    label: "X"
                )
            )

            root.addChildNode(
                makeScaleAxisGizmo(
                    axis: .y,
                    length: length,
                    color: axisGizmoColor(for: .y),
                    label: "Y"
                )
            )

            root.addChildNode(
                makeScaleAxisGizmo(
                    axis: .z,
                    length: length,
                    color: axisGizmoColor(for: .z),
                    label: "Z"
                )
            )
        }

        return root
    }

    func gizmoMaterial(
        color: UIColor
    ) -> SCNMaterial {
        let material = SCNMaterial()
        material.diffuse.contents = color
        material.emission.contents = color
        material.lightingModel = .constant
        material.readsFromDepthBuffer = false
        material.writesToDepthBuffer = false
        return material
    }

    func makeMoveAxisGizmo(
        axis: Axis3D,
        length: Float,
        color: UIColor,
        label: String
    ) -> SCNNode {
        let root = SCNNode()
        root.name = "GizmoHandle_\(label)"
        root.renderingOrder = 1000

        let mat =
            gizmoMaterial(color: color)

        let shaft = SCNCylinder(
            radius: 0.030,
            height: CGFloat(length)
        )

        shaft.materials = [mat]

        let shaftNode =
            SCNNode(geometry: shaft)

        shaftNode.name =
            "GizmoHandle_\(label)"

        shaftNode.position.y =
            length * 0.5

        shaftNode.renderingOrder = 1000

        let cone = SCNCone(
            topRadius: 0,
            bottomRadius: 0.095,
            height: 0.22
        )

        cone.materials = [mat]

        let coneNode =
            SCNNode(geometry: cone)

        coneNode.name =
            "GizmoHandle_\(label)"

        coneNode.position.y =
            length + 0.11

        coneNode.renderingOrder = 1000

        root.addChildNode(shaftNode)
        root.addChildNode(coneNode)

        // iPad touch target: deliberately wider than the visible arrow.
        // It keeps the gizmo precise visually while making X/Y/Z easy to grab.
        let touchMaterial = SCNMaterial()
        // Hit geometry must NEVER become visible.  Earlier every descendant of a
        // GizmoHandle was recolored for axis highlighting, which also recolored
        // this invisible sleeve and produced the giant/thick "broken arrows".
        touchMaterial.diffuse.contents = UIColor.clear
        touchMaterial.emission.contents = UIColor.clear
        touchMaterial.transparency = 0.001
        touchMaterial.lightingModel = .constant
        touchMaterial.readsFromDepthBuffer = false
        touchMaterial.writesToDepthBuffer = false
        let touchSleeve = SCNCylinder(radius: 0.115, height: CGFloat(length + 0.30))
        touchSleeve.materials = [touchMaterial]
        let touchNode = SCNNode(geometry: touchSleeve)
        touchNode.name = "_GizmoTouch_\(label)"
        touchNode.setValue(true, forKey: "5lnGizmoHitOnly")
        touchNode.position.y = (length + 0.30) * 0.5
        touchNode.renderingOrder = 999
        root.addChildNode(touchNode)

        orientGizmo(
            root,
            axis: axis
        )

        return root
    }

    func makeScaleAxisGizmo(
        axis: Axis3D,
        length: Float,
        color: UIColor,
        label: String
    ) -> SCNNode {
        let root = SCNNode()
        root.name = "GizmoHandle_\(label)"
        root.renderingOrder = 1000

        let mat =
            gizmoMaterial(color: color)

        let shaft = SCNCylinder(
            radius: 0.034,
            height: CGFloat(length)
        )

        shaft.materials = [mat]

        let shaftNode =
            SCNNode(geometry: shaft)

        shaftNode.name =
            "GizmoHandle_\(label)"

        shaftNode.position.y =
            length * 0.5

        let box = SCNBox(
            width: 0.20,
            height: 0.20,
            length: 0.20,
            chamferRadius: 0.022
        )

        box.materials = [mat]

        let boxNode =
            SCNNode(geometry: box)

        boxNode.name =
            "GizmoHandle_\(label)"

        boxNode.position.y = length

        root.addChildNode(shaftNode)
        root.addChildNode(boxNode)

        // Large invisible touch target, matching the simple mobile-editor feel.
        let touchMaterial = SCNMaterial()
        touchMaterial.diffuse.contents = UIColor.clear
        touchMaterial.emission.contents = UIColor.clear
        touchMaterial.transparency = 0.001
        touchMaterial.lightingModel = .constant
        touchMaterial.readsFromDepthBuffer = false
        touchMaterial.writesToDepthBuffer = false
        let touchSleeve = SCNCylinder(radius: 0.12, height: CGFloat(length + 0.22))
        touchSleeve.materials = [touchMaterial]
        let touchNode = SCNNode(geometry: touchSleeve)
        touchNode.name = "_GizmoTouch_\(label)"
        touchNode.setValue(true, forKey: "5lnGizmoHitOnly")
        touchNode.position.y = (length + 0.10) * 0.5
        touchNode.renderingOrder = 999
        root.addChildNode(touchNode)

        orientGizmo(
            root,
            axis: axis
        )

        return root
    }

    private func rotationSectorPath(
        radius: CGFloat,
        thickness: CGFloat,
        startAngle: CGFloat,
        endAngle: CGFloat,
        segments: Int = 28
    ) -> UIBezierPath {
        let outer = radius
        let inner = max(0.001, radius - thickness)
        let path = UIBezierPath()

        func point(_ r: CGFloat, _ angle: CGFloat) -> CGPoint {
            CGPoint(x: cos(angle) * r, y: sin(angle) * r)
        }

        path.move(to: point(outer, startAngle))
        if segments > 0 {
            for i in 1...segments {
                let t = CGFloat(i) / CGFloat(segments)
                let a = startAngle + (endAngle - startAngle) * t
                path.addLine(to: point(outer, a))
            }
        }
        for i in stride(from: segments, through: 0, by: -1) {
            let t = CGFloat(i) / CGFloat(max(1, segments))
            let a = startAngle + (endAngle - startAngle) * t
            path.addLine(to: point(inner, a))
        }
        path.close()
        return path
    }

    func makeRotateRing(
        axis: Axis3D,
        radius: Float,
        color: UIColor,
        label: String
    ) -> SCNNode {
        let root = SCNNode()
        root.name = "GizmoHandle_\(label)"
        root.renderingOrder = 1000

        let r = CGFloat(radius)
        let visibleMat = gizmoMaterial(color: color)
        // Keep the ring readable even when the camera gets close to the mesh.
        // We still preserve the 3D orientation by placing each arc in its true
        // axis plane, but we avoid depth clipping so the handles do not sink
        // into the selected object during zoom-in work.
        visibleMat.readsFromDepthBuffer = false
        visibleMat.writesToDepthBuffer = false
        visibleMat.isDoubleSided = true

        // The WOW reference uses broad ribbon-like quarters, not thin rings.
        // Keep the outer radius common to all axes so their radial end faces
        // meet exactly on +X/+Y/+Z and read as one assembled 3D control.
        let thickness = max(0.070, r * 0.30)
        let quarterTurn = CGFloat.pi * 0.5
        let path = rotationSectorPath(
            radius: r,
            thickness: thickness,
            startAngle: 0,
            endAngle: quarterTurn,
            segments: 30
        )
        let shape = SCNShape(path: path, extrusionDepth: max(0.018, r * 0.045))
        shape.chamferRadius = max(0.006, r * 0.018)
        shape.materials = [visibleMat]

        let visible = SCNNode(geometry: shape)
        visible.name = "GizmoHandle_\(label)"
        visible.renderingOrder = 1001
        root.addChildNode(visible)

        // The hit target follows the same 90-degree quarter but is substantially
        // wider than the painted ribbon. This preserves the exact visual shape
        // while keeping finger selection forgiving on iPad.
        let hitPath = rotationSectorPath(
            radius: r,
            thickness: max(0.20, r * 0.46),
            startAngle: 0,
            endAngle: quarterTurn,
            segments: 24
        )
        root.addChildNode(makeInvisibleRotationHit(path: hitPath, label: label))

        // SCNShape starts in the XY plane and spans +X -> +Y. The signs here
        // are deliberate: they place all three quarters in the same positive
        // octant, so their radial end faces meet pairwise:
        //   Z/green: +X -> +Y
        //   Y/blue : +X -> +Z
        //   X/red  : +Z -> +Y
        // This is what creates the rounded triangular WOW assembly.
        switch axis {
        case .x:
            // YZ plane -> rotation around X (red), +Z to +Y.
            root.eulerAngles.y = -.pi / 2
        case .y:
            // XZ plane -> rotation around Y (blue), +X to +Z.
            root.eulerAngles.x = .pi / 2
        case .z:
            // XY plane -> rotation around Z (green), +X to +Y.
            break
        }

        return root
    }

    private func makeInvisibleRotationHit(path: UIBezierPath, label: String) -> SCNNode {
        let mat = SCNMaterial()
        mat.diffuse.contents = UIColor.clear
        mat.emission.contents = UIColor.clear
        mat.transparency = 0.001
        mat.lightingModel = .constant
        mat.readsFromDepthBuffer = false
        mat.writesToDepthBuffer = false
        mat.isDoubleSided = true

        let shape = SCNShape(path: path, extrusionDepth: 0.06)
        shape.materials = [mat]
        let node = SCNNode(geometry: shape)
        node.name = "_GizmoTouch_\(label)"
        node.setValue(true, forKey: "5lnGizmoHitOnly")
        node.renderingOrder = 999
        return node
    }

    func orientGizmo(
        _ root: SCNNode,
        axis: Axis3D
    ) {
        switch axis {
        case .x:
            root.eulerAngles.z = -.pi / 2

        case .y:
            break

        case .z:
            root.eulerAngles.x = .pi / 2
        }
    }

    func axisGizmoColor(for axis: TransformAxis) -> UIColor {
        // Keep one consistent dark palette across move / rotate / scale.
        // Mapping stays aligned with the WOW rotation gizmo:
        // X = red, Y = blue, Z = green.
        switch axis {
        case .x:
            return UIColor(red: 0.60, green: 0.055, blue: 0.050, alpha: 1.0)
        case .y:
            return UIColor(red: 0.050, green: 0.235, blue: 0.56, alpha: 1.0)
        case .z:
            return UIColor(red: 0.045, green: 0.46, blue: 0.085, alpha: 1.0)
        case .free:
            return UIColor(red: 0.82, green: 0.52, blue: 0.14, alpha: 1.0)
        }
    }

    func rotationGizmoColor(for axis: TransformAxis) -> UIColor {
        axisGizmoColor(for: axis)
    }

    func baseGizmoColor(for axis: TransformAxis) -> UIColor {
        axisGizmoColor(for: axis)
    }

    func transformAxis(forGizmoName name: String?) -> TransformAxis? {
        guard let name else { return nil }
        if name == "GizmoHandle_X" { return .x }
        if name == "GizmoHandle_Y" { return .y }
        if name == "GizmoHandle_Z" { return .z }
        return nil
    }

    func refreshGizmoAxisHighlight() {
        guard let gizmo = selectionGizmo else { return }

        for handle in gizmo.childNodes {
            guard let axis = transformAxis(forGizmoName: handle.name) else { continue }

            let color: UIColor
            if pressedTransformAxis == axis {
                color = .white
            } else if transformAxis == axis {
                color = .systemYellow
            } else {
                color = baseGizmoColor(for: axis)
            }

            var nodes: [SCNNode] = [handle]
            handle.enumerateChildNodes { node, _ in
                nodes.append(node)
            }

            for node in nodes {
                // Keep oversized hit sleeves fully invisible. Only the authored
                // shaft/head/ring geometry participates in visual highlighting.
                if (node.value(forKey: "5lnGizmoHitOnly") as? Bool) == true ||
                    node.name?.hasPrefix("_GizmoTouch_") == true {
                    continue
                }
                guard let geometry = node.geometry else { continue }
                for material in geometry.materials {
                    material.diffuse.contents = color
                    material.emission.contents = color
                }
            }
        }
    }

    func setTransformAxis(_ axis: TransformAxis, pressed: Bool = false) {
        transformAxis = axis
        pressedTransformAxis = pressed ? axis : nil
        refreshGizmoAxisHighlight()
    }

    func setPressedTransformAxis(_ axis: TransformAxis?) {
        pressedTransformAxis = axis
        refreshGizmoAxisHighlight()
    }

    func offsetSelectionGizmo(by worldDelta: SCNVector3) {
        guard let gizmo = selectionGizmo else { return }
        gizmo.position = SCNVector3(
            gizmo.position.x + worldDelta.x,
            gizmo.position.y + worldDelta.y,
            gizmo.position.z + worldDelta.z
        )
    }

    private func updateRotationGizmoCameraFacingOctant() {
        guard transformMode == .rotate,
              let gizmo = selectionGizmo,
              let cameraNode = scnView?.pointOfView else { return }

        // Express the camera position in gizmo-local coordinates. This makes the
        // behavior correct in both WORLD and LOCAL transform spaces. We only care
        // about which side of each axis plane the camera occupies.
        let cameraLocal = gizmo.convertPosition(cameraNode.presentation.worldPosition, from: nil)
        let maxComponent = max(0.0001, max(abs(cameraLocal.x), max(abs(cameraLocal.y), abs(cameraLocal.z))))
        let deadZone = maxComponent * 0.035

        func rememberedSign(_ key: String, value: Float) -> Float {
            let previous = (gizmo.value(forKey: key) as? NSNumber)?.floatValue ?? 1.0
            let next: Float
            if value > deadZone {
                next = 1.0
            } else if value < -deadZone {
                next = -1.0
            } else {
                next = previous
            }
            gizmo.setValue(NSNumber(value: next), forKey: key)
            return next
        }

        let sx = rememberedSign("5lnRotateOctantX", value: cameraLocal.x)
        let sy = rememberedSign("5lnRotateOctantY", value: cameraLocal.y)
        let sz = rememberedSign("5lnRotateOctantZ", value: cameraLocal.z)

        // Each handle was authored as the same +X/+Y quarter before being rotated
        // into its axis plane. Mirror its two in-plane dimensions so all three
        // quarters always meet in the camera-facing octant:
        //   Z/green -> XY uses sx, sy
        //   Y/blue  -> XZ uses sx, sz
        //   X/red   -> YZ uses sy, sz (local X maps to world Z on this handle).
        for handle in gizmo.childNodes {
            switch handle.name {
            case "GizmoHandle_X":
                handle.scale = SCNVector3(sz, sy, 1)
            case "GizmoHandle_Y":
                handle.scale = SCNVector3(sx, sz, 1)
            case "GizmoHandle_Z":
                handle.scale = SCNVector3(sx, sy, 1)
            default:
                break
            }
        }
    }

    func updateSelectionGizmoScreenScale() {
        guard let gizmo = selectionGizmo,
              let cameraNode = scnView?.pointOfView else { return }

        let gp = gizmo.worldPosition
        let cp = cameraNode.worldPosition
        let dx = gp.x - cp.x, dy = gp.y - cp.y, dz = gp.z - cp.z
        let distance = max(0.05, sqrt(dx * dx + dy * dy + dz * dz))
        let fov = Float(cameraNode.camera?.fieldOfView ?? 60) * .pi / 180
        let baseLength = max(0.05, (gizmo.value(forKey: "5lnGizmoBaseLength") as? NSNumber)?.floatValue ?? 1)

        // Keep ALL transform gizmos at the same apparent on-screen radius.
        // Rotation was already the visual size we wanted: its outer radius is
        // 0.80 * baseLength and, with the old 98 pt target, appeared at 78.4 pt.
        // Move and Scale extend farther than baseLength because of their arrow/
        // box heads, so compensate for that authored reach instead of assigning
        // the same raw root scale (which made them look much larger).
        let visibleHeight = 2 * distance * tan(max(0.08, fov * 0.5))
        let viewportHeight = Float(max(1.0, scnView?.bounds.height ?? 1000.0))
        let targetReachPoints: Float = 78.4
        let authoredReach: Float
        switch transformMode {
        case .rotate:
            authoredReach = 0.80       // quarter-ring outer radius
        case .move:
            authoredReach = 1.22       // shaft length + cone tip
        case .scale:
            authoredReach = 1.10       // shaft length + half of end box
        }
        let desiredBasePoints = targetReachPoints / authoredReach
        let desiredLength = max(0.18, visibleHeight * (desiredBasePoints / viewportHeight))
        let scale = min(8.0, max(0.16, desiredLength / baseLength))
        gizmo.scale = SCNVector3(scale, scale, scale)

        // Keep the WOW quarter-arc assembly on the side facing the current camera.
        // This is what makes it feel like a genuinely three-dimensional gizmo as
        // the editor viewpoint moves around the object.
        updateRotationGizmoCameraFacingOctant()
    }

    func refreshSelectionGizmoOrientationOnly() {
        guard let selectedNode,
              let gizmo = selectionGizmo else { return }
        if transformSpace == .local {
            gizmo.worldOrientation = selectedNode.worldOrientation
        } else {
            gizmo.worldOrientation = SCNQuaternion(0, 0, 0, 1)
        }
        updateRotationGizmoCameraFacingOctant()
    }

    func rebuildTransformGizmo() {
        guard let selectedNode else {
            return
        }

        let selected =
            multiSelectedNodes

        select(
            selectedNode,
            preserveMultiSelection: true
        )

        multiSelectedNodes = selected
        refreshSelectionGizmo()
    }

    func refreshSelectionGizmo() {
        guard let selectedNode,
              let gizmo = selectionGizmo else {
            return
        }

        let nodes = editingNodes.isEmpty
            ? [selectedNode]
            : editingNodes

        if let wb = combinedGizmoWorldBounds(of: nodes) {
            gizmo.position = SCNVector3(
                (wb.min.x + wb.max.x) * 0.5,
                (wb.min.y + wb.max.y) * 0.5,
                (wb.min.z + wb.max.z) * 0.5
            )
        } else {
            gizmo.position = selectedNode.worldPosition
        }

        if transformSpace == .local {
            gizmo.worldOrientation = selectedNode.worldOrientation
        } else {
            gizmo.worldOrientation =
                SCNQuaternion(
                    0,
                    0,
                    0,
                    1
                )
        }

        updateSelectionGizmoScreenScale()
        refreshGizmoAxisHighlight()
    }

    func selectAndFrame(_ node: SCNNode) {
        select(node)
        frameNode(node)
    }

    func editableDescendants(of root: SCNNode) -> [SCNNode] {
        var nodes: [SCNNode] = [root]
        root.enumerateChildNodes { node, _ in
            guard node.name != "_SelectionOutline",
                  node.name != "_TransformGizmo",
                  node.name != "_SelectionOutline" && node.name != "_TransformGizmo" && !node.isStudioMetadata else { return }
            nodes.append(node)
        }
        return nodes
    }

    func recursiveLocalBounds(of root: SCNNode) -> (min: SCNVector3, max: SCNVector3)? {
        var found = false
        var minV = SCNVector3(Float.greatestFiniteMagnitude, Float.greatestFiniteMagnitude, Float.greatestFiniteMagnitude)
        var maxV = SCNVector3(-Float.greatestFiniteMagnitude, -Float.greatestFiniteMagnitude, -Float.greatestFiniteMagnitude)

        for node in editableDescendants(of: root) where node.geometry != nil && node.name != "_SelectionOutline" {
            let b = node.boundingBox
            let corners = boxCorners(min: b.min, max: b.max)

            for corner in corners {
                let p = node.convertPosition(corner, to: root)
                guard p.x.isFinite, p.y.isFinite, p.z.isFinite else { continue }
                minV.x = min(minV.x, p.x)
                minV.y = min(minV.y, p.y)
                minV.z = min(minV.z, p.z)
                maxV.x = max(maxV.x, p.x)
                maxV.y = max(maxV.y, p.y)
                maxV.z = max(maxV.z, p.z)
                found = true
            }
        }

        return found ? (minV, maxV) : nil
    }

    func worldBounds(of root: SCNNode) -> (min: SCNVector3, max: SCNVector3)? {
        var found = false
        var minV = SCNVector3(Float.greatestFiniteMagnitude, Float.greatestFiniteMagnitude, Float.greatestFiniteMagnitude)
        var maxV = SCNVector3(-Float.greatestFiniteMagnitude, -Float.greatestFiniteMagnitude, -Float.greatestFiniteMagnitude)

        for node in editableDescendants(of: root) where node.geometry != nil && node.name != "_SelectionOutline" {
            let b = node.boundingBox
            for corner in boxCorners(min: b.min, max: b.max) {
                let p = node.presentation.convertPosition(corner, to: nil)
                guard p.x.isFinite, p.y.isFinite, p.z.isFinite else { continue }
                minV.x = min(minV.x, p.x)
                minV.y = min(minV.y, p.y)
                minV.z = min(minV.z, p.z)
                maxV.x = max(maxV.x, p.x)
                maxV.y = max(maxV.y, p.y)
                maxV.z = max(maxV.z, p.z)
                found = true
            }
        }

        return found ? (minV, maxV) : nil
    }

    func boxCorners(min mn: SCNVector3, max mx: SCNVector3) -> [SCNVector3] {
        [
            SCNVector3(mn.x, mn.y, mn.z),
            SCNVector3(mx.x, mn.y, mn.z),
            SCNVector3(mn.x, mx.y, mn.z),
            SCNVector3(mx.x, mx.y, mn.z),
            SCNVector3(mn.x, mn.y, mx.z),
            SCNVector3(mx.x, mn.y, mx.z),
            SCNVector3(mn.x, mx.y, mx.z),
            SCNVector3(mx.x, mx.y, mx.z)
        ]
    }

    func clearSelection() {
        select(nil)
    }

    // MARK: - SceneKit Compatibility Helpers

    func isAncestorNode(
        _ possibleAncestor: SCNNode,
        of node: SCNNode
    ) -> Bool {
        var current = node.parent

        while let parent = current {
            if parent === possibleAncestor {
                return true
            }
            current = parent.parent
        }

        return false
    }

    func setWorldTransform(
        _ world: SCNMatrix4,
        on node: SCNNode
    ) {
        if let parent = node.parent {
            node.transform = parent.convertTransform(
                world,
                from: nil
            )
        } else {
            node.transform = world
        }
    }

    func applyMaterialRecursively(
        _ node: SCNNode,
        action: (SCNMaterial) -> Void
    ) {
        if let geometry = node.geometry, let editable = geometry.copy() as? SCNGeometry {
            editable.materials = geometry.materials.compactMap { $0.copy() as? SCNMaterial }
            if editable.materials.isEmpty { editable.firstMaterial = SCNMaterial() }
            node.geometry = editable
            editable.materials.forEach(action)
        }

        for child in node.childNodes {
            applyMaterialRecursively(
                child,
                action: action
            )
        }
    }

    // MARK: - Object Workflow Utilities

    func duplicateSelectedObjects(
        linkedGeometry: Bool = false
    ) {
        let originals = editingNodes
        guard !originals.isEmpty else {
            toast = "حدد عنصرًا أولًا"
            return
        }

        pushUndoSnapshot(
            linkedGeometry ? "Linked Duplicate" : "Duplicate"
        )

        var copies: [SCNNode] = []

        for original in originals {
            let copy = original.clone()
            renewAnimationIdentity(copy)
            copy.name = nextName(
                (original.name ?? "Object") +
                (linkedGeometry ? " Linked" : " Copy")
            )

            if !linkedGeometry {
                makeGeometryUniqueRecursively(copy)
            }

            let parent = original.parent ?? contentRoot
            parent.addChildNode(copy)
            copy.transform = original.transform
            copy.position.x += 0.25
            copy.position.z += 0.25
            copies.append(copy)
        }

        if let last = copies.last {
            select(last)
            multiSelectedNodes = copies
            refreshSelectionGizmo()
        }

        viewportInteractionMode = .object
        transformMode = .move
        rebuildTransformGizmo()
        objectWillChange.send()

        toast = linkedGeometry
            ? "Linked duplicate created"
            : "Duplicate created"
    }

    func makeGeometryUniqueRecursively(
        _ node: SCNNode
    ) {
        if let geometry = node.geometry,
           let copied = geometry.copy() as? SCNGeometry {
            node.geometry = copied
            copied.materials = geometry.materials.map {
                ($0.copy() as? SCNMaterial) ?? $0
            }
        }

        for child in node.childNodes {
            makeGeometryUniqueRecursively(child)
        }
    }

    func parentSelectionToActive() {
        guard let active = selectedNode else {
            toast = "حدد العنصر الأب"
            return
        }

        let children = editingNodes.filter {
            $0 !== active && !isAncestorNode($0, of: active)
        }

        guard !children.isEmpty else {
            toast = "حدد الأب ومعه عنصر تابع"
            return
        }

        pushUndoSnapshot("Parent")

        for child in children {
            let world = child.worldTransform
            active.addChildNode(child)
            setWorldTransform(world, on: child)
        }

        select(active)
        toast = "Parent set"
    }

    func clearParentKeepTransform() {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }

        pushUndoSnapshot("Clear Parent")

        for node in nodes {
            guard let parent = node.parent,
                  parent !== contentRoot else {
                continue
            }

            let world = node.worldTransform
            contentRoot.addChildNode(node)
            setWorldTransform(world, on: node)
        }

        refreshSelectionGizmo()
        objectWillChange.send()
        toast = "Parent cleared"
    }

    func resetSelectedRotation() {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }

        pushUndoSnapshot("Reset Rotation")

        for node in nodes {
            node.eulerAngles = SCNVector3Zero
            node.orientation = SCNQuaternion(0, 0, 0, 1)
        }

        refreshSelectionGizmo()
        objectWillChange.send()
        toast = "Rotation reset"
    }

    func resetSelectedScale() {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }

        pushUndoSnapshot("Reset Scale")

        for node in nodes {
            node.scale = SCNVector3(1, 1, 1)
        }

        refreshSelectionGizmo()
        objectWillChange.send()
        toast = "Scale reset"
    }

    func showAllObjects() {
        contentRoot.enumerateChildNodes { node, _ in
            if node.name != "_SelectionOutline" && node.name != "_TransformGizmo" && !node.isStudioMetadata {
                node.isHidden = false
            }
        }

        objectWillChange.send()
        toast = "All objects visible"
    }

    func unlockAllObjects() {
        contentRoot.enumerateChildNodes { node, _ in
            node.categoryBitMask &= ~lockedCategoryBit
        }

        objectWillChange.send()
        toast = "All objects unlocked"
    }

    // MARK: - Array / Instance Tools

    func safeArrayCount(_ requested: Int, source: SCNNode) -> Int {
        var nodes = 1
        source.enumerateChildNodes { _, stop in
            nodes += 1
            if nodes > 6_000 { stop.pointee = true }
        }
        return min(max(2, min(64, requested)), 6_000 / nodes)
    }

    func createLinearArray(count: Int = 4, spacing: Float = 1.5, axis: Axis3D = .x, linkedGeometry: Bool = true) {
        guard let source = selectedNode else { toast = "حدد عنصرًا أولًا"; return }
        let safeCount = safeArrayCount(count, source: source)
        guard safeCount >= 2 else { toast = "العنصر كبير جدًا للنسخ المتكرر / Array exceeds node budget"; return }
        let safeSpacing = max(0.01, spacing)
        pushUndoSnapshot("Linear Array")
        var created: [SCNNode] = [source]

        for index in 1..<safeCount {
            let copy = source.clone()
            renewAnimationIdentity(copy)
            copy.name = nextName((source.name ?? "Object") + " Array")
            if !linkedGeometry { makeGeometryUniqueRecursively(copy) }
            let parent = source.parent ?? contentRoot
            parent.addChildNode(copy)
            copy.transform = source.transform
            let amount = Float(index) * safeSpacing
            switch axis {
            case .x: copy.position.x += amount
            case .y: copy.position.y += amount
            case .z: copy.position.z += amount
            }
            created.append(copy)
        }

        if let last = created.last {
            select(last)
            multiSelectedNodes = created
            refreshSelectionGizmo()
        }
        objectWillChange.send()
        toast = "Linear array • \(safeCount)"
    }

    func createRadialArray(count: Int = 8, radius: Float = 2, axis: Axis3D = .y, linkedGeometry: Bool = true) {
        guard let source = selectedNode else { toast = "حدد عنصرًا أولًا"; return }
        let safeCount = safeArrayCount(count, source: source)
        guard safeCount >= 2 else { toast = "العنصر كبير جدًا للنسخ المتكرر / Array exceeds node budget"; return }
        let safeRadius = max(0.05, radius)
        pushUndoSnapshot("Radial Array")
        let center = workPoint
        var created: [SCNNode] = []

        for index in 0..<safeCount {
            let node: SCNNode
            if index == 0 {
                node = source
            } else {
                node = source.clone()
                renewAnimationIdentity(node)
                node.name = nextName((source.name ?? "Object") + " Radial")
                if !linkedGeometry { makeGeometryUniqueRecursively(node) }
                let parent = source.parent ?? contentRoot
                parent.addChildNode(node)
                node.transform = source.transform
            }

            let angle = Float(index) / Float(safeCount) * Float.pi * 2
            var world = center
            switch axis {
            case .x:
                world.y += cos(angle) * safeRadius
                world.z += sin(angle) * safeRadius
            case .y:
                world.x += cos(angle) * safeRadius
                world.z += sin(angle) * safeRadius
            case .z:
                world.x += cos(angle) * safeRadius
                world.y += sin(angle) * safeRadius
            }

            if let parent = node.parent {
                node.position = parent.convertPosition(world, from: nil)
            } else {
                node.position = world
            }
            created.append(node)
        }

        if let last = created.last {
            select(last)
            multiSelectedNodes = created
            refreshSelectionGizmo()
        }
        objectWillChange.send()
        toast = "Radial array • \(safeCount)"
    }

    func makeSelectedGeometryUnique() {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }
        pushUndoSnapshot("Make Unique")
        for node in nodes { makeGeometryUniqueRecursively(node) }
        objectWillChange.send()
        toast = "Geometry is now unique"
    }

    func isolateSelectedObjects() {
        let chosen = editingNodes
        guard !chosen.isEmpty else { toast = "حدد عنصرًا أولًا"; return }

        contentRoot.enumerateChildNodes { node, _ in
            guard node.geometry != nil else { return }
            var keep = chosen.contains { $0 === node }
            if !keep {
                keep = chosen.contains {
                    isAncestorNode($0, of: node) || isAncestorNode(node, of: $0)
                }
            }
            node.isHidden = !keep
        }
        objectWillChange.send()
        toast = "Isolated selection"
    }

    // MARK: - Object Constraints / Display

    func addLookAtConstraintToActive() {
        guard let target = selectedNode else { toast = "حدد الهدف أولًا"; return }
        let followers = editingNodes.filter { $0 !== target }
        guard !followers.isEmpty else { toast = "حدد الهدف ومعه عنصرًا آخر"; return }
        pushUndoSnapshot("Look At Constraint")
        for node in followers {
            let c = SCNLookAtConstraint(target: target)
            c.isGimbalLockEnabled = true
            node.constraints = (node.constraints ?? []) + [c]
        }
        objectWillChange.send()
        toast = "Look At constraint added"
    }

    func addBillboardConstraintToSelection() {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }
        pushUndoSnapshot("Billboard Constraint")
        for node in nodes {
            let c = SCNBillboardConstraint()
            c.freeAxes = [.Y]
            node.constraints = (node.constraints ?? []) + [c]
        }
        objectWillChange.send()
        toast = "Billboard constraint added"
    }

    func clearSelectedConstraintsKeepTransform() {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }
        pushUndoSnapshot("Clear Constraints")
        for node in nodes {
            let world = node.presentation.worldTransform
            node.constraints = nil
            setWorldTransform(world, on: node)
        }
        refreshSelectionGizmo()
        objectWillChange.send()
        toast = "Constraints cleared"
    }

    func setSelectedWireframe(_ enabled: Bool) {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }
        for node in nodes {
            applyMaterialRecursively(node) { material in
                material.fillMode = enabled ? .lines : .fill
            }
        }
        objectWillChange.send()
        toast = enabled ? "Wireframe display" : "Solid display"
    }

    func setSelectedDepthRead(_ enabled: Bool) {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }
        for node in nodes {
            applyMaterialRecursively(node) { material in
                material.readsFromDepthBuffer = enabled
            }
        }
        objectWillChange.send()
        toast = enabled ? "Depth enabled" : "X-Ray style"
    }

    // MARK: - Object Organization / Blender-style Tools

    func isNodeLocked(_ node: SCNNode) -> Bool {
        var current: SCNNode? = node
        while let item = current {
            if (item.categoryBitMask & lockedCategoryBit) != 0 { return true }
            current = item.parent
        }
        return false
    }

    func toggleLockSelected() {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }

        pushUndoSnapshot("Lock / Unlock")

        let shouldLock = nodes.contains {
            !isNodeLocked($0)
        }

        for node in nodes {
            if shouldLock {
                node.categoryBitMask |= lockedCategoryBit
            } else {
                node.categoryBitMask &= ~lockedCategoryBit
            }
        }

        toast = shouldLock ? "Locked" : "Unlocked"
        objectWillChange.send()
    }

    func toggleHideSelected() {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }

        pushUndoSnapshot("Hide / Show")

        let shouldHide = nodes.contains {
            !$0.isHidden
        }

        for node in nodes {
            node.isHidden = shouldHide
        }

        if shouldHide {
            select(nil)
            viewportInteractionMode = .view
        }

        objectWillChange.send()
    }

    func groupSelectedNodes() {
        let nodes = editingNodes

        guard nodes.count >= 2 else {
            toast = "حدد عنصرين أو أكثر للتجميع"
            return
        }

        pushUndoSnapshot("Group")

        let parent = nodes.first?.parent ?? contentRoot
        let group = SCNNode()
        group.name = nextName("Group")

        var center = SCNVector3Zero

        for node in nodes {
            let p = node.presentation.worldPosition
            center.x += p.x
            center.y += p.y
            center.z += p.z
        }

        let count = Float(nodes.count)
        group.worldPosition = SCNVector3(
            center.x / count,
            center.y / count,
            center.z / count
        )

        parent.addChildNode(group)

        for node in nodes {
            let world = node.worldTransform
            group.addChildNode(node)
            setWorldTransform(world, on: node)
        }

        select(group)
        toast = "تم التجميع"
    }

    func ungroupSelectedNode() {
        guard let group = selectedNode,
              group.geometry == nil,
              !group.childNodes.isEmpty,
              let parent = group.parent else {
            toast = "حدد Group لفك التجميع"
            return
        }

        pushUndoSnapshot("Ungroup")

        let children = group.childNodes

        for child in children {
            let world = child.worldTransform
            parent.addChildNode(child)
            setWorldTransform(world, on: child)
        }

        group.removeFromParentNode()
        selectMultiple(children)
        toast = "تم فك التجميع"
    }

    func centerPivotOnSelection() {
        guard let node = selectedNode else { return }

        pushUndoSnapshot("Center Pivot")

        let box = node.boundingBox
        let center = SCNVector3(
            (box.min.x + box.max.x) * 0.5,
            (box.min.y + box.max.y) * 0.5,
            (box.min.z + box.max.z) * 0.5
        )

        let world = node.worldTransform

        node.pivot = SCNMatrix4MakeTranslation(
            center.x,
            center.y,
            center.z
        )

        setWorldTransform(world, on: node)
        select(node)
        toast = "Pivot centered"
    }

    func resetPivotOnSelection() {
        guard let node = selectedNode else { return }

        pushUndoSnapshot("Reset Pivot")

        let world = node.worldTransform
        node.pivot = SCNMatrix4Identity
        setWorldTransform(world, on: node)

        select(node)
        toast = "Pivot reset"
    }

    func mirrorSelected(axis: Axis3D) {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }

        pushUndoSnapshot("Mirror")

        for node in nodes {
            switch axis {
            case .x:
                node.scale.x *= -1
            case .y:
                node.scale.y *= -1
            case .z:
                node.scale.z *= -1
            }

            node.geometry?.materials.forEach {
                $0.isDoubleSided = true
            }
        }

        refreshSelectionGizmo()
        objectWillChange.send()
    }

    func addReferenceImage(_ image: UIImage) {
        pushUndoSnapshot("Reference Image")

        let ratio = max(
            0.1,
            image.size.width / max(1, image.size.height)
        )

        let plane = SCNPlane(
            width: CGFloat(3.0 * ratio),
            height: 3.0
        )

        let material = SCNMaterial()
        material.diffuse.contents = image
        material.emission.contents = image
        material.emission.intensity = 0.2
        material.isDoubleSided = true
        material.lightingModel = .constant

        plane.materials = [material]

        let node = SCNNode(geometry: plane)
        node.name = nextName("Reference")
        node.position = SCNVector3(
            workPoint.x,
            workPoint.y + 1.6,
            workPoint.z
        )

        contentRoot.addChildNode(node)
        select(node)
        toast = "Reference image added"
    }

    enum TextMaterialStyle: String, CaseIterable, Identifiable {
        case plain, metal, gold, neon, glass, matte, chrome, glow, gradient, outline
        var id: String { rawValue }
    }

    func availableTextFonts() -> [String] {
        let preferred = [
            "Arial-BoldMT", "ArialRoundedMTBold", "AvenirNext-Bold",
            "AvenirNextCondensed-Bold", "HelveticaNeue-Bold",
            "HelveticaNeue-CondensedBlack", "Futura-Bold",
            "GillSans-Bold", "Georgia-Bold", "TimesNewRomanPS-BoldMT",
            "Courier-Bold", "Menlo-Bold", "MarkerFelt-Wide",
            "Noteworthy-Bold", "ChalkboardSE-Bold", "Copperplate-Bold",
            "Damascus-Bold", "GeezaPro-Bold", "AlNile-Bold",
            "DiwanMishafi", "Farisi", "Kefa-Bold"
        ]
        let installed = Set(UIFont.familyNames.flatMap { UIFont.fontNames(forFamilyName: $0) })
        let valid = preferred.filter { installed.contains($0) }
        return valid.isEmpty ? ["HelveticaNeue-Bold"] : valid
    }

    func applyTextMaterialStyle(
        _ style: TextMaterialStyle,
        to material: SCNMaterial,
        color: UIColor
    ) {
        material.diffuse.contents = color
        material.emission.contents = UIColor.black
        material.emission.intensity = 0
        material.metalness.contents = 0.0
        material.roughness.contents = 0.45
        material.transparency = 1.0
        material.lightingModel = .physicallyBased
        material.blendMode = .alpha
        material.isDoubleSided = true

        switch style {
        case .plain:
            material.roughness.contents = 0.45
        case .metal:
            material.metalness.contents = 0.9
            material.roughness.contents = 0.24
        case .gold:
            material.diffuse.contents = UIColor(red: 1.0, green: 0.68, blue: 0.12, alpha: 1)
            material.metalness.contents = 0.95
            material.roughness.contents = 0.18
        case .neon:
            material.diffuse.contents = color
            material.emission.contents = color
            material.emission.intensity = 2.2
            material.roughness.contents = 0.2
        case .glass:
            material.diffuse.contents = color.withAlphaComponent(0.32)
            material.transparency = 0.34
            material.roughness.contents = 0.08
            material.metalness.contents = 0.05
        case .matte:
            material.roughness.contents = 0.92
            material.metalness.contents = 0.0
        case .chrome:
            material.diffuse.contents = UIColor(white: 0.82, alpha: 1)
            material.metalness.contents = 1.0
            material.roughness.contents = 0.06
        case .glow:
            material.diffuse.contents = color
            material.emission.contents = color
            material.emission.intensity = 4.0
            material.roughness.contents = 0.1
        case .gradient:
            let size = CGSize(width: 512, height: 128)
            let renderer = UIGraphicsImageRenderer(size: size)
            material.diffuse.contents = renderer.image { context in
                let colors = [color.cgColor, UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor] as CFArray
                let space = CGColorSpaceCreateDeviceRGB()
                if let gradient = CGGradient(colorsSpace: space, colors: colors, locations: [0, 0.5, 1]) {
                    context.cgContext.drawLinearGradient(
                        gradient,
                        start: CGPoint(x: 0, y: 0),
                        end: CGPoint(x: size.width, y: 0),
                        options: []
                    )
                }
            }
            material.roughness.contents = 0.3
        case .outline:
            material.diffuse.contents = color
            material.emission.contents = color.withAlphaComponent(0.35)
            material.emission.intensity = 0.7
            material.metalness.contents = 0.15
            material.roughness.contents = 0.28
        }
    }

    func add3DText(
        _ value: String = "نص",
        fontName: String? = nil,
        style: TextMaterialStyle = .plain,
        color: UIColor = .white,
        extrusion: CGFloat = 0.08,
        fontSize: CGFloat = 1.0,
        chamfer: CGFloat = 0.02,
        flatness: CGFloat = 0.12
    ) {
        pushUndoSnapshot("3D Text")

        let text = SCNText(string: value.isEmpty ? "نص" : value, extrusionDepth: extrusion)
        text.flatness = max(0.01, flatness)
        if let fontName, let font = UIFont(name: fontName, size: fontSize) {
            text.font = font
        } else {
            text.font = UIFont.systemFont(ofSize: fontSize, weight: .bold)
        }
        text.alignmentMode = CATextLayerAlignmentMode.center.rawValue
        text.chamferRadius = min(max(0, chamfer), max(0.001, extrusion * 0.8))

        let front = SCNMaterial()
        applyTextMaterialStyle(style, to: front, color: color)
        text.materials = [front]

        let node = SCNNode(geometry: text)
        node.name = nextName("Text")
        node.scale = SCNVector3(0.7, 0.7, 0.7)
        node.setValue(style.rawValue, forKey: "studioTextStyle")
        node.setValue(fontName ?? "", forKey: "studioTextFont")

        contentRoot.addChildNode(node)
        placeNewNode(node)
        select(node)
        toast = appLanguage == .arabic ? "تمت إضافة النص" : "Text added"
    }

    func updateSelected3DText(
        value: String,
        fontName: String,
        style: TextMaterialStyle,
        color: UIColor,
        extrusion: CGFloat
    ) {
        guard let node = selectedNode, let text = node.geometry as? SCNText else { return }
        pushUndoSnapshot("Edit 3D Text")
        text.string = value
        if let font = UIFont(name: fontName, size: text.font?.pointSize ?? 1.0) {
            text.font = font
        }
        text.extrusionDepth = extrusion
        if text.materials.isEmpty { text.materials = [SCNMaterial()] }
        if let material = text.materials.first {
            applyTextMaterialStyle(style, to: material, color: color)
        }
        node.setValue(style.rawValue, forKey: "studioTextStyle")
        node.setValue(fontName, forKey: "studioTextFont")
        objectWillChange.send()
        toast = appLanguage == .arabic ? "تم تحديث النص" : "Text updated"
    }



    enum TextAnimationPreset: String, CaseIterable, Identifiable {
        case wave, pop, spin, float, pulse
        var id: String { rawValue }
    }

    func animateSelectedText(_ preset: TextAnimationPreset) {
        guard let node = selectedNode, node.geometry is SCNText else {
            toast = appLanguage == .arabic ? "حدد نصًا أولًا" : "Select a text object first"
            return
        }
        pushUndoSnapshot("Text Animation")
        let key = "5ln.text.\(preset.rawValue)"
        node.removeAnimation(forKey: key, blendOutDuration: 0.1)

        let animation: CAAnimation
        switch preset {
        case .wave:
            let a = CABasicAnimation(keyPath: "position.y")
            a.byValue = 0.35
            a.duration = 0.55
            a.autoreverses = true
            a.repeatCount = .greatestFiniteMagnitude
            a.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
            animation = a
        case .pop:
            let a = CAKeyframeAnimation(keyPath: "scale")
            a.values = [
                NSValue(scnVector3: SCNVector3(0.65,0.65,0.65)),
                NSValue(scnVector3: SCNVector3(1.15,1.15,1.15)),
                NSValue(scnVector3: SCNVector3(1,1,1))
            ]
            a.keyTimes = [0,0.65,1]
            a.duration = 0.5
            animation = a
        case .spin:
            let a = CABasicAnimation(keyPath: "rotation")
            a.byValue = NSValue(scnVector4: SCNVector4(0,1,0,Float.pi * 2))
            a.duration = 2.2
            a.repeatCount = .greatestFiniteMagnitude
            animation = a
        case .float:
            let a = CABasicAnimation(keyPath: "position.y")
            a.byValue = 0.18
            a.duration = 1.4
            a.autoreverses = true
            a.repeatCount = .greatestFiniteMagnitude
            a.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
            animation = a
        case .pulse:
            let a = CABasicAnimation(keyPath: "scale")
            a.byValue = NSValue(scnVector3: SCNVector3(0.12,0.12,0.12))
            a.duration = 0.7
            a.autoreverses = true
            a.repeatCount = .greatestFiniteMagnitude
            animation = a
        }
        animation.isRemovedOnCompletion = false
        node.addAnimation(animation, forKey: key)
        toast = appLanguage == .arabic ? "تمت إضافة حركة للنص" : "Text animation added"
    }

    func removeTextAnimations() {
        guard let node = selectedNode else { return }
        for key in node.animationKeys where key.hasPrefix("5ln.text.") {
            node.removeAnimation(forKey: key, blendOutDuration: 0.15)
        }
    }

    // MARK: - Workspace / Placement Engine

    var workPoint = SCNVector3(0, 0, 0)

    func prepareForWorkspace(_ node: SCNNode, normalizeSize: Bool) {
        selectionOutline?.removeFromParentNode()
        selectionOutline = nil
        selectionGizmo?.removeFromParentNode()
        selectionGizmo = nil

        unhideImportedTree(node)

        // For imported assemblies, use actual world-space bounds after the model
        // is inside the scene. This prevents translated child meshes from vanishing.
        if normalizeSize, autoFitImports, let before = worldBounds(of: node) {
            let sx = max(0.0001, before.max.x - before.min.x)
            let sy = max(0.0001, before.max.y - before.min.y)
            let sz = max(0.0001, before.max.z - before.min.z)
            let maxSide = max(sx, max(sy, sz))

            let targetSize: Float = 4.2
            if maxSide.isFinite && maxSide > 0.0001 {
                let factor = targetSize / maxSide
                node.scale = SCNVector3(
                    node.scale.x * factor,
                    node.scale.y * factor,
                    node.scale.z * factor
                )
            }
        }

        // Recalculate after scaling, then move the complete assembly so its
        // center is at X/Z = 0 and its bottom rests on Y = 0.
        if let after = worldBounds(of: node) {
            let centerX = (after.min.x + after.max.x) * 0.5
            let centerZ = (after.min.z + after.max.z) * 0.5
            let bottomY = after.min.y

            node.position = SCNVector3(
                node.position.x + workPoint.x - centerX,
                node.position.y + workPoint.y - bottomY,
                node.position.z + workPoint.z - centerZ
            )
        } else {
            node.position = workPoint
        }
    }

    func placeNewNode(_ node: SCNNode, normalizeSize: Bool = false) {
        prepareForWorkspace(node, normalizeSize: normalizeSize)
        select(node)
        if autoFocusNewObjects {
            DispatchQueue.main.async { [weak self, weak node] in
                guard let self, let node else { return }
                self.frameNode(node)
            }
        }
    }

    func centerSelectedOnWorkPoint() {
        guard let selectedNode else { return }
        prepareForWorkspace(selectedNode, normalizeSize: false)
        select(selectedNode)
        frameNode(selectedNode)
        toast = "تم نقل العنصر إلى نقطة العمل"
    }

    func snapSelectedToGrid() {
        guard let node = selectedNode else { return }
        let step = Float(max(0.01, snapStep))
        node.position = SCNVector3(
            (node.position.x / step).rounded() * step,
            (node.position.y / step).rounded() * step,
            (node.position.z / step).rounded() * step
        )
        objectWillChange.send()
    }

    // MARK: - Precision / Snap / Align Tools

    func snapSelectionToWorldOrigin() {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }

        pushUndoSnapshot("Selection to World Origin")

        let center = selectionWorldCenter(nodes)
        let delta = SCNVector3(
            -center.x,
            -center.y,
            -center.z
        )

        offsetWorld(nodes, by: delta)
        refreshSelectionGizmo()
        objectWillChange.send()
        toast = "Selection → World Origin"
    }

    func snapSelectionToWorkPoint() {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }

        pushUndoSnapshot("Selection to Work Point")

        let center = selectionWorldCenter(nodes)
        let delta = SCNVector3(
            workPoint.x - center.x,
            workPoint.y - center.y,
            workPoint.z - center.z
        )

        offsetWorld(nodes, by: delta)
        refreshSelectionGizmo()
        objectWillChange.send()
        toast = "Selection → Work Point"
    }

    func snapSelectionToActive() {
        guard let active = selectedNode, multiSelectedNodes.count > 1 else { return }
        let target = active.worldPosition
        for node in editingNodes where node !== active && !isNodeLocked(node) {
            node.worldPosition = target
        }
        refreshSelectionGizmo()
    }

    func workPointToSelection() {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }

        workPoint = selectionWorldCenter(nodes)
        rebuildHelpers()
        objectWillChange.send()
        toast = "Work Point → Selection"
    }

    func workPointToWorldOrigin() {
        workPoint = SCNVector3Zero
        rebuildHelpers()
        objectWillChange.send()
        toast = "Work Point → World Origin"
    }

    func snapSelectionToGridPrecise() {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }

        pushUndoSnapshot("Selection to Grid")

        let step = Float(max(0.01, snapStep))
        let center = selectionWorldCenter(nodes)

        let target = SCNVector3(
            (center.x / step).rounded() * step,
            (center.y / step).rounded() * step,
            (center.z / step).rounded() * step
        )

        offsetWorld(
            nodes,
            by: SCNVector3(
                target.x - center.x,
                target.y - center.y,
                target.z - center.z
            )
        )

        refreshSelectionGizmo()
        objectWillChange.send()
        toast = "Selection → Grid"
    }

    func alignSelectionToActive(axis: Axis3D) {
        guard let active = selectedNode else { return }

        let nodes = editingNodes.filter { $0 !== active }
        guard !nodes.isEmpty else {
            toast = "حدد أكثر من عنصر للمحاذاة"
            return
        }

        pushUndoSnapshot("Align to Active")

        let activeWorld = active.presentation.worldPosition

        for node in nodes {
            var world = node.presentation.worldPosition

            switch axis {
            case .x:
                world.x = activeWorld.x
            case .y:
                world.y = activeWorld.y
            case .z:
                world.z = activeWorld.z
            }

            if let parent = node.parent {
                node.position = parent.convertPosition(world, from: nil)
            } else {
                node.position = world
            }
        }

        refreshSelectionGizmo()
        objectWillChange.send()
        toast = "Aligned \(axisLabel(axis))"
    }

    func distributeSelection(axis: Axis3D) {
        let nodes = editingNodes
        guard nodes.count >= 3 else {
            toast = "حدد 3 عناصر أو أكثر للتوزيع"
            return
        }

        pushUndoSnapshot("Distribute")

        let sorted = nodes.sorted {
            axisComponent($0.presentation.worldPosition, axis) <
            axisComponent($1.presentation.worldPosition, axis)
        }

        guard let first = sorted.first,
              let last = sorted.last else { return }

        let minValue = axisComponent(
            first.presentation.worldPosition,
            axis
        )

        let maxValue = axisComponent(
            last.presentation.worldPosition,
            axis
        )

        let step = (maxValue - minValue) /
            Float(max(1, sorted.count - 1))

        for (index, node) in sorted.enumerated() {
            var world = node.presentation.worldPosition
            setAxisComponent(
                &world,
                axis,
                minValue + Float(index) * step
            )

            if let parent = node.parent {
                node.position = parent.convertPosition(world, from: nil)
            } else {
                node.position = world
            }
        }

        refreshSelectionGizmo()
        objectWillChange.send()
        toast = "Distributed \(axisLabel(axis))"
    }

    func selectionWorldCenter(
        _ nodes: [SCNNode]
    ) -> SCNVector3 {
        guard !nodes.isEmpty else { return SCNVector3Zero }

        var sum = SCNVector3Zero

        for node in nodes {
            let p = node.presentation.worldPosition
            sum.x += p.x
            sum.y += p.y
            sum.z += p.z
        }

        let count = Float(nodes.count)

        return SCNVector3(
            sum.x / count,
            sum.y / count,
            sum.z / count
        )
    }

    func offsetWorld(
        _ nodes: [SCNNode],
        by delta: SCNVector3
    ) {
        for node in nodes {
            let old = node.presentation.worldPosition
            let target = SCNVector3(
                old.x + delta.x,
                old.y + delta.y,
                old.z + delta.z
            )

            if let parent = node.parent {
                node.position = parent.convertPosition(target, from: nil)
            } else {
                node.position = target
            }
        }
    }

    func axisComponent(
        _ value: SCNVector3,
        _ axis: Axis3D
    ) -> Float {
        switch axis {
        case .x: return value.x
        case .y: return value.y
        case .z: return value.z
        }
    }

    func setAxisComponent(
        _ value: inout SCNVector3,
        _ axis: Axis3D,
        _ component: Float
    ) {
        switch axis {
        case .x: value.x = component
        case .y: value.y = component
        case .z: value.z = component
        }
    }

    func axisLabel(_ axis: Axis3D) -> String {
        switch axis {
        case .x: return "X"
        case .y: return "Y"
        case .z: return "Z"
        }
    }

    func addEmpty() {
        pushUndoSnapshot("Add Empty")
        let n = SCNNode()
        n.name = nextName("Empty")
        n.position = SCNVector3(workPoint.x, workPoint.y + 0.5, workPoint.z)
        contentRoot.addChildNode(n)
        select(n)
        toast = "تمت إضافة Empty للتحريك أو التجميع"
    }

    func addPrimitive(_ type: PrimitiveKind) {
        pushUndoSnapshot("Add \(type.title)")
        let node: SCNNode
        switch type {
        case .cube:
            node = SCNNode(geometry: SCNBox(width: 1, height: 1, length: 1, chamferRadius: 0.03))
            node.name = nextName("Cube")
        case .sphere:
            node = SCNNode(geometry: SCNSphere(radius: 0.65))
            node.name = nextName("Sphere")
        case .cylinder:
            node = SCNNode(geometry: SCNCylinder(radius: 0.55, height: 1.3))
            node.name = nextName("Cylinder")
        case .plane:
            node = SCNNode(geometry: SCNPlane(width: 2, height: 2))
            node.eulerAngles.x = -.pi / 2
            node.name = nextName("Plane")
        case .torus:
            node = SCNNode(geometry: SCNTorus(ringRadius: 0.7, pipeRadius: 0.18))
            node.name = nextName("Torus")
        case .capsule:
            node = SCNNode(geometry: SCNCapsule(capRadius: 0.42, height: 1.55))
            node.name = nextName("Capsule")
        case .cone:
            node = SCNNode(geometry: SCNCone(topRadius: 0, bottomRadius: 0.65, height: 1.4))
            node.name = nextName("Cone")
        case .pyramid:
            node = SCNNode(geometry: SCNPyramid(width: 1.2, height: 1.4, length: 1.2))
            node.name = nextName("Pyramid")
        case .tube:
            node = SCNNode(geometry: SCNTube(innerRadius: 0.35, outerRadius: 0.62, height: 1.2))
            node.name = nextName("Tube")
        }

        // New primitives use the same readable default material family as the starter cube.
        // Create/assign explicit material instances so SceneKit never falls back to white.
        if let geometry = node.geometry {
            let material = SCNMaterial()
            material.name = "DefaultBlue"
            material.lightingModel = .physicallyBased
            material.diffuse.contents = UIColor(red: 0.19, green: 0.42, blue: 0.98, alpha: 1)
            material.metalness.contents = 0.25
            material.roughness.contents = 0.28
            material.isDoubleSided = (type == .plane)
            geometry.materials = [material]
        }
        contentRoot.addChildNode(node)
        placeNewNode(node)
        statusText = "تمت إضافة \(node.name ?? "Object") عند نقطة العمل"
    }

    func addLight(_ type: LightKind) {
        pushUndoSnapshot("Add Light")
        let n = SCNNode()
        n.name = nextName(type.title)
        let light = SCNLight()
        switch type {
        case .omni: light.type = .omni
        case .spot:
            light.type = .spot
            light.spotInnerAngle = 20
            light.spotOuterAngle = 55
        case .directional: light.type = .directional
        case .ambient: light.type = .ambient
        }
        light.intensity = type == .ambient ? 350 : 1000
        switch type {
        case .ambient:
            break
        default:
            light.castsShadow = true
            light.shadowRadius = 5
            light.shadowSampleCount = 8
        }
        n.light = light
        n.position = SCNVector3(workPoint.x + 1.8, workPoint.y + 2.6, workPoint.z + 2.2)
        lightsRoot.addChildNode(n)
        installEditorMarker(for: n)
        select(n)
        toast = "تمت إضافة \(n.name ?? "Light") قرب نقطة العمل"
    }

    func addCamera() {
        pushUndoSnapshot("Add Camera")
        let n = SCNNode()
        n.name = nextName("Camera")
        n.camera = SCNCamera()
        n.camera?.fieldOfView = 55
        n.camera?.wantsHDR = true
        n.camera?.zNear = 0.01
        n.camera?.zFar = 100_000
        n.camera?.categoryBitMask = Int.max ^ editorOnlyCategoryBit
        // New cameras always start close to the scene origin.  This must not
        // depend on a work point that may have been moved far away.
        n.position = SCNVector3(0, 1.7, 4.5)
        n.studioLook(at: SCNVector3(0, 0.8, 0))
        camerasRoot.addChildNode(n)
        installEditorMarker(for: n)
        select(n)
        toast = "تمت إضافة كاميرا قرب بداية المشروع"
    }

    enum CameraMotionPreset: String, CaseIterable, Identifiable {
        case orbit, pushIn, pullOut, panLeft, panRight, craneUp, craneDown, flyBy, reveal, dolly
        var id: String { rawValue }
        var title: String {
            switch self {
            case .orbit: return "Orbit 360°"; case .pushIn: return "Push In"; case .pullOut: return "Pull Out"
            case .panLeft: return "Pan Left"; case .panRight: return "Pan Right"; case .craneUp: return "Crane Up"
            case .craneDown: return "Crane Down"; case .flyBy: return "Fly By"; case .reveal: return "Reveal"; case .dolly: return "Dolly Side"
            }
        }
    }

    func applyCameraMotionPreset(_ preset: CameraMotionPreset, seconds: Double = 15) {
        guard let camera = selectedNode, camera.camera != nil else { toast = "حدد كاميرا أولًا / Select a camera first"; return }
        pushUndoSnapshot("Camera Preset")
        let start = currentTime
        let end = start + max(1, seconds)
        if duration < end { duration = end }
        let original = camera.position
        let target = workPoint
        let track = activeMotionTrackID(for: camera)
        func pose(_ t: Double, _ p: SCNVector3, look: SCNVector3 = target) -> StudioKeyframe {
            let helper = SCNNode(); helper.position = p; helper.studioLook(at: look)
            return StudioKeyframe(nodeID: animationIdentity(camera), nodeName: camera.name ?? "Camera", time: t, position: p, euler: helper.eulerAngles, scale: camera.scale, cameraFOV: Double(camera.camera?.fieldOfView ?? 55), cameraExposure: Double(camera.camera?.exposureOffset ?? 0), cameraBloom: Double(camera.camera?.bloomIntensity ?? 0), trackID: track, interpolation: .smooth)
        }
        let r = max(3.0, sqrt(pow(original.x-target.x,2)+pow(original.z-target.z,2)))
        var frames:[StudioKeyframe] = []
        switch preset {
        case .orbit:
            frames = [pose(start, SCNVector3(target.x+r, original.y, target.z)), pose(start+seconds*0.25, SCNVector3(target.x, original.y, target.z+r)), pose(start+seconds*0.5, SCNVector3(target.x-r, original.y, target.z)), pose(start+seconds*0.75, SCNVector3(target.x, original.y, target.z-r)), pose(end, SCNVector3(target.x+r, original.y, target.z))]
        case .pushIn: frames = [pose(start, original), pose(end, SCNVector3((original.x+target.x)*0.5, (original.y+target.y)*0.5, (original.z+target.z)*0.5))]
        case .pullOut: frames = [pose(start, original), pose(end, SCNVector3(target.x+(original.x-target.x)*1.8, target.y+(original.y-target.y)*1.4, target.z+(original.z-target.z)*1.8))]
        case .panLeft: frames = [pose(start, original), pose(end, SCNVector3(original.x-r, original.y, original.z))]
        case .panRight: frames = [pose(start, original), pose(end, SCNVector3(original.x+r, original.y, original.z))]
        case .craneUp: frames = [pose(start, original), pose(end, SCNVector3(original.x, original.y+r, original.z))]
        case .craneDown: frames = [pose(start, original), pose(end, SCNVector3(original.x, original.y-r*0.6, original.z))]
        case .flyBy: frames = [pose(start, SCNVector3(target.x-r, original.y, target.z+r)), pose(end, SCNVector3(target.x+r, original.y, target.z-r))]
        case .reveal: frames = [pose(start, SCNVector3(original.x-r*0.35, original.y, original.z+r*0.25)), pose(end, original)]
        case .dolly: frames = [pose(start, SCNVector3(original.x-r*0.5, original.y, original.z)), pose(end, SCNVector3(original.x+r*0.5, original.y, original.z))]
        }
        keyframes.removeAll { $0.nodeID == animationIdentity(camera) && $0.trackID == track && $0.time >= start-0.001 && $0.time <= end+0.001 }
        keyframes.append(contentsOf: frames); keyframes.sort { $0.time < $1.time }; timelineChannels = nil
        toast = "تمت إضافة حركة كاميرا 15 ثانية / Camera motion added"
    }

    func installEditorMarker(for target: SCNNode) {
        guard target.camera != nil || target.light != nil else { return }
        let identity = animationIdentity(target)
        let markerName = "_EditorMarker:" + identity
        editorRoot.childNode(withName: markerName, recursively: false)?.removeFromParentNode()

        let root = SCNNode()
        root.name = markerName
        root.categoryBitMask = editorOnlyCategoryBit
        root.renderingOrder = 999

        let color: UIColor = target.camera != nil ? .systemBlue : .systemYellow
        let body: SCNGeometry
        if target.camera != nil {
            body = SCNBox(width: 0.34, height: 0.22, length: 0.22, chamferRadius: 0.04)
            let lens = SCNNode(geometry: SCNCone(topRadius: 0.09, bottomRadius: 0.16, height: 0.22))
            lens.eulerAngles.x = -.pi / 2
            lens.position.z = -0.20
            lens.categoryBitMask = editorOnlyCategoryBit
            root.addChildNode(lens)
        } else {
            body = SCNSphere(radius: 0.14)
        }
        let material = SCNMaterial()
        material.diffuse.contents = color
        material.emission.contents = color.withAlphaComponent(0.65)
        material.lightingModel = .constant
        body.materials = [material]
        let glyph = SCNNode(geometry: body)
        glyph.categoryBitMask = editorOnlyCategoryBit
        root.addChildNode(glyph)

        // Keep the editor-only symbol attached to the real object without
        // making it part of the camera/light hierarchy or final render.
        let follow = SCNTransformConstraint(inWorldSpace: true) { [weak target] _, _ in
            target?.presentation.worldTransform ?? SCNMatrix4Identity
        }
        root.constraints = [follow]
        editorRoot.addChildNode(root)
    }

    func refreshEditorMarkers() {
        editorRoot.childNodes.filter { $0.name?.hasPrefix("_EditorMarker:") == true }.forEach { $0.removeFromParentNode() }
        camerasRoot.childNodes.filter { $0.camera != nil }.forEach { installEditorMarker(for: $0) }
        lightsRoot.childNodes.filter { $0.light != nil }.forEach { installEditorMarker(for: $0) }
    }

    func duplicateSelected() {
        let nodes = editingNodes
        guard !nodes.isEmpty else { return }

        pushUndoSnapshot("Duplicate")

        var clones: [SCNNode] = []

        for node in nodes {
            // Duplicate the transform hierarchy while sharing heavy geometry.
            // "Make Unique" remains available when an independent mesh/material
            // copy is actually needed.
            let clone = node.clone()
            renewAnimationIdentity(clone)
            clone.name = nextName(
                node.name ?? "Object"
            )
            clone.position.x += 0.45
            node.parent?.addChildNode(clone)
            clones.append(clone)
        }

        selectMultiple(clones)

        if clones.count == 1,
           autoFocusNewObjects,
           let clone = clones.first {
            frameNode(clone)
        }
    }

    func deleteSelected() {
        let nodes = editingNodes.filter {
            $0 !== contentRoot &&
            $0 !== camerasRoot &&
            $0 !== lightsRoot
        }

        guard !nodes.isEmpty else {
            return
        }

        // Keep only top-level selected nodes. If a selected child belongs to another
        // selected node, the parent's snapshot already contains it.
        let nodeIDs = Set(nodes.map { ObjectIdentifier($0) })
        let topLevelNodes = nodes.filter { node in
            var p = node.parent
            while let parent = p {
                if nodeIDs.contains(ObjectIdentifier(parent)) { return false }
                p = parent.parent
            }
            return true
        }

        let records: [DeletedNodeRecord] = topLevelNodes.compactMap { node in
            guard let parent = node.parent,
                  let index = parent.childNodes.firstIndex(where: { $0 === node }) else { return nil }
            return DeletedNodeRecord(
                parent: parent,
                siblingIndex: index,
                snapshot: cleanDeepClone(node, copyGeometry: true)
            )
        }
        guard !records.isEmpty else { return }
        let command = DeleteHistoryCommand(
            label: records.count > 1 ? "Delete \(records.count) Parts" : "Delete",
            records: records
        )
        deleteUndoStack.append(command)
        deleteRedoStack.removeAll()
        redoStack.removeAll(); transformRedoStack.removeAll(); materialRedoStack.removeAll()
        if deleteUndoStack.count > 30 { deleteUndoStack.removeFirst(deleteUndoStack.count - 30) }

        for node in topLevelNodes {
            node.removeFromParentNode()
        }
        undoCount = undoStack.count + transformUndoStack.count + materialUndoStack.count + deleteUndoStack.count
        redoCount = redoStack.count + transformRedoStack.count + materialRedoStack.count + deleteRedoStack.count
        importNodeItems.removeAll { item in
            var current: SCNNode? = item.node
            while let node = current {
                if node === scene.rootNode { return false }
                current = node.parent
            }
            return true
        }

        select(nil)
        viewportInteractionMode = .view
        statusText = appLanguage == .arabic ? "تم الحذف" : "Deleted"
    }

    func beginHierarchyDrag(_ node: SCNNode) {
        guard node !== contentRoot, node !== camerasRoot, node !== lightsRoot else { return }
        hierarchyDraggedNode = node
        hierarchyDragIsActive = true
        select(node)
    }

    func cancelHierarchyDrag() {
        hierarchyDraggedNode = nil
        hierarchyDragIsActive = false
    }

    private func hierarchyCanReparent(_ node: SCNNode, to newParent: SCNNode) -> Bool {
        guard node !== newParent,
              node !== contentRoot, node !== camerasRoot, node !== lightsRoot else { return false }
        var current: SCNNode? = newParent
        while let value = current {
            if value === node { return false }
            current = value.parent
        }
        return true
    }

    @discardableResult
    func finishHierarchyDrag(to newParent: SCNNode) -> Bool {
        guard let node = hierarchyDraggedNode else { return false }
        defer { cancelHierarchyDrag() }
        guard hierarchyCanReparent(node, to: newParent) else { return false }

        if node.parent === newParent {
            select(node)
            return true
        }

        pushUndoSnapshot("Hierarchy Reparent")
        let world = node.simdWorldTransform
        node.removeFromParentNode()
        newParent.addChildNode(node)
        node.simdWorldTransform = world
        select(node)
        refreshSelectionGizmo()
        objectWillChange.send()
        toast = newParent === contentRoot
            ? (appLanguage == .arabic ? "تم فصل القطعة عن المجموعة" : "Part detached from group")
            : (appLanguage == .arabic ? "تم نقل القطعة داخل المجموعة" : "Part moved into group")
        return true
    }

    @discardableResult
    func detachHierarchyDraggedNode() -> Bool {
        finishHierarchyDrag(to: contentRoot)
    }

    func nextName(_ base: String) -> String {
        var i = 1
        var candidate = base
        while scene.rootNode.childNode(withName: candidate, recursively: true) != nil {
            i += 1
            candidate = "\(base) \(i)"
        }
        return candidate
    }
}


// MARK: - Motion & Lighting Engine (merged for Swift Playgrounds target stability)
@MainActor
extension StudioStore {
// MARK: - Quick Motion Engine

    func applyMotionPreset(_ preset: MotionPreset) {
        let nodes = editingNodes

        guard !nodes.isEmpty else {
            toast = "حدد عنصرًا أولًا"
            return
        }

        pushUndoSnapshot("Quick Motion")

        for node in nodes {
            node.removeAction(
                forKey: "QuickMotion"
            )

            let action: SCNAction

            switch preset {
            case .spinY:
                action = .repeatForever(
                    .rotateBy(
                        x: 0,
                        y: .pi * 2,
                        z: 0,
                        duration: 2
                    )
                )

            case .wheelX:
                action = .repeatForever(
                    .rotateBy(
                        x: .pi * 2,
                        y: 0,
                        z: 0,
                        duration: 1
                    )
                )

            case .bounce:
                let up = SCNAction.moveBy(
                    x: 0,
                    y: 0.12,
                    z: 0,
                    duration: 0.22
                )

                up.timingMode = .easeOut

                let down = SCNAction.moveBy(
                    x: 0,
                    y: -0.12,
                    z: 0,
                    duration: 0.22
                )

                down.timingMode = .easeIn

                action = .repeatForever(
                    .sequence([up, down])
                )

            case .sway:
                let a = SCNAction.rotateBy(
                    x: 0,
                    y: 0,
                    z: 0.08,
                    duration: 0.4
                )

                let b = SCNAction.rotateBy(
                    x: 0,
                    y: 0,
                    z: -0.16,
                    duration: 0.8
                )

                let c = SCNAction.rotateBy(
                    x: 0,
                    y: 0,
                    z: 0.08,
                    duration: 0.4
                )

                action = .repeatForever(
                    .sequence([a, b, c])
                )

            case .pulse:
                let up = SCNAction.scale(
                    by: 1.08,
                    duration: 0.35
                )

                let down = SCNAction.scale(
                    by: 1.0 / 1.08,
                    duration: 0.35
                )

                action = .repeatForever(
                    .sequence([up, down])
                )

            case .forward:
                action = SCNAction.moveBy(
                    x: 0,
                    y: 0,
                    z: -3,
                    duration: 2.5
                )
            }

            node.runAction(
                action,
                forKey: "QuickMotion"
            )
        }

        toast = preset.title
    }

    func stopQuickMotion() {
        for node in editingNodes {
            node.removeAction(
                forKey: "QuickMotion"
            )
        }

        toast = "Motion stopped"
    }

    // MARK: - Manual Lighting Tools

    func aimSelectedLightAtWorkPoint() {
        guard let node = selectedNode, node.light != nil else {
            toast = "حدد إضاءة من القائمة أولًا"
            return
        }
        node.studioLook(at: SCNVector3(workPoint.x, workPoint.y + 0.8, workPoint.z))
        objectWillChange.send()
    }

    func aimSelectedLightAtSelectedObject() {
        guard let lightNode = selectedNode, lightNode.light != nil else {
            toast = "حدد إضاءة من القائمة أولًا"
            return
        }

        // If a light is selected there is no second selection, so the work point
        // is the predictable manual target. The user can then rotate it precisely.
        lightNode.studioLook(at: SCNVector3(workPoint.x, workPoint.y + 0.8, workPoint.z))
        objectWillChange.send()
    }

    // MARK: - Part / Assembly Tools

    func selectParent() {
        guard let node = selectedNode,
              let parent = node.parent,
              parent !== contentRoot,
              parent !== scene.rootNode else { return }
        select(parent)
        statusText = "Selected Parent • \(parent.name ?? "Part")"
    }

    func toggleIsolation() {
        guard let selectedNode else { return }

        if isolateSelection {
            contentRoot.enumerateChildNodes { node, _ in
                node.isHidden = false
            }
            contentRoot.isHidden = false
            isolateSelection = false
            toast = "تم إظهار كل العناصر"
            return
        }

        let keep = Set(nodeChain(from: selectedNode))
        contentRoot.enumerateChildNodes { node, _ in
            if node.name == "_SelectionOutline" { return }

            let isSelectedBranch = keep.contains(ObjectIdentifier(node)) ||
                nodeIsDescendant(node, of: selectedNode)

            node.isHidden = !isSelectedBranch
        }

        selectedNode.isHidden = false
        isolateSelection = true
        toast = "تم عزل القطعة المحددة"
    }

    func nodeChain(from node: SCNNode) -> [ObjectIdentifier] {
        var chain: [ObjectIdentifier] = []
        var current: SCNNode? = node
        while let n = current {
            chain.append(ObjectIdentifier(n))
            if n === contentRoot { break }
            current = n.parent
        }
        return chain
    }

    func nodeIsDescendant(_ node: SCNNode, of ancestor: SCNNode) -> Bool {
        var current = node.parent
        while let c = current {
            if c === ancestor { return true }
            current = c.parent
        }
        return false
    }

    // MARK: - View Presets

    func resetEditorViewportCameraToOverview() {
        if editorViewportCamera == nil {
            rebuildEditorViewportRig()
        }
        guard let camera = editorViewportCamera else { return }
        camera.camera?.usesOrthographicProjection = false
        camera.camera?.fieldOfView = 50
        camera.camera?.zNear = 0.01
        camera.camera?.zFar = 100_000
        // Comfortable authoring overview: the starter object is visible with plenty
        // of workspace around it, but not so far away that it becomes a dot.
        camera.position = SCNVector3(7.6, 5.1, 10.2)
        camera.studioLook(at: SCNVector3(0, 0.70, 0))
        if let view = scnView {
            view.pointOfView = camera
            view.setNeedsDisplay()
        }
        updateSelectionGizmoScreenScale()
    }

    func frameAllObjects() {
        guard let view = scnView,
              let camera = view.pointOfView else {
            return
        }

        var points: [SCNVector3] = []

        contentRoot.enumerateChildNodes { node, _ in
            if node.geometry != nil && !node.isHidden {
                points.append(node.presentation.worldPosition)
            }
        }

        guard !points.isEmpty else { return }

        var minV = points[0]
        var maxV = points[0]

        for p in points.dropFirst() {
            minV.x = min(minV.x, p.x)
            minV.y = min(minV.y, p.y)
            minV.z = min(minV.z, p.z)
            maxV.x = max(maxV.x, p.x)
            maxV.y = max(maxV.y, p.y)
            maxV.z = max(maxV.z, p.z)
        }

        let center = SCNVector3(
            (minV.x + maxV.x) * 0.5,
            (minV.y + maxV.y) * 0.5,
            (minV.z + maxV.z) * 0.5
        )

        let extent = max(
            maxV.x - minV.x,
            max(maxV.y - minV.y, maxV.z - minV.z)
        )

        let distance = max(3, extent * 2.2)

        camera.position = SCNVector3(
            center.x + distance * 0.45,
            center.y + distance * 0.35,
            center.z + distance
        )

        camera.camera?.usesOrthographicProjection = false
        camera.studioLook(at: center)
        updateSelectionGizmoScreenScale()
        statusText = "Frame All"
    }

    func setCameraViewPreset(_ preset: CameraViewPreset) {
        guard let view = scnView,
              let camera = view.pointOfView else {
            return
        }

        let target = viewportPivot()
        let current = camera.presentation.worldPosition

        let dx = current.x - target.x
        let dy = current.y - target.y
        let dz = current.z - target.z

        let distance = max(
            0.5,
            sqrtf(
                dx * dx +
                dy * dy +
                dz * dz
            )
        )

        camera.camera?.usesOrthographicProjection =
            preset != .perspective

        if preset != .perspective {
            camera.camera?.orthographicScale =
                Double(max(1, distance * 0.65))
        }

        switch preset {
        case .perspective:
            camera.position = SCNVector3(
                target.x + distance * 0.55,
                target.y + distance * 0.35,
                target.z + distance
            )

        case .front:
            camera.position = SCNVector3(
                target.x,
                target.y,
                target.z + distance
            )

        case .back:
            camera.position = SCNVector3(
                target.x,
                target.y,
                target.z - distance
            )

        case .left:
            camera.position = SCNVector3(
                target.x - distance,
                target.y,
                target.z
            )

        case .right:
            camera.position = SCNVector3(
                target.x + distance,
                target.y,
                target.z
            )

        case .top:
            camera.position = SCNVector3(
                target.x,
                target.y + distance,
                target.z
            )

        case .bottom:
            camera.position = SCNVector3(
                target.x,
                target.y - distance,
                target.z
            )
        }

        camera.studioLook(at: target)
        updateSelectionGizmoScreenScale()
        statusText = "View • \(preset.title)"
    }
}


