import Foundation
import UIKit
import SceneKit
import CoreText
import SwiftUI

@MainActor
enum WorkshopFonts {
    static let files = ["NotoSansArabic[wdth,wght]", "NotoNaskhArabic[wght]", "Lato-Regular", "Lato-Bold", "SpaceMono-Regular", "BebasNeue-Regular"]
    static let names = ["NotoSansArabic-Regular", "NotoNaskhArabic-Regular", "Lato-Regular", "Lato-Bold", "SpaceMono-Regular", "BebasNeue-Regular"]
    private static var registered = false
    static func register() {
        guard !registered else {return}; registered=true
        for file in files {
            for url in StudioResourceFiles.candidates(name:file,fileExtension:"ttf") where FileManager.default.fileExists(atPath:url.path) {
                var error: Unmanaged<CFError>?
                CTFontManagerRegisterFontsForURL(url as CFURL,.process,&error)
                break
            }
        }
    }
}

enum WorkshopMaterial: String,CaseIterable,Identifiable {
    case oak,walnut,marbleWhite,marbleBlack,brickRed,brickGray,tileWhite,tileBlue,denim,canvas,brushedSteel,copper,bronze,concrete,granite,terrazzo,carbon,checker,paintRed,paintBlue,clay,sand,grass,leather,fiberglass
    var id:String {rawValue}
    var category:String {
        switch self {
        case .oak,.walnut:return "wood"
        case .marbleWhite,.marbleBlack,.concrete,.granite,.terrazzo,.clay,.sand:return "stone"
        case .brickRed,.brickGray,.tileWhite,.tileBlue:return "building"
        case .denim,.canvas,.leather:return "fabric"
        case .fiberglass:return "composite"
        case .brushedSteel,.copper,.bronze,.carbon:return "metal"
        default:return "design"
        }
    }
    func title(_ arabic:Bool) -> String {
        let en=["Oak","Walnut","White marble","Black marble","Red brick","Gray brick","White tiles","Blue tiles","Denim","Canvas","Brushed steel","Copper","Bronze","Concrete","Granite","Terrazzo","Carbon weave","UV checker","Red paint","Blue paint","Clay","Sand","Grass","Leather","Fiberglass"]
        let ar=["بلوط","جوز","رخام أبيض","رخام أسود","طوب أحمر","طوب رمادي","بلاط أبيض","بلاط أزرق","جينز","قماش","فولاذ مصقول","نحاس","برونز","خرسانة","جرانيت","تيرازو","نسيج كربون","فحص UV","طلاء أحمر","طلاء أزرق","طين","رمل","عشب","جلد","فايبر جلاس"]
        let i=Self.allCases.firstIndex(of:self)!;return arabic ? ar[i] : en[i]
    }
    var base:SIMD3<Double> {
        switch self {
        case .oak:return .init(0.65,0.39,0.15)
        case .walnut:return .init(0.28,0.13,0.06)
        case .marbleWhite:return .init(0.93,0.93,0.9)
        case .marbleBlack:return .init(0.08,0.08,0.1)
        case .brickRed:return .init(0.63,0.21,0.12)
        case .brickGray:return .init(0.4,0.4,0.39)
        case .tileWhite:return .init(0.92,0.9,0.85)
        case .tileBlue:return .init(0.08,0.35,0.68)
        case .denim:return .init(0.09,0.23,0.44)
        case .canvas:return .init(0.8,0.75,0.6)
        case .brushedSteel:return .init(0.62,0.64,0.66)
        case .copper:return .init(0.8,0.4,0.2)
        case .bronze:return .init(0.63,0.43,0.18)
        case .concrete:return .init(0.53,0.52,0.5)
        case .granite:return .init(0.37,0.38,0.4)
        case .terrazzo:return .init(0.83,0.79,0.72)
        case .carbon:return .init(0.055,0.065,0.08)
        case .checker:return .init(0.9,0.9,0.9)
        case .paintRed:return .init(0.72,0.04,0.06)
        case .paintBlue:return .init(0.03,0.25,0.72)
        case .clay:return .init(0.67,0.33,0.2)
        case .sand:return .init(0.81,0.69,0.43)
        case .grass:return .init(0.15,0.38,0.07)
        case .leather:return .init(0.25,0.11,0.055)
        case .fiberglass:return .init(0.83,0.86,0.80)
        }
    }
    var metalness:Double { category=="metal" ? (self == .carbon ? 0.4 : 1) : ((self == .paintRed || self == .paintBlue) ? 0.25 : 0) }
    var roughness:Double {
        switch self {
        case .marbleWhite,.marbleBlack,.tileBlue,.tileWhite:return 0.22
        case .copper,.bronze,.paintBlue,.paintRed:return 0.25
        case .fiberglass:return 0.28
        case .brushedSteel,.carbon,.leather:return 0.42
        default:return 0.86
        }
    }
    // Periodic fields make the generated maps tile without a visible border.
    func field(_ u:Double,_ v:Double) -> Double {
        let x=u*2 * Double.pi,y=v*2 * Double.pi
        let noise=(sin(x*17+y*13)+sin(x*31-y*19)+cos(x*53+y*47))/6+0.5
        switch self {
        case .oak,.walnut:return 0.5+0.3*sin(x*9+sin(y*3)*1.5)+0.12*sin(x*39+y*2)
        case .marbleWhite,.marbleBlack:return pow(abs(sin(x*3+y*2+sin(x*2+y)*2)),14)
        case .brickRed,.brickGray:
            let row=Int(floor(v*8)),a=(u*4+Double(row%2)*0.5).truncatingRemainder(dividingBy:1),b=(v*8).truncatingRemainder(dividingBy:1)
            return a<0.035 || b<0.07 ? 0 : 0.6+noise*0.25
        case .tileWhite,.tileBlue:
            let a=(u*4).truncatingRemainder(dividingBy:1),b=(v*4).truncatingRemainder(dividingBy:1)
            return a<0.04 || b<0.04 ? 0 : 0.85
        case .denim,.canvas,.carbon:return 0.5+0.23*sin(x*32)*cos(y*32)+0.1*sin(x*64+y*64)
        case .fiberglass:
            // Glass fiber bundles under resin: a subtle periodic over/under weave.
            let warp=0.5+0.5*cos(x*16),weft=0.5+0.5*cos(y*16)
            let over=0.5+0.5*sin(x*8)*sin(y*8)
            return 0.52+0.16*(over*warp+(1-over)*weft)+0.035*cos(x*64+y*64)
        case .brushedSteel:return 0.5+0.25*sin(x*73)+0.15*sin(x*109+y*2)
        case .checker:return (Int(floor(u*8))+Int(floor(v*8)))%2==0 ? 0.95 : 0.1
        case .terrazzo:return noise>0.65 ? 0.1 : (noise<0.3 ? 0.95 : 0.6)
        default:return noise
        }
    }
}

@MainActor
enum WorkshopTextures {
    static var thumbnails:[WorkshopMaterial:UIImage]=[:]
    static func image(_ preset:WorkshopMaterial,size:Int=256,normal:Bool=false) -> UIImage {
        var pixels=[UInt8](repeating:255,count:size*size*4)
        for y in 0..<size { for x in 0..<size {
            let u=Double(x)/Double(size-1),v=Double(y)/Double(size-1),f=preset.field(u,v)
            var color=preset.base*(0.65+f*0.55)
            if [.brickRed,.brickGray,.tileWhite,.tileBlue].contains(preset),f<0.01 {color = .init(0.57,0.55,0.51)}
            if preset == .marbleWhite {color=preset.base*(1-f*0.78)}
            if preset == .marbleBlack {color=preset.base+SIMD3(repeating:f*0.65)}
            if preset == .checker {color=SIMD3(repeating:f)}
            if normal {
                let delta=1/Double(size),du=(preset.field(u+delta,v)-preset.field(u-delta,v))*0.25,dv=(preset.field(u,v+delta)-preset.field(u,v-delta))*0.25
                let n=WorkshopMesh.unit(.init(-du,-dv,1));color=(n+SIMD3(repeating:1))/2
            }
            let offset=(y*size+x)*4
            for channel in 0..<3 {pixels[offset+channel]=UInt8(max(0,min(255,(color[channel]*255).rounded())))}
        } }
        let data=Data(pixels),provider=CGDataProvider(data:data as CFData)!
        let cg=CGImage(width:size,height:size,bitsPerComponent:8,bitsPerPixel:32,bytesPerRow:size*4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGBitmapInfo(rawValue:CGImageAlphaInfo.last.rawValue),provider:provider,decode:nil,shouldInterpolate:true,intent:.defaultIntent)!
        return UIImage(cgImage:cg)
    }
    static func thumbnail(_ preset:WorkshopMaterial) -> UIImage {
        if let image=thumbnails[preset] {return image}
        let image=image(preset,size:64);thumbnails[preset]=image;return image
    }
    static func material(_ preset:WorkshopMaterial,tiling:Double) -> SCNMaterial {
        let m=SCNMaterial();m.name="Workshop • \(preset.rawValue)";m.lightingModel = .physicallyBased
        m.diffuse.contents=image(preset);m.normal.contents=image(preset,normal:true)
        m.normal.intensity=preset == .fiberglass ? 0.16 : 0.35;m.roughness.contents=preset.roughness;m.metalness.contents=preset.metalness
        m.diffuse.wrapS = .repeat;m.diffuse.wrapT = .repeat;m.normal.wrapS = .repeat;m.normal.wrapT = .repeat
        let scale=Float(max(0.1,min(32,tiling)));let transform=SCNMatrix4MakeScale(scale,scale,1)
        m.diffuse.contentsTransform=transform;m.normal.contentsTransform=transform
        return m
    }
}

@MainActor
extension StudioStore {
    func applyWorkshopMaterial(_ preset:WorkshopMaterial,tiling:Double=1,recordUndo:Bool=true) {
        guard !workshopIsRunning,!isExporting,!importIsRunning,tiling.isFinite,let selectedNode,!isNodeLocked(selectedNode) else {return}
        let nodes=editableDescendants(of:selectedNode).filter {$0.geometry != nil}
        guard !nodes.isEmpty else {toast=appLanguage == .arabic ? "حدد مجسمًا" : "Select a mesh";return}
        let material=WorkshopTextures.material(preset,tiling:tiling)
        let beforeMaterials=captureMaterialHistory(nodes.flatMap {$0.geometry?.materials ?? []})
        if recordUndo {pushUndoSnapshot("Material \(preset.rawValue)")}
        for node in nodes {
            guard let geometry=node.geometry,let copy=geometry.copy() as? SCNGeometry else {continue}
            copy.materials=(0..<max(1,geometry.materials.count)).map {_ in ProjectSceneCodec.copyMaterialPreservingProperties(material)};node.geometry=copy
            if let skinner=node.skinner {skinner.baseGeometry=copy}
        }
        reconcileStaticMaterialKeys(beforeMaterials, requireMultipleFrames: false)
        applyViewportSettings(updateMaterials: true, updateProjectLights: false)
        objectWillChange.send();toast=preset.title(appLanguage == .arabic)
    }
    enum WorkshopLook:String,CaseIterable,Identifiable {
        case studio,cinematic,clay,night,daylight,neon
        var id:String {rawValue}
        func title(_ arabic:Bool) -> String {
            switch self {
            case .studio:return arabic ? "استوديو منتج" : "Product studio"
            case .cinematic:return arabic ? "سينمائي دافئ" : "Warm cinematic"
            case .clay:return arabic ? "عرض طيني" : "Clay presentation"
            case .night:return arabic ? "ليل بارد" : "Cool night"
            case .daylight:return arabic ? "ضوء نهاري" : "Daylight"
            case .neon:return arabic ? "ألوان نيون" : "Neon lights"
            }
        }
    }
    func applyWorkshopLook(_ look:WorkshopLook) {
        guard !workshopIsRunning,!isExporting,!importIsRunning else {return}
        pushUndoSnapshot("Look \(look.rawValue)")
        lightsRoot.childNodes.filter { $0.name?.hasPrefix("Workshop Rig •")==true }.forEach {$0.removeFromParentNode()}
        let root=SCNNode();root.name="Workshop Rig • \(look.rawValue)";lightsRoot.addChildNode(root)
        let colors:[UIColor]
        switch look {
        case .neon:colors=[.systemPink,.systemBlue,.systemPurple];environmentPreset = .night
        case .cinematic:colors=[.init(red:1,green:0.72,blue:0.4,alpha:1),.init(red:0.4,green:0.65,blue:1,alpha:1),.white];environmentPreset = .sunset
        case .night:colors=[.init(red:0.4,green:0.6,blue:1,alpha:1),.init(red:0.15,green:0.25,blue:0.6,alpha:1),.white];environmentPreset = .night
        default:colors=[.white,.white,.white];environmentPreset = look == .daylight ? .day : .overcast
        }
        for i in 0..<3 {
            let node=SCNNode();node.name=["Key","Fill","Rim"][i];node.light=SCNLight();node.light!.type = .omni
            node.light!.color=colors[i];node.light!.intensity=CGFloat([850,300,600][i]);node.light!.castsShadow=i==0
            node.position=[SCNVector3(-4,5,4),SCNVector3(4,2,3),SCNVector3(0,4,-4)][i];root.addChildNode(node)
        }
        environmentIntensity=0.4;applySceneEnvironment()
        renderFilterPreset=look == .cinematic ? .cinematic : .none;renderFilterIntensity=0.65
        if look == .clay { applyWorkshopMaterial(.clay,recordUndo:false) }
        objectWillChange.send();toast=look.title(appLanguage == .arabic)
    }
}
