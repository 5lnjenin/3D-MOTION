import SceneKit

/// Rendering keeps the same camera and lighting as the viewport. Only editing
/// overlays are hidden; hiding their parent also hid the viewport light rig.
@MainActor
struct RenderPresentationState {
    private let editor: SCNNode
    private let helpers: SCNNode
    private let outline: SCNNode?
    private let editorHidden: Bool
    private let helpersHidden: Bool
    private let outlineHidden: Bool?
    private let children: [(SCNNode, Bool)]

    init(store: StudioStore) {
        editor = store.editorRoot
        helpers = store.helpersRoot
        outline = store.selectionOutline
        editorHidden = editor.isHidden
        helpersHidden = helpers.isHidden
        outlineHidden = outline?.isHidden
        children = editor.childNodes.map { ($0, $0.isHidden) }
        for child in editor.childNodes where child.camera == nil && child.light == nil {
            child.isHidden = true
        }
        helpers.isHidden = true
        outline?.isHidden = true
    }

    func restore() {
        for (node, hidden) in children { node.isHidden = hidden }
        editor.isHidden = editorHidden
        helpers.isHidden = helpersHidden
        if let outlineHidden { outline?.isHidden = outlineHidden }
    }
}
